# Unsloth Zoo - Utilities for Unsloth
# Copyright 2023-present Daniel Han-Chen, Michael Han-Chen & the Unsloth team. All rights reserved.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import re
from typing import Union, List, Optional, Tuple
import inspect
import torch
import torch.nn as nn
import os
import math
from importlib.metadata import version as importlib_version
from unsloth_zoo.utils import Version
from .common import TEMPORARY_PATCHES, UNSLOTH_ENABLE_LOGGING, logger
from .utils import patch_function, raise_error

transformers_version = Version(importlib_version("transformers"))

# UNSLOTH_MXFP4_NO_DEQUANTIZE=1 keeps MXFP4 quantized (needs triton_kernels);
# otherwise weights dequantize to bf16 for LoRA training.
UNSLOTH_MXFP4_NO_DEQUANTIZE = os.environ.get("UNSLOTH_MXFP4_NO_DEQUANTIZE", "0") == "1"


def _check_triton_kernels_available():
    """Check if OpenAI's triton_kernels package is available for MXFP4."""
    try:
        from triton_kernels import matmul_ogs, swiglu
        return True
    except ImportError:
        return False


_TRITON_KERNELS_AVAILABLE = None
def is_triton_kernels_available():
    """Cached check for triton_kernels availability."""
    global _TRITON_KERNELS_AVAILABLE
    if _TRITON_KERNELS_AVAILABLE is None:
        _TRITON_KERNELS_AVAILABLE = _check_triton_kernels_available()
    return _TRITON_KERNELS_AVAILABLE


def should_dequantize_mxfp4():
    """Whether MXFP4 should be dequantized to bf16 for training.

    True unless UNSLOTH_MXFP4_NO_DEQUANTIZE="1" and triton_kernels is available.
    """
    if not UNSLOTH_MXFP4_NO_DEQUANTIZE:
        return True  # Default: dequantize for compatibility

    if not is_triton_kernels_available():
        if UNSLOTH_ENABLE_LOGGING:
            logger.warning(
                "Unsloth: UNSLOTH_MXFP4_NO_DEQUANTIZE=1 but triton_kernels not available. "
                "Will dequantize MXFP4 to bf16."
            )
        return True  # triton_kernels required for native MXFP4

    return False  # Keep MXFP4 quantized


def get_mxfp4_config_for_training():
    """Return the Mxfp4Config for training (dequantize=True unless
    UNSLOTH_MXFP4_NO_DEQUANTIZE=1 and triton_kernels is available).

    Usage:
        model = AutoModelForCausalLM.from_pretrained(
            "unsloth/gpt-oss-20b",
            quantization_config=get_mxfp4_config_for_training(),
        )
    """
    try:
        from transformers import Mxfp4Config
    except ImportError:
        raise ImportError("transformers.Mxfp4Config not available. Please upgrade transformers.")

    dequantize = should_dequantize_mxfp4()

    if UNSLOTH_ENABLE_LOGGING:
        if dequantize:
            logger.info("Unsloth: MXFP4 will be dequantized to bf16 for training")
        else:
            logger.info("Unsloth: MXFP4 weights will remain quantized (triton_kernels available)")

    return Mxfp4Config(dequantize=dequantize)

def patch_convert_moe_packed_tensors():
    """Pin the GPU convert_moe_packed_tensors with a smaller default chunk."""
    try:
        import transformers.integrations.mxfp4
        from transformers.integrations.mxfp4 import FP4_VALUES
    except Exception as e:
        return raise_error("transformers.integrations.mxfp4", e)

    def convert_moe_packed_tensors(
        blocks,
        scales,
        *,
        dtype: torch.dtype = torch.bfloat16,
        rows_per_chunk: int = 32768 * 1024,
    ) -> torch.Tensor:
        """Dequantize mxfp4 weights into GPT_OSS-compatible form (GPU path)."""
        # Move CPU tensors to GPU if available.
        if not blocks.is_cuda and torch.cuda.is_available():
            blocks = blocks.cuda()
            scales = scales.cuda()

        scales = scales.to(torch.int32) - 127

        assert blocks.shape[:-1] == scales.shape, f"{blocks.shape=} does not match {scales.shape=}"

        lut = torch.tensor(FP4_VALUES, dtype=dtype, device=blocks.device)

        *prefix_shape, G, B = blocks.shape
        rows_total = math.prod(prefix_shape) * G

        blocks = blocks.reshape(rows_total, B)
        scales = scales.reshape(rows_total, 1)

        out = torch.empty(rows_total, B * 2, dtype=dtype, device=blocks.device)

        for r0 in range(0, rows_total, rows_per_chunk):
            r1 = min(r0 + rows_per_chunk, rows_total)

            blk = blocks[r0:r1]
            exp = scales[r0:r1]

            # nibble indices -> int64
            idx_lo = (blk & 0x0F).to(torch.long)
            idx_hi = (blk >> 4).to(torch.long)

            sub = out[r0:r1]
            sub[:, 0::2] = lut[idx_lo]
            sub[:, 1::2] = lut[idx_hi]

            torch.ldexp(sub, exp, out=sub)
            del idx_lo, idx_hi, blk, exp, sub

        out = out.reshape(*prefix_shape, G, B * 2).view(*prefix_shape, G * B * 2)
        del blocks, scales, lut
        return out
    patch_function(transformers.integrations.mxfp4, "convert_moe_packed_tensors", convert_moe_packed_tensors)

    """
    Transformers 4.55.4 did dequantized.transpose(1, 2).contiguous().to(target_device)
    but new versions > 4.56.0 removed the transpose(1, 2) and moved it into patch_convert_moe_packed_tensors
    """
    # convert_moe_packed_tensors above returns the UN-transposed [E, D, G*B*2] layout
    # on purpose (saving_utils._mxfp4_base_returns_transposed keys the export path off
    # that convention), so the live loader hook must restore GPT-OSS's [E, G*B*2, D].
    # Which hook is live:
    #   4.x             -> module level mxfp4.dequantize, called by quantizer_mxfp4
    #   5.0.0 and newer -> Mxfp4Dequantize (a ConversionOps) -> dequantize_convertops
    # mxfp4.dequantize survives unreferenced from 5.0.0 until 5.16.0 (upstream PR
    # #47579, the DTensor TP rewrite) deletes it, so patching only dequantize dropped
    # the transpose from 5.0.0 on and loaded GPT-OSS with dims 1 and 2 silently
    # swapped.
    #
    # 5.0.0 alone declares dequantize_convertops(blocks, scales, target_device); every
    # release from 5.1.0 on declares (blocks, scales). A 2-arg replacement against the
    # 3-arg original is refused by can_safely_patch ("Parameter count mismatch: 3 vs
    # 2"), which left 5.0.0 with the un-transposed convert_moe_packed_tensors above and
    # nothing restoring the transpose. So pick the arm that matches what is actually
    # installed.
    #
    # Dispatch on the observed parameter names rather than on transformers_version:
    # arity is the exact property can_safely_patch enforces, so reading it directly
    # cannot disagree with it, whereas a version gate is a proxy that a backport or a
    # fork can falsify. An unrecognised signature falls through to the 2-arg arm and is
    # rejected loudly by can_safely_patch, which is the correct failure mode.
    _convertops = getattr(transformers.integrations.mxfp4, "dequantize_convertops", None)
    if _convertops is not None:
        # 5.x path, called only by Mxfp4Dequantize.convert. Both arms close over the
        # local un-transposed convert_moe_packed_tensors rather than re-reading the
        # module attribute, so the transpose stays correct even if patch_function above
        # did not take and upstream's self-transposing version is still installed.
        try:
            _convertops_params = tuple(inspect.signature(_convertops).parameters)
        except (TypeError, ValueError):
            _convertops_params = ()

        if _convertops_params == ("blocks", "scales", "target_device"):
            # 5.0.0. Mirrors upstream's own body (empty_cache before the move, and the
            # result placed on target_device) with the transpose added back.
            def dequantize_convertops(blocks, scales, target_device):
                dequantized = convert_moe_packed_tensors(blocks, scales)
                dequantized = dequantized.transpose(1, 2).contiguous()
                if target_device == "cpu" and torch.cuda.is_available():
                    torch.cuda.empty_cache()
                return torch.nn.Parameter(dequantized.to(target_device))
        else:
            # 5.1.0 and newer. Upstream leaves placement to its caller here.
            def dequantize_convertops(blocks, scales):
                dequantized = convert_moe_packed_tensors(blocks, scales)
                return torch.nn.Parameter(dequantized.transpose(1, 2).contiguous())
        patch_function(transformers.integrations.mxfp4, "dequantize_convertops", dequantize_convertops)

    if transformers_version < Version("5.0.0"):
        # 4.x path. shard_and_distribute_module is imported inside the gate because on
        # 5.16.0+ it still imports fine but is a tombstone that raises when called.
        try:
            import transformers.integrations.mxfp4
            from transformers.integrations.tensor_parallel import shard_and_distribute_module
        except Exception as e:
            return raise_error("transformers.integrations.mxfp4.dequantize", e)

        def dequantize(module, param_name, param_value, target_device, dq_param_name, **kwargs):
            model = kwargs.get("model", None)
            empty_param = kwargs.get("empty_param", None)
            casting_dtype = kwargs.get("casting_dtype", None)
            to_contiguous = kwargs.get("to_contiguous", None)
            rank = kwargs.get("rank", None)
            device_mesh = kwargs.get("device_mesh", None)

            for proj in ["gate_up_proj", "down_proj"]:
                if proj in param_name:
                    if device_mesh is not None:
                        # 8 positionals, no set_param: that kwarg was removed in 4.57.0
                        # (and is absent from 5.x), so passing it TypeErrors there.
                        param_value = shard_and_distribute_module(
                            model,
                            param_value,
                            empty_param,
                            dq_param_name,
                            casting_dtype,
                            to_contiguous,
                            rank,
                            device_mesh,
                        )
                    blocks_attr = f"{proj}_blocks"
                    scales_attr = f"{proj}_scales"
                    setattr(module, param_name.rsplit(".", 1)[1], param_value)
                    if hasattr(module, blocks_attr) and hasattr(module, scales_attr):
                        dequantized = convert_moe_packed_tensors(getattr(module, blocks_attr), getattr(module, scales_attr))
                        # [HERE] we must do transpose(1, 2)
                        dequantized = dequantized.transpose(1, 2).contiguous().to(target_device)
                        # TODO: this is perhaps necessary since if target_device is cpu, and the param was on gpu
                        if target_device == "cpu" and torch.cuda.is_available():
                            torch.cuda.empty_cache()
                        setattr(module, proj, torch.nn.Parameter(dequantized))
                        delattr(module, blocks_attr)
                        delattr(module, scales_attr)
        patch_function(transformers.integrations.mxfp4, "dequantize", dequantize)

    """
    Add a new CPU-optimized version of convert_moe_packed_tensors with smaller default chunk size.
    """
    try:
        import transformers.integrations.mxfp4
        from transformers.integrations.mxfp4 import FP4_VALUES
    except Exception as e:
        return raise_error("transformers.integrations.mxfp4_CPU", e)

    def convert_moe_packed_tensors_cpu(
        blocks,
        scales,
        *,
        dtype: torch.dtype = torch.bfloat16,
        rows_per_chunk: int = 1024 * 1024,  # CPU-optimized default (~2.6GB temp memory)
    ) -> torch.Tensor:
        """Dequantize mxfp4 weights into GPT_OSS-compatible form (CPU path,
        smaller default chunk).

        rows_per_chunk default 1M rows; per-chunk memory at B=128: 8192 ~22 MB,
        1M ~2.6 GB, 32M ~90 GB.
        """
        # Force tensors onto CPU.
        if blocks.is_cuda:
            blocks = blocks.cpu()
        if scales.is_cuda:
            scales = scales.cpu()

        scales = scales.to(torch.int32) - 127

        assert blocks.shape[:-1] == scales.shape, f"{blocks.shape[:-1]=} does not match {scales.shape=}"

        lut = torch.tensor(FP4_VALUES, dtype=dtype, device='cpu')

        *prefix_shape, G, B = blocks.shape
        rows_total = math.prod(prefix_shape) * G

        blocks = blocks.reshape(rows_total, B)
        scales = scales.reshape(rows_total, 1)

        out = torch.empty(rows_total, B * 2, dtype=dtype, device='cpu')

        for r0 in range(0, rows_total, rows_per_chunk):
            r1 = min(r0 + rows_per_chunk, rows_total)

            blk = blocks[r0:r1]
            exp = scales[r0:r1]

            # nibble indices -> int64
            idx_lo = (blk & 0x0F).to(torch.long)
            idx_hi = (blk >> 4).to(torch.long)

            sub = out[r0:r1]
            sub[:, 0::2] = lut[idx_lo]
            sub[:, 1::2] = lut[idx_hi]

            torch.ldexp(sub, exp, out=sub)
            del idx_lo, idx_hi, blk, exp, sub

        out = out.reshape(*prefix_shape, G, B * 2).view(*prefix_shape, G * B * 2)
        del blocks, scales, lut
        return out

    if hasattr(transformers.integrations.mxfp4, 'convert_moe_packed_tensors'):
        transformers.integrations.mxfp4.convert_moe_packed_tensors_cpu = convert_moe_packed_tensors_cpu
        if UNSLOTH_ENABLE_LOGGING:
            logger.info("Unsloth: Successfully added convert_moe_packed_tensors_cpu function.")
    else:
        if UNSLOTH_ENABLE_LOGGING:
            logger.info("Unsloth: Failed to add convert_moe_packed_tensors_cpu - original function not found.")
pass
TEMPORARY_PATCHES.append(patch_convert_moe_packed_tensors)
