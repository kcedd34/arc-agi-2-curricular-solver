# Unsloth Zoo - Utilities for Unsloth
# Copyright 2023-present Daniel Han-Chen, Michael Han-Chen & the Unsloth team. All rights reserved.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import os
import torch
import torch.nn as nn
from .common import TEMPORARY_PATCHES, UNSLOTH_ENABLE_LOGGING
from .utils import patch_function, process_return, raise_error, logger
from .moe_utils import (
    patch_param_wrapper_for_moe,
    get_forward_moe_backend,
    extract_moe_lora_weights_for_grouped_mm,
)
# Reuse the Qwen-MoE standard-layout LoRA extractor: Gemma4TextExperts shares
# the (E, out, in) layout and attribute names, and per_expert_scale is folded
# into top_k_weights upstream by Gemma4TextRouter.forward, so no Gemma-4
# specific scale handling is needed inside the extractor.
from .qwen3_moe import _make_qwen_moe_lora_extractor


def _register_gemma4_lora_extractor(experts_cls):
    """Attach _unsloth_lora_extractor_fn to a Gemma-4 experts class.

    Idempotent and safe if experts_cls is None. Without it,
    _extract_lora_from_wrapper falls through to the default canonical-permutation
    branch, which on PEFT 0.19+ swapped layouts yields mismatched contraction
    dims for torch._grouped_mm (RuntimeError: contraction dimension of mat_a
    and mat_b must match) on the first step. The Qwen extractor handles both
    PEFT 0.18 and 0.19 cleanly.
    """
    if experts_cls is None:
        return False
    if getattr(experts_cls, "_unsloth_lora_extractor_registered", False):
        return True
    try:
        extractor = _make_qwen_moe_lora_extractor()
        experts_cls._unsloth_lora_extractor_fn = staticmethod(extractor)
        experts_cls._unsloth_model_type = "gemma4_moe"
        experts_cls._unsloth_lora_extractor_registered = True
        return True
    except Exception as e:
        if UNSLOTH_ENABLE_LOGGING:
            logger.warning(
                f"Unsloth: Could not register Gemma-4 MoE LoRA extractor on "
                f"{getattr(experts_cls, '__name__', experts_cls)}: {e}"
            )
        return False


def _gemma4_moe_lora_extractor(wrapper, weight_A, weight_B, scaling, num_experts):
    return extract_moe_lora_weights_for_grouped_mm(
        wrapper,
        weight_A,
        weight_B,
        scaling,
        num_experts,
        model_name="Gemma4 MoE",
        enable_logging=UNSLOTH_ENABLE_LOGGING,
        logger_obj=logger,
    )


def patch_gemma4_grpo_hidden_states():
    """Patch Gemma4ForConditionalGeneration.forward for GRPO hidden states.

    Independent of MoE layout changes so a MoE-patching failure (e.g. renamed
    expert classes) doesn't silently disable the GRPO memory optimization.
    """
    try:
        from transformers.models.gemma4.modeling_gemma4 import (
            Gemma4ForConditionalGeneration,
            Gemma4CausalLMOutputWithPast,
        )
    except Exception as e:
        return raise_error(
            "transformers.models.gemma4.modeling_gemma4.Gemma4ForConditionalGeneration", e,
        )

    if getattr(Gemma4ForConditionalGeneration, "_unsloth_grpo_hidden_states_patched", False):
        return

    _original_causal_lm_forward = Gemma4ForConditionalGeneration.forward

    def _patched_causal_lm_forward(
        self,
        input_ids=None,
        pixel_values=None,
        pixel_values_videos=None,
        input_features=None,
        attention_mask=None,
        input_features_mask=None,
        position_ids=None,
        image_position_ids=None,
        video_position_ids=None,
        past_key_values=None,
        mm_token_type_ids=None,
        inputs_embeds=None,
        labels=None,
        use_cache=None,
        logits_to_keep=0,
        **kwargs,
    ):
        # Inject mm_token_type_ids=0 for text-only SFT.
        if mm_token_type_ids is None and self.training:
            _ids = input_ids if input_ids is not None else inputs_embeds
            if _ids is not None:
                mm_token_type_ids = torch.zeros(
                    _ids.shape[:2], dtype=torch.long, device=_ids.device,
                )

        # Drop stale mm_token_type_ids during KV-cache generation.
        _seq_ref = input_ids if input_ids is not None else inputs_embeds
        if mm_token_type_ids is not None and _seq_ref is not None:
            if mm_token_type_ids.shape[1] != _seq_ref.shape[1]:
                mm_token_type_ids = None

        return_hidden_states = os.environ.get("UNSLOTH_RETURN_HIDDEN_STATES", "0") == "1"
        if not return_hidden_states:
            return _original_causal_lm_forward(
                self,
                input_ids=input_ids,
                pixel_values=pixel_values,
                pixel_values_videos=pixel_values_videos,
                input_features=input_features,
                attention_mask=attention_mask,
                input_features_mask=input_features_mask,
                position_ids=position_ids,
                image_position_ids=image_position_ids,
                video_position_ids=video_position_ids,
                past_key_values=past_key_values,
                mm_token_type_ids=mm_token_type_ids,
                inputs_embeds=inputs_embeds,
                labels=labels,
                use_cache=use_cache,
                logits_to_keep=logits_to_keep,
                **kwargs,
            )

        kwargs.pop("return_dict", None)
        outputs = self.model(
            input_ids=input_ids,
            pixel_values=pixel_values,
            pixel_values_videos=pixel_values_videos,
            input_features=input_features,
            attention_mask=attention_mask,
            input_features_mask=input_features_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            mm_token_type_ids=mm_token_type_ids,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            image_position_ids=image_position_ids,
            video_position_ids=video_position_ids,
            return_dict=True,
            **kwargs,
        )

        sliced_hidden_states = outputs.last_hidden_state
        # Only slice when a suffix is requested. logits_to_keep=0 would make
        # slice(-0, None) a no-op anyway; guarding avoids relying on -0 == 0.
        if logits_to_keep != 0:
            slice_indices = (
                slice(-logits_to_keep, None)
                if isinstance(logits_to_keep, int)
                else logits_to_keep
            )
            sliced_hidden_states = sliced_hidden_states[:, slice_indices, :]

        return process_return(
            Gemma4CausalLMOutputWithPast,
            {
                "loss": None,
                "logits": sliced_hidden_states,
                "past_key_values": outputs.past_key_values,
                "hidden_states": outputs.hidden_states,
                "attentions": outputs.attentions,
                "image_hidden_states": getattr(outputs, "image_hidden_states", None),
                "audio_hidden_states": getattr(outputs, "audio_hidden_states", None),
            },
        )

    _patched_causal_lm_forward.__qualname__ = _original_causal_lm_forward.__qualname__
    _patched_causal_lm_forward.__name__ = _original_causal_lm_forward.__name__
    _patched_causal_lm_forward.__doc__ = _original_causal_lm_forward.__doc__
    _patched_causal_lm_forward.__wrapped__ = _original_causal_lm_forward

    ok = patch_function(
        Gemma4ForConditionalGeneration, "forward", _patched_causal_lm_forward, force=True,
    )
    if ok:
        Gemma4ForConditionalGeneration._unsloth_grpo_hidden_states_patched = True
        logger.info(
            "Unsloth: Patched Gemma4ForConditionalGeneration.forward for GRPO hidden states."
        )


def _patch_gemma4_moe_current():
    """Patch the current Gemma4 Experts layout (Transformers >= 5)."""
    try:
        from transformers.models.gemma4.modeling_gemma4 import Gemma4TextExperts
    except Exception:
        return False

    if getattr(Gemma4TextExperts, "_unsloth_already_patched", False):
        # Re-register the extractor even if forward is patched, guarding
        # against an older unsloth-zoo that patched forward without it.
        _register_gemma4_lora_extractor(Gemma4TextExperts)
        return True

    _moe_backend = get_forward_moe_backend()

    def _gemma4_experts_forward(self, hidden_states, top_k_index, top_k_weights):
        # Gemma4TextRouter.forward already folds per_expert_scale into
        # top_k_weights, so dispatch straight to the grouped-GEMM backend.
        return _moe_backend(self, hidden_states, top_k_index, top_k_weights)

    ok = patch_function(Gemma4TextExperts, "forward", _gemma4_experts_forward, force=True)
    if ok:
        Gemma4TextExperts._unsloth_lora_extractor_fn = staticmethod(_gemma4_moe_lora_extractor)
        Gemma4TextExperts._unsloth_already_patched = True
        # Register the standard-layout extractor for correct grouped-mm dims.
        _register_gemma4_lora_extractor(Gemma4TextExperts)
    return ok


def _patch_gemma4_moe_legacy():
    """Patch the legacy Gemma4TextMoEBlock layout (Transformers < 5)."""
    try:
        from transformers.models.gemma4.modeling_gemma4 import (
            Gemma4TextMoEBlock,
            Gemma4TextDecoderLayer,
        )
    except Exception:
        return False

    if getattr(Gemma4TextMoEBlock, "_unsloth_already_patched", False):
        _register_gemma4_lora_extractor(Gemma4TextMoEBlock)
        return True

    # Remap decoder layer module names to match checkpoint key layout:
    #   moe.{gate_up_proj,down_proj} -> experts.{...}
    #   moe.per_expert_scale         -> router.per_expert_scale
    _original_decoder_init = Gemma4TextDecoderLayer.__init__

    def _patched_decoder_init(self, config, layer_idx):
        _original_decoder_init(self, config, layer_idx)
        if getattr(self, "enable_moe_block", False) and "moe" in self._modules:
            moe_block = self._modules.pop("moe")
            self._modules["experts"] = moe_block
            object.__setattr__(self, "moe", moe_block)

            per_expert_scale_data = moe_block.per_expert_scale.data
            del moe_block._parameters["per_expert_scale"]
            self.router.per_expert_scale = nn.Parameter(per_expert_scale_data)
            # Non-persistent buffer keeps _init_weights happy without appearing in state_dict
            moe_block.register_buffer(
                "per_expert_scale", torch.ones(config.num_experts), persistent=False,
            )
            object.__setattr__(moe_block, "_router_ref", self.router)

    if getattr(Gemma4TextDecoderLayer, "_unsloth_init_patched", False): init_ok = True
    else:
        init_ok = patch_function(Gemma4TextDecoderLayer, "__init__", _patched_decoder_init, force=True,)
        if init_ok: Gemma4TextDecoderLayer._unsloth_init_patched = True
    if not init_ok: return False

    _moe_backend = get_forward_moe_backend()

    def _gemma4_moe_forward(self, hidden_states, top_k_index, top_k_weights):
        # Fold per_expert_scale into routing weights before grouped_mm.
        router_ref = getattr(self, "_router_ref", None)
        if router_ref is not None:
            pes = router_ref.per_expert_scale
            top_k_weights = top_k_weights * pes[top_k_index].to(top_k_weights.dtype)
        return _moe_backend(self, hidden_states, top_k_index, top_k_weights)

    forward_ok = patch_function(
        Gemma4TextMoEBlock, "forward", _gemma4_moe_forward, force=True,
    )
    if not forward_ok:
        return False

    Gemma4TextMoEBlock._unsloth_lora_extractor_fn = staticmethod(_gemma4_moe_lora_extractor)
    Gemma4TextMoEBlock._unsloth_already_patched = True
    # Legacy block shares the (E, out, in) layout; use the same extractor.
    _register_gemma4_lora_extractor(Gemma4TextMoEBlock)
    return True


def patch_gemma4_moe():
    """Patch Gemma4 MoE for Split LoRA via grouped GEMM.

    Tries the current Transformers >= 5 layout (Gemma4TextExperts +
    Gemma4TextRouter) first, then falls back to the legacy Gemma4TextMoEBlock
    layout. Each path returns a boolean so a missing-class / signature mismatch
    is surfaced via logging rather than silently disabling the patch.
    """
    patch_param_wrapper_for_moe()

    # Short-circuit if Gemma4 is not available at all in this transformers.
    try:
        import transformers.models.gemma4.modeling_gemma4  # noqa: F401
    except Exception as e:
        return raise_error("transformers.models.gemma4.modeling_gemma4", e)

    patched_current = _patch_gemma4_moe_current()
    patched_legacy = False
    if not patched_current:
        patched_legacy = _patch_gemma4_moe_legacy()

    if patched_current or patched_legacy:
        layout = "current" if patched_current else "legacy"
        logger.info(
            f"Unsloth: Patched Gemma4 MoE ({layout} layout) for Split LoRA support."
        )
        return

    # Neither layout matched. warning_once is visible without
    # UNSLOTH_ENABLE_LOGGING and doesn't spam. This affects split-LoRA
    # grouped-GEMM only; the GRPO hidden-states patch is separate and may
    # still be active (checked below so the user knows the real state).
    grpo_active = False
    try:
        from transformers.models.gemma4.modeling_gemma4 import (
            Gemma4ForConditionalGeneration,
        )
        grpo_active = getattr(
            Gemma4ForConditionalGeneration,
            "_unsloth_grpo_hidden_states_patched",
            False,
        )
    except Exception:
        pass

    grpo_status = (
        " GRPO hidden-states patch is still active."
        if grpo_active
        else " GRPO hidden-states patch is not active."
    )
    logger.warning_once(
        "Unsloth: Could not patch Gemma4 MoE. Neither the current layout "
        "(Gemma4TextExperts) nor the legacy layout (Gemma4TextMoEBlock) was "
        "found in the installed transformers version. Split LoRA grouped-GEMM "
        "for Gemma4 MoE will be disabled." + grpo_status
    )


TEMPORARY_PATCHES.append(patch_gemma4_grpo_hidden_states)
TEMPORARY_PATCHES.append(patch_gemma4_moe)
