# Unsloth Zoo - Utilities for Unsloth
# Copyright 2023-present Daniel Han-Chen, Michael Han-Chen & the Unsloth team. All rights reserved.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import torch
import torch.nn as nn
import inspect
import importlib
import warnings
from collections.abc import Mapping
from typing import Any, List, Optional, Tuple, Union, Dict, Set, Callable
import functools
# Guarded because tests load this file by path rather than as
# `unsloth_zoo.temporary_patches.misc`, where a two-level relative import
# raises "attempted relative import beyond top-level package".
try:
    from unsloth_zoo.log import logger
except (ImportError, ValueError):
    import logging
    logger = logging.getLogger("unsloth_zoo.log")
from .common import TEMPORARY_PATCHES, torch_compile, _torch_compile
from .utils import (
    patch_function,
    process_output_options,
    process_return,
    KWARGS_TYPE,
    raise_error,
    ImageInput,
    PreTokenizedInput,
    TextInput,
    Cache,
    StaticCache,
    HybridCache,
    Unpack,
    _get_unique_storage_name,
)
from textwrap import dedent
import re
import os

def patch_ministral3_config_mapping():
    # Ministral-3 VL models set text_config.model_type="ministral3", which is
    # missing from CONFIG_MAPPING; the correct config is MinistralConfig.
    try:
        from transformers.models.auto.configuration_auto import CONFIG_MAPPING
        from transformers import MinistralConfig
    except Exception as e:
        return raise_error("CONFIG_MAPPING or MinistralConfig", e)

    if "ministral3" not in CONFIG_MAPPING:
        CONFIG_MAPPING.register("ministral3", MinistralConfig)
pass
TEMPORARY_PATCHES.append(patch_ministral3_config_mapping)


def patch_tokenizer_convert_added_tokens():
    # Some tokenizer_config.json files store additional_special_tokens as dicts
    # with a "content" key but no "__type": "AddedToken"; convert them to
    # AddedToken since transformers expects strings or AddedToken objects.
    try:
        from transformers.tokenization_utils_base import PreTrainedTokenizerBase, AddedToken
    except Exception as e:
        return raise_error("PreTrainedTokenizerBase", e)

    original_convert_added_tokens = PreTrainedTokenizerBase.convert_added_tokens
    if hasattr(original_convert_added_tokens, "_unsloth_patched"):
        return

    @classmethod
    def patched_convert_added_tokens(cls, obj, save=False, add_type_field=True):
        # Only convert when "content" is a string (AddedToken expects str).
        if isinstance(obj, dict) and "content" in obj and "__type" not in obj and isinstance(obj["content"], str):
            return AddedToken(**obj)
        return original_convert_added_tokens.__func__(cls, obj, save=save, add_type_field=add_type_field)

    patched_convert_added_tokens._unsloth_patched = True
    PreTrainedTokenizerBase.convert_added_tokens = patched_convert_added_tokens
pass
TEMPORARY_PATCHES.append(patch_tokenizer_convert_added_tokens)


def patch_tokenizer_extra_special_tokens():
    # why: old transformers crash on a list extra_special_tokens; v5 accepts it,
    # so only coerce on failure (coercing v5 would drop those tokens).
    try:
        from transformers.tokenization_utils_base import PreTrainedTokenizerBase
    except Exception as e:
        return raise_error("PreTrainedTokenizerBase", e)

    original_init = PreTrainedTokenizerBase.__init__
    if hasattr(original_init, "_unsloth_extra_special_tokens_patched"):
        return

    def patched_init(*args, **kwargs):
        if not isinstance(kwargs.get("extra_special_tokens"), list):
            return original_init(*args, **kwargs)
        try:
            return original_init(*args, **kwargs)
        except AttributeError as e:
            if "keys" not in str(e):
                raise
            kwargs["extra_special_tokens"] = {}
            return original_init(*args, **kwargs)

    patched_init._unsloth_extra_special_tokens_patched = True
    patched_init._unsloth_original_init = original_init
    PreTrainedTokenizerBase.__init__ = patched_init
pass
TEMPORARY_PATCHES.append(patch_tokenizer_extra_special_tokens)


def patch_merge_quantization_configs():
    # Fixes some issues with merging quantization configs
    try:
        import transformers.quantizers.auto
    except Exception as e:
        return raise_error("transformers.quantizers.auto", e)
    try:
        f = transformers.quantizers.auto.AutoHfQuantizer.merge_quantization_configs
    except Exception as e:
        return raise_error("transformers.quantizers.auto.AutoHfQuantizer.merge_quantization_configs", e)

    # Fast return if already patched
    unique_name = _get_unique_storage_name(transformers.quantizers.auto.AutoHfQuantizer, "merge_quantization_configs")
    if hasattr(transformers.quantizers.auto.AutoHfQuantizer, unique_name): return

    source = inspect.getsource(f)
    items = dir(transformers.quantizers.auto)

    # Fix as at 7th August 2025
    # ValueError: The model is quantized with Mxfp4Config but you are passing a NoneType config.
    # Please make sure to pass the same quantization config class to `from_pretrained` with different loading attributes.
    source = source.replace(
        "if quantization_config.__class__.__name__ != quantization_config_from_args.__class__.__name__:",
        "if quantization_config_from_args is not None and quantization_config.__class__.__name__ != quantization_config_from_args.__class__.__name__:",
    )

    exec("from transformers.quantizers.auto import (" + ",".join(x for x in items if x in source) + ")", globals())
    source = dedent(source)
    # Remove cls if classmethod
    is_classmethod = source.startswith("@classmethod")
    source = source[source.find("def"):]
    if is_classmethod:
        matches = re.match(r"(def[\s]{1,}[^(]{1,}\()[\s]{0,}cls[\s]{0,}\,[\s]{0,}", source)
        if matches is not None:
            found, replace = matches.group(0), matches.group(1)
            source = replace + source[len(found):]
    try:
        exec(source, globals())
    except Exception as e:
        return raise_error("", e)

    patch_function(transformers.quantizers.auto.AutoHfQuantizer, "merge_quantization_configs", merge_quantization_configs)
pass
TEMPORARY_PATCHES.append(patch_merge_quantization_configs)


def patch_CsmDepthDecoderForCausalLM_forward():
    try:
        import transformers.models.csm.modeling_csm
        from transformers.modeling_outputs import CausalLMOutputWithPast
        from transformers.loss.loss_utils import ForCausalLMLoss
    except Exception as e:
        return raise_error("CsmDepthDecoderForCausalLM.forward", e)

    target_cls = transformers.models.csm.modeling_csm.CsmDepthDecoderForCausalLM

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        backbone_last_hidden_state: Optional[torch.FloatTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Union[Cache, List[torch.FloatTensor]]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        logits_to_keep: Union[int, torch.Tensor] = 0,
        **kwargs: KWARGS_TYPE,
    ) -> Union[Tuple, CausalLMOutputWithPast]:
        kwargs = process_output_options(self, locals(), kwargs)

        if cache_position is None:
            past_seen_tokens = past_key_values.get_seq_length() if past_key_values is not None else 0
            seq_len = inputs_embeds.shape[1] if inputs_embeds is not None else input_ids.shape[1]
            device = inputs_embeds.device if inputs_embeds is not None else input_ids.device
            codebook_indices = torch.arange(seq_len, device=device) + past_seen_tokens
        else:
            codebook_indices = cache_position

        if inputs_embeds is None and input_ids is not None and backbone_last_hidden_state is not None:
            # Precompute inputs_embeds so self.model skips upstream's in-place
            # first-token replacement. Zoo's GC hook can make frozen embeddings
            # leaf tensors, so detach before CopySlices carries backbone grads.
            codebook_idxs = torch.clamp(codebook_indices - 1, min=0)
            offset = codebook_idxs * self.model.vocab_size
            inputs_embeds = self.model.embed_tokens(input_ids + offset)
            if inputs_embeds.requires_grad and inputs_embeds.is_leaf:
                # Cheap detach when backbone supplies grads; clone only when the
                # GC sentinel itself must survive.
                inputs_embeds = (
                    inputs_embeds.detach()
                    if backbone_last_hidden_state.requires_grad
                    else inputs_embeds.clone()
                )
            inputs_embeds[:, 0] = backbone_last_hidden_state.to(
                device=inputs_embeds.device,
                dtype=inputs_embeds.dtype,
            )
            input_ids = None
            backbone_last_hidden_state = None

        # decoder outputs consists of (dec_features, layer_state, dec_hidden, dec_attn)
        outputs = self.model(
            input_ids = input_ids,
            backbone_last_hidden_state = backbone_last_hidden_state,
            attention_mask = attention_mask,
            position_ids = position_ids,
            past_key_values = past_key_values,
            inputs_embeds = inputs_embeds,
            use_cache = use_cache,
            # Moved outputs to kwargs since transformers 4.54.0 deletes them
            # output_attentions = output_attentions,
            # output_hidden_states = output_hidden_states,
            cache_position = cache_position,
            **kwargs,
        )

        hidden_states = outputs[0]
        # Only compute necessary logits, and do not upcast them to float if we are not computing the loss
        if isinstance(logits_to_keep, int):
            if logits_to_keep == 0:
                # skip idx 0 logits since it's for the concatenated backbone last hidden state
                slice_indices = slice(1, None)
            else:
                slice_indices = slice(-logits_to_keep, None)
        else:
            slice_indices = logits_to_keep

        logits = self.codebooks_head(
            hidden_states[:, slice_indices, :], codebook_indices[slice_indices]
        )
        logits = logits.contiguous()

        loss = None
        if labels is not None:
            shift_labels = labels[..., 1:].contiguous()
            loss = ForCausalLMLoss(
                logits=logits, labels=None, vocab_size=self.config.vocab_size, shift_labels=shift_labels, **kwargs
            )

        return process_return(CausalLMOutputWithPast, {
            "loss" : loss,
            "logits" : logits,
            "past_key_values" : outputs.past_key_values,
            "hidden_states" : outputs.hidden_states,
            "attentions" : outputs.attentions,
        })
    pass

    # Wrap with (self, *args, **kwargs) so check_args_kwargs accepts removed
    # params, but copy the original signature onto the wrapper so
    # transformers._validate_model_kwargs (used by generate) still sees the
    # real named parameters like backbone_last_hidden_state.
    _original_forward_signature = inspect.signature(target_cls.forward)
    _full_forward = forward
    def forward(self, *args, **kwargs):
        return _full_forward(self, *args, **kwargs)
    forward.__signature__ = _original_forward_signature
    patch_function(target_cls, "forward", forward, match_level="relaxed")
pass
TEMPORARY_PATCHES.append(patch_CsmDepthDecoderForCausalLM_forward)


def patch_CsmForConditionalGeneration_forward():
    try:
        import transformers.models.csm.modeling_csm
        from transformers.models.csm.modeling_csm import CsmOutputWithPast
        from transformers.loss.loss_utils import ForCausalLMLoss
    except Exception as e:
        return raise_error("CsmForConditionalGeneration.forward", e)

    target_cls = transformers.models.csm.modeling_csm.CsmForConditionalGeneration

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        input_values: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        input_values_cutoffs: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Union[Cache, List[torch.FloatTensor]]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        logits_to_keep: Union[int, torch.Tensor] = 0,
        **kwargs: KWARGS_TYPE,
    ) -> Union[Tuple, CsmOutputWithPast]:
        kwargs = process_output_options(self, locals(), kwargs)

        if input_ids is not None and input_ids.ndim == 2:
            merged_inputs = self._merge_input_ids_with_input_values(
                input_ids, input_values, input_values_cutoffs, labels
            )
            inputs_embeds = merged_inputs["inputs_embeds"]
            labels = merged_inputs["labels"]
            input_ids = None

        backbone_outputs = self.backbone_model(
            input_ids = input_ids,
            attention_mask = attention_mask,
            position_ids = position_ids,
            past_key_values = past_key_values,
            inputs_embeds = inputs_embeds,
            use_cache = use_cache,
            # Moved outputs to kwargs since transformers 4.54.0 deletes them
            # output_attentions = output_attentions,
            # output_hidden_states = output_hidden_states,
            cache_position = cache_position,
            **kwargs,
        )

        backbone_hidden_states = backbone_outputs[0]
        # Only compute necessary logits, and do not upcast them to float if we are not computing the loss
        slice_indices = slice(-logits_to_keep, None) if isinstance(logits_to_keep, int) else logits_to_keep
        backbone_logits = self.lm_head(backbone_hidden_states[:, slice_indices, :])

        loss = None
        backbone_loss = None
        depth_decoder_loss = None
        depth_decoder_outputs = None
        if labels is not None:
            # select first codebook as labels for the backbone model
            backbone_labels = labels[:, :, 0]
            backbone_loss = self.loss_function(
                logits=backbone_logits, labels=backbone_labels, vocab_size=self.config.vocab_size, **kwargs
            )

            # Depth decoder trains on frames whose labels are not uniformly
            # ignore_index across the codebook dimension.
            train_mask = ~(labels[:, :, 1:] == -100).all(dim=-1)
            depth_decoder_input_ids = labels[train_mask][..., : self.config.num_codebooks - 1]
            # Position 0 placeholder, replaced later by backbone_last_hidden_state.
            depth_decoder_input_ids = torch.nn.functional.pad(depth_decoder_input_ids, (1, 0), value=0)

            train_idxs = train_mask.nonzero(as_tuple=True)
            backbone_last_hidden_states = backbone_hidden_states[train_idxs[0], train_idxs[1] - 1, :]
            depth_decoder_labels = labels[train_mask]

            # Pass kwargs to the depth decoder so it sees num_items_in_batch.
            depth_decoder_kwargs = kwargs.copy()
            # Backbone num_items is the 0th codebook; depth covers the remaining
            # 31 codebooks, so scale num_items_in_batch by 31.
            if 'num_items_in_batch' in depth_decoder_kwargs:
                depth_decoder_kwargs['num_items_in_batch'] = depth_decoder_kwargs['num_items_in_batch'] * 31

            depth_decoder_kwargs.pop('return_dict', None)
            # Move output_attentions/output_hidden_states (transformers 4.54 deletes them)
            depth_decoder_kwargs["output_attentions"   ] = output_attentions
            depth_decoder_kwargs["output_hidden_states"] = output_hidden_states

            depth_decoder_outputs = self.depth_decoder(
                input_ids = depth_decoder_input_ids,
                backbone_last_hidden_state = backbone_last_hidden_states,
                use_cache = use_cache,
                # output_attentions=output_attentions,
                # output_hidden_states=output_hidden_states,
                return_dict = True,
                labels = depth_decoder_labels,
                **depth_decoder_kwargs,
            )

            depth_decoder_loss = depth_decoder_outputs.loss
            loss = backbone_loss + depth_decoder_loss

        return process_return(CsmOutputWithPast, {
            "loss" : loss,
            "backbone_loss" : backbone_loss,
            "depth_decoder_loss" : depth_decoder_loss,
            "logits" : backbone_logits,
            "past_key_values" : backbone_outputs.past_key_values,
            "hidden_states" : backbone_outputs.hidden_states,
            "attentions" : backbone_outputs.attentions,
            "depth_decoder_logits" : depth_decoder_outputs.logits if depth_decoder_outputs is not None else None,
            "depth_decoder_past_key_values" : depth_decoder_outputs.past_key_values
            if depth_decoder_outputs is not None
            else None,
            "depth_decoder_hidden_states" : depth_decoder_outputs.hidden_states
            if depth_decoder_outputs is not None
            else None,
            "depth_decoder_attentions" : depth_decoder_outputs.attentions if depth_decoder_outputs is not None else None,
        })
    pass

    # Preserve the original signature so inspect.signature (used by
    # transformers._validate_model_kwargs) still sees the real named parameters.
    _original_forward_signature = inspect.signature(target_cls.forward)
    _full_forward = forward
    def forward(self, *args, **kwargs):
        return _full_forward(self, *args, **kwargs)
    forward.__signature__ = _original_forward_signature
    patch_function(target_cls, "forward", forward, match_level="relaxed")
pass
TEMPORARY_PATCHES.append(patch_CsmForConditionalGeneration_forward)


def _tie_csm_audio_embeddings(model):
    if not getattr(getattr(model, "config", None), "tie_codebooks_embeddings", True):
        return model
    try:
        audio_embeddings = model.backbone_model.embed_tokens.embed_audio_tokens
        depth_embeddings = model.depth_decoder.model.embed_tokens
        if audio_embeddings.weight.shape == depth_embeddings.weight.shape:
            # Keep CSM's configured codebook tie alive when tie_word_embeddings=False.
            audio_embeddings.weight = depth_embeddings.weight
    except Exception:
        pass
    return model
pass


def patch_CsmForConditionalGeneration_tie_weights():
    try:
        import transformers.models.csm.modeling_csm
    except Exception as e:
        return raise_error("CsmForConditionalGeneration.tie_weights", e)

    target_cls = transformers.models.csm.modeling_csm.CsmForConditionalGeneration
    storage_name = _get_unique_storage_name(target_cls, "tie_weights")
    if hasattr(target_cls, storage_name):
        original_tie_weights = getattr(target_cls, storage_name)
    else:
        original_tie_weights = target_cls.tie_weights
        setattr(target_cls, storage_name, original_tie_weights)
    pass

    def tie_weights(self, *args, **kwargs):
        output = original_tie_weights(self, *args, **kwargs)
        _tie_csm_audio_embeddings(self)
        return output
    pass
    try:
        tie_weights.__signature__ = inspect.signature(original_tie_weights)
    except Exception:
        pass
    target_cls.tie_weights = tie_weights
pass
TEMPORARY_PATCHES.append(patch_CsmForConditionalGeneration_tie_weights)


def _label_csm_audio_eos_tokens(input_ids, labels, audio_eos_token_id):
    if input_ids is None or labels is None or audio_eos_token_id is None:
        return labels
    try:
        eos_mask = input_ids == audio_eos_token_id
        previous_label_is_audio = labels[..., :-1] != -100
        if torch.is_tensor(labels):
            previous_label_is_audio = torch.nn.functional.pad(previous_label_is_audio, (1, 0), value=False)
        else:
            import numpy as np
            previous_label_is_audio = np.concatenate(
                [np.zeros_like(labels[..., :1], dtype=bool), previous_label_is_audio],
                axis=-1,
            )
        labels[eos_mask & previous_label_is_audio] = audio_eos_token_id
    except Exception:
        pass
    return labels
pass


def _get_csm_processor_audio_eos_token_id(processor):
    audio_eos_token_id = getattr(processor, "audio_eos_token_id", None)
    if audio_eos_token_id is not None:
        return audio_eos_token_id

    tokenizer = getattr(processor, "tokenizer", None)
    if tokenizer is None:
        return None

    audio_eos_token_id = getattr(tokenizer, "audio_eos_token_id", None)
    if audio_eos_token_id is not None:
        return audio_eos_token_id

    audio_eos_token = getattr(processor, "audio_eos_token", getattr(tokenizer, "audio_eos_token", "<|audio_eos|>"))
    try:
        return tokenizer.convert_tokens_to_ids(audio_eos_token)
    except Exception:
        return None
pass


def _label_csm_processor_output(processor, output):
    if not isinstance(output, Mapping) or "input_ids" not in output or "labels" not in output:
        return output
    output["labels"] = _label_csm_audio_eos_tokens(
        output.get("input_ids"),
        output.get("labels"),
        _get_csm_processor_audio_eos_token_id(processor),
    )
    return output
pass


def patch_CsmProcessor_apply_chat_template():
    try:
        import transformers.models.csm.processing_csm
    except Exception as e:
        return raise_error("CsmProcessor", e)

    target_cls = transformers.models.csm.processing_csm.CsmProcessor
    apply_storage_name = _get_unique_storage_name(target_cls, "apply_chat_template")
    if hasattr(target_cls, apply_storage_name):
        original_apply_chat_template = getattr(target_cls, apply_storage_name)
    else:
        original_apply_chat_template = target_cls.apply_chat_template
        setattr(target_cls, apply_storage_name, original_apply_chat_template)
    pass
    call_storage_name = _get_unique_storage_name(target_cls, "__call__")
    if hasattr(target_cls, call_storage_name):
        original_call = getattr(target_cls, call_storage_name)
    else:
        original_call = target_cls.__call__
        setattr(target_cls, call_storage_name, original_call)
    pass

    def apply_chat_template(self, *args, **kwargs):
        return _label_csm_processor_output(self, original_apply_chat_template(self, *args, **kwargs))
    pass

    def __call__(self, *args, **kwargs):
        return _label_csm_processor_output(self, original_call(self, *args, **kwargs))
    pass
    try:
        apply_chat_template.__signature__ = inspect.signature(original_apply_chat_template)
        __call__.__signature__ = inspect.signature(original_call)
    except Exception:
        pass
    target_cls.apply_chat_template = apply_chat_template
    target_cls.__call__ = __call__
pass
TEMPORARY_PATCHES.append(patch_CsmProcessor_apply_chat_template)


def patch_transformers_masks():
    if os.environ.get("UNSLOTH_COMPILE_DISABLE", "0") == "1":
        return
    try:
        import transformers.masking_utils as masking_utils
        import transformers.generation.utils as generation_utils
    except Exception as e:
        return raise_error("transformers.masking_utils", e)

    if hasattr(masking_utils, "__unsloth_mask_patch__"):
        return

    try:
        from torch.nn.attention.flex_attention import BlockMask
    except Exception:
        BlockMask = ()

    try:
        from torch.nn.attention.flex_attention import create_block_mask as torch_create_block_mask
    except Exception:
        torch_create_block_mask = None

    if torch_create_block_mask is not None:
        try:
            supports_compile = "_compile" in inspect.signature(torch_create_block_mask).parameters
        except Exception:
            supports_compile = True
        if not supports_compile:
            def create_block_mask_wrapper(*args, **kwargs):
                kwargs.pop("_compile", None)
                return torch_create_block_mask(*args, **kwargs)
            masking_utils.create_block_mask = create_block_mask_wrapper

    original_create_causal_mask = getattr(
        masking_utils,
        "_unsloth_original_create_causal_mask",
        masking_utils.create_causal_mask,
    )
    original_create_sliding_window_causal_mask = getattr(
        masking_utils,
        "_unsloth_original_create_sliding_window_causal_mask",
        masking_utils.create_sliding_window_causal_mask,
    )

    compiled_create_causal_mask = _torch_compile(
        original_create_causal_mask, fullgraph = False, dynamic = True
    )
    compiled_create_sliding_window_causal_mask = _torch_compile(
        original_create_sliding_window_causal_mask, fullgraph = False, dynamic = True
    )

    def wrap(f):
        def return_attention_mask(*args, **kwargs):
            input_embeds = kwargs.get("input_embeds", None)
            if input_embeds is not None and getattr(input_embeds, "requires_grad", False):
                attention_mask = kwargs.get("attention_mask", None)
                if isinstance(attention_mask, BlockMask) or (
                    isinstance(attention_mask, torch.Tensor) and attention_mask.ndim == 4
                ):
                    return attention_mask
            return f(*args, **kwargs)
        return return_attention_mask
    pass

    masking_utils._unsloth_original_create_causal_mask = original_create_causal_mask
    masking_utils._unsloth_original_create_sliding_window_causal_mask = original_create_sliding_window_causal_mask
    masking_utils.create_causal_mask = wrap(compiled_create_causal_mask)
    masking_utils.create_sliding_window_causal_mask = wrap(compiled_create_sliding_window_causal_mask)
    masking_utils.create_masks_for_generate = wrap(masking_utils.create_masks_for_generate)
    generation_utils.create_masks_for_generate = masking_utils.create_masks_for_generate
    # Multi-GPU device_map flex_attention fix: offset tensors may live on a
    # different device than inner_mask runs on. Move them inside the closure
    # rather than .item() (which graph-breaks under torch.compile tracing).
    if hasattr(masking_utils, "add_offsets_to_mask_function"):
        _original_add_offsets = getattr(
            masking_utils,
            "_unsloth_original_add_offsets_to_mask_function",
            masking_utils.add_offsets_to_mask_function,
        )
        masking_utils._unsloth_original_add_offsets_to_mask_function = _original_add_offsets
        def add_offsets_wrapper(mask_function, q_offset, kv_offset):
            _q_is_tensor = isinstance(q_offset, torch.Tensor)
            _kv_is_tensor = isinstance(kv_offset, torch.Tensor)
            def inner_mask(batch_idx, head_idx, q_idx, kv_idx):
                _q_off = q_offset.to(getattr(q_idx, "device", q_offset.device), non_blocking=True) if _q_is_tensor else q_offset
                _kv_off = kv_offset.to(getattr(kv_idx, "device", kv_offset.device), non_blocking=True) if _kv_is_tensor else kv_offset
                return mask_function(batch_idx, head_idx, q_idx + _q_off, kv_idx + _kv_off)
            return inner_mask
        masking_utils.add_offsets_to_mask_function = add_offsets_wrapper

    # Multi-GPU fix: captured mask tensors may be on a different device than
    # the flex_attention vmap indices. Cache per-device copies to avoid
    # repeated cross-device transfers.
    if hasattr(masking_utils, "padding_mask_function"):
        masking_utils._unsloth_original_padding_mask_function = getattr(
            masking_utils,
            "_unsloth_original_padding_mask_function",
            masking_utils.padding_mask_function,
        )
        def padding_mask_wrapper(padding_mask):
            _cache = {padding_mask.device: padding_mask}
            def inner_mask(batch_idx, head_idx, q_idx, kv_idx):
                device = getattr(kv_idx, "device", padding_mask.device)
                pm = _cache.get(device)
                if pm is None:
                    pm = padding_mask.to(device, non_blocking=True)
                    _cache[device] = pm
                return pm[batch_idx, kv_idx]
            return inner_mask
        masking_utils.padding_mask_function = padding_mask_wrapper

    if hasattr(masking_utils, "packed_sequence_mask_function"):
        masking_utils._unsloth_original_packed_sequence_mask_function = getattr(
            masking_utils,
            "_unsloth_original_packed_sequence_mask_function",
            masking_utils.packed_sequence_mask_function,
        )
        def packed_sequence_mask_wrapper(packed_sequence_mask):
            _cache = {packed_sequence_mask.device: packed_sequence_mask}
            def inner_mask(batch_idx, head_idx, q_idx, kv_idx):
                device = getattr(q_idx, "device", packed_sequence_mask.device)
                pm = _cache.get(device)
                if pm is None:
                    pm = packed_sequence_mask.to(device, non_blocking=True)
                    _cache[device] = pm
                return pm[batch_idx, q_idx] == pm[batch_idx, kv_idx]
            return inner_mask
        masking_utils.packed_sequence_mask_function = packed_sequence_mask_wrapper

    masking_utils.__unsloth_mask_patch__ = True
pass
TEMPORARY_PATCHES.append(patch_transformers_masks)


def patch_sdpa_bool_causal_mask():
    """Fix unslothai/unsloth#4906: inf grad_norm on Qwen3.5 at seq_len > 65536.

    Upstream bug pytorch/pytorch#162588: Cutlass SDPA returns garbage gradients
    on bool causal masks at seq_len >= 2**16 (bf16, head_dim=256, no flash-attn).
    Drop pure causal bool masks (is_causal=True); convert non-pure bool masks to
    float additive bias. Skipped below 2**16 where the bug cannot fire.
    """
    if os.environ.get("UNSLOTH_COMPILE_DISABLE", "0") == "1":
        return
    try:
        import transformers.integrations.sdpa_attention as sdpa_mod
        from transformers.modeling_utils import ALL_ATTENTION_FUNCTIONS
    except Exception as e:
        return raise_error("transformers.integrations.sdpa_attention", e)

    current = getattr(sdpa_mod, "sdpa_attention_forward", None)
    if current is None:
        return
    if getattr(current, "__unsloth_bool_causal_mask_fix__", False):
        return  # already installed

    _orig = current

    def sdpa_attention_forward_unsloth(
        module,
        query,
        key,
        value,
        attention_mask,
        dropout = 0.0,
        scaling = None,
        is_causal = None,
        **kwargs,
    ):
        m = attention_mask

        # Below 2**16 the Cutlass bool-mask overflow (pytorch/pytorch#162588)
        # cannot fire, so skip the wrapper. The pure-causal rewrite picks a
        # heavier SDPA backend (~2.5 GB on Gemma4-31B LoRA SFT, 8192 seq_len).
        _q_len = query.shape[2] if query.dim() >= 3 else 0
        _mask_key_len = m.shape[-1] if isinstance(m, torch.Tensor) and m.dim() >= 1 else 0
        if _q_len < 65536 and _mask_key_len < 65536:
            return _orig(
                module, query, key, value, attention_mask,
                dropout = dropout, scaling = scaling, is_causal = is_causal,
                **kwargs,
            )

        # Non-causal modules (BERT, SigLIP) keep their masks; explicit param wins.
        resolved_is_causal = (
            is_causal if is_causal is not None
            else getattr(module, "is_causal", True)
        )
        if not resolved_is_causal:
            return _orig(
                module, query, key, value, attention_mask,
                dropout = dropout, scaling = scaling, is_causal = is_causal,
                **kwargs,
            )

        # Sliding-window layers (Gemma2, Mistral, Qwen2/3) keep windowed masks.
        if kwargs.get("sliding_window", None) is not None:
            return _orig(
                module, query, key, value, attention_mask,
                dropout = dropout, scaling = scaling, is_causal = is_causal,
                **kwargs,
            )

        # Hybrid models (Qwen3.5) may pass a dict keyed by layer type.
        if isinstance(m, dict):
            layer_type = getattr(module, "layer_type", None)
            if layer_type not in m:
                return _orig(
                    module, query, key, value, attention_mask,
                    dropout = dropout, scaling = scaling, is_causal = is_causal,
                    **kwargs,
                )
            m = m[layer_type]

        # Only intercept 4D bool self-attn masks (not cross-attn or kv-cache decode).
        if not (
            isinstance(m, torch.Tensor)
            and m.dtype == torch.bool
            and m.dim() == 4
            and m.shape[-1] == m.shape[-2]
            and m.shape[-1] == query.shape[2]
        ):
            return _orig(
                module, query, key, value, attention_mask,
                dropout = dropout, scaling = scaling, is_causal = is_causal,
                **kwargs,
            )

        # Pure lower-triangular check via two O(1) probes: upper-tri False and
        # last row sees first col. Packed/padded masks fail the second.
        S = m.shape[-1]
        is_pure_causal = (
            (S < 2)
            or (
                not m[0, 0, 0, 1].item()
                and m[0, 0, S - 1, 0].item()
            )
        )

        if is_pure_causal:
            # Drop mask, use native is_causal path (avoids Cutlass >65536 bug, faster).
            return _orig(
                module, query, key, value, None,
                dropout = dropout, scaling = scaling, is_causal = True,
                **kwargs,
            )

        # Non-pure bool mask: convert to float additive bias so SDPA dispatches
        # to the working (non-bool) kernel.
        m_float = torch.where(m, 0.0, torch.finfo(query.dtype).min).to(query.dtype)
        return _orig(
            module, query, key, value, m_float,
            dropout = dropout, scaling = scaling, is_causal = False,
            **kwargs,
        )

    sdpa_attention_forward_unsloth.__unsloth_bool_causal_mask_fix__ = True
    sdpa_mod.sdpa_attention_forward = sdpa_attention_forward_unsloth
    ALL_ATTENTION_FUNCTIONS["sdpa"] = sdpa_attention_forward_unsloth
pass
TEMPORARY_PATCHES.append(patch_sdpa_bool_causal_mask)


def patch_modernbert_attention_mask():
    """Fix ModernBERT attn_bias stride alignment for the SDPA backward pass.

    _prepare_4d_attention_mask uses .expand(), giving non-contiguous strides,
    but the compiled SDPA backward kernel needs strides that are multiples of 4.
    Patch _update_attention_mask to return contiguous masks before they enter
    torch.compile regions so the inductor backward graph uses aligned strides.
    """
    try:
        import transformers.models.modernbert.modeling_modernbert as modernbert_module
    except Exception:
        return  # ModernBERT not available, skip

    ModernBertModel = getattr(modernbert_module, "ModernBertModel", None)
    if ModernBertModel is None:
        return

    original_update = getattr(ModernBertModel, "_update_attention_mask", None)
    if original_update is None:
        return

    def _update_attention_mask_contiguous(self, attention_mask, output_attentions=False):
        global_attention_mask, sliding_window_mask = original_update(self, attention_mask, output_attentions=output_attentions)
        # Make masks contiguous so SDPA backward gets multiple-of-4 strides.
        if global_attention_mask is not None and not global_attention_mask.is_contiguous():
            global_attention_mask = global_attention_mask.contiguous()
        if sliding_window_mask is not None and not sliding_window_mask.is_contiguous():
            sliding_window_mask = sliding_window_mask.contiguous()
        return global_attention_mask, sliding_window_mask

    ModernBertModel._update_attention_mask = _update_attention_mask_contiguous
pass
TEMPORARY_PATCHES.append(patch_modernbert_attention_mask)


def patch_CsmForConditionalGeneration_merge():
    try:
        import transformers.models.csm.modeling_csm
    except Exception as e:
        return raise_error("CsmForConditionalGeneration._merge_input_ids_with_input_values", e)

    def _merge_input_ids_with_input_values(
        self,
        input_ids: Optional[torch.Tensor] = None,
        input_values: Optional[torch.Tensor] = None,
        input_values_cutoffs: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
    ) -> Optional[torch.Tensor]:
        """Merge input_ids and input_values into a single inputs_embeds tensor.

        Runs the codec model on input_values to get codebook tokens, embeds and
        positions them, and (if labels are given) expands labels to codebook
        dimensions. input_values_cutoffs are per-batch cutoffs padded with -1.
        """
        inputs_embeds = self.embed_text_tokens(input_ids)

        if input_values is not None:
            # infer input_values_mask
            input_values_cutoffs = torch.nn.functional.pad(input_values_cutoffs, (1, 0))
            audio_lengths = input_values_cutoffs[input_values_cutoffs >= 0].diff()
            audio_lengths = audio_lengths[audio_lengths > 0]
            input_values_mask = torch.arange(input_values_cutoffs.max(), device=input_values.device).expand(
                len(audio_lengths), -1
            )
            input_values_mask = input_values_mask < audio_lengths.unsqueeze(1)

            # =======================================
            # TODO: @eustlb, this should be batched !!!
            # but requires making sure batched inference of the codec model works as intended
            with torch.no_grad():
                audio_tokens_list = []
                for batch_input_values, batch_input_values_cutoffs in zip(input_values, input_values_cutoffs):
                    batch_input_values_cutoffs = batch_input_values_cutoffs[batch_input_values_cutoffs >= 0]
                    for i in range(batch_input_values_cutoffs.shape[0] - 1):
                        start_idx = batch_input_values_cutoffs[i]
                        end_idx = batch_input_values_cutoffs[i + 1]
                        audio_batch = batch_input_values[..., start_idx:end_idx]
                        codec_outputs = self.codec_model.encode(audio_batch.unsqueeze(0))
                        codebook_ids = codec_outputs.audio_codes.transpose(1, -1)
                        audio_tokens_list.append(codebook_ids[0])

                max_audio_frames = max(el.shape[0] for el in audio_tokens_list)
                batched_audio_token_ids = torch.stack(
                    [torch.nn.functional.pad(el, (0, 0, 0, max_audio_frames - el.shape[0])) for el in audio_tokens_list]
                )
                audio_codes_mask = self.codec_model.get_audio_codes_mask(input_values_mask)
            # =======================================
            audio_token_id = self.config.audio_token_id
            audio_token_mask = input_ids == audio_token_id

            audio_embeds = self.backbone_model.embed_tokens(batched_audio_token_ids)
            inputs_embeds[audio_token_mask] = audio_embeds[audio_codes_mask]

            # same for the audio eos token
            audio_eos_frame_ids = (
                torch.ones((1, 1, self.config.num_codebooks), device=input_ids.device, dtype=torch.long)
                * self.config.codebook_eos_token_id
            )
            audio_eos_embeds = self.backbone_model.embed_tokens(audio_eos_frame_ids).squeeze(1)

            audio_eos_token_mask = input_ids == self.config.audio_eos_token_id
            inputs_embeds[audio_eos_token_mask] = audio_eos_embeds.repeat(audio_eos_token_mask.sum(), 1)

            # if the labels are provided, we need to expand the labels to (batch_size, seq_length, num_codebooks)
            if labels is not None:
                labels_expanded = labels.unsqueeze(-1).repeat(1, 1, self.config.num_codebooks)
                labels_expanded[audio_token_mask] = batched_audio_token_ids[audio_codes_mask]
                labels_expanded[audio_eos_token_mask] = audio_eos_frame_ids
                # mask depth decoder
                depth_decoder_ignore_frames_idxs = (labels == -101).nonzero(as_tuple=True)
                labels_expanded[depth_decoder_ignore_frames_idxs[0], depth_decoder_ignore_frames_idxs[1], 1:] = -100
                labels = labels_expanded

        return {"inputs_embeds": inputs_embeds, "labels": labels}
    pass
    patch_function(transformers.models.csm.modeling_csm.CsmForConditionalGeneration, "_merge_input_ids_with_input_values", _merge_input_ids_with_input_values)
pass
TEMPORARY_PATCHES.append(patch_CsmForConditionalGeneration_merge)


def patch_causal_conv1d_cuda_probe():
    """Probe causal_conv1d CUDA kernels and force the slow path if broken.

    On unsupported compute capabilities (e.g. sm_100 on B200), import succeeds
    but calling causal_conv1d_fn(...) fails with "no kernel image is available".
    A tiny startup forward pass detects this, then nullifies
    causal_conv1d_fn/causal_conv1d_update so Mamba-family models fall back to
    their pure-PyTorch slow paths.
    """
    try:
        import causal_conv1d
        from causal_conv1d import causal_conv1d_fn
        from causal_conv1d import causal_conv1d_update
    except ImportError:
        return  # Package not installed, transformers already handles this
    pass

    if causal_conv1d_fn is None:
        return  # Already nullified
    pass

    if not torch.cuda.is_available():
        return
    pass

    # Probe: try a tiny CUDA forward pass
    try:
        device = torch.device("cuda", torch.cuda.current_device())
        x = torch.randn(1, 4, 8, device=device, dtype=torch.float16)
        w = torch.randn(4, 4, device=device, dtype=torch.float16)
        b = torch.zeros(4, device=device, dtype=torch.float16)
        _ = causal_conv1d_fn(x, w, b, activation="silu")
        del x, w, b
        return  # CUDA kernels work fine
    except Exception:
        pass  # Fall through to disable
    pass

    print(
        "Unsloth: causal_conv1d CUDA kernels not compatible with this GPU. "
        "Using PyTorch slow path for Mamba models."
    )

    import sys

    # 1. Nullify the package exports themselves
    for mod_name in ("causal_conv1d", "causal_conv1d.causal_conv1d_interface"):
        mod = sys.modules.get(mod_name)
        if mod is not None:
            if hasattr(mod, "causal_conv1d_fn"):
                mod.causal_conv1d_fn = None
            if hasattr(mod, "causal_conv1d_update"):
                mod.causal_conv1d_update = None
        pass
    pass

    # 2. Patch is_causal_conv1d_available to return False
    try:
        import transformers.utils.import_utils
        transformers.utils.import_utils.is_causal_conv1d_available = lambda: False
    except Exception:
        pass
    pass

    # 3. Scan loaded modules and nullify broken causal_conv1d references. Uses
    #    identity checks (is) against the originals so vllm's independent
    #    Triton-based causal_conv1d_fn/update is left untouched.
    _original_fn = causal_conv1d_fn
    _original_update = causal_conv1d_update

    def _disabled_lazy_load():
        return (None, None)
    pass

    for mod in list(sys.modules.values()):
        if mod is None:
            continue
        # Only nullify references that point to the causal_conv1d package's functions
        touched = False
        if getattr(mod, "causal_conv1d_fn", None) is _original_fn:
            mod.causal_conv1d_fn = None
            touched = True
        if getattr(mod, "causal_conv1d_update", None) is _original_update:
            mod.causal_conv1d_update = None
            touched = True
        # is_fast_path_available = all((causal_conv1d_fn, ...)) -- must be False
        # Only touch it on modules where we just nullified causal_conv1d refs
        if touched and getattr(mod, "is_fast_path_available", False):
            mod.is_fast_path_available = False
        # Replace lazy load stubs (Pattern B: mamba, falcon_mamba)
        if hasattr(mod, "_lazy_load_causal_conv1d"):
            mod._lazy_load_causal_conv1d = _disabled_lazy_load
        if hasattr(mod, "_causal_conv1d_cache"):
            mod._causal_conv1d_cache = (None, None)
    pass
pass
TEMPORARY_PATCHES.append(patch_causal_conv1d_cuda_probe)


def patch_mamba_ssm_pre_ampere_fallback():
    """Force the Mamba slow path on pre-Ampere GPUs.

    mamba_ssm's Triton kernels need sm_80+. On a T4 the package imports fine
    and `is_fast_path_available` is True, so transformers routes into
    `cuda_kernels_forward` and Triton only fails once training starts, with an
    opaque `RuntimeError: PassManager::run failed`.

    `is_fast_path_available` is baked in at module import, so flip both the
    availability predicates (for modules imported later) and the flag on
    already-imported modules. A capability check rather than a trial launch
    like the causal_conv1d probe above, which would pay a Triton compile at
    every import just to watch it fail. Real NVIDIA CUDA only.
    """
    if not torch.cuda.is_available():
        return
    if getattr(torch.version, "hip", None) is not None:
        return  # ROCm: mamba_ssm's requirements are a different question
    try:
        major, minor = torch.cuda.get_device_capability()
    except Exception:
        return
    if (major, minor) >= (8, 0):
        return  # Ampere or newer; the fast path is fine

    import sys

    # 0. transformers 5 can also fetch these kernels from the Hub, through
    #    `lazy_load_kernel`, which needs no local wheel and never consults the
    #    predicates below. Drop the registry entries so it returns None and the
    #    fast path stays unavailable. Before the local-wheel check, since the
    #    Hub path is exactly the one that reaches a pre-Ampere GPU without one.
    try:
        from transformers.integrations import hub_kernels as _hk
        for _kernel in ("mamba-ssm", "falcon_mamba-ssm", "causal-conv1d"):
            _hk._HUB_KERNEL_MAPPING.pop(_kernel, None)
            # An already-resolved module has to go too. None is enough:
            # lazy_load_kernel only short-circuits on a real module object.
            _hk._KERNEL_MODULE_MAPPING[_kernel] = None
    except Exception:
        pass
    pass

    # 0b. Jamba and Zamba bind `self.use_fast_kernels = config.use_mamba_kernels`
    #     (True by default) at construction and RAISE inside that branch when the
    #     fast path is unavailable, so step 0 above and step 1 below turn their
    #     forward into `ValueError: Fast Mamba kernels are not available` instead
    #     of the slow path this guard promises. Wrapping the mixer is the only
    #     thing that clears the instance flag, so it must not hang off the
    #     module's `is_fast_path_available`:
    #       - transformers >= 5.3 assigns that name from inside the mixer's
    #         __init__ (`global is_fast_path_available`,
    #         models/zamba/modeling_zamba.py:257 on 5.5.0), so it is absent from
    #         the module dict until a mixer already exists, and 5.5's forward
    #         recomputes it as a local (line 449) anyway.
    #       - on 4.x it IS a module global, but step 1 has already made it False
    #         by the time the modeling module gets imported, so a truthiness gate
    #         never fired there either.
    #     Before the local-wheel check: step 0 alone is enough to make the fast
    #     path unavailable, and therefore enough to trigger the raise.
    #     `sys.modules.get`, never a getattr scan: transformers 5 registers ~200
    #     alias modules whose catch-all __getattr__ imports the real object.
    #     Local, not a module global: the test extracts this function by AST and
    #     execs it in a bare namespace.
    _raising_mixers = {
        "transformers.models.jamba.modeling_jamba" : "JambaMambaMixer",
        "transformers.models.zamba.modeling_zamba" : "ZambaMambaMixer",
    }
    for _name, _cls_name in _raising_mixers.items():
        _mod = sys.modules.get(_name, None)
        if _mod is None:
            continue
        try:
            _mixer = _mod.__dict__.get(_cls_name, None)
            if _mixer is None or _mixer.__dict__.get("_unsloth_slow_only", False):
                continue
            def _slow_only(self, *a, __orig = _mixer.forward, **kw):
                self.use_fast_kernels = False
                try:
                    # Jamba on transformers 5.5 reads `self.config.use_mamba_kernels`
                    # rather than the instance flag, and clears exactly this on its
                    # own fallback (models/jamba/modeling_jamba.py:470).
                    _config = getattr(self, "config", None)
                    if getattr(_config, "use_mamba_kernels", False):
                        _config.use_mamba_kernels = False
                except Exception:
                    pass
                return __orig(self, *a, **kw)
            _mixer.forward = _slow_only
            _mixer._unsloth_slow_only = True
        except Exception:
            pass
        pass
    pass

    # 0c. Step 0b can only reach a modeling module that is already imported, and
    #     on the `trust_remote_code = True` path there is never such a moment:
    #     unsloth returns from `unsloth_compile_transformers` before the
    #     pre_compile and post_compile phases (models/_utils.py:3277), so the
    #     only phase that ran is "init", at `import unsloth`, and
    #     `from_pretrained` imports modeling_zamba afterwards. Clear the flag on
    #     the CONFIG class instead, which needs no modeling import and is
    #     order-independent: both families bind `use_fast_kernels =
    #     config.use_mamba_kernels` in the mixer's __init__, so a config built
    #     after this point can no longer ask for kernels that are already gone.
    #     Importing the two configuration modules costs ~1ms and 2 modules
    #     inside a process that has already imported transformers, versus a
    #     `sys.meta_path` hook, which would have to stay installed for the whole
    #     process lifetime and tax every later import for one flag.
    #     The marker lives on the wrapper function, not on the class: the
    #     transformers 5 configs are strict dataclasses, and this leaves them
    #     with no attribute of ours. Locals only, since the test extracts this
    #     function by AST and execs it in a bare namespace.
    import importlib
    _raising_configs = {
        "transformers.models.jamba.configuration_jamba" : "JambaConfig",
        "transformers.models.zamba.configuration_zamba" : "ZambaConfig",
    }
    for _name, _cfg_name in _raising_configs.items():
        try:
            _cfg = importlib.import_module(_name).__dict__.get(_cfg_name, None)
            if _cfg is None or getattr(_cfg.__init__, "_unsloth_slow_only", False):
                continue
            def _slow_only_config(self, *a, __orig = _cfg.__init__, **kw):
                __orig(self, *a, **kw)
                try:
                    self.use_mamba_kernels = False
                except Exception:
                    pass
            _slow_only_config._unsloth_slow_only = True
            _cfg.__init__ = _slow_only_config
        except Exception:
            pass
        pass
    pass

    try:
        import mamba_ssm  # noqa: F401
    except Exception:
        return  # Not installed locally, and the Hub entries are already gone

    # 1. Modules imported LATER see the package as unavailable, so their
    #    `is_fast_path_available` evaluates to False at import time.
    try:
        import transformers.utils.import_utils as _iu
        for _pred in ("is_mamba_ssm_available", "is_mamba_2_ssm_available"):
            if hasattr(_iu, _pred):
                setattr(_iu, _pred, lambda: False)
    except Exception:
        pass
    pass

    # 2. Modules ALREADY imported have baked the flag in; flip it directly.
    #    Confined to transformers' own model modules so vLLM's independent
    #    Triton kernels are left alone. Jamba and Zamba are handled in 0b above,
    #    which does not depend on the flag being present or truthy.
    _touched = False
    for _name, _mod in list(sys.modules.items()):
        if not _name.startswith("transformers.models.") or _mod is None:
            continue
        # __dict__, not getattr: transformers 5 registers ~200 alias modules
        # named transformers.models.<m>.image_processing_<m>_fast whose
        # catch-all __getattr__ imports the real image processor, so a getattr
        # probe warns 200 times, drags in 3800 modules (3.8s measured) per
        # phase, and can propagate an ImportError out of `import unsloth`.
        if not _mod.__dict__.get("is_fast_path_available", False):
            continue
        try:
            _mod.is_fast_path_available = False
            for _sym in (
                "selective_state_update",
                "mamba_chunk_scan_combined",
                "mamba_split_conv1d_scan_combined",
            ):
                if getattr(_mod, _sym, None) is not None:
                    setattr(_mod, _sym, None)
            _touched = True
        except Exception:
            pass
        pass
    pass

    print(
        f"Unsloth: mamba_ssm's Triton kernels need compute capability 8.0+ "
        f"(this GPU is {major}.{minor}). Using the PyTorch slow path for "
        f"Mamba models."
    )
    return _touched


TEMPORARY_PATCHES.append(patch_mamba_ssm_pre_ampere_fallback)


def patch_datasets_map_worker_death_retry():
    """Retry `Dataset.map` single-process when a worker is killed outright.

    Long-text corpora can have the kernel OOM-kill a `dataset_num_proc`
    worker, which datasets turns into "One of the subprocesses has abruptly
    died during map operation", killing the run inside SFTTrainer.__init__.
    The map is issued deep inside TRL, so the user cannot disable
    multiprocessing themselves.

    Narrow by design: only a vanished worker (OOM-kill, segfault) matches, a
    genuine exception from the map function is re-raised as itself and still
    propagates, single-process maps re-raise untouched, and the retry cannot
    recurse because num_proc is pinned to 1.
    """
    try:
        from datasets import Dataset
    except Exception:
        return  # datasets not installed

    original_map = getattr(Dataset, "map", None)
    if original_map is None or getattr(original_map, "_unsloth_worker_death_retry", False):
        return

    import functools

    @functools.wraps(original_map)
    def map(self, *args, **kwargs):
        try:
            return original_map(self, *args, **kwargs)
        except RuntimeError as exc:
            if "abruptly died" not in str(exc):
                raise
            # num_proc has to end up as a keyword we can override, so a call
            # that passed it positionally is re-expanded into keywords first.
            call_args, call_kwargs = args, dict(kwargs)
            num_proc = call_kwargs.get("num_proc", None)
            if num_proc is None and args:
                try:
                    sig = inspect.signature(original_map)
                    if any(p.kind is p.VAR_POSITIONAL for p in sig.parameters.values()):
                        raise TypeError("cannot normalise *args")
                    bound = sig.bind(self, *args, **kwargs)
                    bound.apply_defaults()
                    num_proc = bound.arguments.get("num_proc", None)
                    var_kw = {}
                    for p in sig.parameters.values():
                        if p.kind is p.VAR_KEYWORD:
                            var_kw = bound.arguments.pop(p.name, None) or {}
                    bound.arguments.pop("self", None)
                    call_args = ()
                    call_kwargs = {**bound.arguments, **var_kw}
                except Exception:
                    call_args, call_kwargs = args, dict(kwargs)
                    num_proc = None
            if not isinstance(num_proc, int) or num_proc < 1:
                raise
            print(
                f"Unsloth: a dataset worker was killed with num_proc={num_proc} "
                f"(most likely out of system RAM). Retrying single-process; "
                f"this is slower but survives."
            )
            # None, not 1: datasets >= 4.1.0 gates the pool on
            # `num_proc is not None and num_proc >= 1` (arrow_dataset.py), so
            # num_proc=1 still forks a worker and the kernel can kill it again.
            call_kwargs["num_proc"] = None
            return original_map(self, *call_args, **call_kwargs)
        pass
    pass

    map._unsloth_worker_death_retry = True
    Dataset.map = map
    return True


TEMPORARY_PATCHES.append(patch_datasets_map_worker_death_retry)


def patch_GraniteMoeHybridMambaLayer_cuda_kernels_forward():
    try:
        import transformers.models.granitemoehybrid.modeling_granitemoehybrid
        from transformers.models.granitemoehybrid.modeling_granitemoehybrid import (
            GraniteMoeHybridMambaLayer,
            HybridMambaAttentionDynamicCache,
            apply_mask_to_padding_states,
            mamba_split_conv1d_scan_combined,
            mamba_chunk_scan_combined,
            selective_state_update,
            causal_conv1d_fn,
            causal_conv1d_update,
        )
    except:
        return

    def cuda_kernels_forward(
        self,
        hidden_states: torch.Tensor,
        cache_params: Optional[HybridMambaAttentionDynamicCache] = None,
        cache_position: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        seq_idx: Optional[torch.IntTensor] = None,
    ):
        # 1. Gated MLP's linear projection
        hidden_states = apply_mask_to_padding_states(hidden_states, attention_mask)
        projected_states = self.in_proj(hidden_states)

        # Set up dimensions for reshapes later
        batch_size, seq_len, _ = hidden_states.shape
        groups_time_state_size = self.n_groups * self.ssm_state_size

        use_precomputed_states = (
            cache_params is not None
            and cache_params.has_previous_state
            and seq_len == 1
            and cache_params.conv_states[self.layer_idx].shape[0]
            == cache_params.ssm_states[self.layer_idx].shape[0]
            == batch_size
            and cache_position is not None
            and cache_position[0] > 0
        )

        # getting projected states from cache if it exists
        if use_precomputed_states:
            gate, hidden_states_B_C, dt = projected_states.squeeze(1).split(
                [self.intermediate_size, self.conv_dim, self.num_heads], dim=-1
            )

            # 2. Convolution sequence transformation
            hidden_states_B_C = causal_conv1d_update(
                hidden_states_B_C,
                cache_params.conv_states[self.layer_idx],
                self.conv1d.weight.squeeze(1),
                self.conv1d.bias,
                self.activation,
            )

            hidden_states, B, C = torch.split(
                hidden_states_B_C,
                [self.intermediate_size, groups_time_state_size, groups_time_state_size],
                dim=-1,
            )

            # 3. SSM transformation
            A = -torch.exp(self.A_log.float())  # (nheads,)
            A = A[:, None, ...][:, :, None].expand(-1, self.head_dim, self.ssm_state_size).to(dtype=torch.float32)
            dt = dt[:, :, None].expand(-1, -1, self.head_dim)
            dt_bias = self.dt_bias[:, None, ...].expand(-1, self.head_dim)
            D = self.D[:, None, ...].expand(-1, self.head_dim)
            B = B.view(batch_size, self.n_groups, B.shape[1] // self.n_groups)
            C = C.view(batch_size, self.n_groups, C.shape[1] // self.n_groups)
            hidden_states_reshaped = hidden_states.view(batch_size, self.num_heads, self.head_dim)
            hidden_states = selective_state_update(
                cache_params.ssm_states[self.layer_idx],
                hidden_states_reshaped,
                dt,
                A,
                B,
                C,
                D,
                z=None,
                dt_bias=dt_bias,
                dt_softplus=True,
            )
            hidden_states = hidden_states.view(batch_size, self.num_heads * self.head_dim)
            hidden_states = self.norm(hidden_states, gate)

            # 4. Final linear projection
            out = self.out_proj(hidden_states)[:, None, ...]
        # Fused calculations or step by step if no initialized cache is found
        else:
            A = -torch.exp(self.A_log.float())  # (num_heads) or (intermediate_size, state_size)
            dt_limit_kwargs = {} if self.time_step_limit == (0.0, float("inf")) else {"dt_limit": self.time_step_limit}

            # 2-4. Fused kernel for conv1d, SSM, and the final projection
            if self.training and cache_params is None:
                out = mamba_split_conv1d_scan_combined(
                    projected_states,
                    self.conv1d.weight.squeeze(1),
                    self.conv1d.bias,
                    self.dt_bias,
                    A,
                    D=self.D,
                    chunk_size=self.chunk_size,
                    seq_idx=seq_idx,
                    activation=self.activation,
                    rmsnorm_weight=self.norm.weight,
                    rmsnorm_eps=self.norm.variance_epsilon,
                    outproj_weight=self.out_proj.weight,
                    outproj_bias=self.out_proj.bias,
                    headdim=self.head_dim,
                    ngroups=self.n_groups,
                    norm_before_gate=False,
                    return_final_states=False,
                    **dt_limit_kwargs,
                )

            else:
                gate, hidden_states_B_C, dt = projected_states.split(
                    [self.intermediate_size, self.conv_dim, self.num_heads], dim=-1
                )

                # 2. Convolution sequence transformation
                # Init cache
                if cache_params is not None:
                    # storing the states
                    # If we just take xBC[:, :, -self.d_conv :], it will error if seqlen < self.d_conv
                    # Instead F.pad will pad with zeros if seqlen < self.d_conv, and truncate otherwise.
                    hidden_states_B_C_transposed = hidden_states_B_C.transpose(1, 2)
                    conv_states = nn.functional.pad(
                        hidden_states_B_C_transposed,
                        (self.conv_kernel_size - hidden_states_B_C_transposed.shape[-1], 0),
                    )
                    cache_params.conv_states[self.layer_idx].copy_(conv_states)

                if self.activation not in ["silu", "swish"]:
                    hidden_states_B_C = self.act(
                        self.conv1d(hidden_states_B_C.transpose(1, 2))[..., :seq_len].transpose(1, 2)
                    )
                else:
                    hidden_states_B_C = causal_conv1d_fn(
                        x=hidden_states_B_C.transpose(1, 2),
                        weight=self.conv1d.weight.squeeze(1),
                        bias=self.conv1d.bias,
                        activation=self.activation,
                        seq_idx=seq_idx,
                    ).transpose(1, 2)

                hidden_states_B_C = apply_mask_to_padding_states(hidden_states_B_C, attention_mask)
                hidden_states, B, C = torch.split(
                    hidden_states_B_C,
                    [self.intermediate_size, groups_time_state_size, groups_time_state_size],
                    dim=-1,
                )

                # 3. SSM transformation
                scan_output, ssm_state = mamba_chunk_scan_combined(
                    hidden_states.view(batch_size, seq_len, -1, self.head_dim),
                    dt,
                    A,
                    B.view(batch_size, seq_len, self.n_groups, -1),
                    C.view(batch_size, seq_len, self.n_groups, -1),
                    chunk_size=self.chunk_size,
                    D=self.D,
                    z=None,
                    seq_idx=seq_idx,
                    return_final_states=True,
                    dt_bias=self.dt_bias,
                    dt_softplus=True,
                    **dt_limit_kwargs,
                )

                # Init cache
                if ssm_state is not None and cache_params is not None:
                    cache_params.ssm_states[self.layer_idx].copy_(ssm_state)
                    cache_params.has_previous_state = True

                scan_output = scan_output.view(batch_size, seq_len, -1)
                # Multiply "gate" branch and apply extra normalization layer
                scan_output = self.norm(scan_output, gate)

                # 4. Final linear projection
                out = self.out_proj(scan_output)
        return out
    pass
    patch_function(transformers.models.granitemoehybrid.modeling_granitemoehybrid.GraniteMoeHybridMambaLayer, "cuda_kernels_forward", cuda_kernels_forward)
pass
TEMPORARY_PATCHES.append(patch_GraniteMoeHybridMambaLayer_cuda_kernels_forward)


def fix_mamba_ssm_float32():
    try:
        import mamba_ssm.ops.triton.ssd_chunk_scan
    except ImportError:
        return
    except Exception as e:
        return raise_error("mamba_ssm.ops.triton.ssd_chunk_scan", e)

    # Try getting file for mamba_ssm
    try:
        ssd_chunk_scan_file = inspect.getfile(mamba_ssm.ops.triton.ssd_chunk_scan)
        with open(ssd_chunk_scan_file, "r", encoding = "utf-8") as file: file = file.read()
    except Exception as e:
        return raise_error("mamba_ssm.ops.triton.ssd_chunk_scan", e)

    # Find `dst = tl.dot(a, b)` / `dst += tl.dot(a, b)`
    matches = list(re.finditer(
        r" ([a-zA-Z0-9\_]{1,}) (\=|\+\=) tl\.dot\(([a-zA-Z0-9\_]{1,})\, ([a-zA-Z0-9\_]{1,})\)",
        file)
    )
    for match in matches:
        old = match.group(0)
        dst, adder, a, b = match.groups()
        accumulator = '' if adder == "=" else f', acc = {dst}'
        # Change to float32 if float16 seen otherwise leave as original precision
        new = f" {dst} = tl.dot("\
            f"{a}.to(tl.float32), "\
            f"{b}.to(tl.float32)"\
            f"{accumulator})"
        file = file.replace(old, new)
    pass

    try:
        # Reload module since we editted it
        with open(ssd_chunk_scan_file, "w", encoding = "utf-8") as f: f.write(file)
        importlib.reload(mamba_ssm.ops.triton.ssd_chunk_scan)
    except Exception as e:
        return raise_error("mamba_ssm.ops.triton.ssd_chunk_scan", e)
pass
TEMPORARY_PATCHES.append(fix_mamba_ssm_float32)


# Mllama Patches

def patch_MllamaVisionEncoderLayer():
    try:
        import math
        import inspect
        import transformers.models.mllama.modeling_mllama
        from transformers.models.mllama.modeling_mllama import (
            MllamaVisionConfig,
            MllamaVisionAttention,
            MllamaVisionMLP,
            MllamaVisionEncoder,
        )
        from transformers.modeling_layers import GradientCheckpointingLayer
    except Exception as e:
        return raise_error("transformers.models.mllama.modeling_mllama", e)


    # ref: https://github.com/huggingface/transformers/blob/main/src/transformers/models/mllama/modeling_mllama.py#L275C1-L315C28
    class MllamaVisionEncoderLayer(GradientCheckpointingLayer):
        def __init__(self, config: MllamaVisionConfig, is_gated: bool = False):
            super().__init__()

            self.hidden_size = config.hidden_size
            self.num_attention_heads = config.attention_heads
            self.is_gated = is_gated
            self.intermediate_size = config.intermediate_size

            self.self_attn = MllamaVisionAttention(config)
            self.mlp = MllamaVisionMLP(config)

            self.input_layernorm = nn.LayerNorm(self.hidden_size, eps=config.norm_eps)
            self.post_attention_layernorm = nn.LayerNorm(self.hidden_size, eps=config.norm_eps)

            if is_gated:
                self.gate_attn = nn.Parameter(torch.ones(1) * math.pi / 4)
                self.gate_ffn = nn.Parameter(torch.ones(1) * math.pi / 4)

        def forward(
            self,
            hidden_state: torch.Tensor,
            attention_mask: Optional[torch.Tensor] = None,
        ):
            # Self Attention
            residual = hidden_state
            hidden_state = self.input_layernorm(hidden_state)
            hidden_state, attn_weights = self.self_attn(hidden_state, attention_mask=attention_mask)
            if self.is_gated:
                hidden_state = self.gate_attn.tanh() * hidden_state
            hidden_state = residual + hidden_state

            # Feed forward
            residual = hidden_state
            hidden_state = self.post_attention_layernorm(hidden_state)
            hidden_state = self.mlp(hidden_state)
            if self.is_gated:
                hidden_state = self.gate_ffn.tanh() * hidden_state
            hidden_state = residual + hidden_state

            return hidden_state

    try:
        vision_encoder_forward_source = inspect.getsource(MllamaVisionEncoder.forward)
        if "gradient_checkpointing" not in vision_encoder_forward_source:
            transformers.models.mllama.modeling_mllama.MllamaVisionEncoderLayer = MllamaVisionEncoderLayer
    except Exception as e:
        return raise_error("transformers.models.mllama.modeling_mllama.MllamaVisionEncoderLayer", e)

pass
TEMPORARY_PATCHES.append(patch_MllamaVisionEncoderLayer)


# Patch Siglip for forced float32 / float16 only
def patch_SiglipEncoderLayer():
    if os.environ.get("UNSLOTH_FORCE_FLOAT32", "0") == "0": return
    try:
        import transformers.models.siglip.modeling_siglip
    except Exception as e:
        return raise_error("transformers.models.siglip.modeling_siglip", e)
    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: torch.Tensor,
        output_attentions: Optional[bool] = False,
    ) -> tuple[torch.FloatTensor]:
        """SiglipEncoderLayer forward forced to float32 internals.

        hidden_states: (batch, seq_len, embed_dim); attention_mask:
        (batch, 1, q_len, kv_seq_len) with padding as large negatives.
        """
        hidden_states = hidden_states.to(torch.float32)
        residual = hidden_states

        hidden_states = self.layer_norm1(hidden_states)
        hidden_states, attn_weights = self.self_attn(
            hidden_states=hidden_states.to(torch.float16),
            attention_mask=attention_mask,
            output_attentions=output_attentions,
        )
        hidden_states = hidden_states.to(torch.float32)
        hidden_states = residual + hidden_states

        residual = hidden_states
        hidden_states = self.layer_norm2(hidden_states)
        hidden_states = self.mlp(hidden_states.to(torch.float16))
        hidden_states = hidden_states.to(torch.float32)
        hidden_states = residual + hidden_states

        outputs = (hidden_states,)

        if output_attentions:
            outputs += (attn_weights,)

        return outputs
    pass
    patch_function(transformers.models.siglip.modeling_siglip.SiglipEncoderLayer, "forward", forward)
pass
TEMPORARY_PATCHES.append(patch_SiglipEncoderLayer)


def patch_Lfm2VlMultiModalProjector():
    """Backport the transformers 5.0.0 fix for Lfm2VlMultiModalProjector.

    transformers 4.57.6 ignores config.projector_use_layernorm and always
    creates + applies nn.LayerNorm. LFM2.5-VL-1.6B has it False and ships no
    layer_norm weights, so the LayerNorm is randomly initialized and corrupts
    features.
    """
    try:
        import transformers.models.lfm2_vl.modeling_lfm2_vl as lfm2_vl_module
    except Exception:
        return

    Projector = getattr(lfm2_vl_module, "Lfm2VlMultiModalProjector", None)
    if Projector is None:
        return

    # Already patched or already has conditional logic (transformers >= 5.0.0)
    if hasattr(Projector, "_unsloth_patched") or "use_layer_norm" in (getattr(Projector.__init__, "__code__", None) and Projector.__init__.__code__.co_varnames or ()):
        return

    import torch.nn as nn
    original_init = Projector.__init__
    original_forward = Projector.forward

    def patched_init(self, config, *args, **kwargs):
        original_init(self, config, *args, **kwargs)
        self.use_layer_norm = getattr(config, "projector_use_layernorm", True)
        if not self.use_layer_norm:
            self.layer_norm = None

    def patched_forward(self, image_features):
        image_features = self.pixel_unshuffle(image_features)
        if getattr(self, "use_layer_norm", True) and self.layer_norm is not None:
            image_features = self.layer_norm(image_features)
        hidden_states = self.linear_1(image_features)
        hidden_states = self.act(hidden_states)
        hidden_states = self.linear_2(hidden_states)
        return hidden_states

    Projector.__init__ = patched_init
    Projector.forward = patched_forward
    Projector._unsloth_patched = True
pass
TEMPORARY_PATCHES.append(patch_Lfm2VlMultiModalProjector)


def patch_peft_dispatch_bnb_4bit():
    """Fix PEFT dispatch_bnb_4bit reading compress_statistics on non-Params4bit weights.

    transformers 5.0+ changed BNB load order, so weights may still be
    nn.Parameter (not Params4bit) when PEFT reads .compress_statistics /
    .quant_type. Wrap dispatch to catch AttributeError and supply defaults.
    """
    try:
        import peft.tuners.lora.bnb as peft_bnb
        original_dispatch = peft_bnb.dispatch_bnb_4bit
    except (ImportError, AttributeError):
        return

    if hasattr(original_dispatch, "_unsloth_patched"):
        return

    def safe_dispatch_bnb_4bit(target, adapter_name, **kwargs):
        try:
            return original_dispatch(target, adapter_name, **kwargs)
        except AttributeError as e:
            if "compress_statistics" in str(e) or "quant_type" in str(e):
                # transformers 5.0+: weight not yet Params4bit; backfill attrs and retry.
                w = target.weight
                if not hasattr(w, "compress_statistics"):
                    w.compress_statistics = getattr(
                        target, "_bnb_compress_statistics", True
                    )
                if not hasattr(w, "quant_type"):
                    w.quant_type = getattr(target, "_bnb_quant_type", "nf4")
                return original_dispatch(target, adapter_name, **kwargs)
            raise

    safe_dispatch_bnb_4bit._unsloth_patched = True
    peft_bnb.dispatch_bnb_4bit = safe_dispatch_bnb_4bit
pass
TEMPORARY_PATCHES.append(patch_peft_dispatch_bnb_4bit)

def patch_trl_push_to_hub_token():
    """Make TrainingArguments.to_dict() always include push_to_hub_token.

    TRL 0.22.x-0.27.1 bare-pop "push_to_hub_token" in SFTTrainer /
    IterativeSFTTrainer __init__, but transformers 5.0+ drops it from
    to_dict(), so the pop raises KeyError.
    """
    try:
        from unsloth_zoo.utils import Version
        import transformers
        if Version(transformers.__version__) < Version("5.0.0"):
            return  # Not needed pre-5.0, to_dict() already includes it
        from transformers import TrainingArguments
        _original_to_dict = TrainingArguments.to_dict
        if getattr(_original_to_dict, "_unsloth_patched", False):
            return
        def _patched_to_dict(self):
            d = _original_to_dict(self)
            if "push_to_hub_token" not in d:
                d["push_to_hub_token"] = None
            return d
        _patched_to_dict._unsloth_patched = True
        TrainingArguments.to_dict = _patched_to_dict
    except Exception:
        pass
pass
TEMPORARY_PATCHES.append(patch_trl_push_to_hub_token)


def patch_trl_vision_model_mapping():
    """Fix DPO vision model detection for TRL 0.22.x + transformers 5.0+.

    transformers 5.0.0 renamed MODEL_FOR_VISION_2_SEQ_MAPPING_NAMES to
    MODEL_FOR_IMAGE_TEXT_TO_TEXT_MAPPING_NAMES, breaking TRL 0.22.x's bare
    import and preventing the DPO trainer from loading. Inject the old name as
    an alias before TRL imports it, and patch an already-loaded DPO module.
    """
    try:
        import transformers.models.auto.modeling_auto as auto_mod
    except ImportError:
        return
    # If the old name already exists and is populated, nothing to do
    existing = getattr(auto_mod, "MODEL_FOR_VISION_2_SEQ_MAPPING_NAMES", None)
    if existing is not None and len(existing) > 0:
        return
    # Inject the old name as alias of the new name
    new_mapping = getattr(auto_mod, "MODEL_FOR_IMAGE_TEXT_TO_TEXT_MAPPING_NAMES", None)
    if new_mapping is not None:
        auto_mod.MODEL_FOR_VISION_2_SEQ_MAPPING_NAMES = new_mapping
    # Also patch already-loaded DPO module if present
    try:
        import trl.trainer.dpo_trainer as dpo_mod
        dpo_current = getattr(dpo_mod, "MODEL_FOR_VISION_2_SEQ_MAPPING_NAMES", None)
        if (dpo_current is None or len(dpo_current) == 0) and new_mapping is not None:
            dpo_mod.MODEL_FOR_VISION_2_SEQ_MAPPING_NAMES = new_mapping
    except ImportError:
        pass
pass
TEMPORARY_PATCHES.append(patch_trl_vision_model_mapping)


def patch_vllm_safe_apply_chat_template():
    """Fix vLLM safe_apply_chat_template for transformers 5.0+.

    transformers 5.0.0 made apply_chat_template(tokenize=True) default
    return_dict=True (BatchEncoding instead of list[int]); vLLM doesn't pass
    return_dict=False, causing a TypeError in _validate_model_input. Wrap to
    inject return_dict=False when tokenize=True.
    """
    try:
        from unsloth_zoo.utils import Version
        import transformers
        if Version(transformers.__version__) < Version("5.0.0"):
            return

        import vllm.renderers.hf as hf_mod
        _original_safe_apply = getattr(hf_mod, "safe_apply_chat_template", None)
        if _original_safe_apply is None:
            return
        if getattr(_original_safe_apply, "_unsloth_patched", False):
            return

        def _patched_safe_apply(model_config, tokenizer, conversation, *,
                                tools=None, chat_template=None, tokenize=True, **kwargs):
            if tokenize:
                kwargs["return_dict"] = False
            return _original_safe_apply(
                model_config, tokenizer, conversation,
                tools=tools, chat_template=chat_template, tokenize=tokenize,
                **kwargs,
            )
        _patched_safe_apply._unsloth_patched = True
        hf_mod.safe_apply_chat_template = _patched_safe_apply
    except Exception:
        pass
pass
TEMPORARY_PATCHES.append(patch_vllm_safe_apply_chat_template)


def patch_apply_chat_template_return_dict():
    """Restore pre-5.0 return type for apply_chat_template(tokenize=True).

    transformers 5.0+ changed the default of return_dict from False to True.
    """
    try:
        from unsloth_zoo.utils import Version
        import transformers
        if Version(transformers.__version__) < Version("5.0.0"):
            return

        import inspect
        from transformers import PreTrainedTokenizerBase

        _original_apply = PreTrainedTokenizerBase.apply_chat_template
        if getattr(_original_apply, "_unsloth_patched", False):
            return

        try:
            _orig_sig = inspect.signature(_original_apply)
            _has_return_dict = "return_dict" in _orig_sig.parameters
        except Exception:
            _has_return_dict = True

        if not _has_return_dict:
            return

        def _patched_apply_chat_template(self, conversation, *args, **kwargs):
            tokenize = kwargs.get("tokenize", True)
            if tokenize and "return_dict" not in kwargs:
                kwargs["return_dict"] = False
            return _original_apply(self, conversation, *args, **kwargs)

        _patched_apply_chat_template._unsloth_patched = True
        PreTrainedTokenizerBase.apply_chat_template = _patched_apply_chat_template
    except Exception:
        pass
pass
TEMPORARY_PATCHES.append(patch_apply_chat_template_return_dict)


def patch_qwen2vl_image_processor_pixel_attrs():
    """Add max_pixels/min_pixels property shims to Qwen2VLImageProcessor.

    transformers 5.x moved these into self.size["longest_edge"/"shortest_edge"]
    but vLLM 0.15.x reads image_processor.max_pixels directly. Only patched on
    transformers >= 5.0.0 (4.x already sets them as instance attributes).
    """
    try:
        from unsloth_zoo.utils import Version
        import transformers
        if Version(transformers.__version__) < Version("5.0.0"):
            return  # 4.x already has max_pixels/min_pixels as instance attrs
    except Exception:
        return

    try:
        from transformers.models.qwen2_vl.image_processing_qwen2_vl import Qwen2VLImageProcessor
    except ImportError:
        return

    # Only add shims if not already present as a class-level descriptor
    if not isinstance(Qwen2VLImageProcessor.__dict__.get("max_pixels"), property):
        @property
        def _max_pixels(self):
            return self.size.get("longest_edge", self.size.get("max_pixels", None))
        @property
        def _min_pixels(self):
            return self.size.get("shortest_edge", self.size.get("min_pixels", None))
        Qwen2VLImageProcessor.max_pixels = _max_pixels
        Qwen2VLImageProcessor.min_pixels = _min_pixels

    try:
        from transformers.models.qwen2_5_vl.image_processing_qwen2_5_vl import Qwen2_5_VLImageProcessor
        if not isinstance(Qwen2_5_VLImageProcessor.__dict__.get("max_pixels"), property):
            Qwen2_5_VLImageProcessor.max_pixels = _max_pixels
            Qwen2_5_VLImageProcessor.min_pixels = _min_pixels
    except (ImportError, NameError):
        pass
pass
TEMPORARY_PATCHES.append(patch_qwen2vl_image_processor_pixel_attrs)


def patch_deepseek_v2_moe_alias():
    # transformers 5.x renamed DeepseekV2MoE -> DeepseekV2Moe; trust_remote_code
    # models (e.g. DeepSeek-OCR) still import the old name. Alias it back when
    # absent. Skip on 4.x (rename does not exist) to avoid eagerly importing the
    # deepseek_v2 module on every startup.
    try:
        import importlib, transformers
        from unsloth_zoo.utils import Version
        if Version(transformers.__version__) < Version("5.0.0"):
            return
        m = importlib.import_module(
            "transformers.models.deepseek_v2.modeling_deepseek_v2")
    except Exception:
        return
    if not hasattr(m, "DeepseekV2MoE") and hasattr(m, "DeepseekV2Moe"):
        m.DeepseekV2MoE = m.DeepseekV2Moe
pass
TEMPORARY_PATCHES.append(patch_deepseek_v2_moe_alias)


def patch_trl_entropy_from_logits():
    """trl logs a token-entropy metric from logits Unsloth does not materialise.

    `SFTTrainer.compute_loss` does, with no flag to turn it off other than
    `use_liger_kernel`:

        if not self.args.use_liger_kernel:
            with torch.no_grad():
                per_token_entropy = entropy_from_logits(outputs.logits)

    A [batch, seq, vocab] float32 tensor is the largest allocation in an SFT
    step and Unsloth never materialises it, so a diagnostic metric became a
    hard training failure, in two shapes, both seen live:

      Qwen3_(32B)_A100   NotImplementedError: Unsloth: Logits are empty from
                         2024.11 onwards ... set UNSLOTH_RETURN_LOGITS=1
      Spark_TTS_(0_5B)   TypeError: iteration over a 0-d tensor
                         (trl/trainer/utils.py, per_token_entropies.extend)

    The advice in the first cannot be taken: UNSLOTH_RETURN_LOGITS=1 buys the
    metric back by giving up the memory saving the user came for. So the metric
    degrades instead, reporting 0.0 and saying once why, since silently logging
    a zero would look like a real measurement.

    Patched on `trl.trainer.sft_trainer` as well as `trl.trainer.utils`, which
    binds the name at import, so patching only the source module would be a
    no-op for the one caller that matters.
    """
    try:
        import torch
        import trl.trainer.utils as _utils
    except Exception:
        return

    original = getattr(_utils, "entropy_from_logits", None)
    if original is None or getattr(original, "_unsloth_patched", False):
        return

    _warned = [False]

    def _unusable(logits):
        """Checked on the object, not the exception text. `EmptyLogits.__getattr__`
        hands back the `raise_logits_error` function for every attribute, so what
        blows up depends on which attribute this trl touches first: `.split(...)`
        raises NotImplementedError, `logits.shape[:-1]` subscripts a function and
        raises TypeError. Keying on either message fixes one trl and misses the
        other. Matched by name because unsloth_zoo must not import unsloth.
        """
        if logits is None:
            return True
        if type(logits).__name__ == "EmptyLogits":
            return True
        if isinstance(logits, torch.Tensor) and (logits.numel() == 0 or logits.dim() < 2):
            return True
        return False

    def _warn_once():
        if _warned[0]:
            return
        _warned[0] = True
        logger.warning(
            "Unsloth: your trl version logs a token-entropy metric computed "
            "from the full logits, which Unsloth does not materialise (that is "
            "where the memory saving comes from). Entropy will be reported as "
            "0.0. Set UNSLOTH_RETURN_LOGITS=1 before training if you need the "
            "real value and can afford the memory."
        )

    def _metric_device(logits):
        """Device trl will gather this scalar on.

        trl hands the result straight to `accelerator.gather_for_metrics`, whose
        distributed path allocates on `PartialState().device` and calls NCCL,
        which rejects a CPU tensor ("Tensors must be CUDA and dense"). The
        masked branch is rescued by multiplying with a device-resident
        attention_mask, but the padding-free branch is a bare mean(), so a
        multi-GPU run would swap one crash for another. Asked of accelerate
        rather than guessed, and only once it is already initialised, so a
        single-process run keeps the CPU scalar accelerate leaves alone.

        A tensor's own device is only trusted when it is NOT cpu. The
        fused-loss path returns a module-level `EMPTY_LOGITS = torch.empty(0)`
        (fused_losses/forward_adapter.py), built at import time and therefore
        always on cpu no matter which device the run is on, so following it
        would hand NCCL a CPU scalar on exactly the distributed run this
        function exists for.
        """
        if isinstance(logits, torch.Tensor) and logits.device.type != "cpu":
            return logits.device
        try:
            from accelerate.state import PartialState
            if PartialState._shared_state:
                return PartialState().device
        except Exception:
            pass
        return logits.device if isinstance(logits, torch.Tensor) else None

    # 0-d so it broadcasts against attention_mask in both of the caller's
    # branches: sum(0 * mask)/sum(mask) and mean(0) are both 0.0, neither raises.
    def _no_entropy(logits = None):
        return torch.zeros((), dtype = torch.float32, device = _metric_device(logits))

    @functools.wraps(original)
    def entropy_from_logits(logits, *args, **kwargs):
        if _unusable(logits):
            _warn_once()
            return _no_entropy(logits)
        try:
            return original(logits, *args, **kwargs)
        except TypeError as e:
            # Backstop for a shape the check above did not anticipate. Narrow:
            # anything else from inside entropy_from_logits is a real bug and
            # must still raise, or this hides it on every single step.
            if "iteration over a 0-d tensor" not in str(e):
                raise
            _warn_once()
            return _no_entropy(logits)

    entropy_from_logits._unsloth_patched = True
    # Exposed so the SFT wrapper can mute this for its probing call. That call
    # may be about to fail on the SECOND logits read, in which case the
    # wrapper reports that both metrics are omitted and this message, which
    # promises entropy as 0.0, would contradict it on the very first step.
    entropy_from_logits._unsloth_warned = _warned
    for _mod_name in ("trl.trainer.utils", "trl.trainer.sft_trainer"):
        try:
            _mod = importlib.import_module(_mod_name)
        except Exception:
            continue
        if getattr(_mod, "entropy_from_logits", None) is original:
            _mod.entropy_from_logits = entropy_from_logits
pass
TEMPORARY_PATCHES.append(patch_trl_entropy_from_logits)


# trl >= 1.0 injects these into the forward kwargs when `use_liger_kernel` is
# on, because its liger path expects a liger-patched forward to consume them
# (trl 1.9.2 sft_trainer.py:1718-1735). An Unsloth model is not liger-patched,
# so they must not ride along when the flag is forced on below.
_SFT_LIGER_ONLY_FORWARD_KWARGS = frozenset((
    "skip_logits",
    "return_token_accuracy",
    "use_token_scaling",
))
_SFT_SHIELDED_INPUT_TYPES = {}


def _sft_shielded_inputs(inputs, contents):
    """A copy of `contents` that silently drops the liger-only forward kwargs.

    The injection happens inside `compute_loss`, on the mapping the caller
    handed in, so the mapping is the only interception point available. Built
    from the caller's own mapping type so a `BatchEncoding` stays one, and
    cached per type so the class is created once rather than per step.
    """
    if not isinstance(inputs, Mapping):
        return contents
    cls = type(inputs)
    shielded = _SFT_SHIELDED_INPUT_TYPES.get(cls, None)
    if shielded is None:
        def __setitem__(self, key, value, _cls = cls):
            if key in _SFT_LIGER_ONLY_FORWARD_KWARGS: return
            _cls.__setitem__(self, key, value)
        try:
            shielded = type("Unsloth" + cls.__name__, (cls,), {"__setitem__" : __setitem__})
        except Exception:
            return contents
        _SFT_SHIELDED_INPUT_TYPES[cls] = shielded
    try:
        return shielded(contents)
    except Exception:
        return contents
pass


def _sft_logits_are_unusable(logits):
    """Same predicate `patch_trl_entropy_from_logits` applies to its argument.

    Kept separate rather than shared because that one is closed over the
    entropy patch and matched by name: unsloth_zoo must not import unsloth, so
    the sentinel is recognised by class name, and the fused-loss path returns a
    real 0-element tensor (`fused_losses/forward_adapter.py: EMPTY_LOGITS =
    torch.empty(0)`) instead.
    """
    if logits is None: return True
    if type(logits).__name__ == "EmptyLogits": return True
    if isinstance(logits, torch.Tensor) and (logits.numel() == 0 or logits.dim() < 2):
        return True
    return False
pass


def _sft_raised_on_empty_logits(exception):
    """Decided on the object trl was holding, not on the exception message.

    Which exception comes out depends on which sentinel the model returned and
    which attribute the installed trl reaches for first:

        EmptyLogits().shape[:-1]      TypeError    ('function' not subscriptable)
        EmptyLogits()[..., :-1, :]    NotImplementedError
        torch.empty(0)[..., :-1, :]   IndexError   (too many indices)
        torch.empty(0).argmax(-1)     RuntimeError

    so a message match fixes one build and misses the next. The failing frame
    still holds trl's `outputs`, so the question can be asked of the logits
    themselves: if they are real, this is somebody's genuine bug and it must
    keep propagating.

    Matched on the local rather than on the frame's name, because the raise can
    land in a helper trl called and because the enclosing method has been
    renamed before. The stack starts inside SFTTrainer.compute_loss either way.
    """
    return _sft_empty_logits_outputs(exception) is not None
pass


_SFT_NO_LOGITS = object()


def _sft_empty_logits_outputs(exception):
    """The `outputs` object trl was holding, if its logits were the sentinel.

    Returned rather than just a bool so the caller can replay `aux_loss` off
    it: that metric is not logits-derived, but it lives inside the same
    `if not self.args.use_liger_kernel` block, so skipping the block to avoid
    the logits would silently drop it for MoE runs.
    """
    tb = getattr(exception, "__traceback__", None)
    while tb is not None:
        frame = tb.tb_frame
        if "outputs" in frame.f_locals:
            outputs = frame.f_locals["outputs"]
            try:
                # A default of None would be indistinguishable from a model
                # that really does set `logits = None`, and _..._are_unusable
                # calls that unusable. An output object with no `logits` at all
                # is somebody's broken contract, not our sentinel, and must
                # keep raising.
                logits = getattr(outputs, "logits", _SFT_NO_LOGITS)
                unusable = (logits is not _SFT_NO_LOGITS
                            and _sft_logits_are_unusable(logits))
            except Exception:
                unusable = False
            if unusable: return outputs
        tb = tb.tb_next
    return None
pass


def _sft_inputs_slot(args, kwargs):
    """Where `inputs` sits in a `compute_loss(self, model, inputs, ...)` call."""
    if len(args) > 1: return 1, args[1]
    if "inputs" in kwargs: return "inputs", kwargs["inputs"]
    return None, None
pass


def _sft_mute_entropy_warning():
    """Silence the entropy patch for one probing call; returns a restore token."""
    try:
        import trl.trainer.utils as _u
        flag = getattr(getattr(_u, "entropy_from_logits", None), "_unsloth_warned", None)
        if flag is None: return None
        was, flag[0] = flag[0], True
        return (flag, was)
    except Exception:
        return None
pass


def _sft_aux_loss_count(self):
    """How many aux_loss values trl has logged for the current mode.

    `.get`, never `[...]`: `_metrics[mode]` is a `defaultdict(list)`, so a
    subscript CREATES the key, and this runs on every step including dense
    ones that will never have an aux_loss. trl's `SFTTrainer.log` averages
    every key it finds with `sum(val) / len(val)` (sft_trainer.py:1194), so
    one empty list left behind is a ZeroDivisionError at the first log.
    """
    metrics = getattr(self, "_metrics", None)
    if not isinstance(metrics, dict): return None
    mode = "train" if getattr(getattr(self, "model", None), "training", True) else "eval"
    bucket = metrics.get(mode)
    if bucket is None: return None
    try:
        return len(bucket.get("aux_loss") or ())
    except Exception:
        return None
pass


def _sft_replay_aux_loss(self, outputs, before):
    """Log the aux_loss the skipped block would have logged.

    aux_loss is not logits-derived, but on trl 0.23.0 through 0.25.x it sits
    INSIDE the same `if not self.args.use_liger_kernel` block as the accuracy
    metric, so turning that flag on to dodge the logits drops it too, silently,
    for exactly the MoE runs (`output_router_logits = True`) that want it.

    Gated on the count rather than on a version, because trl 1.x moved this out
    to `# applies to both Liger and non-Liger` (1.9.2 sft_trainer.py:1826) and
    logs it regardless, where appending again would double-count. 0.22.2 has no
    aux_loss in this trainer at all.
    """
    if outputs is None or before is None: return
    if not getattr(self, "aux_loss_enabled", False): return
    if (_sft_aux_loss_count(self) or 0) > before: return
    aux = getattr(outputs, "aux_loss", None)
    if aux is None: return
    try:
        metrics = self._metrics["train" if self.model.training else "eval"]
        metrics["aux_loss"].append(
            self.accelerator.gather_for_metrics(aux).mean().item()
        )
    except Exception:
        # A lost diagnostic must never take down the step that produced it.
        pass
pass


def _sft_call_without_logits_metrics(original, self, args, kwargs, contents = None):
    """Run trl's own `compute_loss` with its logits-derived metrics turned off.

    Every version in the supported range gates that section on
    `self.args.use_liger_kernel` ("liger doesn't return logits"), which is
    exactly the "there are no logits" condition, so the flag is trl's own off
    switch for it. Only forced when the user had it off; a real liger run is
    left alone. `contents` replays the mapping as it was BEFORE a failed first
    attempt, which may have popped `labels` out of it (transformers
    `Trainer.compute_loss` does exactly that when `compute_loss_func` or label
    smoothing is set).
    """
    targs = getattr(self, "args", None)
    previous = getattr(targs, "use_liger_kernel", None)
    if previous is None or previous:
        return original(self, *args, **kwargs), None
    # Ask for the outputs only when there is an aux_loss to rescue off them, so
    # the ordinary path keeps trl's exact call shape.
    asked = args[2] if len(args) > 2 else kwargs.get("return_outputs", False)
    force = bool(getattr(self, "aux_loss_enabled", False)) and not asked
    if force:
        # Replace the positional slot rather than adding a keyword beside it:
        # `compute_loss(model, inputs, False, ...)` is a legal public call, and
        # doing both would raise "got multiple values for argument".
        if len(args) > 2:
            args = args[:2] + (True,) + args[3:]
        else:
            kwargs = dict(kwargs)
            kwargs["return_outputs"] = True
    slot, inputs = _sft_inputs_slot(args, kwargs)
    if slot is not None:
        shielded = _sft_shielded_inputs(inputs, inputs if contents is None else contents)
        if slot == "inputs":
            kwargs = dict(kwargs)
            kwargs["inputs"] = shielded
        else:
            args = args[:slot] + (shielded,) + args[slot + 1:]
    targs.use_liger_kernel = True
    try:
        with warnings.catch_warnings():
            # trl >= 1.0 tells the user to file a liger-kernel bug when the
            # flag is on and the outputs carry no token_accuracy
            # (sft_trainer.py:1821). There is no liger here, so that report
            # would be sent to the wrong project.
            warnings.filterwarnings("ignore", message = ".*token_accuracy.*")
            result = original(self, *args, **kwargs)
    finally:
        targs.use_liger_kernel = previous
    # Take the outputs whenever they are there, not only when we asked. An
    # eval or predict step arrives with return_outputs already True
    # (Trainer.prediction_step), so `force` is False and the side channel would
    # otherwise be empty for exactly the batches that still want aux_loss.
    _outputs = result[1] if isinstance(result, tuple) and len(result) == 2 else None
    if force and _outputs is not None:
        # We asked for these, the caller did not: hand back only the loss.
        result = result[0]
    return result, _outputs
pass


def _sft_wrap_compute_loss(original):
    """The wrapper installed below; separated so it can be driven against a
    stand-in for a trl version that is not the one installed."""

    @functools.wraps(original)
    def compute_loss(self, *args, **kwargs):
        # Per trainer, not per process: two SFTTrainers can live in one process
        # and only one of them may be running an Unsloth model.
        if getattr(self, "_unsloth_logits_are_empty", False):
            before = _sft_aux_loss_count(self)
            result, outputs = _sft_call_without_logits_metrics(
                original, self, args, kwargs)
            _sft_replay_aux_loss(self, outputs, before)
            return result
        # A failed attempt leaves state behind: it advanced the token counter,
        # appended the metrics it got as far as, and let transformers pop
        # `labels` out of the inputs. All three are replayed to the retry as
        # they were, so nothing is counted twice and nothing is missing.
        counter = getattr(self, "_total_train_tokens", None)
        metrics = getattr(self, "_metrics", None)
        lengths = {k : {n : len(v) for n, v in d.items()} for k, d in metrics.items()} \
            if isinstance(metrics, dict) else None
        _, inputs = _sft_inputs_slot(args, kwargs)
        contents = dict(inputs) if isinstance(inputs, Mapping) else None
        aux_before = _sft_aux_loss_count(self)
        # This first call is a probe. If it fails on the second logits read the
        # warning below replaces the entropy patch's, which promises a 0.0 that
        # is not going to be reported after all.
        muted = _sft_mute_entropy_warning()
        try:
            result = original(self, *args, **kwargs)
        except Exception as e:
            outputs = _sft_empty_logits_outputs(e)
            if outputs is None:
                if muted is not None: muted[0][0] = muted[1]
                raise
            if counter is not None:
                self._total_train_tokens = counter
            if lengths is not None:
                for k, d in metrics.items():
                    seen = lengths.get(k, {})
                    for n, v in list(d.items()):
                        # Delete a key the probe invented rather than emptying
                        # it. trl's log averages every key with
                        # sum(val) / len(val), so an emptied list left in place
                        # is a ZeroDivisionError at the first logging step.
                        if n in seen: del v[seen[n]:]
                        else: del d[n]
            logger.warning(
                "Unsloth: your trl version logs entropy and mean_token_accuracy "
                "from the full logits, which Unsloth does not materialise (that "
                "is where the memory saving comes from). Both will be omitted. "
                "Set UNSLOTH_RETURN_LOGITS=1 before training if you need them "
                "and can afford the memory."
            )
            retried, retry_outputs = _sft_call_without_logits_metrics(
                original, self, args, kwargs, contents)
            # Latched only now. If the retry raises too, the logits were wanted
            # by something other than the metric block (trl's loss_type='dft',
            # a custom loss), and latching would keep this trainer in the
            # no-logits path for the rest of the process -- including a rerun
            # with UNSLOTH_RETURN_LOGITS=1, which would then never re-probe.
            self._unsloth_logits_are_empty = True
            _sft_replay_aux_loss(
                self, outputs if retry_outputs is None else retry_outputs, aux_before)
            return retried
        else:
            # No failure, so the entropy message (if it wanted to fire) was
            # accurate after all: let the next step emit it.
            if muted is not None: muted[0][0] = muted[1]
            return result
    compute_loss._unsloth_patched = True
    return compute_loss
pass


def patch_trl_sft_logits_metrics():
    """The entropy rebind above is not enough: trl's SFTTrainer.compute_loss
    touches `outputs.logits` a second time, inline, for mean_token_accuracy.

        trl 0.22.2  sft_trainer.py:1080  shift_logits = outputs.logits[..., :-1, :]
        trl 0.24.0  sft_trainer.py:1146  shift_logits = outputs.logits[..., :-1, :]
        trl 0.25.1  sft_trainer.py:1151  shift_logits = outputs.logits[..., :-1, :]
        trl 1.9.2   sft_trainer.py:1769  shift_logits = outputs.logits[..., :-1, :]

    On trl 1.x that line runs BEFORE entropy_from_logits, so rebinding the
    helper cannot help there at all. There is no helper to rebind for the
    accuracy block, so the whole logits-derived metric section is skipped
    instead -- and only after a run has actually proved its logits are empty,
    so a non-Unsloth trl user keeps the real metrics and pays nothing but one
    `try`.
    """
    try:
        import trl.trainer.sft_trainer as _sft
    except Exception:
        return
    trainer = getattr(_sft, "SFTTrainer", None)
    original = getattr(trainer, "compute_loss", None)
    if original is None or getattr(original, "_unsloth_patched", False):
        return
    trainer.compute_loss = _sft_wrap_compute_loss(original)
pass
TEMPORARY_PATCHES.append(patch_trl_sft_logits_metrics)

def patch_longrope_impossible_attention_factor():
    """Ignore a LongRoPE `attention_factor` that cannot be a real one.

    The factor is by construction

        sqrt(1 + log(factor) / log(original_max_position_embeddings))

    a number near 1. transformers derives that when the key is absent, but
    takes the config's word for it when present, and
    unsloth/Phi-3.5-mini-instruct{,-bnb-4bit} set it equal to `factor` (32.0),
    roughly 27x the real value. Nothing raises; the model just predicts badly
    (4.74 vs 2.13 cross-entropy on the same text).

    The signature is exact on purpose: attention_factor == factor AND
    factor > 2. A genuine attention factor is never the extension ratio and
    never much above 1.5. The real remedy is republishing those configs.
    """
    try:
        import functools
        import math
        from transformers import modeling_rope_utils as _rope
    except Exception:
        return
    original = getattr(_rope, "_compute_longrope_parameters", None)
    if original is None or getattr(original, "_unsloth_patched", False):
        return

    def _sanitise(config):
        scaling = getattr(config, "rope_scaling", None)
        if not isinstance(scaling, dict):
            return
        factor = scaling.get("factor")
        attention_factor = scaling.get("attention_factor")
        if attention_factor is None or factor is None:
            return
        try:
            if float(attention_factor) != float(factor) or float(factor) <= 2.0:
                return
        except (TypeError, ValueError):
            return
        original_max = getattr(config, "original_max_position_embeddings", None) \
            or getattr(config, "max_position_embeddings", None)
        try:
            correct = math.sqrt(1 + math.log(float(factor)) / math.log(float(original_max)))
        except (TypeError, ValueError, ZeroDivisionError):
            correct = None
        cleaned = dict(scaling)
        cleaned.pop("attention_factor", None)
        try:
            config.rope_scaling = cleaned
        except Exception:
            return
        print(
            f"Unsloth: This model's config sets a LongRoPE attention_factor of "
            f"{attention_factor}, which equals its extension factor and cannot be "
            f"a real attention factor"
            + (f" (the derived value is {correct:.4f})" if correct else "")
            + ". Ignoring it so attention is scaled correctly."
        )

    # Everything but `config` is forwarded untouched: on transformers 5 every
    # other parameter has a default and `_init_weights` calls the rope init as
    # `rope_fn(module.config)`, so naming `device` here would make every
    # LongRoPE model fail to load with a missing-argument TypeError.
    @functools.wraps(original)
    def _compute_longrope_parameters(config, *args, **kwargs):
        try:
            _sanitise(config)
        except Exception:
            # Never let the guard itself break a model that would have loaded.
            pass
        return original(config, *args, **kwargs)

    _compute_longrope_parameters._unsloth_patched = True
    try:
        _rope._compute_longrope_parameters = _compute_longrope_parameters
        # Models resolve the callable through this dict, not the module
        # attribute, so patching only the attribute would be a no-op.
        if getattr(_rope, "ROPE_INIT_FUNCTIONS", None) is not None:
            if _rope.ROPE_INIT_FUNCTIONS.get("longrope") is original:
                _rope.ROPE_INIT_FUNCTIONS["longrope"] = _compute_longrope_parameters
    except Exception:
        return
pass
TEMPORARY_PATCHES.append(patch_longrope_impossible_attention_factor)
