# Unsloth Zoo - Utilities for Unsloth
# Copyright 2023-present Daniel Han-Chen, Michael Han-Chen & the Unsloth team. All rights reserved.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import torch
import numpy as np
from typing import Union, Optional, List, Any, Callable, Tuple
from contextlib import contextmanager, nullcontext
import os
import functools
import inspect
import warnings
import gc
import threading
from .utils import _get_dtype, Version
from .device_type import (
    is_hip,
    get_device_type,
    DEVICE_TYPE,
    DEVICE_TYPE_TORCH,
    DEVICE_COUNT,
    ALLOW_PREQUANTIZED_MODELS,
)

__all__ = [
    "calculate_n_gradient_checkpoints",
    "prepare_n_gradient_checkpoints",
    "Unsloth_Offloaded_Gradient_Checkpointer",
    "unsloth_offloaded_gradient_checkpoint",
    "patch_unsloth_gradient_checkpointing",
    "unpatch_unsloth_gradient_checkpointing",

    "Unsloth_Gradient_Checkpointer",
    "unsloth_gradient_checkpoint",
    "patch_gradient_checkpointing",
    "unpatch_gradient_checkpointing",

    "patch_unsloth_smart_gradient_checkpointing",
    "unpatch_unsloth_smart_gradient_checkpointing",
    "reset_unsloth_gradient_checkpointing_buffers",
]

# Initial buffer sizes for gradient checkpointing
INITIAL_CPU_BUFFER_SIZE = 128 * 1024       # per CPU buffer
INITIAL_GPU_BUFFER_SIZE = 2 * 256 * 2048   # per GPU buffer
INITIAL_CPU_BUFFER_COUNT = 200             # number of CPU buffers
DOUBLE_BUFFER_HEADROOM = 512 * 1024 * 1024 # min free CUDA memory to enable double buffering


def _any_device_integrated():
    # True if ANY visible CUDA/HIP device is integrated (unified memory). A single
    # static check on purpose: an integrated device anywhere makes double buffering
    # pure overhead, and a mixed integrated + discrete box is rare.
    try:
        return any(
            bool(getattr(torch.cuda.get_device_properties(i), "is_integrated", 0))
            for i in range(torch.cuda.device_count())
        )
    except Exception:
        return False


@functools.cache
def _double_buffer_disabled():
    # Cached: computed once on the first GC init (after device selection), never at
    # import, so it does not probe the GPU before the caller picks its device. Double
    # buffering overlaps the H2D offload copy with compute, but on unified-memory devices
    # (AMD APUs gfx1150/1151, NVIDIA GB10) there is no transfer to hide: pure overhead
    # (~2x slower, no memory saved). UNSLOTH_DISABLE_DOUBLE_BUFFER=0/1 forces it; else
    # disable when any visible device is integrated.
    env = os.environ.get("UNSLOTH_DISABLE_DOUBLE_BUFFER")
    if env is not None: return env == "1"
    if DEVICE_TYPE not in ("cuda", "hip"): return False
    return _any_device_integrated()


@contextmanager
def _no_inference_mode():
    # Allocate GC buffers outside inference_mode (but in no_grad) so a later
    # offload copy_ does not raise on an inference tensor (unsloth#3828).
    try:
        leave_inference = torch.inference_mode(False)
    except (TypeError, AttributeError):
        leave_inference = nullcontext()  # older torch lacks inference_mode(bool)
    with leave_inference, torch.no_grad():
        yield

torch_version = torch.__version__
if Version(torch_version) < Version("2.4.0"):
    torch_amp_custom_fwd = torch.cuda.amp.custom_fwd
    torch_amp_custom_bwd = torch.cuda.amp.custom_bwd
else:
    torch_amp_custom_fwd = torch.amp.custom_fwd(device_type = "cuda")
    torch_amp_custom_bwd = torch.amp.custom_bwd(device_type = "cuda")
pass


def _calculate_n_gradient_checkpoints(
    n_layers : int,
    method   : Optional[Union[str, int]] = "sqrt",
) -> List[int]:
    assert(type(n_layers) is int and n_layers > 0)

    if method is None: method = "sqrt"

    if method == "sqrt":
        n_checkpoints = int(n_layers**0.5)
    elif type(method) is int and method > 0:
        n_checkpoints = int(np.ceil(n_layers / method))
    else:
        raise ValueError("method must be 'sqrt' or an int >0 and <= n_layers.")

    size = n_layers // n_checkpoints
    sizes = np.full(n_checkpoints, size, dtype = int)
    leftovers = n_layers % n_checkpoints
    # Append leftovers from the right
    for k in range(leftovers):
        sizes[n_checkpoints-1-k] += 1
    boundaries = np.hstack((0, np.cumsum(sizes)))
    boundaries = boundaries.tolist()
    return boundaries
pass


def calculate_n_gradient_checkpoints(
    n_layers              : int,
    layers_per_checkpoint : Optional[Union[str, int]] = "sqrt",
) -> List[int]:
    assert(type(n_layers) is int and n_layers > 0)

    if layers_per_checkpoint is None or layers_per_checkpoint == 1:
        return None

    boundaries = _calculate_n_gradient_checkpoints(n_layers, layers_per_checkpoint)

    assert(boundaries[0] == 0 and boundaries[-1] == n_layers)
    assert(min(boundaries) == 0 and max(boundaries) == n_layers)
    assert(np.diff(boundaries).min() >= 0)
    return boundaries
pass


def prepare_n_gradient_checkpoints(
    model                 : Any,
    layers_per_checkpoint : Optional[Union[str, int]] = "sqrt",
    use_reentrant         : Optional[bool] = True,
) -> None:
    """
    Calculates where to place the gradient checkpoints given n_layers.

    Args:
        model: Any LlamaModel with layers.
        layers_per_checkpoint (`Union[str, int]`, *optional*):
            Can either be `sqrt` or an integer for how many layers per checkpoint you want.
            The more, the less memory usage, but can be slower. Default is `sqrt`.
            Choose 1 for Pytorch gradient checkpointing. 2 to wrap 2 layers in 1 module etc.
        use_reentrant (`bool`, *optional*):
            https://github.com/pytorch/pytorch/blob/main/torch/utils/checkpoint.py#L354
            Optimal gradient checkpointing algorithm `use_reentrant=False` which will
            be the default in future Pytorch versions doesn't seem to work??
    """
    _model = None
    if hasattr(model, "layers"):
        _model = model
    elif hasattr(model, "model"):
        if hasattr(model.model, "layers"):
            _model = model.model
    if _model is None:
        raise TypeError("`model` or `model.model` does not have attribute `layers`. Are you sure this is a model?")
    pass

    if use_reentrant is False:
        use_reentrant = True
    pass

    n_layers = len(_model.layers)
    boundaries = calculate_n_gradient_checkpoints(n_layers, layers_per_checkpoint)
    _model._gradient_checkpointing_boundaries    = boundaries
    _model._gradient_checkpointing_use_reentrant = use_reentrant
pass


# ---------------------------------------------------------------------------
# Gradient-checkpoint recompute marker
# ---------------------------------------------------------------------------
# Thread-local flag, True only while a gradient-checkpoint backward is re-running
# its wrapped forward to rebuild activations. Consumers (e.g. the MoE grouped-mm
# recompute policy) read it via in_gradient_checkpoint_recompute() to decide whether
# to pin a freshly dequantized tensor for the immediate backward (cheap under
# checkpointing) or recompute it later. The context manager always restores the
# previous value, so it is idempotent and safe under nesting and exceptions, and it
# never alters checkpointing behaviour itself.
_GC_RECOMPUTE_TLS = threading.local()


def in_gradient_checkpoint_recompute() -> bool:
    """True while a gradient-checkpoint backward is recomputing its forward."""
    return getattr(_GC_RECOMPUTE_TLS, "active", False)


@contextmanager
def _gradient_checkpoint_recompute_marker():
    previous = getattr(_GC_RECOMPUTE_TLS, "active", False)
    _GC_RECOMPUTE_TLS.active = True
    try:
        yield
    finally:
        _GC_RECOMPUTE_TLS.active = previous


def _detach_checkpoint_args(args):
    """Detach the differentiable tensors in ``args`` for a reentrant recompute.

    ``ctx.args`` are the tensors as they were handed to ``Function.apply``; a
    Python ``autograd.Function`` does not strip their ``grad_fn``. Re-running the
    block on them under ``torch.enable_grad()`` and calling
    ``torch.autograd.backward`` on the result therefore walks straight into the
    history *behind* those tensors from inside this backward - a nested backward
    over a graph the outer engine still intends to visit, which frees it early
    ("Trying to backward through the graph a second time") and delivers the
    gradient as a side effect rather than as this Function's output.

    Detaching stops the traversal at the recompute boundary, exactly as
    ``UnslothCheckpointFunction`` and torch's own reentrant checkpoint do, and
    the caller returns the collected ``.grad`` so the engine keeps propagating.

    Returns ``(recompute_args, grad_holders)`` where ``grad_holders[i]`` is the
    detached tensor to read a gradient off, or ``None`` for inputs that take no
    gradient.
    """
    # All Unsloth Zoo code licensed under LGPLv3
    recompute_args = []
    grad_holders   = []
    for arg in args:
        if torch.is_tensor(arg) and arg.requires_grad:
            detached = arg.detach()
            detached.requires_grad_(True)
            recompute_args.append(detached)
            grad_holders  .append(detached)
        else:
            recompute_args.append(arg)
            grad_holders  .append(None)
    return recompute_args, grad_holders
pass


class Unsloth_Offloaded_Gradient_Checkpointer(torch.autograd.Function):
    """
    All Unsloth Zoo code licensed under LGPLv3
    Saves VRAM by smartly offloading to RAM.
    Tiny hit to performance, since we mask the movement via non blocking calls.
    """
    @staticmethod
    @torch_amp_custom_fwd
    def forward(ctx, forward_function, hidden_states, *args):
        ctx.device = hidden_states.device
        saved_hidden_states = hidden_states.to("cpu", non_blocking = True)
        with torch.no_grad():
            output = forward_function(hidden_states, *args)
        ctx.save_for_backward(saved_hidden_states)
        ctx.forward_function = forward_function
        ctx.args = args
        return output
    pass

    @staticmethod
    @torch_amp_custom_bwd
    def backward(ctx, dY):
        (hidden_states,) = ctx.saved_tensors
        hidden_states = hidden_states.to(ctx.device, non_blocking = True).detach()
        hidden_states.requires_grad_(True)
        recompute_args, grad_holders = _detach_checkpoint_args(ctx.args)
        with torch.enable_grad(), _gradient_checkpoint_recompute_marker():
            output = ctx.forward_function(hidden_states, *recompute_args)
        # Layers that return a 1-tuple keep unpacking exactly as before. Layers
        # that return the tensor itself (Qwen2-VL's vision block, and every
        # transformers block since the tuple returns were retired) used to raise
        # `ValueError: too many values to unpack` here, because forward() stored
        # whatever the layer returned while backward() insisted on a 1-tuple.
        if isinstance(output, tuple):
            (output,) = output
        torch.autograd.backward(output, dY)
        # Gradients for the extra inputs are returned to the engine instead of
        # being left to accumulate as a side effect of the nested backward.
        return (None, hidden_states.grad,) + tuple(
            None if holder is None else holder.grad for holder in grad_holders
        )
    pass
pass


class Unsloth_Gradient_Checkpointer(torch.autograd.Function):
    """
    All Unsloth Zoo code licensed under LGPLv3
    Same as normal gradient checkpointing but cleaner
    """
    @staticmethod
    @torch_amp_custom_fwd
    def forward(ctx, forward_function, hidden_states, *args):
        with torch.no_grad():
            output = forward_function(hidden_states, *args)
        ctx.save_for_backward(hidden_states)
        ctx.forward_function = forward_function
        ctx.args = args
        return output
    pass

    @staticmethod
    @torch_amp_custom_bwd
    def backward(ctx, dY):
        (hidden_states,) = ctx.saved_tensors
        hidden_states = hidden_states.detach()
        hidden_states.requires_grad_(True)
        recompute_args, grad_holders = _detach_checkpoint_args(ctx.args)
        with torch.enable_grad(), _gradient_checkpoint_recompute_marker():
            output = ctx.forward_function(hidden_states, *recompute_args)
        # Layers that return a 1-tuple keep unpacking exactly as before. Layers
        # that return the tensor itself (Qwen2-VL's vision block, and every
        # transformers block since the tuple returns were retired) used to raise
        # `ValueError: too many values to unpack` here, because forward() stored
        # whatever the layer returned while backward() insisted on a 1-tuple.
        if isinstance(output, tuple):
            (output,) = output
        torch.autograd.backward(output, dY)
        # Gradients for the extra inputs are returned to the engine instead of
        # being left to accumulate as a side effect of the nested backward.
        return (None, hidden_states.grad,) + tuple(
            None if holder is None else holder.grad for holder in grad_holders
        )
    pass
pass


# @torch._disable_dynamo
# def unsloth_offloaded_gradient_checkpoint(function, *args, use_reentrant = None, **kwargs):
#     return Unsloth_Offloaded_Gradient_Checkpointer.apply(function, *args)
# pass


# Keywords that belong to the checkpoint machinery itself rather than to the
# wrapped function. The Unsloth reentrant checkpointers below never honoured
# them, and that is deliberately left as-is so callers passing only these see
# exactly today's behaviour. What must NOT happen is binding one of them onto
# the wrapped block: the block has no such parameter and raises TypeError, so a
# call that works against unpatched torch would start failing the moment Unsloth
# swaps torch.utils.checkpoint.checkpoint out from under it.
#
# `early_stop` is the one that was missing: torch grew it as a per-call keyword
# (present on 2.10 and 2.13 here) and documents it as ignored when
# use_reentrant = True - which is exactly what these shims force - so dropping
# it is the faithful behaviour.
_TORCH_CHECKPOINT_KEYWORDS_LITERAL = frozenset({
    "preserve_rng_state",
    "context_fn",
    "determinism_check",
    "debug",
    "early_stop",
})


def _torch_checkpoint_keywords():
    """The literal set above, widened by whatever torch's own ``checkpoint``
    actually declares.

    Read off the live signature so a keyword a later torch adds (the same way it
    added ``early_stop``) is dropped rather than bound onto the block. Falls back
    to the literal set if the signature cannot be read, and unions rather than
    replaces so a signature already replaced by one of the shims below can only
    ever widen the set. ``use_reentrant`` is excluded because every shim names it
    explicitly, so it never reaches ``**kwargs``."""
    # All Unsloth Zoo code licensed under LGPLv3
    names = set(_TORCH_CHECKPOINT_KEYWORDS_LITERAL)
    try:
        checkpoint = getattr(
            torch.utils.checkpoint, "_unsloth_pristine_checkpoint", None,
        ) or torch.utils.checkpoint.checkpoint
        for name, parameter in inspect.signature(checkpoint).parameters.items():
            if parameter.kind is inspect.Parameter.KEYWORD_ONLY:
                names.add(name)
    except Exception:
        pass
    names.discard("use_reentrant")
    return frozenset(names)


_TORCH_CHECKPOINT_KEYWORDS = _torch_checkpoint_keywords()


class _KeywordArgumentCall:
    """Re-form keyword arguments from trailing positional arguments.

    ``functools.partial(function, **extra)`` is the obvious way to turn a
    keyword call into the positional-only call an ``autograd.Function`` can
    make, but a tensor closed over that way is invisible to autograd: it never
    appears in the Function's input list, so the Function cannot return a
    gradient for it. The reentrant checkpointers re-run the wrapped block under
    ``torch.enable_grad()`` and then call ``torch.autograd.backward`` on the
    recomputed output, so a captured non-leaf tensor is walked *through* - its
    own history is traversed inside the nested backward. When that history is
    shared (the same tensor handed to several checkpointed layers, or also
    feeding the loss) the first nested backward frees it and the next traversal
    raises ``Trying to backward through the graph a second time``; when it does
    not raise, the gradient arrives as a side effect of the nested call instead
    of as a Function output.

    So tensors are passed as ordinary positional inputs to the Function - which
    is what makes them visible to autograd - and this callable puts them back
    into keyword position, taking them off the tail of the positional list.
    Non-tensor keywords have no gradient and stay bound directly.
    """
    # All Unsloth Zoo code licensed under LGPLv3
    __slots__ = ("function", "keys", "constants",)

    def __init__(self, function, keys, constants):
        self.function  = function
        self.keys      = keys
        self.constants = constants
    pass

    def __call__(self, *args):
        split = len(args) - len(self.keys)
        kwargs = dict(self.constants)
        kwargs.update(zip(self.keys, args[split:]))
        return self.function(*args[:split], **kwargs)
    pass
pass


def _bind_checkpoint_kwargs(function, kwargs):
    """Bind leftover keyword arguments into ``function``.

    ``checkpoint(fn, *args, **kwargs)`` means "call ``fn(*args, **kwargs)``";
    that is what torch's non-reentrant path does. The Unsloth checkpointers are
    ``torch.autograd.Function`` subclasses and can only forward positionals, so
    the keywords are bound into the callable instead - the same trick
    ``transformers.modeling_layers.GradientCheckpointingLayer.__call__`` uses.

    Before this, ``unsloth_gradient_checkpoint`` /
    ``unsloth_offloaded_gradient_checkpoint`` dropped them silently (the wrapped
    block then ran with different arguments and no diagnostic) while
    ``unsloth_checkpoint`` raised ``Unexpected keyword arguments``. Binding makes
    all three agree and never turns a working call into an error.

    Returns ``(callable, extra_positional_args)``. The extra arguments are the
    keyword values that require grad; the caller must append them to the
    Function's positional inputs so autograd can see them, and
    ``_KeywordArgumentCall`` moves them back into keyword position before the
    block is called. Returns ``function`` unchanged with an empty tuple when
    there is nothing to bind, so the ordinary empty-kwargs path allocates
    nothing and the no-tensor path keeps the cheap ``functools.partial``.
    """
    # All Unsloth Zoo code licensed under LGPLv3
    if not kwargs:
        return function, ()
    extra = {k : v for k, v in kwargs.items() if k not in _TORCH_CHECKPOINT_KEYWORDS}
    if not extra:
        return function, ()
    keys = tuple(
        k for k, v in extra.items() if torch.is_tensor(v) and v.requires_grad
    )
    if not keys:
        return functools.partial(function, **extra), ()
    constants = {k : v for k, v in extra.items() if k not in keys}
    return _KeywordArgumentCall(function, keys, constants), \
        tuple(extra[k] for k in keys)
pass


@torch._disable_dynamo
def unsloth_gradient_checkpoint(function, *args, use_reentrant = None, **kwargs):
    function, tensor_args = _bind_checkpoint_kwargs(function, kwargs)
    return Unsloth_Gradient_Checkpointer.apply(function, *args, *tensor_args)
pass


# Names of the checkpoint shims below; none is the pristine torch fn.
_UNSLOTH_CKPT_SHIM_NAMES = frozenset({
    "unsloth_checkpoint",
    "unsloth_gradient_checkpoint",
    "unsloth_offloaded_gradient_checkpoint",
})


def _capture_pristine_checkpoint_once():
    # Stash the genuine torch.utils.checkpoint.checkpoint the first time we patch, before any
    # shim stacks. The per-patch _old_checkpoint is module-level, so a second patch overwrites
    # it with the first shim and the pristine fn becomes unreachable. Consumers that must force
    # use_reentrant=False (e.g. the Gemma-4 KV-sharing fix) read this set-once ref instead.
    ck = torch.utils.checkpoint
    if getattr(ck, "_unsloth_pristine_checkpoint", None) is not None:
        return
    current = getattr(ck, "checkpoint", None)
    if current is not None and getattr(current, "__name__", "") not in _UNSLOTH_CKPT_SHIM_NAMES:
        ck._unsloth_pristine_checkpoint = current


def patch_unsloth_gradient_checkpointing():
    print("Unsloth: Patched gradient checkpointing for long context finetuning.")
    import torch.utils
    if torch.utils.checkpoint.checkpoint.__name__ == "unsloth_offloaded_gradient_checkpoint": return
    _capture_pristine_checkpoint_once()
    torch.utils.checkpoint._old_checkpoint = torch.utils.checkpoint.checkpoint
    torch.utils.checkpoint.checkpoint = unsloth_offloaded_gradient_checkpoint
    import transformers.modeling_utils
    transformers.modeling_utils.checkpoint = unsloth_offloaded_gradient_checkpoint
    os.environ["UNSLOTH_PATCHED"] = "1"
pass


def patch_gradient_checkpointing():
    print("Unsloth: Patched gradient checkpointing.")
    import torch.utils
    if torch.utils.checkpoint.checkpoint.__name__ == "unsloth_gradient_checkpoint": return
    _capture_pristine_checkpoint_once()
    torch.utils.checkpoint._old_checkpoint = torch.utils.checkpoint.checkpoint
    torch.utils.checkpoint.checkpoint = unsloth_gradient_checkpoint
    import transformers.modeling_utils
    transformers.modeling_utils.checkpoint = unsloth_gradient_checkpoint
    os.environ["UNSLOTH_PATCHED"] = "1"
pass


def unpatch_unsloth_gradient_checkpointing():
    import torch.utils
    if hasattr(torch.utils.checkpoint, "_old_checkpoint"):
        torch.utils.checkpoint.checkpoint = torch.utils.checkpoint._old_checkpoint
        del torch.utils.checkpoint._old_checkpoint
    pass
pass


def unpatch_gradient_checkpointing():
    import torch.utils
    if hasattr(torch.utils.checkpoint, "_old_checkpoint"):
        torch.utils.checkpoint.checkpoint = torch.utils.checkpoint._old_checkpoint
        del torch.utils.checkpoint._old_checkpoint
    pass
pass


from torch.utils.checkpoint import (
    check_backward_validity,
    _infer_device_type,
    _get_autocast_kwargs,
    _get_device_module,
    get_device_states,
    # set_device_states,
    detach_variable,
    contextlib,
    DefaultDeviceType,
)
# Added [device_type] in Torch 2.5!
def set_device_states(devices, states, *, device_type=None) -> None:
    """Set RNG states for the given devices.

    device_type defaults to ``DefaultDeviceType.get_device_type()`` (cuda).
    """
    if device_type is None:
        device_type = DefaultDeviceType.get_device_type()
    if device_type == "meta":
        return
    device_module = _get_device_module(device_type)
    for device, state in zip(devices, states):
        with device_module.device(device):
            device_module.set_rng_state(state)
pass

global CPU_BUFFERS
global CPU_INDEX
global GPU_BUFFERS
global GPU_BUFFERS_B
global USE_DOUBLE_BUFFER
global BACKWARD_PASS
global EXTRA_STREAMS
global MAIN_STREAMS
global MINIMUM_SIZE
global USE_UNSLOTH_GC
global LAST_GC_INDEX
global FIRST_PASS
global CURRENT_GC_INDEX
global BUFFER_EVENTS_A
global BUFFER_EVENTS_B
global NEXT_BUFFER_SLOT

if DEVICE_TYPE in ("cuda", "hip"):
    torch_gpu_stream = torch.cuda.stream
elif DEVICE_TYPE == "xpu":
    torch_gpu_stream = torch.xpu.stream

CPU_BUFFERS = []
CPU_INDEX = None

def initialize_unsloth_gradient_checkpointing(dtype = None):
    # All Unsloth Zoo code licensed under LGPLv3
    global CPU_BUFFERS
    global CPU_INDEX
    global GPU_BUFFERS
    global GPU_BUFFERS_B
    global USE_DOUBLE_BUFFER
    global BACKWARD_PASS
    global EXTRA_STREAMS
    global MAIN_STREAMS
    global MINIMUM_SIZE
    global USE_UNSLOTH_GC
    global LAST_GC_INDEX
    global FIRST_PASS
    global CURRENT_GC_INDEX
    global BUFFER_EVENTS_A
    global BUFFER_EVENTS_B
    global NEXT_BUFFER_SLOT
    CPU_BUFFERS = []
    CPU_INDEX = 0

    if dtype is None:
        if DEVICE_TYPE == "cuda":
            major_version, minor_version = torch.cuda.get_device_capability()
            SUPPORTS_BFLOAT16 = (major_version >= 8)
        elif DEVICE_TYPE == "hip":
            # Ask rather than assume: RDNA 1/2 (gfx101x, gfx103x) have no native bf16,
            # so Triton picks a dot intrinsic LLVM cannot lower and the process dies
            # with no Python exception (unslothai/unsloth issue 7922). Unpatched ROCm
            # still answers True here, so this is inert until unsloth patches the probe.
            SUPPORTS_BFLOAT16 = torch.cuda.is_bf16_supported()
        elif DEVICE_TYPE == "xpu":
            SUPPORTS_BFLOAT16 = True
        dtype = torch.bfloat16 if SUPPORTS_BFLOAT16 else torch.float16
    pass

    with _no_inference_mode():
        for i in range(200):
            x = torch.empty(128*1024, dtype = dtype, device = "cpu", pin_memory = True)
            CPU_BUFFERS.append(x)
    pass

    # Allocate one buffer per GPU
    n_gpus = torch.cuda.device_count() if DEVICE_TYPE in ("cuda", "hip") else torch.xpu.device_count()
    NEXT_BUFFER_SLOT = [0] * n_gpus
    try:
        with _no_inference_mode():
            GPU_BUFFERS = tuple([torch.empty(INITIAL_GPU_BUFFER_SIZE, dtype = dtype, device = f"{DEVICE_TYPE_TORCH}:{i}") for i in range(n_gpus)])
        # Double buffering: try to allocate buffer B (auto-off on unified memory, or via env var)
        if _double_buffer_disabled():
            GPU_BUFFERS_B = None
            USE_DOUBLE_BUFFER = False
            BUFFER_EVENTS_A = None
            BUFFER_EVENTS_B = None
        else:
            try:
                with _no_inference_mode():
                    GPU_BUFFERS_B = tuple([torch.empty(INITIAL_GPU_BUFFER_SIZE, dtype = dtype, device = f"{DEVICE_TYPE_TORCH}:{i}") for i in range(n_gpus)])
                USE_DOUBLE_BUFFER = False # enabled after first pass if CUDA free memory > DOUBLE_BUFFER_HEADROOM
                # Per-buffer events prevent double-buffering races; each tracks
                # when compute on that buffer finishes
                if DEVICE_TYPE in ("cuda", "hip"):
                    event_ctor = torch.cuda.Event
                elif DEVICE_TYPE == "xpu":
                    event_ctor = torch.xpu.Event
                else:
                    raise RuntimeError(f"Double buffering unsupported on {DEVICE_TYPE}")
                BUFFER_EVENTS_A = tuple([event_ctor() for _ in range(n_gpus)])
                BUFFER_EVENTS_B = tuple([event_ctor() for _ in range(n_gpus)])
            except RuntimeError as e:
                if "out of memory" not in str(e).lower():
                    raise
                GPU_BUFFERS_B = None
                USE_DOUBLE_BUFFER = False
                BUFFER_EVENTS_A = None
                BUFFER_EVENTS_B = None
    except Exception as e:
        print("="*10 + "\n")
        print("Unsloth: Your setup does not support `PYTORCH_CUDA_ALLOC_CONF`\n")
        print("Please set `import os; os.environ['PYTORCH_CUDA_ALLOC_CONF'] = '';`\n")
        print("Then re-run Unsloth from the start.")
        print("="*10 + "\n")
        raise

    BACKWARD_PASS = True
    EXTRA_STREAMS = tuple([torch.cuda.Stream() if DEVICE_TYPE_TORCH == "cuda" else torch.xpu.Stream() for i in range(n_gpus)])
    if DEVICE_TYPE in ("cuda", "hip"):
        MAIN_STREAMS  = tuple([torch.cuda.default_stream(torch.device(f"cuda:{i}")) for i in range(n_gpus)])
    elif DEVICE_TYPE == "xpu":
        MAIN_STREAMS  = tuple([torch.xpu.current_stream(torch.device(f"xpu:{i}")) for i in range(n_gpus)])

    # Minimum size to enable Unsloth GC is 2MB -> 32 layers = 64MB
    n_bytes = torch.finfo(dtype).bits // 8
    MINIMUM_SIZE = 2 * 1024 * 1024 // n_bytes
    USE_UNSLOTH_GC = True

    # Don't offload the last layer - uses more VRAM and is slower
    # See https://github.com/pytorch/torchtune/pull/1443
    LAST_GC_INDEX = 0
    FIRST_PASS = True
    CURRENT_GC_INDEX = 0
pass


class UnslothCheckpointFunction(torch.autograd.Function):

    @staticmethod
    def forward(ctx, run_function, preserve_rng_state, *args):
        # All Unsloth Zoo code licensed under LGPLv3
        ctx.run_function = run_function
        ctx.preserve_rng_state = preserve_rng_state
        # Handle autocast enabled for cpu AND gpu.
        ctx.device_type = _infer_device_type(*args)
        ctx.device_autocast_kwargs, ctx.cpu_autocast_kwargs = _get_autocast_kwargs(
            ctx.device_type
        )
        if preserve_rng_state:
            ctx.fwd_cpu_state = torch.get_rng_state()
            # Don't eagerly initialize the cuda context by accident: we can't
            # anticipate run_function initializing it later, so don't stash here.
            ctx.had_device_in_fwd = False
            device_module = _get_device_module(ctx.device_type)
            if getattr(device_module, "_initialized", False):
                ctx.had_device_in_fwd = True
                ctx.fwd_devices, ctx.fwd_device_states = get_device_states(*args)

        # Save non-tensor inputs in ctx, keep a placeholder None for tensors
        # to be filled out during the backward.
        ctx.inputs = []
        ctx.tensor_indices = []
        tensor_inputs = []
        ctx._requires_gradient = False
        # Read unconditionally in backward, so it needs a value on every path
        # that never takes the offload branch below.
        ctx._saved_metadata = (None, None, None, None, None, None, None,)
        use_gpu_buffer = False

        for i, arg in enumerate(args):
            if torch.is_tensor(arg):
                # ANY differentiable input means this Function has a gradient to
                # produce, exactly as torch's own reentrant CheckpointFunction
                # (which saves unconditionally) does. Keying this off input zero
                # alone made backward bail out early - and it is reached, since
                # autograd only calls backward when some input requires grad -
                # so the engine got a single None instead of one gradient per
                # input and raised `returned an incorrect number of gradients`.
                # A frozen first activation next to a differentiable later one
                # is ordinary: an untrained embedding feeding layer 0 alongside
                # a learned positional/query tensor, or a tensor keyword routed
                # positionally by _bind_checkpoint_kwargs.
                if arg.requires_grad: ctx._requires_gradient = True

                if i == 0 and arg.requires_grad:
                    global FIRST_PASS
                    global LAST_GC_INDEX
                    if FIRST_PASS:
                        # Save last layer index so next run skips offloading it
                        # (saves VRAM and time). See
                        # https://github.com/pytorch/torchtune/pull/1443
                        LAST_GC_INDEX += 1
                    pass
                    global CURRENT_GC_INDEX
                    CURRENT_GC_INDEX += 1

                    new_size = arg.numel()

                    global MINIMUM_SIZE
                    global CPU_INDEX
                    if new_size > MINIMUM_SIZE and ((CURRENT_GC_INDEX != LAST_GC_INDEX) or FIRST_PASS):
                        use_gpu_buffer = True
                        global CPU_BUFFERS
                        global GPU_BUFFERS
                        global GPU_BUFFERS_B
                        global USE_DOUBLE_BUFFER
                        global BACKWARD_PASS
                        global EXTRA_STREAMS
                        global MAIN_STREAMS
                        device = arg.device
                        device_index = device.index
                        GPU_BUFFER   = GPU_BUFFERS  [device_index]
                        MAIN_STREAM  = MAIN_STREAMS [device_index]
                        EXTRA_STREAM = EXTRA_STREAMS[device_index]

                        # Handle interrupted training runs
                        if BACKWARD_PASS:
                            BACKWARD_PASS = False
                            CPU_INDEX = 0
                            if not FIRST_PASS and not USE_DOUBLE_BUFFER and GPU_BUFFERS_B is not None:
                                try:
                                    if DEVICE_TYPE in ("cuda", "hip"):
                                        free_mem, _ = torch.cuda.mem_get_info(device_index)
                                    elif DEVICE_TYPE == "xpu":
                                        free_mem, _ = torch.xpu.mem_get_info(device_index)
                                    else:
                                        free_mem = 0
                                except Exception as e:
                                    free_mem = 0
                                if free_mem > DOUBLE_BUFFER_HEADROOM:
                                    USE_DOUBLE_BUFFER = True
                                    print(f"Unsloth: Double buffering enabled (parallel H2D + compute) for backward pass.")
                                else:
                                    for j in range(len(GPU_BUFFERS_B)):
                                        GPU_BUFFERS_B[j].resize_(0)
                                    GPU_BUFFERS_B = None
                        pass

                        # Extend buffer size
                        if CPU_INDEX >= len(CPU_BUFFERS):
                            with _no_inference_mode():
                                x = torch.empty(new_size, dtype = arg.dtype, device = "cpu", pin_memory = True)
                            CPU_BUFFERS.append(x)
                        pass

                        x = CPU_BUFFERS[CPU_INDEX]
                        shape = arg.shape
                        if new_size > x.numel(): x.resize_(new_size)
                        if new_size > GPU_BUFFER.numel():
                            try:
                                GPU_BUFFER.resize_(new_size)
                            except RuntimeError as e:
                                if "out of memory" not in str(e).lower():
                                    raise
                                # Clear buffer B and resize the single buffer
                                if GPU_BUFFERS_B is not None:
                                    USE_DOUBLE_BUFFER = False
                                    for j in range(len(GPU_BUFFERS_B)):
                                        GPU_BUFFERS_B[j].resize_(0)
                                    GPU_BUFFERS_B = None
                                    print("Unsloth: Disabled double buffering due to insufficient VRAM.")
                                    GPU_BUFFER.resize_(new_size)
                                else:
                                    raise
                        # Resize buffer B when double buffering; disable + free B on OOM
                        if USE_DOUBLE_BUFFER:
                            GPU_BUFFER_B = GPU_BUFFERS_B[device_index]
                            if new_size > GPU_BUFFER_B.numel():
                                try:
                                    GPU_BUFFER_B.resize_(new_size)
                                except RuntimeError as e:
                                    if "out of memory" not in str(e).lower():
                                        raise
                                    USE_DOUBLE_BUFFER = False
                                    for j in range(len(GPU_BUFFERS_B)):
                                        GPU_BUFFERS_B[j].resize_(0)
                                    GPU_BUFFERS_B = None
                                    print("Unsloth: Disabled double buffering due to insufficient VRAM.")

                        x = x[:new_size].view(shape)

                        # See https://pytorch.org/docs/stable/notes/cuda.html#cuda-streams
                        EXTRA_STREAM.wait_stream(MAIN_STREAM)
                        # x is a normal (non-inference) buffer, so copy_ is safe (unsloth#3828).
                        with torch_gpu_stream(EXTRA_STREAM):
                            x.copy_(arg, non_blocking = True)

                        global NEXT_BUFFER_SLOT
                        buffer_slot = NEXT_BUFFER_SLOT[device_index]
                        NEXT_BUFFER_SLOT[device_index] ^= 1
                        ctx._saved_metadata = (new_size, shape, CPU_INDEX, device_index, MAIN_STREAM, EXTRA_STREAM, buffer_slot,)
                        CPU_INDEX += 1
                        tensor_inputs.append(None)

                        global USE_UNSLOTH_GC
                        if USE_UNSLOTH_GC:
                            print("Unsloth: Will smartly offload gradients to save VRAM!")
                            USE_UNSLOTH_GC = False
                    else:
                        ctx._saved_metadata = (None, None, None, None, None, None, None,)
                        tensor_inputs.append(arg)
                    pass
                else:
                    tensor_inputs.append(arg)
                pass
                ctx.tensor_indices.append(i)
                ctx.inputs.append(None)
            else:
                ctx.inputs.append(arg)
            pass
        pass
        if ctx._requires_gradient: ctx.save_for_backward(*tensor_inputs)

        with torch.no_grad():
            outputs = run_function(*args)

        if use_gpu_buffer: MAIN_STREAM.wait_stream(EXTRA_STREAM)
        return outputs
    pass


    @staticmethod
    def backward(ctx, *args):
        # All Unsloth Zoo code licensed under LGPLv3
        if not ctx._requires_gradient: return None

        if not torch.autograd._is_checkpoint_valid():
            raise RuntimeError(
                "When use_reentrant=True, torch.utils.checkpoint is incompatible"
                " with .grad() or passing an `inputs` parameter to .backward()."
                " To resolve this error, you can either set use_reentrant=False,"
                " or call .backward() without passing the `inputs` argument."
            )

        # Copy the list to avoid modifying original list.
        inputs = list(ctx.inputs)
        tensor_indices = ctx.tensor_indices
        tensors = ctx.saved_tensors

        new_size, shape, CPU_INDEX, device_index, MAIN_STREAM, EXTRA_STREAM, buffer_slot = ctx._saved_metadata
        if CPU_INDEX is not None:
            global GPU_BUFFER
            global USE_DOUBLE_BUFFER
            global GPU_BUFFERS_B
            global BUFFER_EVENTS_A
            global BUFFER_EVENTS_B
            # Select buffer from per-device buffer_slot
            if USE_DOUBLE_BUFFER and buffer_slot == 1:
                buffer = GPU_BUFFERS_B[device_index][:new_size].view(shape)
            else:
                buffer = GPU_BUFFERS[device_index][:new_size].view(shape)

            x = CPU_BUFFERS[CPU_INDEX][:new_size].view(shape)

            # See https://pytorch.org/docs/stable/notes/cuda.html#cuda-streams
            if USE_DOUBLE_BUFFER:
                # Wait for the last compute on THIS buffer to finish
                event_buffer = BUFFER_EVENTS_B if buffer_slot == 1 else BUFFER_EVENTS_A
                EXTRA_STREAM.wait_event(event_buffer[device_index])
            else:
                # Single buffer mode: wait for MAIN_STREAM
                EXTRA_STREAM.wait_stream(MAIN_STREAM)

            # buffer is a normal (non-inference) buffer, so this reload copy_ is safe (unsloth#3828).
            with torch_gpu_stream(EXTRA_STREAM):
                buffer.copy_(x, non_blocking = True)
        else:
            # No GPU buffer seen
            if len(tensor_indices) != 0:
                inputs[tensor_indices[0]] = tensors[0]
        pass

        # Fill in inputs with appropriate saved tensors.
        for i, idx in enumerate(tensor_indices[1:], start = 1):
            inputs[idx] = tensors[i]
        pass

        global BACKWARD_PASS
        BACKWARD_PASS = True
        global FIRST_PASS
        FIRST_PASS = False
        global CURRENT_GC_INDEX
        CURRENT_GC_INDEX = 0

        # Stash the surrounding rng state, mimic the forward state, then
        # restore the surrounding state when done.
        rng_devices = []
        if ctx.preserve_rng_state and ctx.had_device_in_fwd:
            rng_devices = ctx.fwd_devices
        with torch.random.fork_rng(
            devices=rng_devices, enabled=ctx.preserve_rng_state, device_type=ctx.device_type
        ):
            if ctx.preserve_rng_state:
                torch.set_rng_state(ctx.fwd_cpu_state)
                if ctx.had_device_in_fwd:
                    set_device_states(ctx.fwd_devices, ctx.fwd_device_states, device_type=ctx.device_type)

            device_autocast_ctx = torch.amp.autocast(
                device_type=ctx.device_type, **ctx.device_autocast_kwargs
            ) if torch.amp.is_autocast_available(ctx.device_type) else nullcontext()

            # detached_inputs = detach_variable(tuple(inputs))
            detached_inputs = []
            for inp in inputs:
                if not isinstance(inp, torch.Tensor):
                    detached_inputs.append(inp)
                    continue
                x = inp.detach()
                x.requires_grad = inp.requires_grad
                detached_inputs.append(x)
            pass

            # Wait for GPU buffer to finish
            if CPU_INDEX is not None:
                MAIN_STREAM.wait_stream(EXTRA_STREAM)
                x = buffer.detach()
                x.requires_grad_(True)
                detached_inputs[0] = x
            pass

            with torch.enable_grad(), device_autocast_ctx, torch.amp.autocast("cpu", **ctx.cpu_autocast_kwargs), _gradient_checkpoint_recompute_marker():  # type: ignore[attr-defined]
                outputs = ctx.run_function(*detached_inputs)
            pass
        pass

        if isinstance(outputs, torch.Tensor):
            outputs = (outputs,)

        # run backward() with only tensor that requires grad
        outputs_with_grad = []
        args_with_grad = []
        for i in range(len(outputs)):
            if torch.is_tensor(outputs[i]) and outputs[i].requires_grad:
                outputs_with_grad.append(outputs[i])
                args_with_grad.append(args[i])
        pass

        if len(outputs_with_grad) == 0:
            pass
            # raise RuntimeError(
            #     "none of output has requires_grad=True,"
            #     " this checkpoint() is not necessary"
            # )
        else:
            torch.autograd.backward(outputs_with_grad, args_with_grad)
        pass

        # Record event after compute so the copy stream can wait on it
        if CPU_INDEX is not None and USE_DOUBLE_BUFFER:
            event_buffer = BUFFER_EVENTS_B if buffer_slot == 1 else BUFFER_EVENTS_A
            event_buffer[device_index].record(MAIN_STREAM)

        grads = tuple(
            inp.grad if isinstance(inp, torch.Tensor) else None
            for inp in detached_inputs
        )
        # Clear all memory
        for i in range(len(detached_inputs)):
            detached_inputs[i] = None
            inputs[i] = None
        pass

        return (None, None) + grads
    pass
pass


from torch.utils.checkpoint import (
    ContextManager,
    _DEFAULT_DETERMINISM_MODE,
    _checkpoint_without_reentrant_generator,
    noop_context_fn,
)
@torch._disable_dynamo
def unsloth_checkpoint(
    function,
    *args,
    use_reentrant: Optional[bool] = None,
    context_fn: Callable[[], Tuple[ContextManager, ContextManager]] = noop_context_fn,
    determinism_check: str = _DEFAULT_DETERMINISM_MODE,
    debug: bool = False,
    **kwargs
):
    r"""Activation checkpoint a model or part of the model.

    Trades compute for memory: forward in checkpointed regions omits saving
    tensors for backward and recomputes them during the backward pass.

    This is Unsloth's drop-in for ``torch.utils.checkpoint.checkpoint``; it
    forces ``use_reentrant=True`` to route through UnslothCheckpointFunction
    (smart CPU offloading). The ``context_fn`` / ``determinism_check`` /
    ``debug`` args are only valid with ``use_reentrant=False`` and raise here.

    .. warning::

        If :attr:`function` behaves differently in backward vs forward (e.g.
        via a global), recomputation may error or yield wrong gradients.

    Args:
        function: forward pass to run; must handle the passed input tuple.
        args: inputs to :attr:`function`.

    Returns:
        Output of running :attr:`function` on :attr:`*args`.
    """
    # Force use_reentrant=True so UnslothCheckpointFunction (smart CPU offloading)
    # is always used. This is safe because unsloth_checkpoint is only active when
    # smart GC is patched; when unpatched, the original torch checkpoint is restored.
    # Fixes transformers 5.2 which defaults use_reentrant=False, bypassing Unsloth.
    use_reentrant = True

    # Hack to mix *args with **kwargs in a python 2.7-compliant way
    preserve = kwargs.pop("preserve_rng_state", True)
    if kwargs and use_reentrant:
        # torch raises here, but only because *the caller* asked for the
        # reentrant path. We force use_reentrant = True above, so raising would
        # turn a call that works on unpatched torch (non-reentrant checkpoint
        # forwards **kwargs straight to `function`) into a crash the moment
        # Unsloth's smart gradient checkpointing is installed. Bind them into
        # the callable instead - same observable behaviour, no keyword reaches
        # UnslothCheckpointFunction. See _bind_checkpoint_kwargs.
        function, extra_args = _bind_checkpoint_kwargs(function, kwargs)
        args = args + extra_args
        kwargs = {}

    if use_reentrant:
        if context_fn is not noop_context_fn or debug is not False:
            raise ValueError(
                "Passing `context_fn` or `debug` is only supported when "
                "use_reentrant=False."
            )
        return UnslothCheckpointFunction.apply(function, preserve, *args)
    else:
        gen = _checkpoint_without_reentrant_generator(
            function, preserve, context_fn, determinism_check, debug, *args, **kwargs
        )
        # Runs pre-forward logic
        next(gen)
        ret = function(*args, **kwargs)
        # Runs post-forward logic
        try:
            next(gen)
        except StopIteration:
            return ret
pass


def patch_unsloth_smart_gradient_checkpointing(dtype = None):
    # All Unsloth Zoo code licensed under LGPLv3
    if torch.utils.checkpoint.CheckpointFunction.__name__ != "UnslothCheckpointFunction":
        initialize_unsloth_gradient_checkpointing(dtype)
        torch.utils.checkpoint._old_CheckpointFunction = torch.utils.checkpoint.CheckpointFunction
        torch.utils.checkpoint.CheckpointFunction = UnslothCheckpointFunction

    if torch.utils.checkpoint.checkpoint.__name__ != "unsloth_checkpoint":
        _capture_pristine_checkpoint_once()
        torch.utils.checkpoint._old_checkpoint = torch.utils.checkpoint.checkpoint
        torch.utils.checkpoint.checkpoint = unsloth_checkpoint

    # Always patch transformers.modeling_utils.checkpoint so
    # gradient_checkpointing_enable() wraps unsloth_checkpoint; otherwise
    # transformers 5.2's use_reentrant=False default bypasses
    # UnslothCheckpointFunction. Outside the conditional above since
    # torch.utils.checkpoint may already be patched while this one is not.
    import transformers.modeling_utils
    transformers.modeling_utils.checkpoint = unsloth_checkpoint
pass


def unpatch_unsloth_smart_gradient_checkpointing():
    # All Unsloth Zoo code licensed under LGPLv3
    if (torch.utils.checkpoint.CheckpointFunction.__name__ == "UnslothCheckpointFunction") and \
        hasattr(torch.utils.checkpoint, "_old_CheckpointFunction"):

        torch.utils.checkpoint.CheckpointFunction = torch.utils.checkpoint._old_CheckpointFunction
        global CPU_BUFFERS
        global GPU_BUFFERS
        global GPU_BUFFERS_B
        global USE_DOUBLE_BUFFER
        global BUFFER_EVENTS_A
        global BUFFER_EVENTS_B
        global NEXT_BUFFER_SLOT
        for i in range(len(CPU_BUFFERS)):
            if hasattr(CPU_BUFFERS[i], "resize_"): CPU_BUFFERS[i].resize_(0)
            if type(CPU_BUFFERS) is list: CPU_BUFFERS[i] = None
        for i in range(len(GPU_BUFFERS)):
            if hasattr(GPU_BUFFERS[i], "resize_"): GPU_BUFFERS[i].resize_(0)
            if type(GPU_BUFFERS) is list: GPU_BUFFERS[i] = None
        if GPU_BUFFERS_B is not None:
            for i in range(len(GPU_BUFFERS_B)):
                if hasattr(GPU_BUFFERS_B[i], "resize_"): GPU_BUFFERS_B[i].resize_(0)
            GPU_BUFFERS_B = None
            USE_DOUBLE_BUFFER = False
        CPU_BUFFERS = None
        GPU_BUFFERS = None
        BUFFER_EVENTS_A = None
        BUFFER_EVENTS_B = None
        NEXT_BUFFER_SLOT = None
        torch.cuda.empty_cache()
        gc.collect()

    if (torch.utils.checkpoint.checkpoint.__name__ == "unsloth_checkpoint") and \
        hasattr(torch.utils.checkpoint, "_old_checkpoint"):

        torch.utils.checkpoint.checkpoint = torch.utils.checkpoint._old_checkpoint

    # Restore transformers.modeling_utils.checkpoint independently: an earlier
    # unpatch_unsloth_gradient_checkpointing() (e.g. training_utils.py:201) may
    # have deleted _old_checkpoint and restored torch.utils.checkpoint,
    # making the condition above False. Prefer _old_checkpoint, else the
    # already-restored torch.utils.checkpoint.checkpoint.
    import transformers.modeling_utils
    if getattr(transformers.modeling_utils, "checkpoint", None) is unsloth_checkpoint:
        transformers.modeling_utils.checkpoint = getattr(
            torch.utils.checkpoint, "_old_checkpoint",
            torch.utils.checkpoint.checkpoint
        )
pass


def reset_unsloth_gradient_checkpointing_buffers():
    """
    All Unsloth Zoo code licensed under LGPLv3

    Reset CPU_BUFFERS and GPU_BUFFERS to their initial sizes after training.

    Call after trainer.train() to free training-allocated memory while keeping
    buffers ready for another run. Unlike unpatch_unsloth_smart_gradient_checkpointing,
    this neither destroys the buffers nor unpatches checkpointing.
    """
    global CPU_BUFFERS
    global GPU_BUFFERS
    global CPU_INDEX
    global BACKWARD_PASS
    global LAST_GC_INDEX
    global FIRST_PASS
    global CURRENT_GC_INDEX
    global USE_UNSLOTH_GC
    global NEXT_BUFFER_SLOT
    global GPU_BUFFERS_B
    global USE_DOUBLE_BUFFER
    global BUFFER_EVENTS_A
    global BUFFER_EVENTS_B

    if CPU_BUFFERS is None or GPU_BUFFERS is None:
        return
    if len(CPU_BUFFERS) == 0:
        return

    # Reset CPU buffers to initial size; free any added during training
    for i in range(len(CPU_BUFFERS)):
        if i < INITIAL_CPU_BUFFER_COUNT:
            if CPU_BUFFERS[i] is not None and hasattr(CPU_BUFFERS[i], "resize_"):
                CPU_BUFFERS[i].resize_(INITIAL_CPU_BUFFER_SIZE)
        else:
            if CPU_BUFFERS[i] is not None and hasattr(CPU_BUFFERS[i], "resize_"):
                CPU_BUFFERS[i].resize_(0)
            CPU_BUFFERS[i] = None
    pass

    # Trim the list back to initial count if it grew
    if len(CPU_BUFFERS) > INITIAL_CPU_BUFFER_COUNT:
        del CPU_BUFFERS[INITIAL_CPU_BUFFER_COUNT:]
    pass

    # Reset GPU buffers to initial size
    for i in range(len(GPU_BUFFERS)):
        if GPU_BUFFERS[i] is not None and hasattr(GPU_BUFFERS[i], "resize_"):
            GPU_BUFFERS[i].resize_(INITIAL_GPU_BUFFER_SIZE)
    pass

    # Reset state for a fresh training run
    CPU_INDEX = 0
    BACKWARD_PASS = True
    LAST_GC_INDEX = 0
    FIRST_PASS = True
    CURRENT_GC_INDEX = 0
    USE_UNSLOTH_GC = True  # re-enable the "Will smartly offload" message
    if NEXT_BUFFER_SLOT is not None:
        for i in range(len(NEXT_BUFFER_SLOT)):
            NEXT_BUFFER_SLOT[i] = 0

    # Reset double buffering if buffer B still exists, or try to re-allocate
    if _double_buffer_disabled():
        if GPU_BUFFERS_B is not None:
            for i in range(len(GPU_BUFFERS_B)):
                if GPU_BUFFERS_B[i] is not None and hasattr(GPU_BUFFERS_B[i], "resize_"):
                    GPU_BUFFERS_B[i].resize_(0)
            GPU_BUFFERS_B = None
        USE_DOUBLE_BUFFER = False
    elif GPU_BUFFERS_B is not None:
        for i in range(len(GPU_BUFFERS_B)):
            if GPU_BUFFERS_B[i] is not None and hasattr(GPU_BUFFERS_B[i], "resize_"):
                GPU_BUFFERS_B[i].resize_(INITIAL_GPU_BUFFER_SIZE)
        USE_DOUBLE_BUFFER = False
    else:
        try:
            n_gpus = len(GPU_BUFFERS)
            dtype = GPU_BUFFERS[0].dtype
            with _no_inference_mode():
                GPU_BUFFERS_B = tuple([torch.empty(INITIAL_GPU_BUFFER_SIZE, dtype=dtype, device=f"{DEVICE_TYPE_TORCH}:{i}") for i in range(n_gpus)])
            if DEVICE_TYPE in ("cuda", "hip"):
                event_ctor = torch.cuda.Event
            elif DEVICE_TYPE == "xpu":
                event_ctor = torch.xpu.Event
            else:
                raise RuntimeError(f"Double buffering unsupported on {DEVICE_TYPE}")
            BUFFER_EVENTS_A = tuple([event_ctor() for _ in range(n_gpus)])
            BUFFER_EVENTS_B = tuple([event_ctor() for _ in range(n_gpus)])
            USE_DOUBLE_BUFFER = False
        except RuntimeError:
            pass

    torch.cuda.empty_cache()
    gc.collect()
pass


@torch._disable_dynamo
def unsloth_offloaded_gradient_checkpoint(function, *args, use_reentrant = None, **kwargs):
    global CPU_BUFFERS
    if len(CPU_BUFFERS) == 0:
        initialize_unsloth_gradient_checkpointing(args[0].dtype)
    function, tensor_args = _bind_checkpoint_kwargs(function, kwargs)
    return UnslothCheckpointFunction.apply(function, *args, *tensor_args)
pass

# Unsloth Zoo - Utilities for Unsloth
# Copyright 2023-present Daniel Han-Chen, Michael Han-Chen & the Unsloth team. All rights reserved.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
