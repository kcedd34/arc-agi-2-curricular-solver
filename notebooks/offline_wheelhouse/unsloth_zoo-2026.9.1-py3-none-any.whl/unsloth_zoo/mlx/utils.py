# Unsloth Zoo - Utilities for Unsloth
# Copyright 2023-present Daniel Han-Chen, Michael Han-Chen & the Unsloth team. All rights reserved.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""
MLX utilities for Apple Silicon training.

Provides loss functions (CCE and baseline CE), data batching,
weight extraction helpers, and model save/load/export for LoRA adapters
and merged models (safetensors, GGUF, HuggingFace Hub).
"""

import mlx.core as mx
import mlx.nn as nn
import mlx.utils
import ast
import collections
import contextlib
import contextvars
import copy
import dis
import inspect
import itertools
import importlib
import importlib.util
import json
import math
import numbers
import operator
import textwrap
import numpy as np
import os
import random
import re
import sys
import shutil
import struct
import tempfile
import queue as _queue_module
import threading
import time
import unicodedata
import warnings
import weakref
import zlib
from collections.abc import Iterator, Mapping, Sequence
from dataclasses import dataclass
from functools import lru_cache, partial, wraps
from pathlib import Path
from typing import NamedTuple

from packaging.version import Version as _Version


from unsloth_zoo.mlx.cce import _get_runtime_cce
from unsloth_zoo.mlx.cce.runtime_cce import _normalize_label_smoothing


_LLAMA_CPP_PATCHER_ENV_LOCK = threading.Lock()


def _safe_token_denominator(ntoks):
    return mx.maximum(ntoks.astype(mx.float32), mx.array(1.0, dtype=mx.float32))


def _normalize_seed(seed, default=3407):
    return default if seed is None else int(seed)


class _MLXNormOutputCastState:
    __slots__ = ("patched_classes", "missing", "lock")

    def __init__(self):
        self.patched_classes = set()
        self.missing = object()
        self.lock = threading.RLock()


_MLX_NORM_OUTPUT_CAST_STATE = _MLXNormOutputCastState()


def _mlx_norm_path_part_is_norm(part: str) -> bool:
    # "norm" matches RMSNorm/LayerNorm/input_layernorm; ln_* covers GPT-2/GPT-OSS.
    return "norm" in part or part.startswith("ln_") or part == "ln_f"


def is_mlx_norm_parameter_path(path) -> bool:
    parts = str(path).lower().split(".")
    return any(_mlx_norm_path_part_is_norm(part) for part in parts[:-1])


def is_mlx_norm_module_path(path) -> bool:
    return any(
        _mlx_norm_path_part_is_norm(part)
        for part in str(path).lower().split(".")
    )


def _join_mlx_parameter_path(module_path, parameter_path):
    if module_path and parameter_path:
        return f"{module_path}.{parameter_path}"
    return module_path or parameter_path


def _mlx_norm_runtime():
    import mlx.core as _mx
    import mlx.nn as _nn
    from mlx.utils import tree_flatten as _tree_flatten

    return _mx, _nn, _tree_flatten


def _has_mlx_norm_selected_floating_parameter(module_path, module) -> bool:
    _mx, _nn, tree_flatten = _mlx_norm_runtime()
    try:
        parameters = module.parameters()
    except Exception:
        return False

    module_path_selected = is_mlx_norm_module_path(module_path)
    try:
        for parameter_path, value in tree_flatten(parameters):
            if (
                hasattr(value, "dtype")
                and _mx.issubdtype(value.dtype, _mx.floating)
                and (
                    module_path_selected
                    or is_mlx_norm_parameter_path(parameter_path)
                    or is_mlx_norm_parameter_path(
                        _join_mlx_parameter_path(module_path, parameter_path)
                    )
                )
            ):
                return True
    except Exception:
        return False
    return False


def _has_mlx_floating_parameter(module) -> bool:
    _mx, _nn, tree_flatten = _mlx_norm_runtime()
    try:
        parameters = module.parameters()
    except Exception:
        return False

    try:
        for _, value in tree_flatten(parameters):
            if hasattr(value, "dtype") and _mx.issubdtype(value.dtype, _mx.floating):
                return True
    except Exception:
        return False
    return False


def _has_mlx_parameterized_non_norm_children(module) -> bool:
    _mx, _nn, tree_flatten = _mlx_norm_runtime()
    try:
        children = module.children()
    except Exception:
        return False

    try:
        is_module = getattr(_nn.Module, "is_module", None)
        child_items = (
            tree_flatten(children, is_leaf=is_module)
            if is_module is not None else tree_flatten(children)
        )
        for _, child in child_items:
            if (
                isinstance(child, _nn.Module)
                and "norm" not in type(child).__name__.lower()
                and _has_mlx_floating_parameter(child)
            ):
                return True
    except Exception:
        return False
    return False


def is_mlx_norm_output_cast_candidate(module_path, module) -> bool:
    """Return whether a custom module itself produces norm-like output."""
    _mx, _nn, tree_flatten = _mlx_norm_runtime()
    base_norm_classes = tuple(
        cls for cls in (getattr(_nn, "RMSNorm", None), getattr(_nn, "LayerNorm", None))
        if isinstance(cls, type)
    )
    norm_cls = type(module)
    if base_norm_classes and issubclass(norm_cls, base_norm_classes):
        return True
    if "norm" not in norm_cls.__name__.lower():
        return False
    if _has_mlx_parameterized_non_norm_children(module):
        return False
    if not _has_mlx_norm_selected_floating_parameter(module_path, module):
        return False
    return True


def mlx_norm_input_dtype(args, kwargs):
    for value in args:
        if hasattr(value, "dtype"):
            return value.dtype
    for value in kwargs.values():
        if hasattr(value, "dtype"):
            return value.dtype
    return None


def iter_mlx_norm_output_cast_classes(model=None):
    _mx, _nn, tree_flatten = _mlx_norm_runtime()
    norm_classes = []
    seen = set()

    for norm_cls in (getattr(_nn, "RMSNorm", None), getattr(_nn, "LayerNorm", None)):
        if isinstance(norm_cls, type):
            norm_classes.append(norm_cls)
            seen.add(norm_cls)

    if model is not None:
        try:
            named_modules = model.named_modules()
        except Exception:
            named_modules = ()
        for module_path, module in named_modules:
            if is_mlx_norm_output_cast_candidate(module_path, module):
                norm_cls = type(module)
                if norm_cls not in seen:
                    norm_classes.append(norm_cls)
                    seen.add(norm_cls)

    return tuple(norm_classes)


def _set_mlx_norm_output_cast_classes(enabled: bool, norm_classes) -> None:
    patched_classes = _MLX_NORM_OUTPUT_CAST_STATE.patched_classes
    for norm_cls in norm_classes:
        patched = norm_cls in patched_classes
        if enabled:
            original_call = norm_cls.__call__
            current_is_wrapper = getattr(
                original_call, "_unsloth_norm_output_cast_wrapper", False
            )
            if patched and not current_is_wrapper:
                patched_classes.discard(norm_cls)
                patched = False
            if (
                patched
                or current_is_wrapper
            ):
                continue

            def norm_call_cast_output(self, *args, _original_call=original_call, **kwargs):
                input_dtype = mlx_norm_input_dtype(args, kwargs)
                out = _original_call(self, *args, **kwargs)
                if (
                    input_dtype is not None
                    and hasattr(out, "dtype")
                    and out.dtype != input_dtype
                ):
                    return out.astype(input_dtype)
                return out

            norm_call_cast_output._unsloth_norm_output_cast_wrapper = True
            norm_call_cast_output._unsloth_original_call = original_call
            norm_cls._unsloth_original_call = original_call
            norm_cls.__call__ = norm_call_cast_output
            norm_cls._unsloth_cast_output_to_input_dtype = True
            patched_classes.add(norm_cls)
        elif patched:
            if not getattr(norm_cls.__call__, "_unsloth_norm_output_cast_wrapper", False):
                patched_classes.discard(norm_cls)
                continue
            original_call = getattr(norm_cls, "_unsloth_original_call", None)
            if original_call is not None:
                norm_cls.__call__ = original_call
            norm_cls._unsloth_original_call = None
            norm_cls._unsloth_cast_output_to_input_dtype = False
            patched_classes.discard(norm_cls)


def mlx_norm_output_cast_patched_classes():
    with _MLX_NORM_OUTPUT_CAST_STATE.lock:
        return tuple(_MLX_NORM_OUTPUT_CAST_STATE.patched_classes)


def snapshot_mlx_norm_output_cast_state(norm_classes=None):
    with _MLX_NORM_OUTPUT_CAST_STATE.lock:
        patched_classes = _MLX_NORM_OUTPUT_CAST_STATE.patched_classes
        missing = _MLX_NORM_OUTPUT_CAST_STATE.missing
        snapshot_classes = []
        seen = set()
        for norm_cls in patched_classes:
            snapshot_classes.append(norm_cls)
            seen.add(norm_cls)
        for norm_cls in norm_classes or ():
            if isinstance(norm_cls, type) and norm_cls not in seen:
                snapshot_classes.append(norm_cls)
                seen.add(norm_cls)

        return tuple(
            (
                norm_cls,
                norm_cls in patched_classes,
                norm_cls.__dict__.get("__call__", missing),
                norm_cls.__dict__.get(
                    "_unsloth_original_call",
                    missing,
                ),
                norm_cls.__dict__.get(
                    "_unsloth_cast_output_to_input_dtype",
                    missing,
                ),
            )
            for norm_cls in snapshot_classes
        )


def _restore_mlx_norm_output_cast_attr(norm_cls, attr_name, value) -> None:
    if value is _MLX_NORM_OUTPUT_CAST_STATE.missing:
        try:
            delattr(norm_cls, attr_name)
        except AttributeError:
            pass
    else:
        setattr(norm_cls, attr_name, value)


def restore_mlx_norm_output_cast_state(snapshot) -> None:
    with _MLX_NORM_OUTPUT_CAST_STATE.lock:
        patched_classes = _MLX_NORM_OUTPUT_CAST_STATE.patched_classes
        desired = {}
        for entry in snapshot:
            try:
                norm_cls, was_patched, call, original_call, cast_output = entry
            except (TypeError, ValueError):
                continue
            if isinstance(norm_cls, type):
                desired[norm_cls] = (was_patched, call, original_call, cast_output)

        for norm_cls, (was_patched, call, original_call, cast_output) in desired.items():
            current_call = getattr(norm_cls, "__call__", None)
            current_is_wrapper = getattr(
                current_call, "_unsloth_norm_output_cast_wrapper", False
            )
            if not was_patched and not current_is_wrapper:
                patched_classes.discard(norm_cls)
                continue
            _restore_mlx_norm_output_cast_attr(norm_cls, "__call__", call)
            _restore_mlx_norm_output_cast_attr(
                norm_cls, "_unsloth_original_call", original_call
            )
            _restore_mlx_norm_output_cast_attr(
                norm_cls, "_unsloth_cast_output_to_input_dtype", cast_output
            )
            if was_patched:
                patched_classes.add(norm_cls)
            else:
                patched_classes.discard(norm_cls)


def set_mlx_norm_output_cast_to_input_dtype(enabled: bool, model=None) -> None:
    """Control whether MLX norm outputs are cast back to activation dtype.

    MLX training can keep norm parameters in fp32 for stability, but letting
    fp32 norm outputs flow through the rest of the graph promotes downstream
    intermediates and materially increases LoRA/QLoRA memory. Casting the
    result back keeps bf16/fp16 downstream activations.

    This patches norm classes process-wide, not per model. Use
    snapshot_mlx_norm_output_cast_state() and restore_mlx_norm_output_cast_state()
    to bracket temporary changes; overlapping trainer/inference runs in the
    same process are still not safe because the patched classes are shared.
    """
    with _MLX_NORM_OUTPUT_CAST_STATE.lock:
        try:
            from . import compile as _mlx_compile
            _mlx_compile.set_qwen3_vision_norm_cast_output(enabled)
        except Exception:
            pass

        norm_classes = list(iter_mlx_norm_output_cast_classes(model))
        if not enabled:
            norm_classes.extend(
                norm_cls for norm_cls in mlx_norm_output_cast_patched_classes()
                if norm_cls not in norm_classes
            )
        _set_mlx_norm_output_cast_classes(enabled, norm_classes)


# MLX raises instead of returning zero when a backward pass reaches a
# gather/scatter index, aborting every graph that derives indices from activations:
# MoE routing, SwitchGLU's gather-sort, GLM-5.x's sparse mask. Detaching changes no
# forward value; producers are wrapped too, since `__getitem__` hides the consumer.
_MLX_INDEX_PRODUCERS = ("argpartition", "argsort", "argmax", "argmin")
_MLX_INDEX_CONSUMERS = {  # index-argument positions, by op
    "take": (1,), "take_along_axis": (1,), "put_along_axis": (1,),
    "gather_mm": (2, 3), "gather_qmm": (4, 5)}
_MLX_INDEX_KEYWORDS = frozenset(("indices", "lhs_indices", "rhs_indices"))
_MLX_INDEX_OP_NAMES = _MLX_INDEX_PRODUCERS + tuple(_MLX_INDEX_CONSUMERS)
_MLX_INDEX_GRADIENT_LOCK = threading.RLock()
# Two depths, with different scopes. Physical: how many runs still need `mlx.core`
# wrapped. Global under the lock, since unpatching is process-wide.
_MLX_TRAINING_PATCH_DEPTH = 0
# Logical: is THIS context inside a training step. Context-local because a global
# one is wrong both ways -- never cleared, a nested evaluation reads as training;
# always cleared, one trainer's evaluation clears the flag under another that is
# still differentiating, and a call site passing no `use_kernel` (GLM-5.x) then
# routes its backward to the fused kernel, which has no VJP. ContextVar covers
# threads and asyncio Tasks; `threading.local` would cover only the first.
_MLX_TRAINING_ACTIVE_DEPTH = contextvars.ContextVar(
    "unsloth_mlx_training_active_depth", default=0)
# Tuple, not list: a mutable ContextVar default is shared by every context that
# never set one, putting the stack straight back in global scope.
_MLX_TRAINING_PAUSE_STACK = contextvars.ContextVar(
    "unsloth_mlx_training_pause_stack", default=())
# MLX differentiates integer arrays, so only real index positions are detached.
_MLX_INTEGER_DTYPES = frozenset((mx.int8, mx.int16, mx.int32, mx.int64,
                                 mx.uint8, mx.uint16, mx.uint32, mx.uint64))


def _detach_if_index(value):
    return (mx.stop_gradient(value)
            if getattr(value, "dtype", None) in _MLX_INTEGER_DTYPES else value)


def _wrap_mlx_index_op(name, original):
    positions = _MLX_INDEX_CONSUMERS.get(name)

    @wraps(original)
    def wrapper(*args, **kwargs):
        if positions is None:  # producer: the result is entirely an index
            return mx.stop_gradient(original(*args, **kwargs))
        return original(
            *(_detach_if_index(arg) if i in positions else arg
              for i, arg in enumerate(args)),
            **{key: _detach_if_index(value) if key in _MLX_INDEX_KEYWORDS
               else value for key, value in kwargs.items()},
        )

    wrapper._unsloth_index_stop_gradient = True
    wrapper._unsloth_index_original = original
    return wrapper


def _set_mlx_index_gradient_stop(enabled: bool) -> None:
    for name in _MLX_INDEX_OP_NAMES:
        current = getattr(mx, name, None)
        if current is None:
            continue
        patched = bool(getattr(current, "_unsloth_index_stop_gradient", False))
        if enabled and not patched:
            setattr(mx, name, _wrap_mlx_index_op(name, current))
        elif not enabled and patched:
            setattr(mx, name, current._unsloth_index_original)


def acquire_mlx_training_patches() -> None:
    """Reference-counted: the `mlx.core` patches are process-wide while trainer
    runs are not, so an inner run must not unpatch an outer one."""
    global _MLX_TRAINING_PATCH_DEPTH
    with _MLX_INDEX_GRADIENT_LOCK:
        if _MLX_TRAINING_PATCH_DEPTH == 0:
            _set_mlx_index_gradient_stop(True)
        _MLX_TRAINING_PATCH_DEPTH += 1
    _MLX_TRAINING_ACTIVE_DEPTH.set(_MLX_TRAINING_ACTIVE_DEPTH.get() + 1)


def release_mlx_training_patches() -> None:
    global _MLX_TRAINING_PATCH_DEPTH
    with _MLX_INDEX_GRADIENT_LOCK:
        if _MLX_TRAINING_PATCH_DEPTH == 0:
            return
        _MLX_TRAINING_PATCH_DEPTH -= 1
        if _MLX_TRAINING_PATCH_DEPTH == 0:
            _set_mlx_index_gradient_stop(False)
    _MLX_TRAINING_ACTIVE_DEPTH.set(max(0, _MLX_TRAINING_ACTIVE_DEPTH.get() - 1))


def pause_mlx_training_patches() -> bool:
    """Evaluation runs under `model.eval()` but inside the trainer's window, which
    would otherwise route it down the training paths.

    Always clears the logical flag, but only for THIS context, so a second trainer
    on another thread keeps its own. The return value reports only whether the
    process-wide patches came off: they stay while another run needs them, which
    costs nothing, since they stop gradients into gather indices and evaluation
    takes none.
    """
    global _MLX_TRAINING_PATCH_DEPTH
    _MLX_TRAINING_PAUSE_STACK.set(
        _MLX_TRAINING_PAUSE_STACK.get() + (_MLX_TRAINING_ACTIVE_DEPTH.get(),))
    _MLX_TRAINING_ACTIVE_DEPTH.set(0)
    with _MLX_INDEX_GRADIENT_LOCK:
        if _MLX_TRAINING_PATCH_DEPTH != 1:
            return False
        _MLX_TRAINING_PATCH_DEPTH = 0
        _set_mlx_index_gradient_stop(False)
        return True


def resume_mlx_training_patches(paused: bool) -> None:
    """Give back exactly what `pause_mlx_training_patches` took.

    By increment, never assignment: another trainer may have acquired during the
    pause, and assigning 1 there would drop this run's reference, so that
    trainer's release would unpatch `mlx.core` mid-differentiation. The logical
    depth comes off this context's own stack, so it does not count a second run
    the way `acquire()` would.
    """
    global _MLX_TRAINING_PATCH_DEPTH
    with _MLX_INDEX_GRADIENT_LOCK:
        if paused:
            if _MLX_TRAINING_PATCH_DEPTH == 0:
                _set_mlx_index_gradient_stop(True)
            _MLX_TRAINING_PATCH_DEPTH += 1
    stack = _MLX_TRAINING_PAUSE_STACK.get()
    if stack:
        _MLX_TRAINING_ACTIVE_DEPTH.set(stack[-1])
        _MLX_TRAINING_PAUSE_STACK.set(stack[:-1])


def mlx_training_patches_active() -> bool:
    return _MLX_TRAINING_ACTIVE_DEPTH.get() > 0


# Sorted `gather_qmm` silently corrupts its output on neural-accelerator Metal GPUs:
# unaligned K (ml-explore/mlx#3887, open) and rows past 32768 (ml-explore/mlx#3856,
# fixed by #3922). `sorted_indices` is only a dispatch hint, so dropping it where a
# probe measures corruption is safe. Kill switch: UNSLOTH_MLX_GATHER_QMM_GUARD=0.
_MLX_MAX_SORTED_ROWS = 32768
_MLX_CANARY_ERROR_LIMIT = 1.0
_MLX_K_REMAINDER = "k_remainder"
_MLX_ROW_OVERFLOW = "row_overflow"
_MLX_PROBE_ROWS = {_MLX_K_REMAINDER: 64, _MLX_ROW_OVERFLOW: _MLX_MAX_SORTED_ROWS + 1}
_MLX_PROBE_EXPERTS = 8
_MLX_PROBE_OUT_DIM = 64
# Below this, nvfp4 degenerates to one group that mlx gets wrong even without a NAX.
_MLX_MIN_PROBE_K = 96
_MLX_GATHER_QMM_ORIGINAL = None
_MLX_GATHER_QMM_CANARIES = {}
_MLX_GATHER_QMM_DEFAULTS = {}
_MLX_GATHER_QMM_UNREADABLE = False


def _gather_qmm_probe_k(condition, group_size):
    """Probe width, or None: a 64-multiple group size leaves no K remainder to probe."""
    if condition == _MLX_ROW_OVERFLOW:
        return math.lcm(group_size, 64)
    if group_size % 64 == 0:
        return None
    k = group_size
    while k < _MLX_MIN_PROBE_K or k % 64 == 0:
        k += group_size
    return k


def _gather_qmm_canary_error(condition, group_size, bits, mode, device) -> float:
    """`gather_mm` is the reference: its NAX kernel carries neither defect."""
    with mx.stream(mx.default_stream(device)):
        rows = _MLX_PROBE_ROWS[condition]
        k = _gather_qmm_probe_k(condition, group_size)
        keys = mx.random.split(mx.random.key(0x3887), 3)
        w = mx.random.normal(
            (_MLX_PROBE_EXPERTS, _MLX_PROBE_OUT_DIM, k), key=keys[0]).astype(mx.bfloat16)
        quantized = mx.quantize(w, group_size=group_size, bits=bits, mode=mode)
        wq, scales = quantized[0], quantized[1]
        biases = quantized[2] if len(quantized) > 2 else None
        x = (mx.random.normal((rows, 1, k), key=keys[1]) * 0.5).astype(mx.bfloat16)
        indices = mx.sort(mx.random.randint(
            0, _MLX_PROBE_EXPERTS, (rows,), key=keys[2]).astype(mx.uint32))
        reference = mx.gather_mm(
            x.astype(mx.float32),
            mx.dequantize(wq, scales, biases, group_size=group_size, bits=bits,
                          mode=mode).astype(mx.float32).swapaxes(-1, -2),
            rhs_indices=indices, sorted_indices=False)
        out = _MLX_GATHER_QMM_ORIGINAL(
            x, wq, scales, biases, rhs_indices=indices, transpose=True,
            group_size=group_size, bits=bits, mode=mode, sorted_indices=True)
        return mx.abs(out.astype(mx.float32) - reference).max().item()


def _gather_qmm_canary_defective(condition, group_size, bits, mode, device) -> bool:
    """Keyed by device name: mlx devices hash by identity, not value."""
    if _gather_qmm_probe_k(condition, group_size) is None:
        return False
    key = (condition, group_size, bits, mode, str(device))
    cached = _MLX_GATHER_QMM_CANARIES.get(key)
    if cached is not None:
        return cached
    if not mx.metal.is_available():
        _MLX_GATHER_QMM_CANARIES[key] = False
        return False
    try:
        max_error = _gather_qmm_canary_error(condition, group_size, bits, mode, device)
    except Exception as error:
        # Fails CLOSED, unlike the pass-through in `_gather_qmm_guarded`: an unusable
        # probe proves nothing, and rerouting a healthy call only costs throughput
        # where admitting a corrupt one costs gradients. Uncached, so a later call
        # re-probes.
        print(f"Unsloth: sorted gather_qmm {condition} probe failed ({error}); "
              f"rerouting this call.")
        return True
    defective = not (max_error < _MLX_CANARY_ERROR_LIMIT)   # NaN reads as corrupt
    _MLX_GATHER_QMM_CANARIES[key] = defective
    if defective:
        print(f"Unsloth: sorted gather_qmm is corrupt on this machine ({condition} "
              f"probe, {mode}, max error {max_error:.3g}); rerouting affected calls.")
    return defective


def _gather_qmm_resolved_quantization(bits, mode):
    """Asked of mlx: scales reveal the group size only for transposed weights."""
    cached = _MLX_GATHER_QMM_DEFAULTS.get((bits, mode))
    if cached is not None:
        return cached
    probe = mx.zeros((1, 256), dtype=mx.bfloat16)
    packed, scales = mx.quantize(probe, bits=bits, mode=mode)[:2]
    resolved = (probe.shape[-1] // scales.shape[-1],
                bits if bits is not None else 32 * packed.shape[-1] // probe.shape[-1])
    _MLX_GATHER_QMM_DEFAULTS[(bits, mode)] = resolved
    return resolved


def _gather_qmm_quantization(args, kwargs):
    group_size = args[5] if len(args) > 5 else kwargs.get("group_size")
    bits = args[6] if len(args) > 6 else kwargs.get("bits")
    mode = args[7] if len(args) > 7 else kwargs.get("mode", "affine")
    if group_size is None:
        group_size = _gather_qmm_resolved_quantization(bits, mode)[0]
    return group_size, bits, mode


def _gather_qmm_target_device(kwargs):
    """mlx takes a stream, device or device type here."""
    stream = kwargs.get("stream")
    if stream is None:
        return mx.default_device()
    device = getattr(stream, "device", stream)
    return device if isinstance(device, mx.Device) else mx.default_stream(device).device


def _gather_qmm_gradient_rows(x, w, lhs_indices, rhs_indices):
    """mlx fills an absent index side in from the operand it would have indexed."""
    left = lhs_indices.shape if lhs_indices is not None else x.shape[:-2]
    right = rhs_indices.shape if rhs_indices is not None else w.shape[:-2]
    batch = mx.broadcast_shapes(tuple(left), tuple(right))
    return math.prod(batch) * x.shape[-2]


def _gather_qmm_conditions(x, w, args, kwargs):
    """Defects this call is exposed to, empty when it misses the kernel. Re-derived
    per geometry: a `shapeless=True` trace would instead freeze one call's answer onto
    every later one, since the sorted flag is baked into the traced primitive."""
    if not kwargs.get("sorted_indices"):
        return ()
    if _gather_qmm_target_device(kwargs).type != mx.gpu:
        return ()
    lhs_indices = args[2] if len(args) > 2 else kwargs.get("lhs_indices")
    rhs_indices = args[3] if len(args) > 3 else kwargs.get("rhs_indices")
    transpose = args[4] if len(args) > 4 else kwargs.get("transpose", True)
    # mlx records the sorted flag only when exactly one index side is given.
    if (lhs_indices is None) == (rhs_indices is None):
        return ()
    # The kernel is dispatched at one output row per matmul; the gradient inherits it.
    if x.shape[-2] != 1:
        return ()
    conditions = []
    if transpose:
        if rhs_indices is None:
            return ()
        k, rows = x.shape[-1], x.size // x.shape[-1]
    else:
        # The forward misses, but the VJP re-issues it transposed, rhs-indexed, sorted.
        bits = args[6] if len(args) > 6 else kwargs.get("bits")
        mode = args[7] if len(args) > 7 else kwargs.get("mode", "affine")
        k = w.shape[-1] * 32 // _gather_qmm_resolved_quantization(bits, mode)[1]
        rows = _gather_qmm_gradient_rows(x, w, lhs_indices, rhs_indices)
    if k % 64:
        conditions.append(_MLX_K_REMAINDER)
    if rows > _MLX_MAX_SORTED_ROWS:
        conditions.append(_MLX_ROW_OVERFLOW)
    return tuple(conditions)


def _gather_qmm_guarded(x, w, *args, **kwargs):
    global _MLX_GATHER_QMM_UNREADABLE
    try:
        conditions = _gather_qmm_conditions(x, w, args, kwargs)
        if conditions:
            group_size, bits, mode = _gather_qmm_quantization(args, kwargs)
            device = _gather_qmm_target_device(kwargs)
            if any(_gather_qmm_canary_defective(condition, group_size, bits, mode,
                                                device)
                   for condition in conditions):
                kwargs = dict(kwargs, sorted_indices=False)
    except Exception as error:
        # Failing to READ a call is not a reason to fail it: this stands on a core mlx
        # op, and the reachable cause is an mlx predating the NAX kernels. Pass through.
        if not _MLX_GATHER_QMM_UNREADABLE:
            _MLX_GATHER_QMM_UNREADABLE = True
            print(f"Unsloth: could not inspect this gather_qmm call "
                  f"({type(error).__name__}: {error}); the sorted NAX guard is "
                  f"inactive for this process.")
    return _MLX_GATHER_QMM_ORIGINAL(x, w, *args, **kwargs)


# Not `wraps`: copied __dict__ markers make the index-stop removal restore the wrong callable.
_gather_qmm_guarded._unsloth_gather_qmm_guard = True


def is_gather_qmm_nax_guard_applied() -> bool:
    """True for the guard anywhere in the chain, index-stop wrapper included."""
    current = mx.gather_qmm
    # Bounded: the real chain is the guard under at most one index-stop wrapper, but
    # `getattr(..., None)` only terminates for an object that can be missing an
    # attribute. A permissive stand-in for mx (the mlx test shim, a Mock) answers every
    # attribute with a fresh object, so an unbounded walk never reaches None and spins.
    for _ in range(16):
        if current is None:
            break
        if getattr(current, "_unsloth_gather_qmm_guard", False):
            return True
        current = getattr(current, "_unsloth_index_original", None)
    return False


def apply_gather_qmm_nax_guard() -> bool:
    """Idempotent, thread-safe, and installed UNDER the index-stop wrapper, which
    removes itself by inspecting `mx` and would be stranded by anything on top."""
    global _MLX_GATHER_QMM_ORIGINAL
    if os.environ.get("UNSLOTH_MLX_GATHER_QMM_GUARD", "1") == "0":
        return False
    with _MLX_INDEX_GRADIENT_LOCK:
        if is_gather_qmm_nax_guard_applied():
            return False
        current = mx.gather_qmm
        if (_MLX_GATHER_QMM_ORIGINAL is not None
                and current is not _MLX_GATHER_QMM_ORIGINAL
                and getattr(current, "_unsloth_index_original", None)
                is not _MLX_GATHER_QMM_ORIGINAL):
            # Capturing an opaque wrapper makes the guard reachable from its original.
            print("Unsloth: mx.gather_qmm was replaced by an unrecognized wrapper; "
                  "leaving the NAX guard as it stands.")
            return False
        if getattr(current, "_unsloth_index_stop_gradient", False):
            # One assignment: removing the index stop would unwrap every index op.
            _MLX_GATHER_QMM_ORIGINAL = current._unsloth_index_original
            mx.gather_qmm = _wrap_mlx_index_op("gather_qmm", _gather_qmm_guarded)
        else:
            _MLX_GATHER_QMM_ORIGINAL = current
            mx.gather_qmm = _gather_qmm_guarded
        return True



def _get_transformer_layers(model):
    """Find transformer layers, unwrapping VLM wrappers if needed.

    VLMs: model.language_model.model.layers; text: model.(model.)layers.
    """
    m = getattr(model, 'language_model', model)
    m = getattr(m, 'model', m)
    return getattr(m, 'layers', None)


def _get_vision_encoder_layers(model):
    """Find vision tower encoder layers (e.g. SigLIP for Gemma3).

    Walks ``model.vision_tower.vision_model.encoder.layers`` and a few
    fallback paths used by other VLM families.
    """
    vt = getattr(model, "vision_tower", None) or getattr(model, "vision_model", None)
    if vt is None:
        return None
    for path in (
        ("vision_model", "encoder", "layers"),  # Gemma3 SigLIP
        ("blocks",),                             # Qwen2.5-VL ViT
        ("encoder", "layers"),
        ("vision_model", "layers"),
        ("layers",),
    ):
        cur = vt
        for name in path:
            cur = getattr(cur, name, None)
            if cur is None:
                break
        if cur is not None and hasattr(cur, "__len__") and len(cur) > 0:
            return cur
    return None


def _detach_integer_arrays(value):
    """`mx.checkpoint` makes every argument a primal of the recomputed function,
    so a layer that embeds the token ids it was handed derives a gather index."""
    if isinstance(value, list):
        return [_detach_integer_arrays(v) for v in value]
    if isinstance(value, tuple):
        detached = tuple(_detach_integer_arrays(v) for v in value)
        # A NamedTuple is a tuple subclass; rebuilding it as a plain tuple would
        # turn a layer's `payload.ids` into an AttributeError.
        return type(value)(*detached) if hasattr(value, "_fields") else detached
    if isinstance(value, dict):
        return {k: _detach_integer_arrays(v) for k, v in value.items()}
    return _detach_if_index(value)


def _patch_layer_class_for_gc(layer_cls):
    if getattr(layer_cls, '_orig_call', None) is not None:
        return  # already patched
    layer_cls._orig_call = layer_cls.__call__
    fn = layer_cls.__call__

    def checkpointed_fn(self, *args, **kwargs):
        slot = next((a for a in args if isinstance(a, _SharedKVSlot)), None)
        if slot is None:
            def inner_fn(params, *args, **kwargs):
                self.update(params)
                args = tuple(_detach_integer_arrays(a) for a in args)
                kwargs = {k: _detach_integer_arrays(v) for k, v in kwargs.items()}
                return fn(self, *args, **kwargs)
            return mx.checkpoint(inner_fn)(
                self.trainable_parameters(), *args, **kwargs)

        # Shared K/V crosses the checkpoint boundary as a traced argument and a
        # traced result; read off the slot and the VJP drops the gradient.
        def inner_fn(params, borrowed, *args, **kwargs):
            self.update(params)
            slot.install(borrowed)
            args = tuple(_detach_integer_arrays(a) for a in args)
            kwargs = {k: _detach_integer_arrays(v) for k, v in kwargs.items()}
            out = fn(self, *args, **kwargs)
            return out, slot.recorded()

        out, recorded = mx.checkpoint(inner_fn)(
            self.trainable_parameters(), slot.borrow(), *args, **kwargs)
        slot.install(recorded)
        return out

    layer_cls.__call__ = checkpointed_fn


def _unpatch_layer_class_gc(layer_cls):
    orig = getattr(layer_cls, '_orig_call', None)
    if orig is not None:
        layer_cls.__call__ = orig
        del layer_cls._orig_call


def apply_gradient_checkpointing(model):
    """Apply gradient checkpointing to language and vision tower layers.

    Patches each layer class's ``__call__`` with ``mx.checkpoint`` to recompute
    the forward during backward instead of storing activations. Trades ~30%
    extra compute for large memory savings — critical for VLM vision towers at
    native resolution, which can otherwise materialize tens of GB.
    """
    lm_layers = _get_transformer_layers(model)
    if lm_layers is not None and len(lm_layers) > 0:
        _patch_layer_class_for_gc(type(lm_layers[0]))

    vt_layers = _get_vision_encoder_layers(model)
    if vt_layers is not None and len(vt_layers) > 0:
        _patch_layer_class_for_gc(type(vt_layers[0]))


def remove_gradient_checkpointing(model):
    """Remove gradient checkpointing, restoring original layer __call__."""
    lm_layers = _get_transformer_layers(model)
    if lm_layers is not None and len(lm_layers) > 0:
        _unpatch_layer_class_gc(type(lm_layers[0]))
    vt_layers = _get_vision_encoder_layers(model)
    if vt_layers is not None and len(vt_layers) > 0:
        _unpatch_layer_class_gc(type(vt_layers[0]))


def _get_text_model(model):
    """Get the inner text model, unwrapping multimodal wrappers if present.

    Standard models (Llama, Qwen) are themselves the text model; multimodal
    wrappers (Gemma 4) expose it at model.language_model.
    """
    if hasattr(model, "language_model"):
        return model.language_model
    return model


def _get_text_backbone(model):
    """Get a separable hidden-state backbone when the model exposes one."""
    tm = _get_text_model(model)
    return getattr(tm, "model", None)


def _has_hidden_stack(obj):
    """Whether an object exposes embed_tokens/layers/norm for manual hidden-state forward."""
    if obj is None:
        return False
    return (
        hasattr(obj, "embed_tokens")
        and hasattr(obj, "layers")
        and hasattr(obj, "norm")
    )


def _build_gemma_image_attention_mask(token_type_ids, attention_mask=None,
                                      window_size=None):
    seq_len = token_type_ids.shape[1]
    q_idx = mx.arange(seq_len)[:, None]
    kv_idx = mx.arange(seq_len)[None, :]
    causal = q_idx >= kv_idx
    if window_size is not None:
        causal = mx.logical_and(causal, q_idx < kv_idx + int(window_size))

    is_image = token_type_ids == 1
    previous_image = mx.concatenate(
        [mx.zeros_like(is_image[:, :1]), is_image[:, :-1]],
        axis=1,
    )
    new_image_start = mx.logical_and(is_image, mx.logical_not(previous_image))
    group_ids = mx.cumsum(new_image_start.astype(mx.int32), axis=1) - 1
    group_ids = mx.where(is_image, group_ids, -1)
    same_image_group = mx.logical_and(
        group_ids[:, :, None] == group_ids[:, None, :],
        group_ids[:, :, None] >= 0,
    )

    mask = mx.logical_or(causal[None, :, :], same_image_group)
    if attention_mask is not None:
        valid = attention_mask.astype(mx.bool_)
        mask = mx.logical_and(mask, valid[:, :, None])
        mask = mx.logical_and(mask, valid[:, None, :])
    return mx.expand_dims(mask, axis=1)


# Families that read the padding mask, or whose layers fall back on a stored
# `_full_attn_mask` without one -- falcon_perception never clears it, so a text
# batch can inherit the previous image batch's. Elsewhere a supplied mask
# reaches the layers, where it REPLACES causality. Listed rather than probed
# from the signature, since molmo_point declares `mask` and never reads it, and
# keyed on `model_type`, so aliases need their own entry.
_VLM_FAMILIES_KEEPING_FORWARDED_MASK = frozenset({
    "gemma3", "paligemma",
    "llava_qwen2", "fastvlm",                    # FastVLM answers to both
    "falcon_ocr", "falcon_perception", "falcon-perception",
})


def _keeps_forwarded_mask(model):
    model_type = _config_get(getattr(model, "config", None), "model_type")
    # mlx-vlm lower-cases model_type to resolve the module but leaves the
    # config's own spelling alone, so match the way it resolves.
    return str(model_type).lower() in _VLM_FAMILIES_KEEPING_FORWARDED_MASK


class _SharedKVSlot:
    """A cache with training semantics, so KV-shared layers borrow rather than
    rebuild K/V that the reference implementation never recomputes.

    Position stays 0 and nothing is ever trimmed; a prompt cache would forget
    past its sliding window and re-rope queries at an advancing offset. No
    version gate: gemma4 from mlx-vlm 0.5.0 reads shared K/V from its layer
    results instead; the slots still travel with the batch, but stop being where
    the sharing is read and leave the training result unchanged.

    `borrow`/`install`/`recorded` exist because gradient checkpointing cannot
    see an attribute read -- the recomputed VJP drops the gradient while the
    forward stays correct -- so the wrapper passes K/V in as an argument and
    takes it back as a result.
    """

    __slots__ = ("keys", "values")

    def __init__(self):
        self.keys = None
        self.values = None

    @property
    def offset(self):
        return 0

    @property
    def state(self):
        return self.keys, self.values

    def update_and_fetch(self, keys, values):
        self.keys, self.values = keys, values
        return keys, values

    def borrow(self):
        """K/V to pass into the next layer's traced region, if any."""
        return None if self.keys is None else (self.keys, self.values)

    def install(self, borrowed):
        if borrowed is not None:
            self.keys, self.values = borrowed

    def recorded(self):
        return self.keys, self.values


# Language models that scale token embeddings by sqrt(hidden_size) on the ids
# path only, so every multimodal forward loses it. gemma3 is absent because
# `_run_hidden_stack`, the route it takes, already compensates.
_VLM_EMBED_SCALE_FAMILIES = frozenset({"gemma3n_text"})


def _vlm_embed_scale(model):
    """The embedding scale this family's LM applies only on the ids path."""
    config = getattr(getattr(_get_text_model(model), "model", None), "config", None)
    if _config_get(config, "model_type") not in _VLM_EMBED_SCALE_FAMILIES:
        return None
    hidden_size = _config_get(config, "hidden_size")
    return float(hidden_size) ** 0.5 if hidden_size else None


def _apply_vlm_embed_scale(model, input_ids, merged_embeds):
    """Scale the token embeddings a multimodal merge left unscaled.

    Only positions still holding a plain token embedding: merged features
    already carry the scaled magnitude. Found by difference, not by token id --
    gemma3n's closing audio delimiter carries a feature without being the audio
    token, and an id-based mask would rescale it.
    """
    scale = _vlm_embed_scale(model)
    if scale is None or input_ids is None:
        return merged_embeds
    backbone = getattr(_get_text_model(model), "model", None)
    embed_tokens = getattr(backbone, "embed_tokens", None)
    if embed_tokens is None:
        return merged_embeds
    raw = embed_tokens(input_ids).astype(merged_embeds.dtype)
    untouched = mx.all(merged_embeds == raw, axis=-1, keepdims=True)
    # In the embedding dtype, as the ids path does: an fp32 product rounded back
    # lands on different bf16 values.
    return mx.where(untouched, merged_embeds * scale, merged_embeds)


# Families whose MLX stack multiplies the embedding by sqrt(hidden_size) after
# the module returns, without exposing the factor as an attribute. Named by the
# base the model type normalizes to, since a tower is reachable as either
# `gemma3` or `gemma3_text` depending on how the wrapper exposes it.
_MLX_SQRT_EMBED_SCALE_FAMILIES = frozenset({
    "gemma", "gemma2", "gemma3", "gemma3n",
})
# Architectures transformers has always scaled inside the embedding, used when
# the installed transformers cannot be asked because it predates them.
# minicpm3 is deliberately absent: no transformers in the supported range has a
# built-in one, so the reference is trust_remote_code, which multiplies by
# scale_emb outside the embedding just as mlx-lm does. Correcting would make MLX
# scale_emb times weaker. A later transformers adds the scaled class, and the
# gate then reads it directly.
_SCALED_INSIDE_WHEN_UNASKABLE = frozenset({
    "gemma3", "gemma3n", "gemma4", "gemma4_unified",
})


def _model_type_base(model_type):
    """The spelling both the family sets and the transformers lookup use."""
    return str(model_type or "").removesuffix("_text")


@lru_cache(maxsize=None)
def _transformers_scales_inside_embedding(model_type):
    """Whether the installed transformers applies this architecture's embedding
    multiply inside the embedding module, so its NEFTune hook fires after it.

    Asked, not assumed: transformers moved gemma and gemma2's multiply into the
    module partway through the supported range, so a fixed answer would be wrong
    at one end. None when it cannot be asked (no such architecture installed).

    Read through the loader, never imported: a modeling module needs torch, which
    is deliberately absent on macOS arm64. Source first, then compiled code, so
    the answer survives a package shipped without its source.
    """
    base = _model_type_base(model_type)
    if not base:
        return None
    try:
        spec = importlib.util.find_spec(f"transformers.models.{base}.modeling_{base}")
    except Exception:
        return None
    if spec is None or spec.loader is None:
        return None
    marker = "ScaledWordEmbedding"
    try:
        source = spec.loader.get_source(spec.name)
    except Exception:
        source = None
    if source is not None:
        return marker in source
    try:
        code = spec.loader.get_code(spec.name)
    except Exception:
        code = None
    if code is None:
        return None
    # A module-level class binds its name, so the flat scan is enough.
    return any(marker in name for name in code.co_names)


def _neftune_embed_scale(model):
    """The multiply applied after the embedding returns that NEFTune noise has
    to be divided by, or None when nothing needs correcting.

    MLX multiplies once the embedding module has returned, so noise injected
    there rides through it; transformers adds its noise after the same multiply
    wherever it keeps it inside the embedding.
    """
    text_model = _get_text_model(model)
    backbone = getattr(text_model, "model", None)
    # mlx-lm keeps this on `args`, mlx-vlm on `config`, at either level.
    holders = (backbone, text_model, getattr(backbone, "args", None),
               getattr(backbone, "config", None), getattr(text_model, "args", None),
               getattr(text_model, "config", None))

    def _first(key):
        for holder in holders:
            value = None if holder is None else _config_get(holder, key)
            if value is not None:
                return value
        return None

    def _usable(value):
        """The value as a positive float, or None if it is not one.

        Truthiness is not enough: embed_scale can be a 0-d array (fine), a
        multi-element array or a string (neither converts), and a non-positive
        scale would flip or blow up the noise. Anything unusable counts as
        absent, so the next candidate is tried instead of crashing.
        """
        if value is None:
            return None
        try:
            number = float(value)
        except (TypeError, ValueError):
            return None
        if not math.isfinite(number) or number <= 0.0:
            return None
        return number

    model_type = str(_first("model_type") or "")
    base = _model_type_base(model_type)
    scale = _usable(getattr(backbone, "embed_scale", None))  # gemma4, gemma4_unified
    if scale is None:
        scale = _usable(_first("scale_emb"))                 # a config value, not a sqrt
    if scale is None and base in _MLX_SQRT_EMBED_SCALE_FAMILIES:
        hidden_size = _usable(_first("hidden_size"))
        scale = hidden_size ** 0.5 if hidden_size else None
    if scale is None:
        return None
    inside = _transformers_scales_inside_embedding(model_type)
    if inside is None:
        inside = base in _SCALED_INSIDE_WHEN_UNASKABLE
    return scale if inside else None


def _vlm_compares_embedding_values(model):
    """Whether the forward finds merged positions by comparing embedding
    values, which noise redrawn per call invalidates. Read off the scale
    families so the two cannot drift apart.

    Matched on the normalized model type too, since `_vlm_embed_scale` compares
    the raw spelling and would miss a tower exposing the bare family name.
    Refusing is the conservative side: a missed refusal injects noise into that
    comparison, a spurious one only trains un-noised.
    """
    if _vlm_embed_scale(model) is not None:
        return True
    config = getattr(getattr(_get_text_model(model), "model", None), "config", None)
    base = _model_type_base(_config_get(config, "model_type"))
    if not base:
        return False
    return any(base == _model_type_base(family)
               for family in _VLM_EMBED_SCALE_FAMILIES)


def _identify_vlm_embedding_module(model):
    """The module a text-only embedding forward uses to build ``inputs_embeds``.

    Observed, not looked up: wrappers disagree on attribute name and container,
    some expose none, and an untied ``lm_head`` carries the same weight shape --
    a quantized embedding carries no such shape at all. Of the modules producing
    the returned shape, drop those another encloses, which picks an adapter over
    the embedding it wraps. None means decline, never guess.
    """
    calls, stack, swapped, recorders = [], [], [], {}
    def _recorder(base):
        cls = recorders.get(base)
        if cls is None:
            class _Probe(base):
                def __call__(self, *args, **kwargs):
                    stack.append(id(self))
                    enclosing = frozenset(stack[:-1])
                    try:
                        out = base.__call__(self, *args, **kwargs)
                    finally:
                        stack.pop()
                    calls.append((self, getattr(out, "shape", None), enclosing))
                    return out
            # The save-window DoRA check reads the class name.
            _Probe.__name__ = base.__name__
            _Probe.__qualname__ = getattr(base, "__qualname__", base.__name__)
            cls = recorders[base] = _Probe
        return cls

    try:
        seen = set()
        for _, module in model.named_modules():
            # One module can appear under several names; wrapping it per name
            # stacks recorders and leaves one installed.
            if id(module) in seen:
                continue
            seen.add(id(module))
            base = type(module)
            try:
                module.__class__ = _recorder(base)
            except TypeError:
                continue
            swapped.append((module, base))
        ids = mx.array([[0, 1, 2]], dtype=mx.int32)
        try:
            embed_result = model.get_input_embeddings(ids, None)
        except TypeError:
            embed_result = model.get_input_embeddings(ids)
        merged, _ = _unpack_embed_result(embed_result, model)
    except Exception:
        return None
    finally:
        for module, base in swapped:
            module.__class__ = base

    shape = getattr(merged, "shape", None)
    if shape is None:
        return None
    matching = [(m, enclosing) for m, s, enclosing in calls if s == shape]
    matching_ids = {id(m) for m, _ in matching}
    outermost = {id(m): m for m, enclosing in matching
                 if not (enclosing & matching_ids)}
    if len(outermost) != 1:
        return None
    return next(iter(outermost.values()))


def _probe_vlm_embedding_module(model):
    """``_identify_vlm_embedding_module`` with the random stream it consumed put
    back.

    Training mode is deliberately untouched: a quantized-activation layer
    requantizes its weights on every flip, and shapes do not depend on the mode.
    """
    # Rewound through the same pair the compile fallbacks use: it reseeds from
    # the key's own words, so it survives mlx 0.32 making mx.random.state a
    # sentinel that refuses item assignment. None (unreadable key) leaves the
    # probe's draws on the caller's stream rather than raising. Never restore by
    # rebinding mx.random.state -- that shadows the sentinel mx.compile captured
    # and stops a compiled step redrawing, turning NEFTune into a fixed offset.
    rng_key = _mlx_rng_key()
    try:
        return _identify_vlm_embedding_module(model)
    except Exception:
        return None
    finally:
        _restore_mlx_rng_key(rng_key)


def _shared_kv_slot_count(model):
    """How many cache slots this stack needs, or 0 when it shares no K/V.

    Not `first_kv_shared_layer_idx > 0`: upstream derives that as
    `num_hidden_layers - num_kv_shared_layers`, so it is positive with zero
    sharing too, as gemma4 12B/26B declare.
    """
    backbone = getattr(_get_text_model(model), "model", None)
    if backbone is None:
        return 0
    config = getattr(backbone, "config", None)
    if not (_config_get(config, "num_kv_shared_layers") or 0):
        return 0
    # mlx-vlm 0.5.0+ threads shared K/V itself, so `_fix_gemma4_kv_sharing`
    # leaves those backbones alone and they keep the ordinary per-layer cache
    # contract. These slots are shorter than the layer count by construction
    # (`first_kv_shared_layer_idx == num_hidden_layers - num_kv_shared_layers`),
    # so handing them over as `cache` would truncate the zip over layers and
    # silently drop the shared tail of the stack. Imported here rather than at
    # module scope: loader imports nothing from this module and vice versa.
    from .loader import _gemma4_has_native_shared_kv
    if _gemma4_has_native_shared_kv(backbone):
        return 0
    return getattr(backbone, "first_kv_shared_layer_idx", 0) or 0


def _build_shared_kv_caches(model):
    """Fresh per-forward slots for a stack that shares K/V, else None."""
    slots = _shared_kv_slot_count(model)
    return [_SharedKVSlot() for _ in range(slots)] if slots else None


def _run_hidden_stack(stack, inputs, inputs_embeds=None, **kwargs):
    """Execute a language stack up to pre-lm_head hidden states."""
    from mlx_vlm.models.base import create_attention_mask

    config = getattr(stack, "config", None)
    if inputs_embeds is None:
        h = stack.embed_tokens(inputs)
    else:
        h = inputs_embeds
    if inputs_embeds is not None and _config_get(config, "model_type") == "gemma3_text":
        h *= mx.array(_config_get(config, "hidden_size")**0.5, mx.bfloat16).astype(h.dtype)

    cache = kwargs.get("cache")
    if cache is None:
        cache = [None] * len(stack.layers)
    mask = kwargs.get("mask")
    if mask is None:
        mask = kwargs.get("attention_mask_4d")
    # No fallback to the 2-D `attention_mask`: layers use what they are handed
    # verbatim, so it would replace causality.
    token_type_ids = kwargs.get("token_type_ids")
    token_type_mask = None
    if token_type_ids is not None:
        attention_mask = kwargs.get("attention_mask")
        token_type_mask = _build_gemma_image_attention_mask(
            token_type_ids,
            attention_mask=attention_mask,
        )
    if mask is None and token_type_mask is None:
        mask = create_attention_mask(h, cache)

    # mlx-vlm gemma3/gemma4 stacks copy these onto the module, but fall back to
    # config (sliding_window) so a stack that only stores them there still
    # builds windowed masks instead of treating every layer as global.
    sliding_window_pattern = getattr(stack, "sliding_window_pattern", None)
    if sliding_window_pattern is None:
        sliding_window_pattern = _config_get(config, "sliding_window_pattern")
    window_size = getattr(stack, "window_size", None)
    if window_size is None:
        window_size = _config_get(config, "sliding_window")
    sliding_token_type_mask = None
    if token_type_ids is not None and sliding_window_pattern and window_size:
        sliding_token_type_mask = _build_gemma_image_attention_mask(
            token_type_ids,
            attention_mask=kwargs.get("attention_mask"),
            window_size=window_size,
        )

    for i, (layer, c) in enumerate(zip(stack.layers, cache)):
        local_mask = mask
        if token_type_mask is not None:
            is_global = not sliding_window_pattern or (
                i % sliding_window_pattern == sliding_window_pattern - 1
            )
            local_mask = token_type_mask if is_global else sliding_token_type_mask
        h = layer(h, local_mask, c)
    return stack.norm(h)


def _has_direct_hidden_stack(model):
    """Whether the text model exposes layers/norm directly instead of under .model."""
    tm = _get_text_model(model)
    return not hasattr(tm, "model") and _has_hidden_stack(tm)


def _forward_text_hidden_states(model, inputs, inputs_embeds=None, **kwargs):
    """Run a text stack up to pre-lm_head hidden states for CCE."""
    tm = _get_text_model(model)
    backbone = getattr(tm, "model", None)
    if backbone is not None:
        if (
            inputs_embeds is not None
            and "token_type_ids" in kwargs
            and _config_get(getattr(backbone, "config", None), "model_type") == "gemma3_text"
            and _has_hidden_stack(backbone)
        ):
            return _run_hidden_stack(backbone, inputs, inputs_embeds=inputs_embeds, **kwargs)
        if getattr(backbone, "lm_head", None) is not None and _has_hidden_stack(backbone):
            return _run_hidden_stack(backbone, inputs, inputs_embeds=inputs_embeds, **kwargs)
        embed_kwarg = _get_backbone_embed_kwarg(backbone)

        if "attention_mask_4d" in kwargs and "mask" not in kwargs:
            kwargs["mask"] = kwargs.pop("attention_mask_4d")
        backbone_kwargs = _filter_backbone_kwargs(backbone, kwargs)
        if inputs_embeds is not None:
            backbone_kwargs[embed_kwarg] = inputs_embeds
        return backbone(inputs, **backbone_kwargs)

    if not _has_direct_hidden_stack(model):
        raise ValueError("Text model does not expose a separable hidden-state backbone")
    return _run_hidden_stack(tm, inputs, inputs_embeds=inputs_embeds, **kwargs)


OutputHeadDescriptor = collections.namedtuple(
    "OutputHeadDescriptor",
    ["module", "path", "status", "has_additive_bias", "quantized",
     "wrapper_type", "raw", "candidate_module", "candidate_path"],
)

_RAW_HEAD_TYPES = (nn.Linear, nn.QuantizedLinear, nn.Embedding, nn.QuantizedEmbedding)


def _self_attr_chain(node):
    """Dotted chain for an ``ast.Attribute`` rooted at the name ``self``,
    else None (subscripts, calls, or other roots break the chain)."""
    parts = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name) and node.id == "self":
        return ".".join(reversed(parts))
    return None


def _output_accessor_chains(tree):
    """Chains with recognized accessor syntax within a parsed body: the X of
    ``self.X.as_linear(...)`` and ``self.X.weight.T``. Syntax-level, so
    strings, comments, and prose can never contribute."""
    chains = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) \
                and node.func.attr == "as_linear":
            chain = _self_attr_chain(node.func.value)
            if chain:
                chains.append(chain)
        elif isinstance(node, ast.Attribute) and node.attr == "T" \
                and isinstance(node.value, ast.Attribute) \
                and node.value.attr == "weight":
            chain = _self_attr_chain(node.value.value)
            if chain:
                chains.append(chain)
    return chains


def _analyze_output_route(tm):
    """Syntactic evidence from the analyzed forward bodies, live-resolved.

    Parses ``type(tm).__call__`` (AST — strings/comments never count) plus one
    hop of ``self.<method>()`` delegation, returning ``(accessor_modules,
    called_module_ids, references_tie_flag)``: chains under
    ``self.X.as_linear(...)`` / ``self.X.weight.T``; modules a self-rooted chain
    is called on (``self.lm_head(x)``); and whether ``tie_word_embeddings`` is
    referenced anywhere. Reachability is NOT analyzed — any recognized syntax
    counts (dead branches included); uniqueness plus fail-closed consumers bound
    mis-selection. Unresolvable chains contribute nothing."""
    cls = type(tm)

    def _parse(method):
        try:
            return ast.parse(textwrap.dedent(inspect.getsource(method)))
        except (OSError, TypeError, AttributeError, SyntaxError):
            return None

    entry = _parse(getattr(cls, "__call__", None))
    if entry is None:
        return {}, set(), False
    trees = [entry]
    invoked = {
        node.func.attr
        for node in ast.walk(entry)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name) and node.func.value.id == "self"
    }
    for helper in invoked - {"__call__"}:
        method = getattr(cls, helper, None)
        if callable(method):
            tree = _parse(method)
            if tree is not None:
                trees.append(tree)

    def _resolve(chain):
        obj = tm
        for part in chain.split("."):
            obj = getattr(obj, part, None)
            if obj is None:
                return None
        return obj

    modules, called, references_flag = {}, set(), False
    for tree in trees:
        for chain in _output_accessor_chains(tree):
            obj = _resolve(chain)
            if obj is not None:
                modules[id(obj)] = (chain, obj)
        for node in ast.walk(tree):
            if isinstance(node, ast.Attribute) and node.attr == "tie_word_embeddings":
                references_flag = True
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                chain = _self_attr_chain(node.func)
                if chain:
                    obj = _resolve(chain)
                    if obj is not None:
                        called.add(id(obj))
    return modules, called, references_flag


def _output_accessor_modules(tm):
    """Live modules with recognized accessors in the analyzed forward bodies
    (see ``_analyze_output_route``). Returns ``{id(module): (path, module)}``."""
    return _analyze_output_route(tm)[0]


def _resolve_embedding_anchor(owner, types, accessor_modules=None):
    """(name, module) of the unique direct child whose type is exactly in
    ``types``; None when absent, ambiguous, or not a module tree. Multiple
    embedding candidates (Gemma-4 backbones carry a second vocab-sized
    per-layer embedding) resolve ONLY by live accessor identity — the unique
    candidate that IS one of the modules the output route accesses
    (`_output_accessor_modules`). Dimensional agreement is deliberately not
    identity evidence (metadata can be stale after a vocab resize).
    Still-ambiguous stays None (fail closed)."""
    children = getattr(owner, "children", None)
    if not callable(children):
        return None
    found = [(n, c) for n, c in children().items() if type(c) in types]
    if len(found) > 1 and accessor_modules:
        found = [e for e in found if id(e[1]) in accessor_modules]
    return found[0] if len(found) == 1 else None


def _embedding_dims(emb):
    """Semantic (vocab, hidden). QuantizedEmbedding packs its weight, so read
    the stored attributes instead of the array shape."""
    if type(emb) is nn.QuantizedEmbedding:
        return int(emb.num_embeddings), int(emb.dims)
    return int(emb.weight.shape[0]), int(emb.weight.shape[1])


def _linear_semantic_dims(layer):
    out_dim, in_dim = int(layer.weight.shape[0]), int(layer.weight.shape[1])
    if type(layer) is nn.QuantizedLinear:
        in_dim = in_dim * 32 // int(layer.bits)
    return out_dim, in_dim


def _resolve_module_path(model, path):
    obj = model
    for part in path.split("."):
        obj = getattr(obj, part)
    return obj


def describe_output_head(model):
    """Resolve the live output head with affirmative evidence only: a True tie
    flag, a real ``lm_head``, or (when no flag attribute exists) an embedding
    named via a live-resolving ``.as_linear(...)`` / ``.weight.T`` accessor in
    the analyzed forward bodies (see ``_analyze_output_route``). Missing
    ``lm_head`` never implies tying; conflicting flags fail closed. ``path`` is
    rooted at the argument (VLM wrappers keep the ``language_model.`` prefix);
    at unknown status ``candidate_*`` carry the unique shape-matched alt head.
    A True flag is corroborated against the route: if a live ``lm_head`` is
    called there with no syntactic flag reference and no accessor for the
    anchored embedding, it fails closed to unknown (Qwen2-MoE ships a dead
    flag). Syntax is evidence, not proof — deeper consultation downgrades
    conservatively to baseline; a dead reference keeps today's resolution.
    """
    prefix = "language_model." if hasattr(model, "language_model") else ""
    tm = _get_text_model(model)
    backbone = getattr(tm, "model", None)
    if backbone is not None:
        emb_owner, emb_prefix = backbone, prefix + "model."
    else:
        emb_owner, emb_prefix = tm, prefix
    accessor_modules, called_modules, references_flag = _analyze_output_route(tm)
    emb_entry = _resolve_embedding_anchor(
        emb_owner, (nn.Embedding, nn.QuantizedEmbedding),
        accessor_modules=accessor_modules,
    )

    flags, flag_attr_present = [], False
    # Include config: some models (e.g. VLM language stacks) carry the live
    # tie flag only on tm.config, the same site logit_scale/softcap are read from.
    for holder in (tm, getattr(tm, "args", None), getattr(tm, "config", None)):
        if holder is None or not hasattr(holder, "tie_word_embeddings"):
            continue
        flag_attr_present = True
        value = holder.tie_word_embeddings
        # Mirror the forward's `if self.args.tie_word_embeddings:` truthiness for
        # any value: from_dict does not coerce, so a config may ship the flag as
        # an int or string, and the forward consumes it by truth value. Only a
        # value whose truth is undefined (raises) stays unread.
        try:
            flags.append(bool(value))
        except Exception:
            pass
    conflicting = len(set(flags)) > 1

    # An uncorroborated True flag: the analyzed route calls a live lm_head
    # at EITHER supported location (any type — a wrapped head the forward
    # uses is just as contradictory as a raw one), shows no syntactic flag
    # consultation, and no accessor evidence for the anchored embedding.
    # When both routes are syntactically visible the flag plausibly selects
    # between them through indirection the analyzer cannot see, so the flag
    # keeps winning there. No execution-order claim is made; syntax alone
    # fails closed (see the docstring for both residual directions).
    live_head_ids = {
        id(owner.lm_head)
        for owner in (tm, backbone)
        if owner is not None and getattr(owner, "lm_head", None) is not None
    }
    flag_contradicted = (
        bool(live_head_ids & called_modules)
        and not references_flag
        and (emb_entry is None or id(emb_entry[1]) not in accessor_modules)
    )

    head, path, status = None, None, "unknown"
    if conflicting:
        pass
    elif flags and flags[0]:
        # A truthy tie flag routes the forward through the embedding: resolve
        # that anchor (unless the flag is contradicted), else fail closed to
        # unknown -- never fall through to a possibly-dead lm_head, which would
        # train the wrong weight.
        if emb_entry is not None and not flag_contradicted:
            head, path, status = emb_entry[1], emb_prefix + emb_entry[0], "tied"
    elif getattr(tm, "lm_head", None) is not None:
        head, path, status = tm.lm_head, prefix + "lm_head", "untied"
    elif backbone is not None and getattr(backbone, "lm_head", None) is not None:
        head, path, status = backbone.lm_head, prefix + "model.lm_head", "untied"
    elif not flag_attr_present and emb_entry is not None:
        # Same structured interpretation as the anchor: tied evidence means
        # the analyzed output-route bodies access THIS embedding module.
        if id(emb_entry[1]) in accessor_modules:
            head, path, status = emb_entry[1], emb_prefix + emb_entry[0], "tied"

    candidate, candidate_path = None, None
    if status == "unknown" and emb_entry is not None:
        vocab, hidden = _embedding_dims(emb_entry[1])
        owners = [(tm, prefix)]
        if backbone is not None:
            owners.append((backbone, prefix + "model."))
        matches, seen = [], set()
        for owner, owner_prefix in owners:
            for name, child in (owner.children() if callable(getattr(owner, "children", None)) else {}).items():
                if id(child) in seen:
                    continue
                seen.add(id(child))
                if (type(child) in (nn.Linear, nn.QuantizedLinear)
                        and _linear_semantic_dims(child) == (vocab, hidden)):
                    matches.append((owner_prefix + name, child))
        if len(matches) == 1:
            candidate_path, candidate = matches[0]

    target = head if head is not None else candidate
    return OutputHeadDescriptor(
        module=head,
        path=path,
        status=status,
        has_additive_bias=(target is not None and "bias" in target),
        quantized=(target is not None and hasattr(target, "scales")),
        wrapper_type=(type(target) if target is not None else None),
        raw=(target is not None and type(target) in _RAW_HEAD_TYPES),
        candidate_module=candidate,
        candidate_path=candidate_path,
    )


def _cce_head_ineligibility(desc):
    """Reason fused CCE must not run for this head, or None when eligible."""
    if desc.status == "unknown":
        return "unresolved output-head topology"
    if not desc.raw:
        return f"non-raw output-head wrapper ({desc.wrapper_type.__name__})"
    if desc.has_additive_bias:
        return "additive output-head bias"
    return None


def _get_lm_head_layer(model):
    """The affirmatively resolved output head (see describe_output_head).

    Raises for unknown topology: the loss factories gate on the descriptor
    first, so reaching this without a resolved head is a caller bug.
    """
    desc = describe_output_head(model)
    if desc.module is None:
        raise ValueError(
            "Unsloth: output-head topology is unresolved for this model; "
            "gate on describe_output_head before requesting the head layer."
        )
    return desc.module


def _is_quantized_layer(layer):
    """Check if a layer has quantized weights (has .scales attribute)."""
    return hasattr(layer, "scales")


def _get_logit_softcap(model):
    """Get logit softcapping value if model uses it (e.g. Gemma-2/4), else 0.0."""
    tm = _get_text_model(model)
    softcap = getattr(tm, "final_logit_softcapping", None)
    if softcap is None and hasattr(tm, "args"):
        softcap = getattr(tm.args, "final_logit_softcapping", None)
    return float(softcap) if softcap is not None and softcap > 0 else 0.0


def _get_logit_scale(model):
    """Get the scalar multiplier some archs apply to lm-head logits, if any.

    Cohere-family models (mlx-lm ``cohere``/``cohere2``, mlx-vlm
    ``aya_vision``/``cohere2_moe``) multiply logits by ``logit_scale`` inside
    the forward — a step CCE bypasses and must re-apply. Returns
    ``(scale, invalid)``: scale None when absent or 1.0; ``invalid=True`` for
    bool/non-scalar/non-finite/out-of-range values (callers must fall back).
    """
    tm = _get_text_model(model)
    # Only the verified application sites — args (cohere/cohere2/cohere2_moe)
    # then config (aya_vision); no upstream forward reads a direct attribute.
    scale = None
    if hasattr(tm, "args"):
        scale = getattr(tm.args, "logit_scale", None)
    if scale is None and hasattr(tm, "config"):
        scale = getattr(tm.config, "logit_scale", None)
    return _validated_head_multiplier(scale)


def _validated_head_multiplier(scale):
    """Returns ``(scale, invalid)``, scale None when absent or a no-op 1.0."""
    if scale is None:
        return None, False
    if isinstance(scale, bool) or not isinstance(scale, numbers.Real):
        return None, True
    try:
        scale = float(scale)
    except (TypeError, ValueError, OverflowError):
        return None, True
    if not np.isfinite(scale):
        return None, True
    if scale == 1.0:
        return None, False
    # Pre-scaling is validated only for moderate magnitudes; extreme scales
    # can under/overflow before accumulation, so fail closed outside 2^-6..4.
    if scale != 0.0 and not (2.0 ** -6 <= abs(scale) <= 2.0 ** 2):
        return None, True
    return scale, False


_KNOB_MISSING = object()

# Knobs whose consuming forwards transform logits after the output head,
# with lookup sites in consumer-preference order. "attr" = the live module
# attribute (Granite/Phi3Small forwards read a constructor copy, so copy vs
# config drift must fail closed); others read args (config for VLM wrappers).
_HEAD_TRANSFORM_KNOBS = {
    "logit_scale": ("args", "config"),          # Cohere: out * logit_scale
    "output_multiplier": ("attr", "args", "config"),  # Muse Glimmer: pre-softcap multiply
    "logits_scaling": ("attr", "args", "config"),  # Granite: out / logits_scaling
    "lm_head_multiplier": ("args", "config"),   # Falcon-H1 tied composite
    "dim_model_base": ("args", "config"),       # MiniCPM untied ratio divide
    "mup_width_multiplier": ("attr", "args", "config"),  # Phi3Small masked tail
}
# Where a knob is read and what values are usable, not where it sits in the forward.
# Fused CCE pre-scales and caps after, so a row here asserts the model scales before
# it caps. Every softcapping architecture in mlx-lm and mlx-vlm does.
_KNOB_AUX_SITES = {
    "embedding_multiplier": ("args", "config"),
    "hidden_size": ("args", "config"),
}


def _knob_values_equal(a, b):
    """Total equality: raising / non-boolean comparisons count as disagreement."""
    try:
        return a is b or bool(a == b)
    except Exception:
        return False


def _knob_value(tm, name, sites):
    """(value, conflict) from the consumer sites; ``_KNOB_MISSING`` when no
    site defines the knob. A present ``None`` is a value, never absence."""
    holders = {"attr": tm, "args": getattr(tm, "args", None), "config": getattr(tm, "config", None)}
    found = [v for site in sites if holders[site] is not None
             for v in (getattr(holders[site], name, _KNOB_MISSING),)
             if v is not _KNOB_MISSING]
    if not found:
        return _KNOB_MISSING, False
    conflict = any(not _knob_values_equal(v, found[0]) for v in found[1:])
    return found[0], conflict


def _validated_knob(value, source):
    """Normalize one knob value to a finite float, or return a reason string."""
    if isinstance(value, bool) or not isinstance(value, numbers.Real):
        return None, f"{source} is not a finite real scalar"
    try:
        value = float(value)
    except (TypeError, ValueError, OverflowError):
        return None, f"{source} is not a finite real scalar"
    if not np.isfinite(value):
        return None, f"{source} is not a finite real scalar"
    return value, None


def _detect_logit_softcap(model):
    """Logit softcap from either known attr, as ``(softcap, problem)``.

    ``final_logit_softcapping`` keeps its ``_get_logit_softcap`` semantics.
    ``logits_soft_cap`` (RecurrentGemma) caps for any truthy value: None/0.0
    mean no cap, a positive finite real caps, anything else (or both attrs
    present) fails closed rather than dropping the cap.
    """
    tm = _get_text_model(model)
    # Presence, not value: an explicitly-None legacy attr still makes the
    # dual-attr combination unverified.
    legacy = getattr(tm, "final_logit_softcapping", _KNOB_MISSING)
    if legacy is _KNOB_MISSING and hasattr(tm, "args"):
        legacy = getattr(tm.args, "final_logit_softcapping", _KNOB_MISSING)
    alias, conflict = _knob_value(tm, "logits_soft_cap", ("args", "config"))
    if conflict:
        return 0.0, ("logits_soft_cap differs between its configuration "
                     "sites")
    if alias is not _KNOB_MISSING and legacy is not _KNOB_MISSING:
        return 0.0, ("both final_logit_softcapping and logits_soft_cap are "
                     "present, an unverified combination")
    if alias is _KNOB_MISSING:
        return _get_logit_softcap(model), None
    if alias is None:
        return 0.0, None  # falsy: the forward skips the cap entirely
    value, problem = _validated_knob(alias, "logits_soft_cap")
    if problem is not None:
        return 0.0, problem
    if value == 0.0:
        return 0.0, None  # falsy: the forward skips the cap entirely
    if value < 0:
        return 0.0, "logits_soft_cap must be positive when set"
    return value, None


def _aux_knob(tm, name):
    """A ratio's companion knob: value or a fail-closed reason string."""
    value, conflict = _knob_value(tm, name, _KNOB_AUX_SITES[name])
    if conflict or value is _KNOB_MISSING:
        return None, (f"{name} is missing or inconsistent across its "
                      "configuration sites")
    return _validated_knob(value, name)


def _detect_head_transform(model, head_status):
    """Resolve known output-transform knobs to one effective logit scale.

    Mirrors the scalar transforms the consuming forwards apply between the
    output head and the returned logits. Returns ``(scale, problem)``: a
    reason string means fall back to the eager baseline; scale None is the
    no-op case; accepted scales obey the ``_get_logit_scale`` range.
    ``head_status`` selects branch-conditional transforms as the forwards do.
    """
    tm = _get_text_model(model)
    present = {}
    for name, sites in _HEAD_TRANSFORM_KNOBS.items():
        value, conflict = _knob_value(tm, name, sites)
        if conflict:
            return None, f"{name} is inconsistent across its configuration sites"
        if value is not _KNOB_MISSING:
            present[name] = value
    if len(present) > 1:
        return None, ("multiple output-transform knobs are present "
                      f"({', '.join(present)}), an unverified combination")
    if not present:
        return None, None
    knob, raw = next(iter(present.items()))
    if knob == "mup_width_multiplier":
        # Its only consumer (Phi3Small) masks dummy-token logits after the
        # value-guarded divide: presence alone makes the tail non-scalar.
        return None, ("mup_width_multiplier models mask logits after the "
                      "output head, which fused CCE cannot reproduce")
    if knob in ("logit_scale", "output_multiplier"):
        # A present-None value is malformed live state (the forward would
        # multiply logits by None); fail closed rather than run unscaled.
        if raw is None:
            return None, f"{knob} is present but None"
        # logit_scale re-reads its own consumer sites; output_multiplier is
        # read straight off the resolved knob, whose sites already agreed.
        scale, invalid = (
            _get_logit_scale(model)
            if knob == "logit_scale"
            else _validated_head_multiplier(raw)
        )
        if invalid:
            return None, (f"{knob} cannot be applied by fused CCE "
                          "(non-finite, non-scalar, or outside the "
                          "supported range)")
        return scale, None
    # The remaining knobs are ratios num/den mirrored from their forwards.
    if knob == "logits_scaling":
        num, problem = 1.0, None
        den, p2 = _validated_knob(raw, knob)
    elif knob == "lm_head_multiplier":
        if head_status != "tied":  # the untied branch applies the plain head
            return None, None
        num, problem = _validated_knob(raw, knob)
        den, p2 = _aux_knob(tm, "embedding_multiplier")
    else:  # dim_model_base: divide by hidden_size/dim_model_base pre-head
        if head_status != "untied":  # the tied branch is a plain matmul
            return None, None
        num, problem = _validated_knob(raw, knob)
        den, p2 = _aux_knob(tm, "hidden_size")
    problem = problem or p2
    if problem is None and den == 0.0:
        problem = f"the {knob} configuration divides the logits by zero"
    if problem is not None:
        return None, problem
    scale = num / den
    if scale == 1.0:
        return None, None
    if not np.isfinite(scale) or not (2.0 ** -6 <= abs(scale) <= 2.0 ** 2):
        return None, (f"effective logit scale {scale!r} from {knob} is "
                      "outside the range validated for fused CCE")
    return scale, None


def _is_lm_head_trainable(model):
    """Whether fused CCE should compute the output head's weight gradient.

    Returns False when the head is frozen by a LoRA/adapter setup or is
    unresolved (its gradient would be a wasted V x chunk_size x H matmul per
    chunk, so callers wrap the weight with mx.stop_gradient); True when the
    resolved head carries a trainable param, or when there are no adapters at
    all (full fine-tuning). Resolution is by descriptor module identity in the
    registered tree, not by name — a property-backed ``language_model``
    returning ``self`` is not a registered child, and an alt-named tied
    embedding (InternLM2 ``tok_embeddings``) is classified like any head.
    """
    trainable = dict(mlx.utils.tree_flatten(model.trainable_parameters()))
    # Module-anchored so unrelated trainables containing the substring
    # "lora" are not treated as adapter state.
    adapter_keys = set(collect_mlx_lora_adapter_tensors(model))
    # Drop reload-leaked base tensors INSIDE a LoRA-wrapped head (would
    # defeat the CCE memory guard) while keeping intentional trainables
    # like `lm_head.bias`. Shares the filter with save_trainable_adapters.
    _lora_module_names = [name for name, _ in iter_mlx_lora_modules(model)]
    lora_module_prefixes = tuple(f"{name}." for name in _lora_module_names if name)
    has_root_lora_module = any(name == "" for name in _lora_module_names)
    head_module = describe_output_head(model).module
    head_prefix = None
    if head_module is not None:
        for name, module in model.named_modules():
            if module is head_module and name:
                head_prefix = f"{name}."
                break
    if head_prefix is None:
        return False
    for key in trainable:
        if key in adapter_keys:
            continue
        if _is_base_tensor_inside_lora_module(
            key, lora_module_prefixes, has_root_lora_module,
        ):
            continue
        if key.startswith(head_prefix):
            return True
    return len(trainable) == 0  # no LoRA = full fine-tuning


def make_cce_loss_fn(model, label_smoothing=0.0):
    """Create a chunked cross-entropy (CCE) loss function.

    CCE computes loss directly from hidden states and the LM head weight,
    avoiding full logit materialization (big memory savings for large vocabs).

    Returns a function (model, batch, lengths, labels=None) -> (loss, ntoks).
    With labels, uses labels[:,1:] as targets and (targets != -100) as mask.
    The returned function has a ``_unsloth_cce_backend`` attribute for logging.
    """
    label_smoothing = _normalize_label_smoothing(label_smoothing)
    # Topology first (mirrors the VLM factory), then head eligibility, then
    # scale validation — no positive CCE notice may precede a fallback decision.
    # Backboneless models (e.g. a stack not exposed as `.model` or as direct
    # embed_tokens/layers/norm attributes) cannot yield pre-head hidden states,
    # so the full model forward is the only faithful loss.
    tm = _get_text_model(model)
    if getattr(tm, "model", None) is None and not _has_direct_hidden_stack(model):
        print("Unsloth: text model does not expose a separable hidden-state "
              "backbone for CCE; falling back to standard cross-entropy.")
        loss_fn = make_baseline_loss_fn(label_smoothing=label_smoothing)
        loss_fn._unsloth_cce_backend = "baseline-fallback"
        return loss_fn
    head_desc = describe_output_head(model)
    _ineligible = _cce_head_ineligibility(head_desc)
    if _ineligible is not None:
        print(f"Unsloth: fused CCE cannot faithfully use this model's output "
              f"head ({_ineligible}); falling back to standard cross-entropy.")
        loss_fn = make_baseline_loss_fn(label_smoothing=label_smoothing)
        loss_fn._unsloth_cce_backend = "baseline-fallback"
        return loss_fn
    logit_scale, _transform_problem = _detect_head_transform(model, head_desc.status)
    if _transform_problem is not None:
        print(f"Unsloth: {_transform_problem}; falling back to standard cross-entropy.")
        loss_fn = make_baseline_loss_fn(label_smoothing=label_smoothing)
        loss_fn._unsloth_cce_backend = "baseline-fallback"
        return loss_fn

    softcap, _softcap_problem = _detect_logit_softcap(model)
    if _softcap_problem is not None:
        print(f"Unsloth: {_softcap_problem}; falling back to standard cross-entropy.")
        loss_fn = make_baseline_loss_fn(label_smoothing=label_smoothing)
        loss_fn._unsloth_cce_backend = "baseline-fallback"
        return loss_fn
    if softcap > 0:
        print(f"Unsloth: CCE using logit_softcap={softcap} for this model.")
    if logit_scale is not None:
        print(f"Unsloth: CCE using logit_scale={logit_scale} for this model.")

    lm_layer = head_desc.module
    use_quantized = _is_quantized_layer(lm_layer)

    _head_path = head_desc.path

    def _get_backbone(model):
        """Get backbone (for hidden states) from the live model tree."""
        return _forward_text_hidden_states

    def _get_lm_weight_layer(model):
        """Re-resolve the head from the live model tree by its descriptor path."""
        return _resolve_module_path(model, _head_path)

    if use_quantized:
        # Backstop: quantized CCE backward zeros the weight gradient
        # (dequant->grad->requant unimplemented). Fine when the LM head is
        # frozen (LoRA on a quantized base flows grad through grad_hidden), but
        # full fine-tuning would silently skip the LM head update. The loader
        # rejects this earlier; this is a safety net.
        if getattr(model, "_unsloth_full_finetuning", False):
            raise ValueError(
                "Unsloth: full_finetuning=True with a quantized LM head is "
                "not supported. The CCE backward zeros the quantized weight "
                "gradient, so the LM head would never update. Load the "
                "unquantized base model for full fine-tuning, or use LoRA "
                "(full_finetuning=False) on this quantized base."
            )
        group_size = getattr(lm_layer, "group_size", 64)
        bits = getattr(lm_layer, "bits", 4)
        quant_mode = getattr(lm_layer, "mode", "affine")
        print(
            "Unsloth: CCE using quantized matmul "
            f"(group_size={group_size}, bits={bits}, mode={quant_mode})"
        )
        _has_biases = hasattr(lm_layer, "biases")

        rt_cce = _get_runtime_cce(
            ignore_index=-100,
            logit_softcap=softcap,
            quantized=True,
            group_size=group_size,
            bits=bits,
            mode=quant_mode,
            label_smoothing=label_smoothing,
        )

        def loss_fn(model, batch, lengths, labels=None):
            if labels is None:
                inputs, targets = batch[:, :-1], batch[:, 1:]
            else:
                inputs = batch[:, :-1]
                targets = labels[:, 1:]
            hidden = _get_backbone(model)(model, inputs)
            layer = _get_lm_weight_layer(model)
            w = layer.weight
            sc = layer.scales
            bi = layer.biases if _has_biases else None
            if bi is None and quant_mode == "affine":
                bi = mx.zeros_like(sc)
            steps = mx.arange(1, targets.shape[1] + 1)
            length_mask = mx.logical_and(steps >= lengths[:, 0:1], steps < lengths[:, 1:])
            # Widen unsigned dtypes so mx.where can inject the signed -100
            # (mx.where on uint crashes the torch-backed shim).
            targets = _normalize_cce_label_dtype(targets)
            if labels is None:
                mask = length_mask
            else:
                mask = mx.logical_and(targets != -100, length_mask)
            ignore = mx.array(-100, dtype=targets.dtype)
            masked_targets = mx.where(mask, targets, ignore)
            ntoks = mask.sum()
            hidden_flat = hidden.reshape((-1, hidden.shape[-1]))
            if logit_scale is not None:
                # (h * s) @ W equals s * (h @ W) per vocab chunk, so softcap
                # and the CCE backward see the model's own scaled logits while
                # cached kernels stay scale-independent.
                hidden_flat = hidden_flat * logit_scale
            targets_flat = masked_targets.reshape((-1,))  # runtime CCE validates dtype before narrowing
            loss = rt_cce(hidden_flat, w, sc, bi, targets_flat)
            loss = loss.astype(mx.float32).sum() / _safe_token_denominator(ntoks)
            return loss, ntoks
    else:
        _skip_weight_grad = not _is_lm_head_trainable(model)
        if _skip_weight_grad:
            print("Unsloth: CCE skipping weight gradient (LM head is frozen).")

        rt_cce = _get_runtime_cce(
            ignore_index=-100,
            logit_softcap=softcap,
            label_smoothing=label_smoothing,
        )

        def loss_fn(model, batch, lengths, labels=None):
            if labels is None:
                inputs, targets = batch[:, :-1], batch[:, 1:]
            else:
                inputs = batch[:, :-1]
                targets = labels[:, 1:]
            hidden = _get_backbone(model)(model, inputs)
            w = _get_lm_weight_layer(model).weight
            if _skip_weight_grad:
                w = mx.stop_gradient(w)
            steps = mx.arange(1, targets.shape[1] + 1)
            length_mask = mx.logical_and(steps >= lengths[:, 0:1], steps < lengths[:, 1:])
            # Same widen-to-int64 rationale as the quantized branch above.
            targets = _normalize_cce_label_dtype(targets)
            if labels is None:
                mask = length_mask
            else:
                mask = mx.logical_and(targets != -100, length_mask)
            ignore = mx.array(-100, dtype=targets.dtype)
            masked_targets = mx.where(mask, targets, ignore)
            ntoks = mask.sum()
            hidden_flat = hidden.reshape((-1, hidden.shape[-1]))
            if logit_scale is not None:
                # Same pre-scaling identity as the quantized branch above.
                hidden_flat = hidden_flat * logit_scale
            targets_flat = masked_targets.reshape((-1,))  # runtime CCE validates dtype before narrowing
            loss = rt_cce(hidden_flat, w, targets_flat)
            loss = loss.astype(mx.float32).sum() / _safe_token_denominator(ntoks)
            return loss, ntoks

    loss_fn._unsloth_cce_backend = "runtime-cce"
    return loss_fn


def _model_logits(output):
    """mlx_lm models return the logits array; mlx-vlm wrappers wrap them."""
    logits = getattr(output, "logits", None)
    if logits is not None:
        return logits
    if hasattr(output, "logits"):
        # Unwrapping to None instead leaves a `'NoneType' has no attribute 'ndim'`
        # inside cross-entropy.
        raise ValueError(
            "Unsloth: the model returned an output wrapper whose `logits` is "
            "None, so there is nothing to compute a loss from."
        )
    return output


def make_baseline_loss_fn(label_smoothing=0.0):
    """Create a standard cross-entropy loss function (full logits via LM head).

    Used when use_cce=False. Returns a function
    (model, batch, lengths, labels=None) -> (loss, ntoks). With labels, uses
    labels[:,1:] and (targets != -100) as mask. With label_smoothing=0 the
    labels=None branch is byte-identical to ``mlx_lm.tuner.trainer.default_loss``.
    """
    eps = _normalize_label_smoothing(label_smoothing)
    if eps > 0.0:

        def _token_ce(logits, targets):
            # HF LabelSmoother form: lse - (1-eps)*target - eps*mean_v, with
            # the smoothed vocabulary term reduced in float32.
            logits32 = logits.astype(mx.float32)
            lse = mx.logsumexp(logits32, axis=-1)
            tgt = mx.take_along_axis(
                logits32, mx.expand_dims(targets, -1), axis=-1
            ).squeeze(-1)
            return lse - (1.0 - eps) * tgt - eps * logits32.mean(axis=-1)
    else:
        _token_ce = nn.losses.cross_entropy

    def loss_fn(model, batch, lengths, labels=None):
        if labels is None:
            # Half-open [start, end) end-exclusive mask; matches CCE/labels paths
            # (:360, :393, :439) and mlx_lm's lengths convention.
            inputs = batch[:, :-1]
            targets = batch[:, 1:]
            logits = _model_logits(model(inputs))
            steps = mx.arange(1, targets.shape[1] + 1)
            mask = mx.logical_and(steps >= lengths[:, 0:1], steps < lengths[:, 1:])
            ce = _token_ce(logits, targets) * mask
            ntoks = mask.sum()
            # Raw ntoks (no safe denominator) to match mlx_lm default_loss
            # byte-for-byte; the safe wrapper stays on the labels-aware path.
            ce = ce.astype(mx.float32).sum() / ntoks
            return ce, ntoks
        # labels-aware path: train_on_responses_only style masking.
        inputs = batch[:, :-1]
        # Widen unsigned dtypes so mx.where(..., -100, ...) and the
        # `targets != -100` compare both see signed int64.
        targets = _normalize_cce_label_dtype(labels[:, 1:])
        logits = _model_logits(model(inputs))
        steps = mx.arange(1, targets.shape[1] + 1)
        length_mask = mx.logical_and(steps >= lengths[:, 0:1], steps < lengths[:, 1:])
        if labels is None:
            mask = length_mask.astype(mx.float32)
        else:
            mask = mx.logical_and(targets != -100, length_mask).astype(mx.float32)
        # Replace -100 with 0 before CE, MLX has no ignore_index;
        # the mask already zeros out these positions in the loss.
        safe_targets = mx.where(
            targets == -100, mx.array(0, dtype=targets.dtype), targets,
        )
        ce = _token_ce(logits, safe_targets) * mask
        ntoks = mask.sum()
        loss = ce.astype(mx.float32).sum() / _safe_token_denominator(ntoks)
        return loss, ntoks

    return loss_fn


# ---------------------------------------------------------------------------
# VLM helpers
# ---------------------------------------------------------------------------

# Image/vision/audio special tokens that should never contribute to loss.
# Single source of truth shared with the CUDA collator (unsloth_zoo/vlm_tokens.py),
# so the two backends cannot drift apart.
from unsloth_zoo.vlm_tokens import VLM_PLACEHOLDER_TOKENS
_IMAGE_TOKEN_STRINGS = tuple(VLM_PLACEHOLDER_TOKENS)


def _append_unique_int(ids, value):
    if value is None:
        return
    if isinstance(value, (list, tuple, set)):
        for item in value:
            _append_unique_int(ids, item)
        return
    try:
        value = int(value)
    except (TypeError, ValueError):
        return
    if value not in ids:
        ids.append(value)


def _convert_token_to_id(tokenizer, token):
    try:
        token_ids = tokenizer.convert_tokens_to_ids([token])
    except Exception:
        try:
            token_ids = tokenizer.convert_tokens_to_ids(token)
        except Exception:
            return None
    if isinstance(token_ids, (list, tuple)):
        token_id = token_ids[0] if token_ids else None
    else:
        token_id = token_ids
    if token_id is None:
        return None
    unk_id = getattr(tokenizer, "unk_token_id", None)
    if unk_id is not None and token_id == unk_id:
        return None
    return token_id


def _get_vlm_ignore_token_ids(processor=None, config=None, model=None):
    """Resolve VLM token IDs that should be ignored by SFT loss labels.

    Mirrors the CUDA vision collator's best-effort token masking without making
    the loss depend on processor state attached to the model.
    """
    if processor is None and model is not None:
        processor = getattr(model, "_processor", None)
    if config is None and model is not None:
        config = getattr(model, "_config", None)

    ids = []
    tokenizer = _get_processor_tokenizer(processor)
    if tokenizer is not None:
        for tok_str in _IMAGE_TOKEN_STRINGS:
            _append_unique_int(ids, _convert_token_to_id(tokenizer, tok_str))

        for attr in (
            "image_token",
            "video_token",
            "audio_token",
            "boi_token",
            "eoi_token",
            # Gemma 4 wraps every audio run in these, the way boi/eoi wrap an
            # image run: processing_gemma4.py builds boa_token + placeholders +
            # eoa_token per clip.
            "boa_token",
            "eoa_token",
        ):
            token = getattr(tokenizer, attr, None)
            if token is not None:
                _append_unique_int(ids, _convert_token_to_id(tokenizer, token))

        for attr in (
            "image_token_id",
            "video_token_id",
            "audio_token_id",
            # Delimiters around a media run are generated the same way the run
            # is, so they are no more a target than the run itself.
            "audio_start_id",
            "audio_end_id",
            "boa_token_id",
            "eoa_token_id",
        ):
            _append_unique_int(ids, getattr(tokenizer, attr, None))

    for key in (
        "image_token_index",
        "image_token_id",
        "video_token_index",
        "video_token_id",
        "audio_token_index",
        "audio_token_id",
        "boi_token_index",
        "boi_token_id",
        "eoi_token_index",
        "eoi_token_id",
        # Gemma 4 declares its audio delimiters here (gemma4/config.py).
        "boa_token_index",
        "boa_token_id",
        "eoa_token_index",
        "eoa_token_id",
    ):
        _append_unique_int(ids, _config_get(config, key, None))

    # The repeated audio placeholder, which the names above do not always reach:
    # Phi-4 spells it `<|endoftext11|>` and declares it in neither the tokenizer
    # attributes nor its checkpoint config, so every audio position was a
    # supervised target. Resolved the same way run counting resolves it.
    for token_id in _get_vlm_audio_soft_token_ids(processor, config) or ():
        _append_unique_int(ids, token_id)

    if not ids:
        return None
    return ids  # plain Python list; avoids mx.eval in the hot path


def _get_image_token_ids(model):
    """Backward-compatible wrapper for legacy callers."""
    return _get_vlm_ignore_token_ids(model=model)


def _get_vlm_audio_soft_token_ids(processor=None, config=None):
    """Resolve the repeated audio placeholder ("soft") token IDs.

    Narrower than the loss-masking set in two ways: image placeholders are
    excluded, and so are the begin/end audio delimiters, which appear once per
    clip and would corrupt run counting. Families that identify their
    placeholder only by a config index resolve through a config when one is
    reachable; when nothing resolves, the caller refuses the row rather than
    training on an unverifiable audio/text alignment.
    """
    ids = []
    tokenizer = _get_processor_tokenizer(processor)
    if tokenizer is not None:
        for tok_str in _AUDIO_SOFT_TOKEN_STRINGS:
            _append_unique_int(ids, _convert_token_to_id(tokenizer, tok_str))
        token = getattr(tokenizer, "audio_token", None)
        if token is not None:
            _append_unique_int(ids, _convert_token_to_id(tokenizer, token))
        _append_unique_int(ids, getattr(tokenizer, "audio_token_id", None))
    for source in (config, getattr(processor, "config", None)):
        for key in ("audio_token_index", "audio_token_id"):
            _append_unique_int(ids, _config_get(source, key, None))
    return ids


def _normalize_cce_label_dtype(labels):
    """Widen unsigned label dtypes to int64 so masking can inject -100.

    uint8/16/32 fit losslessly in int64. uint64 values in (2**63, 2**64)
    wrap negative on cast and are routed to a positive out-of-vocab
    sentinel (1<<62) so runtime CCE's validity check NaN-poisons those
    rows instead of letting an overflowed uint64 like 2**64-100 collide
    with ignore_index=-100. Signed/float dtypes pass through unchanged.
    """
    if labels is None:
        return labels
    dtype = getattr(labels, "dtype", None)
    if dtype is None:
        return labels
    uint64_dtype = getattr(mx, "uint64", None)
    if uint64_dtype is not None and dtype == uint64_dtype:
        # Cast to signed int64 first; uint64 compares crash the torch shim.
        # `labels_i64 < 0` catches every uint64 >= 2**63.
        labels_i64 = labels.astype(mx.int64)
        invalid_sentinel = mx.array((1 << 62), dtype=mx.int64)
        return mx.where(labels_i64 < 0, invalid_sentinel, labels_i64)
    unsigned_dtypes = tuple(
        d for d in (
            getattr(mx, "uint8", None),
            getattr(mx, "uint16", None),
            getattr(mx, "uint32", None),
        )
        if d is not None
    )
    if dtype in unsigned_dtypes:
        return labels.astype(mx.int64)
    return labels


def _stage_vlm_label_mask_np(inputs, ignore_token_ids=None, labels=None):
    """Decide WHICH VLM positions are ignored (ignore tokens, attention zeros,
    positions a response/completion mask already set to -100). Label VALUES come
    at finalize time from the SAME converted ids the legacy path used, so
    coercion parity holds by construction. Float comparisons mirror MLX's
    effective float32 narrowing so placement matches the finalized tensors.
    """
    if labels is None:
        labels = inputs.get(_RAW_INPUT_IDS_FOR_LABELS)
        if labels is None:
            labels = inputs["input_ids"]
    if isinstance(labels, np.ndarray):
        values = labels
    elif hasattr(labels, "tolist"):
        try:
            values = np.asarray(labels)  # dtype-preserving (torch fp16 etc.)
        except (TypeError, ValueError):
            values = np.asarray(labels.tolist())
    else:
        values = np.asarray(labels)
    if values.ndim == 1:
        values = values.reshape(1, -1)
    if values.dtype == np.float64:
        values = values.astype(np.float32)
    if np.issubdtype(values.dtype, np.integer):
        # Same normalization finalize uses (wide unsigned ids -> int64 sentinels)
        values = _normalize_numpy_cce_labels(values)
    mask = values == -100
    if ignore_token_ids:
        compare = np.asarray(list(ignore_token_ids))
        if np.issubdtype(values.dtype, np.floating):
            compare = compare.astype(values.dtype)  # mirror mx scalar narrowing
        mask = mask | np.isin(values, compare)
    spans = _audio_span_positions_np(inputs, mask.shape)
    if spans is not None:
        mask = mask | spans
    attention = inputs.get("attention_mask")
    if attention is not None:
        attention_np = (
            attention if isinstance(attention, np.ndarray)
            else np.asarray(
                attention.tolist() if hasattr(attention, "tolist")
                else attention
            )
        )
        if attention_np.ndim == 1:
            attention_np = attention_np.reshape(1, -1)
        if attention_np.dtype == np.float64:
            attention_np = attention_np.astype(np.float32)
        mask = mask | (attention_np.astype(np.int32) == 0)
    return mask

def _reject_mlx_valued_vlm(context):
    raise ValueError(
        f"Unsloth MLX VLM: {context} produced MLX-array values; the prefetch "
        "producer must not convert MLX values off the consumer thread. Use "
        "streaming_prefetch_batches=0 for this stream."
    )


def _reject_non_integer_host_vlm_ids(context):
    raise ValueError(
        f"Unsloth MLX VLM: {context} produced non-integer host token ids, "
        "which need the synchronous legacy conversion path. Use "
        "streaming_prefetch_batches=0 for this stream."
    )


def _vlm_ids_integer_host(inputs):
    """True when label-bearing ids are integer host values (the staged case).
    Float or exotic-dtype ids route to the bit-exact legacy path instead of a
    numpy re-implementation of MLX float semantics."""
    ids = inputs.get(_RAW_INPUT_IDS_FOR_LABELS)
    if ids is None:
        ids = inputs.get("input_ids")
    if isinstance(ids, np.ndarray):
        return np.issubdtype(ids.dtype, np.integer)
    if isinstance(ids, (list, tuple)):
        def _all_integer_leaves(value):
            if isinstance(value, (list, tuple)):
                return all(_all_integer_leaves(element) for element in value)
            return (
                isinstance(value, (int, np.integer))
                and not isinstance(value, bool)
            )
        return _all_integer_leaves(ids)
    try:
        arr = np.asarray(ids)
    except (TypeError, ValueError):
        return False
    return np.issubdtype(arr.dtype, np.integer)


def _vlm_inputs_host_valued(inputs):
    """False when any processor output field arrived as an MLX array."""
    return not any(_contains_mlx_values(value) for value in inputs.values())


class _HostStagedVLMBatch:
    """Host-side VLM batch: processor fields + decided labels, pre-MLX.

    ``prefinalized`` carries an already-MLX legacy batch for MLX-valued
    processor outputs in synchronous mode. In producer mode those stage
    opaquely instead, materialized producer-side because lazy MLX graphs cannot
    cross threads: plain-SFT rides ``inputs`` with ``label_mask=None``,
    prompt/completion rides ``pc_opaque`` with the combine deferred to the
    consumer finalizer.
    """

    __slots__ = ("inputs", "label_mask", "widen_labels_int64", "host_valued",
                 "ignore_token_ids", "config", "prefinalized", "pc_opaque",
                 "pc_audio")

    def __init__(self, inputs, label_mask, host_valued=True,
                 ignore_token_ids=None, config=None, prefinalized=None,
                 widen_labels_int64=False, pc_opaque=None, pc_audio=None):
        self.inputs = inputs
        self.label_mask = label_mask
        self.host_valued = host_valued
        self.ignore_token_ids = ignore_token_ids
        self.config = config
        self.prefinalized = prefinalized
        self.widen_labels_int64 = widen_labels_int64
        self.pc_opaque = pc_opaque
        # Checked after the deferred combine: the ids only exist once it runs.
        self.pc_audio = pc_audio


def _finalize_vlm_batch(staged, keep_raw_carrier=False, phase=None):
    """The single consumer-thread point converting staged VLM batches to MLX.

    Host-staged batches already made every label decision, so only conversion
    and compile preparation run here. Opaque processor-owned payloads (plain-SFT
    with ``label_mask=None``, ``pc_opaque`` prompt/completion carriers) instead
    run their combine and legacy label decisions here.

    ``phase`` is forwarded verbatim to the terminal compile preparation at every
    exit, so ``"content"`` stops at the width seam and leaves the caller to pad
    to a planned width and run the ``"positions"`` phase.
    """
    if staged.prefinalized is not None:
        return _prepare_vlm_batch_for_compile(
            staged.prefinalized, staged.config, phase=phase,
        )
    if staged.pc_opaque is not None:
        (prompt_inputs, completion_inputs, flush_side, pad_id, max_seq_length,
         completion_only_loss) = staged.pc_opaque
        audio_counts, audio_soft_ids, audio_budget = (
            staged.pc_audio or (None, None, None)
        )
        inner = _combine_vlm_prompt_completion_inputs(
            prompt_inputs, completion_inputs, flush_side, pad_id,
            max_seq_length,
            ignore_token_ids=staged.ignore_token_ids,
            completion_only_loss=completion_only_loss,
            audio_counts=audio_counts, audio_soft_ids=audio_soft_ids,
            audio_budget=audio_budget,
        )
        inner.config = staged.config
        return _finalize_vlm_batch(
            inner, keep_raw_carrier=keep_raw_carrier, phase=phase,
        )
    batch = _to_mx_vlm_batch(staged.inputs)
    if staged.label_mask is None:
        # Opaque processor outputs (mlx-vlm wrappers return MLX arrays): run the
        # legacy label path here on the consumer thread. The producer only
        # materialized the processor's own pending graphs, nothing more.
        batch["labels"] = _apply_vlm_label_masks(
            batch, ignore_token_ids=staged.ignore_token_ids,
        )
        batch.pop(_RAW_INPUT_IDS_FOR_LABELS, None)
        return _prepare_vlm_batch_for_compile(batch, staged.config, phase=phase)
    if staged.label_mask is not None:
        # Values ride the same converted ids legacy used, so conversion-time
        # errors match exactly; only the host-decided placement differs.
        raw = (
            batch.get(_RAW_INPUT_IDS_FOR_LABELS)
            if keep_raw_carrier
            else batch.pop(_RAW_INPUT_IDS_FOR_LABELS, None)
        )
        base = _normalize_cce_label_dtype(
            raw if raw is not None else batch["input_ids"]
        )
        ignore = mx.array(-100, dtype=base.dtype)
        labels = mx.where(mx.array(staged.label_mask), ignore, base)
        if staged.widen_labels_int64:
            labels = mx.array(
                np.asarray(labels.tolist(), dtype=np.int64)
            )  # legacy completion-branch coercion, verbatim
        batch["labels"] = labels
    return _prepare_vlm_batch_for_compile(batch, staged.config, phase=phase)


def _mask_label_token_ids(targets, ignore_token_ids, ignore_index=-100):
    if not ignore_token_ids:
        return targets
    # Widen unsigned dtypes so the signed ignore_index can be injected.
    targets = _normalize_cce_label_dtype(targets)
    should_ignore = targets == ignore_token_ids[0]
    for tok_id in ignore_token_ids[1:]:
        should_ignore = should_ignore | (targets == tok_id)
    ignore = mx.array(ignore_index, dtype=targets.dtype)
    return mx.where(should_ignore, ignore, targets)


def _mask_image_tokens(targets, image_token_ids):
    """Set image/vision token positions in targets to -100."""
    return _mask_label_token_ids(targets, image_token_ids)


def _apply_vlm_label_masks(batch_dict, labels=None, ignore_token_ids=None,
                           ignore_index=-100):
    # Do NOT narrow to int32: runtime CCE validates the original dtype before
    # its own narrow, so wide/unsigned invalid ids (e.g. uint32(2**32-100))
    # must survive as out-of-vocab sentinels instead of wrapping to -100.
    # Prefer the pre-narrow raw carrier when deriving labels from input_ids.
    if labels is None:
        labels = batch_dict.get(_RAW_INPUT_IDS_FOR_LABELS, batch_dict["input_ids"])
    labels = _normalize_cce_label_dtype(labels)
    labels = _mask_label_token_ids(labels, ignore_token_ids, ignore_index)
    spans = _audio_span_positions_np(batch_dict, labels.shape)
    if spans is not None:
        # This path decides labels for processor output the host staging could
        # not claim, so it owns the span masking too.
        labels = mx.where(mx.array(spans),
                          mx.array(ignore_index, dtype=labels.dtype), labels)
    attention_mask = batch_dict.get("attention_mask")
    if attention_mask is not None:
        ignore = mx.array(ignore_index, dtype=labels.dtype)
        labels = mx.where(attention_mask == 0, ignore, labels)
    return labels


def _mask_prompt_tokens(targets, assistant_token_id):
    """Mask tokens before the first assistant response (train_on_completions_only).

    Per row, positions before the first assistant_token_id become -100. If the
    token is absent, the row is left unmasked (assumed all completion).
    """
    if assistant_token_id <= 0:
        return targets
    targets = _normalize_cce_label_dtype(targets)
    is_assistant = (targets == assistant_token_id)
    cumulative = mx.cumsum(is_assistant.astype(mx.int32), axis=1)
    has_assistant = mx.any(is_assistant, axis=1, keepdims=True)
    prompt_mask = mx.logical_and(has_assistant, cumulative == 0)
    ignore = mx.array(-100, dtype=targets.dtype)
    return mx.where(prompt_mask, ignore, targets)


def _is_vlm_model(model) -> bool:
    """Check if model is a VLM (has language_model + vision component)."""
    if getattr(model, "_unsloth_text_only_vlm", False):
        return False
    explicit_flag = getattr(model, "_is_vlm_model", None)
    if explicit_flag is not None:
        return bool(explicit_flag)
    if not hasattr(model, "language_model"):
        return False
    return any(hasattr(model, attr) for attr in
               ("vision_tower", "vision_model", "vision_encoder", "visual",
                "multi_modal_projector", "audio_tower"))


def _align_logits_with_labels(logits, labels):
    """Truncate logits or labels so their sequence dimensions match.

    VLMs can inject vision tokens that change the sequence length of logits
    relative to the label sequence.
    """
    l_seq = logits.shape[1]
    t_seq = labels.shape[1]
    if l_seq > t_seq:
        logits = logits[:, :t_seq, :]
    elif t_seq > l_seq:
        labels = labels[:, :l_seq]
    return logits, labels


def _trim_sequence_aligned_vlm_kwargs(extra_kwargs, seq_len):
    """Trim auxiliary VLM tensors that track token sequence length.

    Some VLMs, notably Qwen3-VL, pass position_ids through the batch. The loss
    function shifts input_ids for causal LM training, so these auxiliary tensors
    must be shifted to the same token length before the model builds rotary
    embeddings.
    """
    position_ids = extra_kwargs.get("position_ids")
    if position_ids is not None and hasattr(position_ids, "shape"):
        if position_ids.shape[-1] != seq_len:
            extra_kwargs["position_ids"] = position_ids[..., :seq_len]
    return extra_kwargs


def make_vlm_baseline_loss_fn(model=None, assistant_token_id=0,
                              ignore_token_ids=None):
    """Create a standard cross-entropy loss function for VLMs.

    Takes a batch dict with input_ids, pixel_values, attention_mask.

    Returns:
        A function (model, batch_dict) -> (loss, ntoks).
    """
    _image_token_ids = (
        ignore_token_ids
        if ignore_token_ids is not None
        else (_get_image_token_ids(model) if model is not None else None)
    )
    _assistant_token_id = assistant_token_id

    def loss_fn(model, batch_dict):
        input_ids = batch_dict["input_ids"]
        pixel_values = batch_dict.get("pixel_values")
        attention_mask = batch_dict.get("attention_mask")
        labels = batch_dict.get("labels")

        # Forward full sequence then shift (Qwen3-VL mRoPE/deepstack need it);
        # mirrors `_vlm_cce_forward` so use_cce={True,False} stay in parity.
        inputs = input_ids

        # Pass through extras (e.g. image_grid_thw); strip the private
        # `_unsloth_*` carriers, matching _vlm_cce_forward's filter.
        fwd_kwargs = {
            k: v for k, v in batch_dict.items()
            if k not in ("input_ids", "pixel_values", "attention_mask", "labels")
            and not k.startswith("_unsloth_")
            and v is not None
        }
        fwd_kwargs = _trim_sequence_aligned_vlm_kwargs(fwd_kwargs, inputs.shape[1])
        # Always sent: 13 families declare `mask` without a default. None lets
        # them build the mask they would use for generation.
        fwd_kwargs["mask"] = (
            attention_mask if _keeps_forwarded_mask(model) else None
        )
        shared_kv = _build_shared_kv_caches(model)
        if shared_kv is not None:
            fwd_kwargs["cache"] = shared_kv
        # gemma3n scales token embeddings by sqrt(hidden_size) on the ids path
        # only, and `Model.__call__` sends ids through `get_input_embeddings`,
        # which does not scale. Handing the model ids therefore trains on text
        # embeddings ~45x too small beside merged features. `_vlm_cce_forward`
        # already merges and rescales itself; do the same here so
        # use_cce={True,False} stay in parity instead of differing by that.
        scaled_embeds = None
        if _vlm_embed_scale(model) is not None:
            embed_result = model.get_input_embeddings(
                inputs,
                pixel_values,
                mask=fwd_kwargs.get("mask"),
                **{k: v for k, v in fwd_kwargs.items()
                   if k not in ("mask", "cache")},
            )
            merged_embeds, embed_kwargs = _unpack_embed_result(embed_result, model)
            scaled_embeds = _apply_vlm_embed_scale(model, inputs, merged_embeds)
            # per_layer_inputs and friends: the merge produced them, and
            # recomputing from ids inside the stack would redo the work.
            for key, value in embed_kwargs.items():
                fwd_kwargs.setdefault(key, value)
        if scaled_embeds is not None:
            # Not `model(...)`: mlx-vlm up to 0.4.4 -- the floor this package
            # declares -- re-embeds from ids inside `Model.__call__` and drops
            # a supplied `inputs_embeds`, so the rescale above would be thrown
            # away on exactly the versions that need it. 0.5.0 onwards honors
            # it by forwarding straight to the language model; do that here on
            # every version, which is what `_vlm_cce_forward` already does.
            output = _get_text_model(model)(
                inputs, inputs_embeds=scaled_embeds, **fwd_kwargs
            )
        else:
            output = model(inputs, pixel_values=pixel_values, **fwd_kwargs)
        logits = _model_logits(output)
        logits = logits.astype(mx.float32)
        # Drop the final position so logits predict the next token.
        logits = logits[:, :-1, :]

        if labels is not None:
            # Extra masks keep externally supplied labels compatible.
            targets = _normalize_cce_label_dtype(labels[:, 1:])
            targets = _mask_image_tokens(targets, _image_token_ids)
            # _apply_vlm_label_masks ignores assistant boundaries; mask here.
            targets = _mask_prompt_tokens(targets, _assistant_token_id)
            logits, targets = _align_logits_with_labels(logits, targets)
            if attention_mask is not None:
                length_mask = attention_mask[:, 1:][:, :targets.shape[1]]
            else:
                length_mask = mx.ones_like(targets, dtype=mx.float32)
            mask = mx.logical_and(targets != -100, length_mask).astype(mx.float32)
        else:
            # Prefer the raw (pre-narrow) input_ids so wide invalid ids
            # (e.g. np.uint32(2**32-100)) reach runtime CCE as out-of-vocab
            # sentinels instead of wrapping to -100 via the int32 narrow.
            target_source = batch_dict.get(_RAW_INPUT_IDS_FOR_LABELS, input_ids)
            targets = _normalize_cce_label_dtype(target_source[:, 1:])

            # Vision token injection can change seq length
            logits, targets = _align_logits_with_labels(logits, targets)

            # Build mask from attention_mask (shifted to match targets)
            if attention_mask is not None:
                length_mask = attention_mask[:, 1:]
                length_mask = length_mask[:, :targets.shape[1]]
            else:
                length_mask = mx.ones_like(targets, dtype=mx.float32)

            targets = _mask_image_tokens(targets, _image_token_ids)
            targets = _mask_prompt_tokens(targets, _assistant_token_id)
            # Exclude masked positions from length_mask
            mask = mx.where(
                targets == -100,
                mx.array(0, dtype=length_mask.dtype),
                length_mask,
            )

        # Replace -100 with 0 before CE, MLX has no ignore_index;
        # the mask already zeros out these positions in the loss.
        safe_targets = mx.where(
            targets == -100, mx.array(0, dtype=targets.dtype), targets,
        )
        ce = nn.losses.cross_entropy(logits, safe_targets) * mask
        ntoks = mask.sum()
        loss = ce.astype(mx.float32).sum() / _safe_token_denominator(ntoks)
        return loss, ntoks

    loss_fn._unsloth_cce_backend = "baseline-ce"
    return loss_fn


def _unpack_embed_result(embed_result, model):
    """Unpack get_input_embeddings result into embeds + backbone kwargs.

    Handles plain mx.array returns and the InputEmbeddingsFeatures dataclass
    (gemma4 per_layer_inputs, qwen3-vl position_ids/deepstack, etc.).
    """
    backbone_kwargs = {}
    if hasattr(embed_result, "inputs_embeds"):
        merged_embeds = embed_result.inputs_embeds
        if getattr(embed_result, "attention_mask_4d", None) is not None:
            model_type = _config_get(getattr(model, "config", None), "model_type")
            if model_type != "gemma3":
                backbone_kwargs["attention_mask_4d"] = embed_result.attention_mask_4d
        if getattr(embed_result, "position_ids", None) is not None:
            backbone_kwargs["position_ids"] = embed_result.position_ids
        # Gemma4: per-layer inputs for vision token injection
        if getattr(embed_result, "per_layer_inputs", None) is not None:
            backbone_kwargs["per_layer_inputs"] = embed_result.per_layer_inputs
        # Qwen3-VL deepstack: visual position masks + visual embeds
        if getattr(embed_result, "visual_pos_masks", None) is not None:
            backbone_kwargs["visual_pos_masks"] = embed_result.visual_pos_masks
        if getattr(embed_result, "deepstack_visual_embeds", None) is not None:
            backbone_kwargs["deepstack_visual_embeds"] = embed_result.deepstack_visual_embeds
        if getattr(embed_result, "cross_attention_states", None) is not None:
            backbone_kwargs["cross_attention_states"] = embed_result.cross_attention_states
        if getattr(embed_result, "cross_attention_mask", None) is not None:
            backbone_kwargs["cross_attention_mask"] = embed_result.cross_attention_mask
        if getattr(embed_result, "full_text_row_masked_out_mask", None) is not None:
            backbone_kwargs["full_text_row_masked_out_mask"] = (
                embed_result.full_text_row_masked_out_mask
            )
        if getattr(embed_result, "decoder_inputs_embeds", None) is not None:
            backbone_kwargs["decoder_inputs_embeds"] = embed_result.decoder_inputs_embeds
        if getattr(embed_result, "attention_mask", None) is not None:
            backbone_kwargs["attention_mask"] = embed_result.attention_mask
    else:
        merged_embeds = embed_result

    # Qwen-VL family: some get_input_embeddings paths stash position_ids on the
    # language model wrapper; the inner backbone needs them explicitly.
    # Do not override position_ids explicitly returned by InputEmbeddingsFeatures
    # (for example when the collator passed CUDA-parity mRoPE IDs through the
    # embedder).
    # When no position_ids were stashed (e.g. text-only samples or simple
    # images without grid_thw), generate sequential ones so the backbone
    # doesn't crash accessing cache.offset with cache=None.
    lm = getattr(model, "language_model", None)
    if lm is not None and "position_ids" not in backbone_kwargs:
        _MISSING = object()
        pos_ids = getattr(lm, "_position_ids", _MISSING)
        if pos_ids is not _MISSING and pos_ids is not None:
            backbone_kwargs["position_ids"] = pos_ids
        elif pos_ids is None:
            # Fallback: sequential position_ids. Correct for text-only and
            # single-image samples. For multi-image with spatial m-RoPE
            # (Qwen VL), the per-axis positions should differ for image
            # regions — but grid_thw metadata is unavailable here so we
            # use sequential as an approximation.
            seq_len = merged_embeds.shape[1]
            pos_ids = mx.arange(seq_len).reshape(1, -1)
            pos_ids = mx.broadcast_to(pos_ids, (merged_embeds.shape[0], seq_len))
            # Qwen VL m-RoPE uses 3 axes: temporal, height, width
            MROPE_AXES = 3
            pos_ids = mx.expand_dims(pos_ids, axis=0)
            pos_ids = mx.tile(pos_ids, (MROPE_AXES, 1, 1))
            backbone_kwargs["position_ids"] = pos_ids

    return merged_embeds, backbone_kwargs


def _get_backbone_embed_kwarg(backbone):
    try:
        params = inspect.signature(backbone.__call__).parameters
    except (TypeError, ValueError):
        return "inputs_embeds"
    if "inputs_embeds" in params:
        return "inputs_embeds"
    if "input_embeddings" in params:
        return "input_embeddings"
    if "input_embeds" in params:
        return "input_embeds"
    return "inputs_embeds"


def _filter_backbone_kwargs(backbone, kwargs):
    try:
        params = inspect.signature(backbone.__call__).parameters
    except (TypeError, ValueError):
        return kwargs
    if any(param.kind == inspect.Parameter.VAR_KEYWORD for param in params.values()):
        return kwargs
    allowed = set(params)
    return {k: v for k, v in kwargs.items() if k in allowed}


def _vlm_cce_forward(model, batch_dict, image_token_ids=None,
                     assistant_token_id=0):
    """Shared VLM CCE forward: embed -> backbone -> hidden + masked_targets + ntoks."""
    input_ids = batch_dict["input_ids"]
    pixel_values = batch_dict.get("pixel_values")
    attention_mask = batch_dict.get("attention_mask")
    labels = batch_dict.get("labels")

    # Forward full sequence then shift hidden[:, :-1] (Qwen3-VL mRoPE/deepstack).
    inputs = input_ids
    fwd_attn_mask = attention_mask

    # Collect extra keys (e.g. image_grid_thw for Qwen). Read the private
    # collated-position flag first, then strip all `_unsloth_*` carriers
    # so the embedder/backbone never sees them.
    use_collated_position_ids = bool(
        batch_dict.get("_unsloth_collated_position_ids")
    )
    extra_kwargs = {
        k: v for k, v in batch_dict.items()
        if k not in ("input_ids", "pixel_values", "attention_mask", "labels")
        and not k.startswith("_unsloth_")
        and v is not None
    }
    extra_kwargs = _trim_sequence_aligned_vlm_kwargs(extra_kwargs, inputs.shape[1])

    embed_result = model.get_input_embeddings(
        inputs,
        pixel_values,
        mask=fwd_attn_mask,
        **extra_kwargs,
    )
    merged_embeds, backbone_kwargs = _unpack_embed_result(embed_result, model)
    merged_embeds = _apply_vlm_embed_scale(model, inputs, merged_embeds)
    # Prefer collator-built mRoPE IDs when present. Qwen/GLM collators build
    # CUDA-parity full-sequence positions; recomputing inside the embedder moved
    # Qwen3-VL first-step loss from ~6.45 to ~6.90 on the real-cat fixture.
    if use_collated_position_ids and "position_ids" in extra_kwargs:
        backbone_kwargs["position_ids"] = extra_kwargs["position_ids"]
    if "token_type_ids" in extra_kwargs:
        backbone_kwargs["token_type_ids"] = extra_kwargs["token_type_ids"]
        if attention_mask is not None:
            backbone_kwargs["attention_mask"] = attention_mask

    shared_kv = _build_shared_kv_caches(model)
    if shared_kv is not None:
        backbone_kwargs["cache"] = shared_kv

    hidden = _forward_text_hidden_states(
        model,
        inputs,
        inputs_embeds=merged_embeds,
        **backbone_kwargs,
    )
    hidden = hidden[:, :-1, :]

    if labels is not None:
        # Extra mask keeps externally supplied labels compatible.
        targets = labels[:, 1:]
        masked_targets = _mask_image_tokens(targets, image_token_ids)
        if attention_mask is not None:
            length_mask = attention_mask[:, 1:][:, :masked_targets.shape[1]]
        else:
            length_mask = mx.ones_like(masked_targets, dtype=mx.bool_)
        masked_targets = mx.where(
            mx.logical_and(masked_targets != -100, length_mask),
            masked_targets,
            -100,
        )
        # Completion-only masking; _apply_vlm_label_masks doesn't do this.
        masked_targets = _mask_prompt_tokens(masked_targets, assistant_token_id)
        ntoks = (masked_targets != -100).sum()
    else:
        # Prefer the raw (pre-narrow) input_ids so wide invalid ids
        # (e.g. np.uint32(2**32-100)) reach runtime CCE as out-of-vocab
        # sentinels instead of wrapping to -100 via the int32 narrow.
        target_source = batch_dict.get(_RAW_INPUT_IDS_FOR_LABELS, input_ids)
        targets = _normalize_cce_label_dtype(target_source[:, 1:])

        if attention_mask is not None:
            length_mask = attention_mask[:, 1:][:, :targets.shape[1]]
        else:
            length_mask = mx.ones_like(targets, dtype=mx.float32)

        ignore = mx.array(-100, dtype=targets.dtype)
        masked_targets = mx.where(length_mask, targets, ignore)

        masked_targets = _mask_image_tokens(masked_targets, image_token_ids)
        # Completion-only: mask prompt before first assistant response
        masked_targets = _mask_prompt_tokens(masked_targets, assistant_token_id)

        ntoks = (masked_targets != -100).sum()

    # Align sequence lengths (vision token injection changes seq len)
    h_seq, t_seq = hidden.shape[1], masked_targets.shape[1]
    if h_seq > t_seq:
        hidden = hidden[:, :t_seq, :]
    elif t_seq > h_seq:
        masked_targets = masked_targets[:, :h_seq]
        ntoks = (masked_targets != -100).sum()

    return hidden, masked_targets, ntoks


def _config_get(config, key, default=None):
    if isinstance(config, dict):
        return config.get(key, default)
    return getattr(config, key, default)


def _config_to_mapping(config):
    if isinstance(config, dict):
        return config
    if config is None:
        return {}
    return {
        key: getattr(config, key)
        for key in dir(config)
        if not key.startswith("_") and not callable(getattr(config, key))
    }


def _phi4mm_token_ids(config):
    """Phi-4-multimodal's image and audio token ids.

    Its checkpoint config.json declares neither; mlx-vlm supplies both as
    dataclass defaults. Training threads the checkpoint mapping rather than the
    model's config object, so read the defaults off the dataclass instead of
    restating them here.
    """
    image_id = _config_get(config, "image_token_index")
    audio_id = _config_get(config, "audio_token_index")
    if image_id is None or audio_id is None:
        from mlx_vlm.models.phi4mm.config import ModelConfig as _Phi4MMConfig

        fields = _Phi4MMConfig.__dataclass_fields__
        if image_id is None:
            image_id = fields["image_token_index"].default
        if audio_id is None:
            audio_id = fields["audio_token_index"].default
    return int(image_id), int(audio_id)


def _normalize_grid_thw(grid_thw):
    if grid_thw is None:
        return None
    if isinstance(grid_thw, mx.array):
        grid_thw = grid_thw.tolist()
    elif hasattr(grid_thw, "tolist"):
        grid_thw = grid_thw.tolist()

    normalized = []
    for item in grid_thw:
        if hasattr(item, "tolist"):
            item = item.tolist()
        normalized.append(tuple(int(x) for x in item))
    return tuple(normalized)


def _mlx_vlm_canonical_model_type(model_type):
    """The name mlx-vlm resolves this config's `model_type` to.

    mlx-vlm lower-cases the value and sends it through MODEL_REMAPPING to pick the
    module, never writing the result back, so a family set keyed on the canonical
    spelling has to resolve the same way or an aliased checkpoint misses it. Hyphens
    are folded too, since MODEL_REMAPPING carries only the aliases it has met.

    Any failure leaves the name alone: an mlx-vlm too old to have MODEL_REMAPPING is
    exactly the case where the raw spelling is the only spelling.
    """
    if not model_type:
        return ""
    name = str(model_type).lower()
    try:
        from mlx_vlm.utils import MODEL_REMAPPING
        name = MODEL_REMAPPING.get(name, name)
    except Exception:
        pass
    return name.replace("-", "_")


# Families whose mlx-vlm code indexes the vision grid as an array (`.tolist()`,
# `.prod()`, `[:, 1:]`). Everything else keeps the tuple the Qwen/Paddle compile
# patches trace: an array becomes a tracer under mx.compile and `.tolist()` raises.
_VLM_ARRAY_GRID_MODEL_TYPES = frozenset({
    "glm4v",
    "glm_ocr",
    # Not compile-patched, and opens with `grid_thw.tolist()`.
    "muse_glimmer",
    "glm5_next",
})


def _grid_thw_to_mx_array(grid_thw):
    if grid_thw is None:
        return None
    return mx.array(grid_thw, dtype=mx.int32)


def _normalize_size_tuples(values):
    if values is None:
        return None
    if isinstance(values, mx.array):
        values = values.tolist()
    elif hasattr(values, "tolist"):
        values = values.tolist()

    normalized = []
    for item in values:
        if hasattr(item, "tolist"):
            item = item.tolist()
        normalized.append(tuple(int(x) for x in item))
    return tuple(normalized)


def _normalize_int_tuple(values):
    if values is None:
        return None
    if isinstance(values, mx.array):
        values = values.tolist()
    elif hasattr(values, "tolist"):
        values = values.tolist()
    return tuple(int(x) for x in values)


def _normalize_numpy_cce_labels(labels):
    """numpy-side analogue of `_normalize_cce_label_dtype` for VLM expand paths.

    np.uint64 values above 2**63-1 would OverflowError when packed into the
    int64 buffer used by `_expand_image_token_sequences` / `_expand_token_runs`;
    route them to a positive 1<<62 sentinel (so an overflowed 2**64-100 cannot
    silently masquerade as ignore_index=-100) and downcast other unsigned
    dtypes to int64.
    """
    labels_np = np.asarray(labels)
    if labels_np.dtype == np.uint64:
        overflow_mask = labels_np > np.uint64((1 << 63) - 1)
        return np.where(
            overflow_mask,
            np.int64(1 << 62),
            labels_np.astype(np.int64),
        )
    if np.issubdtype(labels_np.dtype, np.unsignedinteger):
        return labels_np.astype(np.int64)
    return labels_np


def _expand_image_token_sequences(
    input_ids,
    attention_mask,
    image_token_id,
    repeat_count,
    labels=None,
):
    input_ids_np = np.asarray(input_ids)
    attention_mask_np = (
        np.asarray(attention_mask)
        if attention_mask is not None
        else np.ones_like(input_ids_np, dtype=np.int32)
    )
    labels_np = _normalize_numpy_cce_labels(labels) if labels is not None else None

    expanded_ids = []
    expanded_masks = []
    expanded_labels = [] if labels_np is not None else None
    max_len = 0
    for row_idx, (row_ids, row_mask) in enumerate(zip(input_ids_np, attention_mask_np)):
        new_ids = []
        new_mask = []
        new_labels = [] if labels_np is not None else None
        row_labels_list = labels_np[row_idx].tolist() if labels_np is not None else None
        for pos, (token_id, mask_value) in enumerate(zip(row_ids.tolist(), row_mask.tolist())):
            if int(token_id) == int(image_token_id):
                new_ids.extend([int(image_token_id)] * int(repeat_count))
                new_mask.extend([int(mask_value)] * int(repeat_count))
                if new_labels is not None:
                    new_labels.extend([-100] * int(repeat_count))
            else:
                new_ids.append(int(token_id))
                new_mask.append(int(mask_value))
                if new_labels is not None:
                    new_labels.append(int(row_labels_list[pos]))
        expanded_ids.append(new_ids)
        expanded_masks.append(new_mask)
        if expanded_labels is not None:
            expanded_labels.append(new_labels)
        max_len = max(max_len, len(new_ids))

    padded_ids = np.zeros((len(expanded_ids), max_len), dtype=np.int32)
    padded_masks = np.zeros((len(expanded_masks), max_len), dtype=np.int32)
    # int64 so wide invalid labels survive without OverflowError before the
    # runtime CCE validity check; CCE owns dtype narrowing post-validate.
    padded_labels = (
        np.full((len(expanded_labels), max_len), -100, dtype=np.int64)
        if expanded_labels is not None else None
    )
    for row_idx, (row_ids, row_mask) in enumerate(zip(expanded_ids, expanded_masks)):
        row_len = len(row_ids)
        padded_ids[row_idx, :row_len] = row_ids
        padded_masks[row_idx, :row_len] = row_mask
        if padded_labels is not None:
            padded_labels[row_idx, :row_len] = expanded_labels[row_idx]

    if padded_labels is not None:
        return mx.array(padded_ids), mx.array(padded_masks), mx.array(padded_labels)
    return mx.array(padded_ids), mx.array(padded_masks)


def _expand_token_runs(
    input_ids,
    attention_mask,
    replacements_by_batch,
    labels=None,
):
    input_ids_np = np.asarray(input_ids)
    attention_mask_np = (
        np.asarray(attention_mask)
        if attention_mask is not None
        else np.ones_like(input_ids_np, dtype=np.int32)
    )
    labels_np = _normalize_numpy_cce_labels(labels) if labels is not None else None

    expanded_ids = []
    expanded_masks = []
    expanded_labels = [] if labels_np is not None else None
    max_len = 0
    for row_idx, (row_ids, row_mask, replacements) in enumerate(zip(
        input_ids_np,
        attention_mask_np,
        replacements_by_batch,
    )):
        replacements = sorted(replacements, key=lambda item: item[0])
        new_ids = []
        new_mask = []
        new_labels = [] if labels_np is not None else None
        row_labels_list = labels_np[row_idx].tolist() if labels_np is not None else None
        prev = 0
        row_ids_list = row_ids.tolist()
        row_mask_list = row_mask.tolist()
        for start, end, token_id, repeat in replacements:
            start = int(start)
            end = int(end)
            repeat = int(repeat)
            if start > prev:
                new_ids.extend(row_ids_list[prev:start])
                new_mask.extend(row_mask_list[prev:start])
                if new_labels is not None:
                    new_labels.extend(row_labels_list[prev:start])
            new_ids.extend([int(token_id)] * repeat)
            fill_mask = int(row_mask_list[start]) if start < len(row_mask_list) else 1
            new_mask.extend([fill_mask] * repeat)
            if new_labels is not None:
                new_labels.extend([-100] * repeat)
            prev = end
        if prev < len(row_ids_list):
            new_ids.extend(row_ids_list[prev:])
            new_mask.extend(row_mask_list[prev:])
            if new_labels is not None:
                new_labels.extend(row_labels_list[prev:])
        expanded_ids.append(new_ids)
        expanded_masks.append(new_mask)
        if expanded_labels is not None:
            expanded_labels.append(new_labels)
        max_len = max(max_len, len(new_ids))

    padded_ids = np.zeros((len(expanded_ids), max_len), dtype=np.int32)
    padded_masks = np.zeros((len(expanded_masks), max_len), dtype=np.int32)
    # int64 so wide invalid labels survive expansion without OverflowError.
    padded_labels = (
        np.full((len(expanded_labels), max_len), -100, dtype=np.int64)
        if expanded_labels is not None else None
    )
    for row_idx, (row_ids, row_mask) in enumerate(zip(expanded_ids, expanded_masks)):
        row_len = len(row_ids)
        padded_ids[row_idx, :row_len] = row_ids
        padded_masks[row_idx, :row_len] = row_mask
        if padded_labels is not None:
            padded_labels[row_idx, :row_len] = expanded_labels[row_idx]

    if padded_labels is not None:
        return mx.array(padded_ids), mx.array(padded_masks), mx.array(padded_labels)
    return mx.array(padded_ids), mx.array(padded_masks)


def _build_qwen_position_ids(
    input_ids,
    attention_mask,
    image_grid_thw,
    video_grid_thw,
    image_token_id,
    video_token_id,
    spatial_merge_size,
):
    batch_size, seq_length = input_ids.shape
    position_ids = np.ones((3, batch_size, seq_length), dtype=np.int32)

    image_grids = list(image_grid_thw or ())
    video_grids = list(video_grid_thw or ())
    image_index = 0
    video_index = 0

    for batch_idx in range(batch_size):
        valid_len = (
            int(attention_mask[batch_idx].sum())
            if attention_mask is not None
            else seq_length
        )
        tokens = input_ids[batch_idx, :valid_len].tolist()
        if valid_len == 0:
            continue

        llm_pos_ids_list = []
        st = 0

        while st < valid_len:
            try:
                ed_image = tokens.index(image_token_id, st)
            except ValueError:
                ed_image = valid_len + 1

            try:
                ed_video = tokens.index(video_token_id, st)
            except ValueError:
                ed_video = valid_len + 1

            ed = min(ed_image, ed_video)
            if ed > valid_len:
                text_len = valid_len - st
                if text_len > 0:
                    start_idx = int(llm_pos_ids_list[-1].max()) + 1 if llm_pos_ids_list else 0
                    text_ids = np.broadcast_to(
                        np.arange(text_len, dtype=np.int32)[None, :],
                        (3, text_len),
                    )
                    llm_pos_ids_list.append(text_ids + start_idx)
                break

            text_len = ed - st
            start_idx = int(llm_pos_ids_list[-1].max()) + 1 if llm_pos_ids_list else 0
            if text_len > 0:
                text_ids = np.broadcast_to(
                    np.arange(text_len, dtype=np.int32)[None, :],
                    (3, text_len),
                )
                llm_pos_ids_list.append(text_ids + start_idx)
                start_idx += text_len

            if ed_image < ed_video:
                t, h, w = image_grids[image_index]
                image_index += 1
            else:
                t, h, w = video_grids[video_index]
                video_index += 1

            llm_grid_t = int(t)
            llm_grid_h = int(h) // spatial_merge_size
            llm_grid_w = int(w) // spatial_merge_size

            t_index = np.broadcast_to(
                np.arange(llm_grid_t, dtype=np.int32)[:, None],
                (llm_grid_t, llm_grid_h * llm_grid_w),
            ).reshape(-1)
            h_index = np.broadcast_to(
                np.arange(llm_grid_h, dtype=np.int32)[None, :, None],
                (llm_grid_t, llm_grid_h, llm_grid_w),
            ).reshape(-1)
            w_index = np.broadcast_to(
                np.arange(llm_grid_w, dtype=np.int32)[None, None, :],
                (llm_grid_t, llm_grid_h, llm_grid_w),
            ).reshape(-1)
            llm_pos_ids_list.append(
                np.stack([t_index, h_index, w_index], axis=0) + start_idx
            )
            st = ed + (llm_grid_t * llm_grid_h * llm_grid_w)

        if llm_pos_ids_list:
            batch_positions = np.concatenate(llm_pos_ids_list, axis=1)
            batch_positions = batch_positions[:, :valid_len]
        else:
            batch_positions = np.broadcast_to(
                np.arange(valid_len, dtype=np.int32)[None, :],
                (3, valid_len),
            )

        position_ids[:, batch_idx, :valid_len] = batch_positions

    return mx.array(position_ids)


def _build_glm_ocr_position_ids(
    input_ids,
    attention_mask,
    image_grid_thw,
    video_grid_thw,
    image_start_token_id,
    image_token_id,
    video_token_id,
    spatial_merge_size,
):
    batch_size, seq_length = input_ids.shape
    position_ids = np.ones((3, batch_size, seq_length), dtype=np.int32)

    image_grids = list(image_grid_thw or ())
    video_grids = list(video_grid_thw or ())
    image_index = 0
    video_index = 0

    for batch_idx in range(batch_size):
        valid_len = (
            int(attention_mask[batch_idx].sum())
            if attention_mask is not None
            else seq_length
        )
        tokens = input_ids[batch_idx, :valid_len].tolist()
        if valid_len == 0:
            continue

        masked_tokens = tokens[:]
        llm_pos_ids_list = []
        st = 0

        try:
            vision_start_index = masked_tokens.index(image_start_token_id)
            vision_token = (
                masked_tokens[vision_start_index + 1]
                if vision_start_index + 1 < len(masked_tokens)
                else None
            )
            image_nums = int(vision_token == image_token_id)
            video_nums = int(vision_token == video_token_id)
        except ValueError:
            image_nums = 0
            video_nums = 0

        remain_images = image_nums
        remain_videos = video_nums

        for _ in range(image_nums + video_nums):
            try:
                ed_image = masked_tokens.index(image_token_id, st) if remain_images > 0 else valid_len + 1
            except ValueError:
                ed_image = valid_len + 1
            try:
                ed_video = masked_tokens.index(video_token_id, st) if remain_videos > 0 else valid_len + 1
            except ValueError:
                ed_video = valid_len + 1

            if ed_image < ed_video:
                t, h, w = image_grids[image_index]
                image_index += 1
                remain_images -= 1
                ed = ed_image
            else:
                t, h, w = video_grids[video_index]
                video_index += 1
                remain_videos -= 1
                ed = ed_video

            llm_grid_t = int(t)
            llm_grid_h = int(h) // spatial_merge_size
            llm_grid_w = int(w) // spatial_merge_size

            text_len = ed - st
            start_idx = int(llm_pos_ids_list[-1].max()) + 1 if llm_pos_ids_list else 0
            if text_len > 0:
                text_ids = np.broadcast_to(
                    np.arange(text_len, dtype=np.int32)[None, :],
                    (3, text_len),
                )
                llm_pos_ids_list.append(text_ids + start_idx)
                start_idx += text_len

            t_index = np.broadcast_to(
                np.arange(llm_grid_t, dtype=np.int32)[:, None],
                (llm_grid_t, llm_grid_h * llm_grid_w),
            ).reshape(-1)
            h_index = np.broadcast_to(
                np.arange(llm_grid_h, dtype=np.int32)[None, :, None],
                (llm_grid_t, llm_grid_h, llm_grid_w),
            ).reshape(-1)
            w_index = np.broadcast_to(
                np.arange(llm_grid_w, dtype=np.int32)[None, None, :],
                (llm_grid_t, llm_grid_h, llm_grid_w),
            ).reshape(-1)

            llm_pos_ids_list.append(
                np.stack([t_index, h_index, w_index], axis=0) + start_idx
            )
            st = ed + (llm_grid_t * llm_grid_h * llm_grid_w)

        if st < valid_len:
            start_idx = int(llm_pos_ids_list[-1].max()) + 1 if llm_pos_ids_list else 0
            text_len = valid_len - st
            text_ids = np.broadcast_to(
                np.arange(text_len, dtype=np.int32)[None, :],
                (3, text_len),
            )
            llm_pos_ids_list.append(text_ids + start_idx)

        if llm_pos_ids_list:
            batch_positions = np.concatenate(llm_pos_ids_list, axis=1)
            batch_positions = batch_positions[:, :valid_len]
        else:
            batch_positions = np.broadcast_to(
                np.arange(valid_len, dtype=np.int32)[None, :],
                (3, valid_len),
            )

        position_ids[:, batch_idx, :valid_len] = batch_positions

    return mx.array(position_ids)


_RAW_INPUT_IDS_FOR_LABELS = "_unsloth_raw_input_ids_for_labels"

# Text-width-aligned arrays the VLM pipeline owns, with the inert value their
# right-padded tail takes ("pad" is the tokenizer pad id). Only these are padded;
# any other array sharing an extent with the text width declines its batch.
_VLM_WIDTH_PADDABLE_KEYS = {
    "input_ids": "pad",
    "attention_mask": 0,
    "labels": -100,
    _RAW_INPUT_IDS_FOR_LABELS: "pad",
    "token_type_ids": 0,
    "mm_token_type_ids": 0,
}
# Width-derived arrays generated AFTER width finalization (sequence axis last).
_VLM_WIDTH_GENERATED_KEYS = ("position_ids",)
# Model types whose position ids the position phase builds, and rebuilds after
# planned padding; elsewhere they are processor-authored, so the batch declines.
_VLM_QWEN_POSITION_MODEL_TYPES = frozenset({
    "qwen2_vl",
    "qwen2_5_vl",
    "paddleocr_vl",
    "qwen3_vl",
    "qwen3_vl_moe",
    "qwen3_5",
    "qwen3_5_moe",
    "qwen4_exp",
})
_VLM_POSITION_GENERATING_MODEL_TYPES = (
    _VLM_QWEN_POSITION_MODEL_TYPES | {"glm_ocr"}
)


def _vlm_pipeline_disposable_keys(config):
    """Keys the position-recording phase overwrites wholesale for this config.

    Whatever a processor placed under them is disposable for width admission:
    it can neither decline a batch nor forbid extents."""
    model_type = _config_get(config, "model_type")
    if model_type in _VLM_POSITION_GENERATING_MODEL_TYPES:
        return frozenset(("position_ids",))
    if model_type == "phi3_v":
        return frozenset(("image_positions",))
    return frozenset()


def _vlm_width_survey(batch_dict, disposable_keys=None):
    """(text_width, symbolic_axes, padable, forbidden) for a prepared batch.

    ``text_width`` is the post-prepare ``input_ids`` width. ``symbolic_axes``
    maps pipeline-owned width-coupled leaf paths to their sequence axis for
    ``_vlm_batch_family``. ``forbidden`` collects extents appearing at any
    depth in arrays the pipeline does not pad: a planned endpoint must avoid
    them, or an untouched array would suddenly share the text width and
    reclassify the batch. ``padable`` is False (and the axes None) whenever
    right-padding cannot be proven safe: invalid array-metadata captures, no
    exact-mx 2-D ``input_ids``, position data under a key outside
    ``disposable_keys`` (the pipeline neither pads nor regenerates it), a
    non-mx shape-carrying leaf, an ``attention_mask`` row that is not
    content-then-padding, or an untouched array already sharing an extent
    with the text width.

    The walk mirrors the family serializer's traversal and reads metadata
    only through the import-time captures, so classification and the
    symbolic family always describe the same pytree.
    """
    if not _MX_ARRAY_CAPTURES_VALID:
        return None, None, False, frozenset()

    def dims_of(value):
        return tuple(
            int(dim)
            for dim in _MX_ARRAY_SHAPE.__get__(value, _MX_ARRAY_TYPE)
        )

    input_ids = batch_dict.get("input_ids")
    if type(input_ids) is not _MX_ARRAY_TYPE:
        return None, None, False, frozenset()
    ids_shape = dims_of(input_ids)
    if len(ids_shape) != 2:
        return None, None, False, frozenset()
    width = ids_shape[1]
    if disposable_keys is None:
        disposable_keys = frozenset()
    axes = {}
    forbidden = set()
    declined = False

    def visit_untouched(node):
        nonlocal declined
        if declined:
            return
        # Mirror the family serializer's dispatch: raw runtime types (a lying
        # __class__ cannot smuggle a non-container in) and exact built-in
        # constants. Anything else has no validated metadata and refuses padding.
        node_type = type(node)
        if node_type is _MX_ARRAY_TYPE:
            extents = dims_of(node)
            forbidden.update(extents)
            if width in extents:
                declined = True
            return
        if issubclass(node_type, dict):
            for value in dict.values(node):
                visit_untouched(value)
            return
        if issubclass(node_type, Mapping):
            declined = True
            return
        if issubclass(node_type, (list, tuple)):
            if issubclass(node_type, tuple) and node_type is not tuple:
                # The serializer marks tuple subclasses unstable; agree with it.
                declined = True
                return
            walk = (
                list.__iter__(node)
                if issubclass(node_type, list)
                else tuple.__iter__(node)
            )
            for item in walk:
                visit_untouched(item)
            return
        if node_type is bool or node_type is float or node_type is str:
            return
        if node_type is int:
            # Out-of-int64 constants are opaque to mx.compile, so they cannot pad.
            if -(2 ** 63) <= node < 2 ** 63:
                return
            declined = True
            return
        if node is None:
            return
        declined = True

    for key, value in dict.items(batch_dict):
        if key in _VLM_WIDTH_PADDABLE_KEYS and type(value) is _MX_ARRAY_TYPE:
            value_dims = dims_of(value)
            if len(value_dims) == 2 and value_dims[1] == width:
                axes[(key,)] = 1
            elif width in value_dims:
                declined = True
            else:
                forbidden.update(value_dims)
            continue
        if key in disposable_keys:
            # The position phase rebuilds this key wholesale, so anything here is
            # disposable: it neither declines the batch nor forbids extents. Only a
            # canonical exact-array sequence-last position_ids earns the symbolic
            # axis; anything else stays concrete and still surfaces drift.
            if (
                key in _VLM_WIDTH_GENERATED_KEYS
                and type(value) is _MX_ARRAY_TYPE
            ):
                value_dims = dims_of(value)
                if value_dims and value_dims[-1] == width:
                    axes[(key,)] = len(value_dims) - 1
            continue
        visit_untouched(value)
    if declined:
        return width, None, False, frozenset(forbidden)
    attention_mask = batch_dict.get("attention_mask")
    if type(attention_mask) is _MX_ARRAY_TYPE and (
        len(dims_of(attention_mask)) == 2
    ):
        mask_np = np.asarray(attention_mask)
        for row in (mask_np != 0).astype(np.int8):
            content = int(row.sum())
            if content and not bool(row[:content].all()):
                return width, None, False, frozenset(forbidden)
    return width, axes, True, frozenset(forbidden)


def _finalize_vlm_batch_width(
    batch_dict, target_width, pad_token_id, disposable_keys=None,
):
    """Right-pad the pipeline-owned text-aligned arrays to ``target_width``.

    Runs after expansion and response masking produce the final content but
    before width-derived sidecars are generated, so recorded absolute
    positions refer to the preserved content prefix and sidecars are born at
    the final width. Padded tails are inert: pad id under a zero attention
    mask, labels -100. Batches the width survey declines return unchanged; a
    target below the current width fails hard. ``max_seq_length`` is never
    consulted, since post-expansion widths may legitimately exceed it.
    """
    width, _axes, padable, forbidden = _vlm_width_survey(
        batch_dict, disposable_keys=disposable_keys,
    )
    if not padable:
        return batch_dict
    target_width = operator.index(target_width)
    if target_width < width:
        raise ValueError(
            f"Unsloth MLX: VLM width plan endpoint {target_width} is below "
            f"this batch's prepared width {width}; endpoints must cover "
            f"every member batch."
        )
    if target_width == width:
        return batch_dict
    if target_width in forbidden:
        raise ValueError(
            f"Unsloth MLX: VLM width plan endpoint {target_width} collides "
            f"with an extent of an array the pipeline does not pad; "
            f"endpoints must avoid every member batch's untouched extents."
        )
    for key, pad_value in _VLM_WIDTH_PADDABLE_KEYS.items():
        value = batch_dict.get(key)
        # The survey guarantees paddable keys are exact mx arrays, and metadata
        # uses the same captured descriptors, so a patched property cannot skip a pad.
        if type(value) is not _MX_ARRAY_TYPE:
            continue
        value_shape = tuple(
            int(dim) for dim in _MX_ARRAY_SHAPE.__get__(value, _MX_ARRAY_TYPE)
        )
        if len(value_shape) != 2 or value_shape[1] != width:
            continue
        fill = pad_token_id if pad_value == "pad" else pad_value
        if fill is None:
            raise ValueError(
                "Unsloth MLX: a tokenizer pad id is required to pad "
                f"'{key}' to a planned width."
            )
        tail = mx.full(
            (value_shape[0], target_width - width),
            fill,
            dtype=_MX_ARRAY_DTYPE.__get__(value, _MX_ARRAY_TYPE),
        )
        batch_dict[key] = mx.concatenate([value, tail], axis=1)
    return batch_dict


def _prepare_vlm_batch_for_compile(batch_dict, config, phase=None):
    """Prepare a collated VLM batch for the compiled/training path.

    ``phase`` splits the work at the width seam: ``"content"`` runs sidecar
    normalization and the expansions that may rebuild the text arrays at
    data-dependent lengths; ``"positions"`` runs the steps that record
    absolute positions or generate width-derived sidecars and must see the
    final text width. ``None`` runs both back to back, byte-identical to the
    historical single pass since each model type takes exactly one of the
    disjoint branches.
    """
    if phase is None:
        batch_dict = _prepare_vlm_batch_for_compile(
            batch_dict, config, phase="content",
        )
        return _prepare_vlm_batch_for_compile(
            batch_dict, config, phase="positions",
        )
    if phase == "positions":
        return _vlm_positions_for_compile(batch_dict, config)
    if phase != "content":
        raise ValueError(f"unknown VLM prepare phase: {phase!r}")
    # The provenance marker is pipeline-private: processor output carrying it is a
    # forgery that would misclassify foreign position ids as regenerated.
    batch_dict.pop("_unsloth_collated_position_ids", None)
    model_type = _config_get(config, "model_type")
    vision_config = _config_to_mapping(_config_get(config, "vision_config", {}))

    image_grid_thw = _normalize_grid_thw(batch_dict.get("image_grid_thw"))
    video_grid_thw = _normalize_grid_thw(batch_dict.get("video_grid_thw"))
    image_sizes = _normalize_size_tuples(batch_dict.get("image_sizes"))
    spatial_shapes = _normalize_size_tuples(batch_dict.get("spatial_shapes"))
    images_spatial_crop = _normalize_size_tuples(batch_dict.get("images_spatial_crop"))
    audio_embed_sizes = _normalize_int_tuple(batch_dict.get("audio_embed_sizes"))
    # Resolved, not raw: an aliased config is routed to the canonical family's tower,
    # so the grid form has to follow it there.
    grid_as_array = (
        _mlx_vlm_canonical_model_type(model_type) in _VLM_ARRAY_GRID_MODEL_TYPES
    )
    if image_grid_thw is not None:
        batch_dict["image_grid_thw"] = (
            _grid_thw_to_mx_array(image_grid_thw) if grid_as_array else image_grid_thw
        )
    if video_grid_thw is not None:
        batch_dict["video_grid_thw"] = (
            _grid_thw_to_mx_array(video_grid_thw) if grid_as_array else video_grid_thw
        )
    if image_sizes is not None:
        batch_dict["image_sizes"] = image_sizes
    if spatial_shapes is not None:
        batch_dict["spatial_shapes"] = spatial_shapes
    if images_spatial_crop is not None:
        batch_dict["images_spatial_crop"] = images_spatial_crop
    if audio_embed_sizes is not None:
        # The model calls .item() on each entry, so hand over an array; the
        # tuple above is only for this function's span arithmetic.
        batch_dict["audio_embed_sizes"] = mx.array(list(audio_embed_sizes))

    if model_type == "multi_modality":
        input_ids = batch_dict.get("input_ids")
        if input_ids is not None:
            _labels = batch_dict.get("labels")
            _raw_labels = batch_dict.get(_RAW_INPUT_IDS_FOR_LABELS)
            # Labels absent: expand the raw pre-narrow carrier so labels-free
            # paths still see wide invalid ids for NaN-poisoning. Labels
            # present: pop the now-stale carrier so a pre-expansion copy
            # cannot break _apply_response_mask_to_vlm_batch with a shape mismatch.
            _label_source = _labels if _labels is not None else _raw_labels
            _expanded = _expand_image_token_sequences(
                input_ids=input_ids,
                attention_mask=batch_dict.get("attention_mask"),
                image_token_id=int(_config_get(config, "image_token_index")),
                repeat_count=int(_config_get(config, "num_image_tokens")),
                labels=_label_source,
            )
            if _labels is not None:
                batch_dict["input_ids"], batch_dict["attention_mask"], batch_dict["labels"] = _expanded
                batch_dict.pop(_RAW_INPUT_IDS_FOR_LABELS, None)
            elif _raw_labels is not None:
                batch_dict["input_ids"], batch_dict["attention_mask"], batch_dict[_RAW_INPUT_IDS_FOR_LABELS] = _expanded
            else:
                batch_dict["input_ids"], batch_dict["attention_mask"] = _expanded

    if model_type in {"phi4-siglip", "phi4_siglip"}:
        input_ids = batch_dict.get("input_ids")
        pixel_attention_mask = batch_dict.get("pixel_attention_mask")
        if input_ids is not None:
            input_ids_np = np.asarray(input_ids)
            batch_dict["image_token_positions"] = tuple(
                tuple(
                    int(pos)
                    for pos in np.where(row == -200)[0].tolist()
                )
                for row in input_ids_np
            )
        if pixel_attention_mask is not None:
            pam_np = np.asarray(pixel_attention_mask)
            pixel_valid_lengths = tuple(
                int(row.astype(np.int32).sum()) for row in pam_np
            )
            batch_dict["pixel_valid_lengths"] = pixel_valid_lengths
            if input_ids is not None:
                replacements = []
                image_idx = 0
                for batch_positions in batch_dict["image_token_positions"]:
                    batch_replacements = []
                    for pos in batch_positions:
                        repeat = pixel_valid_lengths[image_idx]
                        batch_replacements.append((pos, pos + 1, -200, repeat))
                        image_idx += 1
                    replacements.append(tuple(batch_replacements))
                _labels = batch_dict.get("labels")
                _raw_labels = batch_dict.get(_RAW_INPUT_IDS_FOR_LABELS)
                # See multi_modality branch above for why we expand the raw
                # carrier when labels are absent and pop it when labels exist.
                _label_source = _labels if _labels is not None else _raw_labels
                _expanded = _expand_token_runs(
                    input_ids=input_ids,
                    attention_mask=batch_dict.get("attention_mask"),
                    replacements_by_batch=tuple(replacements),
                    labels=_label_source,
                )
                if _labels is not None:
                    batch_dict["input_ids"], batch_dict["attention_mask"], batch_dict["labels"] = _expanded
                    batch_dict.pop(_RAW_INPUT_IDS_FOR_LABELS, None)
                elif _raw_labels is not None:
                    batch_dict["input_ids"], batch_dict["attention_mask"], batch_dict[_RAW_INPUT_IDS_FOR_LABELS] = _expanded
                else:
                    batch_dict["input_ids"], batch_dict["attention_mask"] = _expanded

    if model_type == "phi4mm":
        input_ids = batch_dict.get("input_ids")
        pixel_attention_mask = batch_dict.get("pixel_attention_mask")
        if input_ids is not None:
            input_ids_np = np.asarray(input_ids)
            image_token_id, audio_token_id = _phi4mm_token_ids(config)
            batch_dict["image_token_positions"] = tuple(
                tuple(
                    int(pos)
                    for pos in np.where(row == image_token_id)[0].tolist()
                )
                for row in input_ids_np
            )
            audio_spans = []
            for row in input_ids_np:
                spans = []
                idx = 0
                row_list = row.tolist()
                while idx < len(row_list):
                    if int(row_list[idx]) != audio_token_id:
                        idx += 1
                        continue
                    start = idx
                    while idx < len(row_list) and int(row_list[idx]) == audio_token_id:
                        idx += 1
                    spans.append((start, idx))
                audio_spans.append(tuple(spans))
            batch_dict["audio_token_spans"] = tuple(audio_spans)
            input_ids_np = np.asarray(input_ids)
        if pixel_attention_mask is not None:
            pam_np = np.asarray(pixel_attention_mask)
            batch_dict["pixel_valid_lengths"] = tuple(
                int(row.astype(np.int32).sum()) for row in pam_np
            )
        if input_ids is not None:
            image_positions = batch_dict.get("image_token_positions", ())
            audio_spans = batch_dict.get("audio_token_spans", ())
            pixel_valid_lengths = batch_dict.get("pixel_valid_lengths")
            replacements = []
            image_idx = 0
            audio_idx = 0
            image_token_id, audio_token_id = _phi4mm_token_ids(config)
            for batch_idx, row in enumerate(input_ids_np):
                batch_replacements = []
                for pos in image_positions[batch_idx]:
                    repeat = (
                        int(pixel_valid_lengths[image_idx])
                        if pixel_valid_lengths is not None
                        else 1
                    )
                    batch_replacements.append((pos, pos + 1, image_token_id, repeat))
                    image_idx += 1
                for start, end in audio_spans[batch_idx]:
                    repeat = int(audio_embed_sizes[audio_idx]) if audio_embed_sizes is not None else int(end - start)
                    batch_replacements.append((start, end, audio_token_id, repeat))
                    audio_idx += 1
                replacements.append(tuple(batch_replacements))
            if replacements:
                _labels = batch_dict.get("labels")
                _raw_labels = batch_dict.get(_RAW_INPUT_IDS_FOR_LABELS)
                # See multi_modality branch above for why we expand the raw
                # carrier when labels are absent and pop it when labels exist.
                _label_source = _labels if _labels is not None else _raw_labels
                _expanded = _expand_token_runs(
                    input_ids=input_ids,
                    attention_mask=batch_dict.get("attention_mask"),
                    replacements_by_batch=tuple(replacements),
                    labels=_label_source,
                )
                if _labels is not None:
                    batch_dict["input_ids"], batch_dict["attention_mask"], batch_dict["labels"] = _expanded
                    batch_dict.pop(_RAW_INPUT_IDS_FOR_LABELS, None)
                elif _raw_labels is not None:
                    batch_dict["input_ids"], batch_dict["attention_mask"], batch_dict[_RAW_INPUT_IDS_FOR_LABELS] = _expanded
                else:
                    batch_dict["input_ids"], batch_dict["attention_mask"] = _expanded

    return batch_dict


def _vlm_positions_for_compile(batch_dict, config):
    """Position-recording prepare steps: absolute-position constants and
    width-derived sidecars, computed from the final text arrays (after any
    expansion and planned padding, whose tails never shift a content
    position)."""
    model_type = _config_get(config, "model_type")
    vision_config = _config_to_mapping(_config_get(config, "vision_config", {}))
    image_grid_thw = _normalize_grid_thw(batch_dict.get("image_grid_thw"))
    video_grid_thw = _normalize_grid_thw(batch_dict.get("video_grid_thw"))

    if model_type in _VLM_QWEN_POSITION_MODEL_TYPES:
        input_ids = batch_dict.get("input_ids")
        if input_ids is not None:
            input_ids_np = np.asarray(input_ids)
            attention_mask = batch_dict.get("attention_mask")
            attention_mask_np = (
                np.asarray(attention_mask)
                if attention_mask is not None
                else None
            )
            batch_dict["position_ids"] = _build_qwen_position_ids(
                input_ids=input_ids_np,
                attention_mask=attention_mask_np,
                image_grid_thw=image_grid_thw,
                video_grid_thw=video_grid_thw,
                image_token_id=int(_config_get(config, "image_token_id", _config_get(config, "image_token_index"))),
                video_token_id=int(_config_get(config, "video_token_id", _config_get(config, "video_token_index"))),
                spatial_merge_size=int(vision_config.get("spatial_merge_size", 2)),
            )
            batch_dict["_unsloth_collated_position_ids"] = True

    if model_type == "glm_ocr":
        input_ids = batch_dict.get("input_ids")
        if input_ids is not None:
            input_ids_np = np.asarray(input_ids)
            attention_mask = batch_dict.get("attention_mask")
            attention_mask_np = (
                np.asarray(attention_mask)
                if attention_mask is not None
                else None
            )
            batch_dict["position_ids"] = _build_glm_ocr_position_ids(
                input_ids=input_ids_np,
                attention_mask=attention_mask_np,
                image_grid_thw=image_grid_thw,
                video_grid_thw=video_grid_thw,
                image_start_token_id=int(_config_get(config, "image_start_token_id")),
                image_token_id=int(_config_get(config, "image_token_id")),
                video_token_id=int(_config_get(config, "video_token_id")),
                spatial_merge_size=int(vision_config.get("spatial_merge_size", 2)),
            )
            batch_dict["_unsloth_collated_position_ids"] = True

    if model_type == "phi3_v":
        input_ids = batch_dict.get("input_ids")
        if input_ids is not None:
            input_ids_np = np.asarray(input_ids)
            batch_dict["image_positions"] = tuple(
                tuple(int(x) for x in pos)
                for pos in np.argwhere(input_ids_np < 0).tolist()
            )

    return batch_dict


def make_vlm_cce_loss_fn(model, assistant_token_id=0, ignore_token_ids=None):
    """Create a CCE loss function for VLMs.

    Uses model.get_input_embeddings() for merged vision+text embeddings, runs
    the backbone to pre-lm_head hidden states, and applies CCE. Falls back to
    baseline loss when get_input_embeddings is unavailable.

    assistant_token_id > 0 enables completion-only training (mask tokens before
    the first occurrence). Returns a function (model, batch_dict) -> (loss, ntoks).
    """
    def _marked_vlm_baseline():
        loss_fn = make_vlm_baseline_loss_fn(
            model,
            assistant_token_id=assistant_token_id,
            ignore_token_ids=ignore_token_ids,
        )
        loss_fn._unsloth_cce_backend = "baseline-fallback"
        return loss_fn

    if not hasattr(model, "get_input_embeddings"):
        import warnings
        warnings.warn(
            "VLM model does not have get_input_embeddings — "
            "falling back to baseline CE loss.",
            stacklevel=2,
        )
        return _marked_vlm_baseline()

    tm = _get_text_model(model)
    if getattr(tm, "model", None) is None and not _has_direct_hidden_stack(model):
        import warnings
        warnings.warn(
            "VLM text stack does not expose a separable hidden-state backbone for CCE; "
            "falling back to baseline CE loss.",
            stacklevel=2,
        )
        return _marked_vlm_baseline()

    head_desc = describe_output_head(model)
    _ineligible = _cce_head_ineligibility(head_desc)
    if _ineligible is not None:
        print(f"Unsloth: fused CCE cannot faithfully use this model's output "
              f"head ({_ineligible}); falling back to standard cross-entropy.")
        return _marked_vlm_baseline()

    logit_scale, _transform_problem = _detect_head_transform(model, head_desc.status)
    if _transform_problem is not None:
        print(f"Unsloth: {_transform_problem}; falling back to standard cross-entropy.")
        return _marked_vlm_baseline()

    softcap, _softcap_problem = _detect_logit_softcap(model)
    if _softcap_problem is not None:
        print(f"Unsloth: {_softcap_problem}; falling back to standard cross-entropy.")
        return _marked_vlm_baseline()
    # Every decision above prints when it declines; print when it accepts too, since
    # a silently ignored head transform is the failure this prevents.
    if softcap > 0:
        print(f"Unsloth: VLM CCE using logit_softcap={softcap} for this model.")
    if logit_scale is not None:
        print(f"Unsloth: VLM CCE using logit_scale={logit_scale} for this model.")
    lm_layer = head_desc.module
    use_quantized = _is_quantized_layer(lm_layer)
    _head_path = head_desc.path
    # Evaluate once (after LoRA setup); trainability doesn't change mid-training.
    _skip_weight_grad = not _is_lm_head_trainable(model)

    _image_token_ids = (
        ignore_token_ids
        if ignore_token_ids is not None
        else _get_image_token_ids(model)
    )
    if _image_token_ids is not None:
        print(f"Unsloth: Masking {len(_image_token_ids)} image token IDs from VLM loss.")
    _assistant_token_id = assistant_token_id
    if _assistant_token_id > 0:
        print(f"Unsloth: Completion-only training (assistant_token_id={_assistant_token_id}).")

    if use_quantized:
        # Backstop (as in the text CCE path): full FT against a quantized LM
        # head silently skips the LM head update. Reject loudly here in case
        # the loader-level check is bypassed.
        if getattr(model, "_unsloth_full_finetuning", False):
            raise ValueError(
                "Unsloth: full_finetuning=True with a quantized VLM LM head "
                "is not supported. The CCE backward zeros the quantized "
                "weight gradient, so the LM head would never update. Load "
                "the unquantized base model for full fine-tuning, or use "
                "LoRA on this quantized base."
            )
        group_size = getattr(lm_layer, "group_size", 64)
        bits = getattr(lm_layer, "bits", 4)
        quant_mode = getattr(lm_layer, "mode", "affine")

        rt_cce = _get_runtime_cce(
            ignore_index=-100,
            logit_softcap=softcap,
            quantized=True,
            group_size=group_size,
            bits=bits,
            mode=quant_mode,
        )

        def loss_fn(model, batch_dict):
            hidden, masked_targets, ntoks = _vlm_cce_forward(
                model, batch_dict, image_token_ids=_image_token_ids,
                assistant_token_id=_assistant_token_id)
            lm_head = _resolve_module_path(model, _head_path)
            w = lm_head.weight
            sc = lm_head.scales
            bi = getattr(lm_head, "biases", None)
            if bi is None and quant_mode == "affine":
                bi = mx.zeros_like(sc)
            # Quantized backward already returns zero weight/scales/biases
            # gradients (see runtime_cce.py VJP), so stop_gradient is
            # redundant here even when the LM head is frozen.
            hidden_flat = hidden.reshape((-1, hidden.shape[-1]))
            if logit_scale is not None:
                # (h * s) @ W equals s * (h @ W) per vocab chunk (Aya Vision,
                # Cohere2-MoE apply logit_scale in their forward tails).
                hidden_flat = hidden_flat * logit_scale
            targets_flat = masked_targets.reshape((-1,))  # runtime CCE validates dtype before narrowing
            loss = rt_cce(hidden_flat, w, sc, bi, targets_flat)
            loss = loss.astype(mx.float32).sum() / _safe_token_denominator(ntoks)
            return loss, ntoks
    else:
        if _skip_weight_grad:
            print("Unsloth: VLM CCE skipping weight gradient (LM head is frozen).")

        rt_cce = _get_runtime_cce(
            ignore_index=-100,
            logit_softcap=softcap,
        )

        def loss_fn(model, batch_dict):
            hidden, masked_targets, ntoks = _vlm_cce_forward(
                model, batch_dict, image_token_ids=_image_token_ids,
                assistant_token_id=_assistant_token_id)
            w = _resolve_module_path(model, _head_path).weight
            if _skip_weight_grad:
                w = mx.stop_gradient(w)
            hidden_flat = hidden.reshape((-1, hidden.shape[-1]))
            if logit_scale is not None:
                # Same pre-scaling identity as the quantized branch above.
                hidden_flat = hidden_flat * logit_scale
            targets_flat = masked_targets.reshape((-1,))  # runtime CCE validates dtype before narrowing
            loss = rt_cce(hidden_flat, w, targets_flat)
            loss = loss.astype(mx.float32).sum() / _safe_token_denominator(ntoks)
            return loss, ntoks

    loss_fn._unsloth_cce_backend = "runtime-cce"
    return loss_fn


def _get_vlm_image_size(config, processor):
    """Get target image size for uniform resizing, matching the GPU collator.

    Tries vision_config.image_size (dict or dataclass), then
    processor.image_processor.size, falls back to 512.

    Note: Qwen2.5-VL's image_processor.size holds *area pixel counts*
    (shortest_edge/longest_edge = min/max pixels), not dimensions. Reading
    them as height would 3136x3136-upsample -> 50k patches -> OOM, so skip
    area-style ``size`` dicts.
    """
    vc = config.get("vision_config") if isinstance(config, dict) else getattr(config, "vision_config", None)
    if vc is not None:
        sz = vc.get("image_size") if isinstance(vc, dict) else getattr(vc, "image_size", None)
        if isinstance(sz, int) and sz > 0:
            return sz
    ip = getattr(processor, "image_processor", None)
    if ip is not None:
        sz = getattr(ip, "size", None)
        if isinstance(sz, dict):
            # Skip area-pixel-count dicts (Qwen2.5-VL style) — those use
            # {shortest_edge, longest_edge} as area bounds, not dimensions.
            if "longest_edge" in sz and sz.get("longest_edge", 0) > 1_000_000:
                pass  # area-count form, fall through to default
            else:
                h = sz.get("height", sz.get("shortest_edge", 0))
                if isinstance(h, int) and 0 < h < 4096:
                    return h
        elif isinstance(sz, int) and sz > 0:
            return sz
    return 512


def _is_vlm_no_resize_image_size(image_size):
    """Return True when a VLM image-size override means preserve full size."""
    return image_size is None or (
        isinstance(image_size, str) and image_size.lower() == "max"
    )


def _resolve_vlm_image_size(image_size, config, processor):
    """Resolve omitted VLM image size while preserving explicit no-resize."""
    if isinstance(image_size, str) and image_size.lower() == "max":
        return None
    if image_size is None:
        return _get_vlm_image_size(config, processor)
    return image_size


def _has_chat_template(obj):
    template = getattr(obj, "chat_template", None)
    return isinstance(template, str) and len(template.strip()) > 0


def _get_processor_tokenizer(processor):
    if processor is None:
        return None
    # HF fast tokenizers expose the public API directly while their _tokenizer
    # is the low-level Rust backend (no convert_tokens_to_ids / chat_template /
    # apply_chat_template). Only unwrap _tokenizer for wrappers that do not
    # already speak the HF tokenizer API (mlx-lm's TokenizerWrapper proxies it).
    if hasattr(processor, "convert_tokens_to_ids"):
        return processor
    if hasattr(processor, "_tokenizer"):
        return processor._tokenizer
    return getattr(processor, "tokenizer", processor)


_MLX_BUILTIN_CHAT_TEMPLATES = {
    "alpaca": """{% for message in messages %}{% if message['role'] == 'user' %}### Instruction:
{{ message['content'] }}

{% elif message['role'] == 'assistant' %}### Response:
{{ message['content'] }}
{% endif %}{% endfor %}""",
}


def _mlx_builtin_chat_template(chat_template):
    if not isinstance(chat_template, str):
        return None
    return _MLX_BUILTIN_CHAT_TEMPLATES.get(chat_template.strip().lower())


def _apply_mlx_chat_template_override(target, chat_template, *, is_vlm=False):
    """Apply an explicit template override to a tokenizer or VLM processor."""
    if chat_template is None:
        return target

    original_tokenizer = _get_processor_tokenizer(target)
    tokenizer = original_tokenizer
    builtin_template = _mlx_builtin_chat_template(chat_template)
    if builtin_template is not None:
        tokenizer.chat_template = builtin_template
    elif isinstance(chat_template, str) and ("{{" in chat_template or "{%" in chat_template):
        tokenizer.chat_template = chat_template
    else:
        try:
            from unsloth.chat_templates import get_chat_template

            if isinstance(chat_template, (tuple, list)):
                tokenizer = get_chat_template(tokenizer, *chat_template)
            else:
                tokenizer = get_chat_template(tokenizer, chat_template)
        except Exception as exc:
            kind = "VLM" if is_vlm else "text"
            raise ValueError(
                f"Unsloth MLX {kind}: could not apply the requested chat template "
                f"{chat_template!r}. Pass a valid Unsloth template name or a raw "
                "Jinja chat_template string."
            ) from exc

    if is_vlm:
        if tokenizer is not original_tokenizer and hasattr(target, "tokenizer"):
            target.tokenizer = tokenizer
        if _has_chat_template(tokenizer):
            target.chat_template = tokenizer.chat_template
        return target
    return tokenizer


def normalize_mlx_chat_template(
    target,
    *,
    chat_template=None,
    model_name=None,
    model_type=None,
    is_vlm=False,
    strict=False,
):
    """Normalize chat template state for MLX text tokenizers and VLM processors."""
    if target is None:
        return target

    if chat_template is not None:
        target = _apply_mlx_chat_template_override(target, chat_template, is_vlm=is_vlm)

    if model_name is not None:
        setattr(target, "_unsloth_model_name", model_name)
    if model_type is not None:
        setattr(target, "_unsloth_model_type", model_type)

    tokenizer = _get_processor_tokenizer(target)
    if is_vlm and not _has_chat_template(target) and _has_chat_template(tokenizer):
        target.chat_template = tokenizer.chat_template

    template_target = target if is_vlm else tokenizer
    if strict and not _has_chat_template(template_target):
        _raise_mlx_chat_template_error(target, is_vlm=is_vlm)
    return target


def normalize_vlm_processor_chat_template(
    processor,
    *,
    chat_template=None,
    model_name=None,
    model_type=None,
    strict=False,
):
    """Make mlx-vlm processors behave like regular Unsloth vision processors.

    mlx-vlm often returns processors where the inner tokenizer has a template
    but the processor itself does not. Transformers' VLM processors expect the
    template on the processor for apply_chat_template(), so copy it once here.
    """
    return normalize_mlx_chat_template(
        processor,
        chat_template=chat_template,
        model_name=model_name,
        model_type=model_type,
        is_vlm=True,
        strict=strict,
    )


def _contains_mlx_values(value):
    if isinstance(value, mx.array):
        return True
    if isinstance(value, (list, tuple)):
        return any(_contains_mlx_values(element) for element in value)
    if isinstance(value, Mapping):
        return any(_contains_mlx_values(element) for element in value.values())
    return False


def _collect_mlx_values(value, out):
    if isinstance(value, mx.array):
        out.append(value)
    elif isinstance(value, (list, tuple)):
        for element in value:
            _collect_mlx_values(element, out)
    elif isinstance(value, Mapping):
        for element in value.values():
            _collect_mlx_values(element, out)


def _materialize_mlx_values(*trees):
    """Force pending MLX graphs on the thread that created them.

    Lazy MLX arrays cannot be evaluated from another thread, so opaque
    processor-owned payloads must cross the prefetch boundary materialized.
    This only completes computation the processor already issued on this thread.
    """
    arrays = []
    for tree in trees:
        _collect_mlx_values(tree, arrays)
    if arrays:
        mx.eval(*arrays)


def _reject_mlx_valued_text(context):
    raise ValueError(
        f"Unsloth MLX text: {context} carried MLX-array values; the prefetch "
        "producer must not convert MLX values off the consumer thread. Use "
        "streaming_prefetch_batches=0 for this stream."
    )


def _guard_host_token_output(value, state, context):
    """Record/reject an MLX-valued tokenizer or template output pre-conversion."""
    if state is not None and _contains_mlx_values(value):
        if state.get("reject_mlx_valued"):
            raise ValueError(
                f"Unsloth MLX: {context} returned an MLX array; the prefetch "
                "producer must not convert MLX values off the consumer "
                "thread. Use streaming_prefetch_batches=0."
            )
        state["host_valued"] = False
    return value


def encode_mlx_text(tokenizer, text, state=None, *, add_special_tokens=None):
    """Tokenize text while mirroring Unsloth's double-BOS guard."""
    if add_special_tokens is None:
        add_special_tokens = True
        bos_token = getattr(tokenizer, "bos_token", None)
        if bos_token is not None and text.startswith(bos_token):
            add_special_tokens = False

    try:
        encoded = tokenizer.encode(text, add_special_tokens=add_special_tokens)
    except TypeError:
        encoded = tokenizer.encode(text)
    return _guard_host_token_output(encoded, state, "the tokenizer")


def _raise_mlx_chat_template_error(target, *, is_vlm=False):
    if is_vlm:
        _raise_vlm_chat_template_error(target)
    model_name = getattr(target, "_unsloth_model_name", None) or "this text model"
    model_type = getattr(target, "_unsloth_model_type", None)
    detail = f" ({model_type})" if model_type else ""
    raise ValueError(
        f"Unsloth MLX text: {model_name}{detail} has no tokenizer chat_template. "
        "Use an instruction/chat checkpoint, pass chat_template= to "
        "FastLanguageModel.from_pretrained(), set MLXTrainingConfig(chat_template=...), "
        "or provide formatting_func / a pre-rendered text column."
    )


def _raise_vlm_chat_template_error(processor):
    model_name = getattr(processor, "_unsloth_model_name", None) or "this VLM"
    model_type = getattr(processor, "_unsloth_model_type", None)
    detail = f" ({model_type})" if model_type else ""
    raise ValueError(
        f"Unsloth MLX VLM: {model_name}{detail} has no processor chat_template. "
        "For VLM training, Unsloth will not silently install ChatML because base "
        "vision-language models often require model-specific image tokens. Use an "
        "instruction/chat checkpoint, pass chat_template= to "
        "FastLanguageModel.from_pretrained(), set MLXTrainingConfig(vlm_chat_template=...), "
        "or provide formatting_func that returns already-templated text."
    )


def _select_vlm_messages_or_raw(item):
    if isinstance(item, str):
        return item
    if not isinstance(item, dict):
        return item
    for key in ("messages", "conversations"):
        value = item.get(key)
        if value is not None:
            return value
    return item


def _select_mlx_messages_or_raw(item):
    if isinstance(item, str):
        return item
    if not isinstance(item, dict):
        return item
    for key in ("messages", "conversations"):
        value = item.get(key)
        if value is not None:
            return value
    return item


def _clean_vlm_none_keys(obj):
    """Remove Arrow-created None keys without mutating the source dataset row."""
    if isinstance(obj, list):
        return [_clean_vlm_none_keys(x) for x in obj]
    if isinstance(obj, dict):
        return {
            key: _clean_vlm_none_keys(value)
            for key, value in obj.items()
            if value is not None
        }
    return obj


def _normalize_mlx_messages(messages, *, is_vlm=False):
    if isinstance(messages, str):
        return messages
    messages = _clean_vlm_none_keys(messages)
    if isinstance(messages, dict) and "role" in messages and "content" in messages:
        messages = [messages]
    if not isinstance(messages, list):
        kind = "VLM" if is_vlm else "text"
        raise TypeError(
            f"Unsloth MLX {kind}: expected a dataset row with messages/conversations, "
            "a list of chat messages, or a formatted text string."
        )

    normalized = []
    for message in messages:
        if not isinstance(message, dict):
            kind = "VLM" if is_vlm else "text"
            raise TypeError(
                f"Unsloth MLX {kind}: every chat message must be a dict with role/content."
            )
        msg = dict(message)
        content = msg.get("content", "")
        if isinstance(content, str):
            msg["content"] = content
        elif isinstance(content, list):
            if is_vlm:
                parts = []
                for part in content:
                    if isinstance(part, str):
                        parts.append({"type": "text", "text": part})
                    elif isinstance(part, dict):
                        clean = _clean_vlm_none_keys(part)
                        # Gemma 3n's template renders a placeholder for
                        # "audio" alone, so a part left under an alias carries
                        # a clip with nothing behind it, and an untyped one
                        # reaches neither the family gate nor the extractor.
                        if "type" not in clean:
                            if "text" in clean:
                                clean["type"] = "text"
                            elif "image" in clean:
                                clean["type"] = "image"
                            elif any(alias in clean for alias in _AUDIO_PART_TYPES):
                                clean["type"] = "audio"
                        elif clean["type"] in _AUDIO_PART_TYPES:
                            clean["type"] = "audio"
                        parts.append(clean)
                msg["content"] = parts
            else:
                texts = []
                for part in content:
                    if isinstance(part, str):
                        texts.append(part)
                    elif isinstance(part, dict):
                        clean = _clean_vlm_none_keys(part)
                        if clean.get("type") == "text" or "text" in clean:
                            texts.append(str(clean.get("text", "")))
                msg["content"] = "".join(texts)
        else:
            msg["content"] = str(content)
        normalized.append(msg)
    return normalized


def _normalize_vlm_messages(messages):
    return _normalize_mlx_messages(messages, is_vlm=True)


def _collapse_vlm_assistant_content(messages):
    collapsed = copy.deepcopy(messages)
    for message in collapsed:
        if message.get("role") != "assistant" or not isinstance(message.get("content"), list):
            continue
        texts = []
        for part in message["content"]:
            if isinstance(part, dict) and part.get("type") == "text":
                texts.append(str(part.get("text", "")))
            elif isinstance(part, str):
                texts.append(part)
        message["content"] = "".join(texts)
    return collapsed


def _flatten_vlm_content_for_text_template(messages):
    """Render list-style VLM content as text for text-only chat templates."""
    flattened = copy.deepcopy(messages)
    for message in flattened:
        content = message.get("content", "")
        if not isinstance(content, list):
            continue
        texts = []
        for part in content:
            if isinstance(part, dict) and part.get("type") == "text":
                texts.append(str(part.get("text", "")))
            elif isinstance(part, str):
                texts.append(part)
        message["content"] = "".join(texts)
    return flattened


def _flatten_vlm_messages_to_content_parts(messages):
    """Flatten role messages for mlx-vlm processors with content-part templates."""
    parts = []
    for message in messages:
        content = message.get("content", "")
        if isinstance(content, list):
            for part in content:
                if isinstance(part, str):
                    parts.append({"type": "text", "text": part})
                elif isinstance(part, dict):
                    parts.append(_clean_vlm_none_keys(part))
        elif content:
            parts.append({"type": "text", "text": str(content)})
    return parts


def _count_vlm_image_parts(messages):
    if isinstance(messages, str):
        return 0
    count = 0
    for message in messages or []:
        if not isinstance(message, dict):
            continue
        content = message.get("content", "")
        if not isinstance(content, list):
            continue
        for part in content:
            if isinstance(part, dict) and part.get("type") == "image":
                count += 1
    return count


def _repair_deepseek_rendered_image_tokens(processor, text, messages):
    if not isinstance(text, str) or not text.strip():
        return text
    marker = (
        f"{processor.__class__.__module__}.{processor.__class__.__name__}"
    ).lower()
    if "deepseek" not in marker:
        return text
    image_count = _count_vlm_image_parts(messages)
    if image_count <= 0:
        return text
    image_token = getattr(processor, "image_token", None)
    if not image_token:
        return text
    missing = image_count - text.count(image_token)
    if missing <= 0:
        return text
    return (image_token * missing) + text


def _processor_accepts_assistant_list_content(processor):
    cached = getattr(processor, "_unsloth_assistant_single_content", None)
    if cached is not None:
        return not cached

    probe = [
        {"role": "user", "content": [{"type": "text", "text": "Hi"}]},
        {"role": "assistant", "content": [{"type": "text", "text": "Hello"}]},
    ]
    try:
        processor.apply_chat_template(probe, tokenize=False, add_generation_prompt=False)
        processor._unsloth_assistant_single_content = False
        return True
    except Exception:
        try:
            processor.apply_chat_template(
                _collapse_vlm_assistant_content(probe),
                tokenize=False,
                add_generation_prompt=False,
            )
            processor._unsloth_assistant_single_content = True
            return False
        except Exception:
            processor._unsloth_assistant_single_content = False
            return True


def _render_vlm_messages(
    processor,
    messages,
    *,
    add_generation_prompt=False,
):
    normalize_vlm_processor_chat_template(processor, strict=True)
    if isinstance(messages, str):
        return messages

    render_messages = messages
    if not _processor_accepts_assistant_list_content(processor):
        render_messages = _collapse_vlm_assistant_content(render_messages)

    first_error = None
    second_error = None
    third_error = None

    try:
        text = processor.apply_chat_template(
            render_messages,
            tokenize=False,
            add_generation_prompt=add_generation_prompt,
        )
        text = _repair_deepseek_rendered_image_tokens(processor, text, messages)
        if isinstance(text, str) and text.strip():
            return text
    except Exception as exc:
        first_error = exc

    try:
        text = processor.apply_chat_template(
            _flatten_vlm_messages_to_content_parts(messages),
            tokenize=False,
            add_generation_prompt=add_generation_prompt,
        )
        text = _repair_deepseek_rendered_image_tokens(processor, text, messages)
        if isinstance(text, str) and text.strip():
            return text
    except Exception as exc:
        second_error = exc

    try:
        text = processor.apply_chat_template(
            _flatten_vlm_content_for_text_template(render_messages),
            tokenize=False,
            add_generation_prompt=add_generation_prompt,
        )
        text = _repair_deepseek_rendered_image_tokens(processor, text, messages)
        if isinstance(text, str) and text.strip():
            return text
    except Exception as exc:
        third_error = exc

    if first_error is not None:
        raise RuntimeError(
            "Unsloth MLX VLM: failed to render chat messages with this "
            "processor chat_template. Check that the dataset roles/content "
            "schema matches the model family, or pass a formatting_func that "
            "returns pre-rendered text."
        ) from (third_error or second_error or first_error)

    return ""


def _looks_like_mlx_chat_messages(value):
    return (
        isinstance(value, list)
        and len(value) > 0
        and all(isinstance(x, dict) and ("role" in x or "content" in x) for x in value)
    )


def _render_mlx_messages(target, messages, *, is_vlm=False):
    if is_vlm:
        return _render_vlm_messages(target, _normalize_mlx_messages(messages, is_vlm=True))

    tokenizer = _get_processor_tokenizer(target)
    normalize_mlx_chat_template(tokenizer, is_vlm=False, strict=True)
    messages = _normalize_mlx_messages(messages, is_vlm=False)
    if isinstance(messages, str):
        return messages

    try:
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=False,
        )
    except Exception as exc:
        raise RuntimeError(
            "Unsloth MLX text: failed to render chat messages with this "
            "tokenizer chat_template. Check that dataset roles/content match the "
            "model template, or pass formatting_func that returns pre-rendered text."
        ) from exc


def render_mlx_chat_example(
    target,
    item,
    *,
    dataset_text_field="text",
    is_vlm=False,
    allow_raw_text=True,
):
    """Render one text/chat training example for MLX text or VLM pipelines."""
    if item is None:
        return None
    if isinstance(item, str):
        return item if allow_raw_text else None
    if _looks_like_mlx_chat_messages(item):
        return _render_mlx_messages(target, item, is_vlm=is_vlm)
    if not isinstance(item, dict):
        return None

    if dataset_text_field in item and item[dataset_text_field]:
        value = item[dataset_text_field]
        if isinstance(value, str):
            return value
        if _looks_like_mlx_chat_messages(value):
            return _render_mlx_messages(target, value, is_vlm=is_vlm)

    for key in ("text", "content", "instruction"):
        value = item.get(key)
        if isinstance(value, str) and value:
            return value

    messages = _select_mlx_messages_or_raw(item)
    if messages is not item:
        return _render_mlx_messages(target, messages, is_vlm=is_vlm)

    if "prompt" in item and "completion" in item:
        prompt = render_mlx_chat_example(
            target, item.get("prompt"), dataset_text_field=dataset_text_field,
            is_vlm=is_vlm, allow_raw_text=allow_raw_text,
        )
        completion = render_mlx_chat_example(
            target, item.get("completion"), dataset_text_field=dataset_text_field,
            is_vlm=is_vlm, allow_raw_text=allow_raw_text,
        )
        if prompt is not None or completion is not None:
            return (prompt or "") + (completion or "")

    return None


def collect_mlx_texts(target, item, *, dataset_text_field="text", is_vlm=False):
    """Return one or more rendered text strings from a dataset row or formatter output."""
    if item is None:
        return []
    if isinstance(item, list) and not _looks_like_mlx_chat_messages(item):
        texts = []
        for value in item:
            texts.extend(
                collect_mlx_texts(
                    target, value,
                    dataset_text_field=dataset_text_field,
                    is_vlm=is_vlm,
                )
            )
        return texts
    text = render_mlx_chat_example(
        target,
        item,
        dataset_text_field=dataset_text_field,
        is_vlm=is_vlm,
    )
    return [text] if text else []


def _render_mlx_prompt_completion_texts(
    target,
    item,
    *,
    dataset_text_field="text",
    is_vlm=False,
):
    """Render prompt and completion parts separately for text label masking."""
    if not isinstance(item, dict) or "prompt" not in item or "completion" not in item:
        return None
    prompt = render_mlx_chat_example(
        target,
        item.get("prompt"),
        dataset_text_field=dataset_text_field,
        is_vlm=is_vlm,
    )
    completion = render_mlx_chat_example(
        target,
        item.get("completion"),
        dataset_text_field=dataset_text_field,
        is_vlm=is_vlm,
    )
    if prompt is None and completion is None:
        return None
    return prompt or "", completion or ""


def _looks_like_mlx_chat_value(value):
    """Return True for one chat message or a list of chat messages."""
    return (
        _looks_like_mlx_chat_messages(value)
        or (
            isinstance(value, dict)
            and "role" in value
            and "content" in value
        )
    )


def _flatten_mlx_chat_template_ids(value, state=None):
    """Flatten tokenizer chat-template output to a single token-id list."""
    if isinstance(value, Mapping):
        value = value["input_ids"]
    value = _guard_host_token_output(value, state, "the chat template")
    if hasattr(value, "tolist"):
        value = value.tolist()
    if len(value) > 0 and isinstance(value[0], list):
        value = value[0]
    return list(value)


def _flatten_mlx_chat_template_field(value, field_name, state=None):
    """Flatten one field from tokenizer chat-template output."""
    if isinstance(value, Mapping):
        value = value[field_name]
    value = _guard_host_token_output(value, state, "the chat template")
    if hasattr(value, "tolist"):
        value = value.tolist()
    if len(value) > 0 and isinstance(value[0], list):
        value = value[0]
    return list(value)


def _apply_mlx_chat_template_ids(tokenizer, messages, _unsloth_state=None, /, **kwargs):
    """Tokenize messages through apply_chat_template with a HF-compatible fallback."""
    try:
        return _flatten_mlx_chat_template_ids(
            tokenizer.apply_chat_template(messages, **kwargs),
            state=_unsloth_state,
        )
    except TypeError:
        kwargs.pop("return_dict", None)
        return _flatten_mlx_chat_template_ids(
            tokenizer.apply_chat_template(messages, **kwargs),
            state=_unsloth_state,
        )


def _apply_mlx_chat_template_dict(tokenizer, messages, _unsloth_state=None, /, **kwargs):
    """Tokenize messages through apply_chat_template and preserve returned masks."""
    try:
        value = tokenizer.apply_chat_template(messages, **kwargs)
    except TypeError:
        if kwargs.get("return_assistant_tokens_mask"):
            raise
        kwargs.pop("return_assistant_tokens_mask", None)
        kwargs.pop("return_dict", None)
        value = tokenizer.apply_chat_template(messages, **kwargs)
    if not isinstance(value, Mapping):
        value = {"input_ids": value}
    if _unsloth_state is not None:
        for field_value in value.values():
            _guard_host_token_output(field_value, _unsloth_state, "the chat template")
    return value


def _apply_mlx_text_label_masks(input_ids, *, completion_mask=None, assistant_mask=None):
    """Build labels from input_ids, applying completion then assistant masks."""
    labels = list(input_ids)
    if completion_mask is not None:
        labels = [
            int(label) if int(mask) != 0 else -100
            for label, mask in zip(labels, completion_mask)
        ]
    if assistant_mask is not None:
        labels = [
            int(label) if int(mask) != 0 else -100
            for label, mask in zip(labels, assistant_mask)
        ]
    return labels


def _validate_mlx_assistant_mask(input_ids, assistant_mask, *, source):
    """Validate one assistant mask and mirror TRL's no-assistant-token error."""
    if len(assistant_mask) != len(input_ids):
        raise ValueError(
            f"Unsloth MLX: {source} assistant_masks must match input_ids length."
        )
    if not any(int(mask) == 1 for mask in assistant_mask):
        raise RuntimeError(
            "You're using `assistant_only_loss=True`, but at least one example has "
            "no assistant tokens. This usually means the tokenizer's chat template "
            "doesn't generate assistant masks — it may be missing the "
            "`{% generation %}` keyword. Please check the template and ensure "
            "it's correctly configured to support assistant masking."
        )


def _is_mlx_sft_conversational_value(value):
    """Return True for ChatML values accepted by SFT assistant-only loss."""
    return (
        isinstance(value, list)
        and len(value) > 0
        and isinstance(value[0], Mapping)
        and "role" in value[0]
        and "content" in value[0]
    )


def _is_mlx_sft_conversational_row(item):
    """Return whether one row can support SFT assistant-only loss."""
    if _is_mlx_sft_conversational_value(item):
        return True
    if not isinstance(item, Mapping):
        return False
    if "prompt" in item or "completion" in item:
        return (
            _looks_like_mlx_chat_value(item.get("prompt"))
            and _looks_like_mlx_chat_value(item.get("completion"))
        )
    for key in ("prompt", "chosen", "rejected", "completion", "messages"):
        if _is_mlx_sft_conversational_value(item.get(key)):
            return True
    return False


def _validate_mlx_text_assistant_only_dataset(dataset):
    """Reject first-sample non-conversational datasets like SFTTrainer."""
    for item in dataset:
        if not _is_mlx_sft_conversational_row(item):
            raise ValueError(
                "You set `assistant_only_loss=True`, but the dataset is not "
                "conversational. This option is only supported for "
                "conversational datasets."
            )
        return


def _tokenize_mlx_conversational_prompt_completion(
    tokenizer,
    prompt,
    completion,
    *,
    tools=None,
    chat_template_kwargs=None,
    assistant_only_loss=False,
    completion_only_loss=None,
    state=None,
):
    """Tokenize conversational prompt/completion rows using TRL's split."""
    prompt_messages = _normalize_mlx_messages(prompt, is_vlm=False)
    completion_messages = _normalize_mlx_messages(completion, is_vlm=False)
    template_kwargs = dict(chat_template_kwargs or {})
    prompt_ids = _apply_mlx_chat_template_ids(
        tokenizer,
        prompt_messages,
        state,
        tokenize=True,
        add_generation_prompt=True,
        tools=tools,
        **template_kwargs,
    )
    prompt_completion_processed = _apply_mlx_chat_template_dict(
        tokenizer,
        prompt_messages + completion_messages,
        state,
        tokenize=True,
        return_dict=True,
        return_assistant_tokens_mask=bool(assistant_only_loss),
        tools=tools,
        **template_kwargs,
    )
    input_ids = _flatten_mlx_chat_template_field(
        prompt_completion_processed, "input_ids", state=state,
    )
    assistant_mask = None
    if "assistant_masks" in prompt_completion_processed:
        assistant_mask = _flatten_mlx_chat_template_field(
            prompt_completion_processed, "assistant_masks", state=state,
        )
        _validate_mlx_assistant_mask(
            input_ids, assistant_mask, source="conversational"
        )
    elif assistant_only_loss:
        _validate_mlx_assistant_mask(
            input_ids, [0] * len(input_ids), source="conversational"
        )
    return _mask_mlx_prompt_completion_labels(
        tokenizer,
        prompt_ids,
        input_ids,
        append_eos=False,
        completion_only_loss=completion_only_loss,
        assistant_mask=assistant_mask,
    )


def _tokenize_mlx_prompt_completion(
    tokenizer,
    prompt,
    completion,
    *,
    append_eos=True,
    completion_only_loss=None,
    state=None,
):
    """Tokenize a text prompt/completion pair and mask prompt labels like TRL."""
    encoded = _encode_mlx_prompt_completion(
        tokenizer, prompt, prompt + completion, append_eos=False, state=state,
    )
    return _mask_mlx_prompt_completion_labels(
        tokenizer,
        list(encoded.input_ids[:encoded.prompt_length]),
        list(encoded.input_ids),
        append_eos=append_eos,
        completion_only_loss=completion_only_loss,
    )


@dataclass(frozen=True)
class _MLXPromptCompletionTokens:
    """Immutable encoding shared by SFT and preference tokenization."""

    prompt_ids: tuple
    input_ids: tuple
    prompt_length: int


def _mlx_prompt_completion_boundary(
    prompt_ids, input_ids, *, strict=True, step_back=False,
):
    """Locate the completion after tolerating one boundary-merged token.

    Without ``strict`` it may fall wherever the two tokenizations stop agreeing.

    ``step_back`` drops the verification rather than raising on it. That is what
    ORPOTrainer.build_tokenized_answer does in trl/trainer/orpo_trainer.py: when
    the prompt is not a token prefix it steps back exactly one token and never
    checks what precedes it. Reproducing that is deliberate parity, not an
    oversight, and only the preference path asks for it: a recovered prompt is a
    character prefix and so lands mid-token routinely, where SFT's prompt is
    tokenized from the same text it re-tokenizes and a mismatch is a real error.
    """
    prompt_ids = tuple(prompt_ids)
    input_ids = tuple(input_ids)
    if input_ids[:len(prompt_ids)] == prompt_ids:
        return len(prompt_ids)
    if not strict:
        shared = 0
        while shared < min(len(prompt_ids), len(input_ids)):
            if prompt_ids[shared] != input_ids[shared]:
                break
            shared += 1
        return shared
    prompt_length = min(max(0, len(prompt_ids) - 1), len(input_ids))
    if not step_back and input_ids[:prompt_length] != prompt_ids[:prompt_length]:
        raise ValueError(
            "Unsloth MLX: tokenized prompt and prompt+completion differ before "
            "the final prompt token; only a boundary merge is supported."
        )
    return prompt_length


def _encode_mlx_prompt_completion(
    tokenizer, prompt_text, full_text, *, append_eos=True, state=None,
    step_back=False,
):
    """Encode a prompt and its full text with one EOS policy."""
    prompt_ids = tuple(int(x) for x in encode_mlx_text(
        tokenizer, prompt_text, state=state,
    ))
    input_ids = [int(x) for x in encode_mlx_text(
        tokenizer, full_text, state=state,
    )]
    eos_id = getattr(tokenizer, "eos_token_id", None)
    if append_eos and eos_id is not None and (
        not input_ids or input_ids[-1] != int(eos_id)
    ):
        input_ids.append(int(eos_id))
    input_ids = tuple(input_ids)
    return _MLXPromptCompletionTokens(
        prompt_ids,
        input_ids,
        # A template may re-render the prompt's last message once a completion
        # follows, leaving it no longer even a text prefix.
        _mlx_prompt_completion_boundary(
            prompt_ids, input_ids, strict=full_text.startswith(prompt_text),
            step_back=step_back,
        ),
    )


def _mask_mlx_prompt_completion_labels(
    tokenizer,
    prompt_ids,
    input_ids,
    *,
    append_eos=True,
    completion_only_loss=None,
    assistant_mask=None,
):
    """Build labels by masking the prompt prefix from prompt/completion ids."""
    if input_ids[:len(prompt_ids)] != prompt_ids:
        warnings.warn(
            "Mismatch between tokenized prompt and tokenized prompt+completion; "
            "completion_only_loss masking will use the prompt token length.",
            RuntimeWarning,
            stacklevel=2,
        )
    eos_id = getattr(tokenizer, "eos_token_id", None) if append_eos else None
    if eos_id is not None and (not input_ids or input_ids[-1] != eos_id):
        input_ids.append(int(eos_id))
        if assistant_mask is not None:
            assistant_mask.append(0)
    completion_mask = None
    if completion_only_loss is not False:
        completion_mask = [0] * min(len(prompt_ids), len(input_ids))
        completion_mask.extend([1] * (len(input_ids) - len(completion_mask)))
    labels = _apply_mlx_text_label_masks(
        input_ids,
        completion_mask=completion_mask,
        assistant_mask=assistant_mask,
    )
    return input_ids, labels


def _tokenize_mlx_prompt_completion_row(
    tokenizer,
    item,
    *,
    dataset_text_field="text",
    append_eos=True,
    completion_only_loss=None,
    assistant_only_loss=False,
    state=None,
):
    """Tokenize one text prompt/completion row, including conversational rows."""
    if not isinstance(item, dict) or "prompt" not in item or "completion" not in item:
        return None
    prompt = item.get("prompt")
    completion = item.get("completion")
    if _looks_like_mlx_chat_value(prompt) and _looks_like_mlx_chat_value(completion):
        return _tokenize_mlx_conversational_prompt_completion(
            tokenizer,
            prompt,
            completion,
            tools=item.get("tools"),
            chat_template_kwargs=item.get("chat_template_kwargs"),
            assistant_only_loss=assistant_only_loss,
            completion_only_loss=completion_only_loss,
            state=state,
        )
    pair = _render_mlx_prompt_completion_texts(
        tokenizer,
        item,
        dataset_text_field=dataset_text_field,
        is_vlm=False,
    )
    if pair is None:
        return None
    return _tokenize_mlx_prompt_completion(
        tokenizer,
        pair[0],
        pair[1],
        append_eos=append_eos,
        completion_only_loss=completion_only_loss,
        state=state,
    )


def _tokenize_mlx_assistant_messages_row(tokenizer, item, state=None):
    """Tokenize one conversational row with chat-template assistant masks."""
    messages = (
        item if _looks_like_mlx_chat_messages(item)
        else _select_mlx_messages_or_raw(item)
    )
    if messages is item and not _looks_like_mlx_chat_messages(messages):
        return None
    messages = _normalize_mlx_messages(messages, is_vlm=False)
    if isinstance(messages, str):
        return None
    template_kwargs = (
        dict(item.get("chat_template_kwargs", {}))
        if isinstance(item, Mapping) else {}
    )
    processed = _apply_mlx_chat_template_dict(
        tokenizer,
        messages,
        state,
        return_dict=True,
        tokenize=True,
        return_assistant_tokens_mask=True,
        tools=item.get("tools") if isinstance(item, Mapping) else None,
        **template_kwargs,
    )
    input_ids = _flatten_mlx_chat_template_field(processed, "input_ids", state=state)
    assistant_mask = None
    if "assistant_masks" in processed:
        assistant_mask = _flatten_mlx_chat_template_field(processed, "assistant_masks", state=state)
        _validate_mlx_assistant_mask(input_ids, assistant_mask, source="text")
    else:
        _validate_mlx_assistant_mask(input_ids, [0] * len(input_ids), source="text")
    labels = (
        _apply_mlx_text_label_masks(input_ids, assistant_mask=assistant_mask)
        if assistant_mask is not None else None
    )
    return input_ids, labels


def _prepare_labeled_text_dataset(
    dataset,
    tokenizer,
    dataset_text_field="text",
    formatting_func=None,
    append_eos=True,
    completion_only_loss=None,
    assistant_only_loss=False,
):
    """Materialize text rows that need explicit labels into token ids."""
    formatted = []
    for item in dataset:
        source = formatting_func(item) if formatting_func is not None else item
        sources = source if (
            isinstance(source, list) and not _looks_like_mlx_chat_messages(source)
        ) else [source]
        for row in sources:
            tokenized = _tokenize_mlx_prompt_completion_row(
                tokenizer,
                row,
                dataset_text_field=dataset_text_field,
                append_eos=append_eos,
                completion_only_loss=completion_only_loss,
                assistant_only_loss=assistant_only_loss,
            )
            if tokenized is None and assistant_only_loss:
                tokenized = _tokenize_mlx_assistant_messages_row(tokenizer, row)
            if tokenized is None and assistant_only_loss:
                raise ValueError(
                    "You set `assistant_only_loss=True`, but the dataset is not "
                    "conversational. This option is only supported for "
                    "conversational datasets."
                )
            if tokenized is not None and tokenized[0]:
                formatted.append(tokenized)
    return formatted


def _coerce_mlx_token_list(value, field_name, state=None):
    """Convert one token-id field from a pretokenized row to a Python list.

    With ``state``, an MLX-valued field marks the stream ``host_valued=False``
    BEFORE conversion, since the conversion is itself MLX work the prefetch
    producer must reject rather than run off the consumer thread.
    """
    if state is not None and _contains_mlx_values(value):
        if state.get("reject_mlx_valued"):
            raise ValueError(
                f"Unsloth MLX: pretokenized '{field_name}' is an MLX array; "
                "the prefetch producer must not convert MLX values off the "
                "consumer thread. Use streaming_prefetch_batches=0 "
                "(synchronous mode) for MLX-valued rows."
            )
        state["host_valued"] = False
    if hasattr(value, "tolist"):
        value = value.tolist()
    if not isinstance(value, (list, tuple)):
        raise ValueError(f"Unsloth MLX: pretokenized '{field_name}' must be a sequence.")
    if value and isinstance(value[0], (list, tuple)):
        raise ValueError(f"Unsloth MLX: pretokenized '{field_name}' must be one sequence.")
    return [int(token) for token in value]


def _mlx_text_pad_id(tokenizer):
    """Return the tokenizer pad id used by TRL's text data collator."""
    pad_id = getattr(tokenizer, "pad_token_id", None)
    return int(pad_id) if pad_id is not None else 0


def _resolve_mlx_pretokenized_completion_only_loss(dataset, completion_only_loss):
    """Resolve SFTTrainer's default loss mode from the first raw text row."""
    if completion_only_loss is not None:
        return completion_only_loss
    for item in dataset:
        return isinstance(item, Mapping) and "prompt" in item and "completion" in item
    return False


def _prompt_completion_formatter_conflict(
    dataset, formatting_func, completion_only_loss
):
    """Detect a formatter that erases a prompt/completion boundary under the default.

    SFTTrainer resolves the completion_only_loss default to True for prompt/completion
    datasets and then rejects a formatting_func as incompatible, because formatting
    collapses the row into free text and drops the completion boundary. We only reach
    this after formatting produced no labeled rows, so raising here mirrors that
    guardrail instead of silently training on the full formatted sequence. A formatter
    that keeps prompt/completion keys still yields labeled rows and never lands here.
    """
    if formatting_func is None or completion_only_loss is not None:
        return False
    for item in dataset:
        return isinstance(item, Mapping) and "prompt" in item and "completion" in item
    return False


def _tokenize_mlx_pretokenized_row(
    item,
    *,
    completion_only_loss=None,
    assistant_only_loss=False,
    state=None,
):
    """Read input_ids plus optional labels/completion_mask from one text row."""
    if not isinstance(item, Mapping) or "input_ids" not in item:
        return None

    input_ids = _coerce_mlx_token_list(item["input_ids"], "input_ids", state=state)
    labels = None
    if item.get("labels") is not None:
        labels = _coerce_mlx_token_list(item["labels"], "labels", state=state)
        if len(labels) != len(input_ids):
            raise ValueError(
                "Unsloth MLX: pretokenized 'labels' must match 'input_ids' length."
            )

    if completion_only_loss is True and item.get("completion_mask") is not None:
        completion_mask = _coerce_mlx_token_list(
            item["completion_mask"], "completion_mask", state=state,
        )
        if len(completion_mask) != len(input_ids):
            raise ValueError(
                "Unsloth MLX: pretokenized 'completion_mask' must match "
                "'input_ids' length."
            )
        labels = labels if labels is not None else list(input_ids)
        labels = [
            int(label) if int(mask) != 0 else -100
            for label, mask in zip(labels, completion_mask)
        ]

    assistant_masks = item.get("assistant_masks")
    if assistant_only_loss and assistant_masks is None and labels is None:
        raise ValueError(
            "Unsloth MLX: pretokenized assistant_only_loss=True rows must "
            "include 'assistant_masks' or explicit 'labels'."
        )

    # Match TRL's collator: pretokenized assistant_masks are labels metadata.
    if assistant_masks is not None:
        assistant_mask = _coerce_mlx_token_list(
            assistant_masks, "assistant_masks", state=state,
        )
        if len(assistant_mask) != len(input_ids):
            raise ValueError(
                "Unsloth MLX: pretokenized 'assistant_masks' must match "
                "'input_ids' length."
            )
        if assistant_only_loss:
            _validate_mlx_assistant_mask(
                input_ids, assistant_mask, source="pretokenized",
            )
        labels = labels if labels is not None else list(input_ids)
        labels = _apply_mlx_text_label_masks(
            labels,
            assistant_mask=assistant_mask,
        )

    return input_ids, labels


def _prepare_pretokenized_text_dataset(
    dataset,
    *,
    completion_only_loss=None,
    assistant_only_loss=False,
):
    """Materialize pretokenized text rows and report whether input_ids appeared."""
    completion_only_loss = _resolve_mlx_pretokenized_completion_only_loss(
        dataset,
        completion_only_loss,
    )
    formatted = []
    saw_pretokenized = False
    saw_other = False
    label_states = []
    for item in dataset:
        sources = item if (
            isinstance(item, list) and not _looks_like_mlx_chat_messages(item)
        ) else [item]
        for row in sources:
            tokenized = _tokenize_mlx_pretokenized_row(
                row,
                completion_only_loss=completion_only_loss,
                assistant_only_loss=assistant_only_loss,
            )
            if tokenized is not None:
                saw_pretokenized = True
                label_states.append(tokenized[1] is not None)
                if len(tokenized[0]) >= 2:
                    formatted.append(tokenized)
            else:
                saw_other = True
    if saw_pretokenized and saw_other:
        raise ValueError(
            "Unsloth MLX: pretokenized text datasets with 'input_ids' cannot "
            "be mixed with rows that need text formatting/tokenization."
        )
    if label_states:
        has_labels = label_states[0]
        if any(has_labels != state for state in label_states):
            raise ValueError(
                "Unsloth MLX: pretokenized rows with labels/completion_mask "
                "must not be mixed with rows that do not provide labels."
            )
    return formatted, saw_pretokenized


def _ensure_reiterable_text_dataset(dataset):
    """Materialize one-shot text iterables before probing for labeled rows."""
    if hasattr(dataset, "__len__") and hasattr(dataset, "__getitem__"):
        return dataset
    return list(dataset)


def _is_mlx_lazy_text_source(dataset):
    """Return whether streaming text must avoid map-style source operations."""
    try:
        from datasets import Dataset as HFDataset
        from datasets import IterableDataset as HFIterableDataset
    except ImportError:
        pass
    else:
        if isinstance(dataset, HFIterableDataset):
            return True
        if isinstance(dataset, HFDataset):
            return False
    if isinstance(dataset, Sequence):
        return False
    if isinstance(dataset, Iterator):
        return True
    source_mro = type(dataset).__mro__
    # Explicit iteration wins over map-style methods, which may be advisory or
    # deliberately unusable and must not be probed just to classify the source.
    if any("__iter__" in cls.__dict__ for cls in source_mro):
        return True
    # Python's sequence-iteration fallback accepts __getitem__ without __iter__:
    # both protocols means map-style, getitem-only stays lazy. Neither is probed.
    has_getitem = any("__getitem__" in cls.__dict__ for cls in source_mro)
    has_len = any("__len__" in cls.__dict__ for cls in source_mro)
    return has_getitem and not has_len


def _is_mlx_hf_iterable_text_source(dataset):
    """Return whether Hugging Face defines this source as replayable. Detected
    through ``sys.modules`` so classification never imports ``datasets``: if the
    package was never imported, no instance can exist."""
    hf_datasets = sys.modules.get("datasets")
    hf_iterable = getattr(hf_datasets, "IterableDataset", None)
    return hf_iterable is not None and isinstance(dataset, hf_iterable)


def _mlx_lazy_text_source(dataset):
    """Return the raw source beneath an MLX prepared iterable view."""
    return getattr(dataset, "_mlx_source_dataset", dataset)


class _MLXIterableTokenizedDatasetView:
    """Iterable-only public view over MLX's lazy text normalization pipeline.

    Deliberately has no ``__len__`` or ``__getitem__``. Preserves the source's
    replay/one-shot behavior and forwards epoch changes without consuming a row.
    """

    _INVALIDATED_SOURCE_METADATA = frozenset((
        "column_names", "features", "info", "num_columns", "supervised_keys",
    ))

    def __init__(
        self,
        dataset,
        tokenizer,
        *,
        dataset_text_field="text",
        formatting_func=None,
        append_eos=True,
        completion_only_loss=None,
        assistant_only_loss=False,
        max_seq_length=None,
        response_mask_fn=None,
    ):
        self._mlx_source_dataset = dataset
        self._tokenizer = tokenizer
        self._dataset_text_field = dataset_text_field
        self._formatting_func = formatting_func
        self._append_eos = append_eos
        self._completion_only_loss = completion_only_loss
        self._assistant_only_loss = assistant_only_loss
        self._max_seq_length = max_seq_length
        self._response_mask_fn = response_mask_fn

    def __getattr__(self, name):
        """Lazily expose public metadata and cursor state, not raw transforms."""
        if name.startswith("_") or name in self._INVALIDATED_SOURCE_METADATA:
            raise AttributeError(name)
        value = getattr(self._mlx_source_dataset, name)
        if callable(value):
            raise AttributeError(name)
        return value

    def set_epoch(self, epoch):
        set_epoch = getattr(self._mlx_source_dataset, "set_epoch", None)
        if callable(set_epoch):
            set_epoch(epoch)

    def set_response_mask(self, mask_fn):
        self._response_mask_fn = mask_fn

    def set_tokenizer(self, tokenizer):
        self._tokenizer = tokenizer

    def _iter_tokenized_rows(
        self, dataset=None, *, state=None, include_source=False,
    ):
        source = self._mlx_source_dataset if dataset is None else dataset
        return _iter_lazy_tokenized_text_rows(
            source,
            self._tokenizer,
            dataset_text_field=self._dataset_text_field,
            formatting_func=self._formatting_func,
            append_eos=self._append_eos,
            completion_only_loss=self._completion_only_loss,
            assistant_only_loss=self._assistant_only_loss,
            max_seq_length=self._max_seq_length,
            response_mask_fn=self._response_mask_fn,
            state=state,
            include_source=include_source,
        )

    def __iter__(self):
        for source, input_ids, labels in self._iter_tokenized_rows(
            include_source=True,
        ):
            row = dict(source) if isinstance(source, Mapping) else {}
            row["input_ids"] = list(input_ids)
            row.pop("labels", None)
            if labels is not None:
                row["labels"] = list(labels)
            if isinstance(source, Mapping) and "input_ids" in source:
                for field in ("completion_mask", "assistant_masks"):
                    mask = row.get(field)
                    if hasattr(mask, "tolist"):
                        mask = mask.tolist()
                    if isinstance(mask, (list, tuple)) and (
                        not mask or not isinstance(mask[0], (list, tuple))
                    ):
                        row[field] = list(mask)[:len(input_ids)]
            yield row


def _labeled_row_has_supervision(labels, max_seq_length):
    # Keep rows with a supervised token in labels[1:max_seq_length] (causal shift,
    # length-capped); an all-masked batch aborts training. labels=None always kept.
    if labels is None:
        return True
    return any(int(x) != -100 for x in labels[1:max_seq_length])


class _HostStagedTextBatch:
    """Host-side (python/numpy) text batch awaiting MLX finalization.

    ``host_valued`` is False when any staged field arrived as an MLX array:
    synchronous mode accepts those unchanged, the prefetch producer rejects them.
    """

    __slots__ = ("ids", "lengths_info", "labels", "host_valued")

    def __init__(self, ids, lengths_info, labels, host_valued=True):
        self.ids = ids
        self.lengths_info = lengths_info
        self.labels = labels
        self.host_valued = host_valued


def _is_host_valued_field(value):
    return not _contains_mlx_values(value)


def _finalize_text_batch(staged):
    """The single point where staged text batches become MLX arrays."""
    labels_array = (
        mx.array(staged.labels) if staged.labels is not None else None
    )
    return mx.array(staged.ids), mx.array(staged.lengths_info), labels_array


def _stage_tokenized_text_batch(
    batch_items,
    max_seq_length,
    pad_id=0,
    labels_expected=None,
    host_valued=None,
):
    """Host staging of one pretokenized text batch (no MLX work).

    ``host_valued=None`` computes the flag from the items; the lazy pipeline
    instead passes the stream-level flag recorded at row normalization, where
    MLX origin is still visible.
    """
    valid_items = [item for item in batch_items if item is not None]
    lengths = [
        0 if item is None else min(len(item[0]), max_seq_length)
        for item in batch_items
    ]
    max_length = max(lengths)
    if max_length == 0:
        max_length = min(2, max_seq_length)
    batch_ids = np.full((len(batch_items), max_length), int(pad_id), dtype=np.int32)
    has_labels = (
        valid_items[0][1] is not None
        if valid_items else bool(labels_expected)
    )
    if any(
        (labels is not None) != has_labels
        for ids, labels in valid_items
    ):
        raise ValueError(
            "Unsloth MLX: pretokenized rows with labels/completion_mask must "
            "not be batched with rows that do not provide labels."
        )
    if host_valued is None:
        host_valued = all(
            _is_host_valued_field(item[0])
            and (item[1] is None or _is_host_valued_field(item[1]))
            for item in valid_items
        )
    batch_labels = (
        np.full((len(batch_items), max_length), -100, dtype=np.int64)
        if has_labels else None
    )
    for row_idx, item in enumerate(batch_items):
        if item is None:
            continue
        ids, labels = item
        length = lengths[row_idx]
        batch_ids[row_idx, :length] = ids[:length]
        if batch_labels is not None:
            batch_labels[row_idx, :length] = labels[:length]
    lengths_info = [[0, length] for length in lengths]
    return _HostStagedTextBatch(batch_ids, lengths_info, batch_labels, host_valued)


def _create_tokenized_text_batch(batch_items, max_seq_length, pad_id=0,
                                 labels_expected=None):
    """Pad pretokenized ids plus optional labels for one MLX text batch."""
    # host_valued=True skips the provenance scan: this finalizes immediately.
    return _finalize_text_batch(_stage_tokenized_text_batch(
        batch_items, max_seq_length, pad_id=pad_id,
        labels_expected=labels_expected, host_valued=True,
    ))


def _create_labeled_text_batch(batch_items, max_seq_length, pad_id=0):
    """Pad token ids and labels for one labeled MLX text batch."""
    return _create_tokenized_text_batch(batch_items, max_seq_length, pad_id=pad_id)


@dataclass(frozen=True)
class _FiniteTextRow:
    input_ids: tuple
    offset: int = 0
    labels: tuple | None = None


def _finite_text_pad_width(raw_width, *, pad_to_multiple=0, minimum_width=1,
                           max_seq_length):
    """Shared finite text pad-width policy.

    Order of operations is observable and fixed: optional
    ``1 + pad_to_multiple * ceil(raw_width / pad_to_multiple)`` round-up
    (identity when the multiple is zero), then minimum width, then the
    ``max_seq_length`` cap.
    """
    width = int(raw_width)
    if pad_to_multiple:
        width = 1 + pad_to_multiple * (
            (width + pad_to_multiple - 1) // pad_to_multiple
        )
    if width < minimum_width:
        width = minimum_width
    return min(int(max_seq_length), width)


class _FiniteVisitMixin:
    """Absolute-visit mapping shared by finite CPU batch plans."""

    __slots__ = ()

    _VISIT_POLICIES = ("identity", "epoch_permute")

    @property
    def visit_policy(self):
        return self._visit_policy

    def batch_index_for_visit(self, absolute_visit):
        """Map an absolute batch visit to one stored schedule index.

        Identity plans replay the schedule cyclically (the historical
        ``visit % len``). ``epoch_permute`` plans replay the stored order for
        epoch 0, then visit a deterministic permutation of the same batch
        multiset each later epoch, derived only from the normalized seed and
        the epoch, never from ambient RNG state.
        """
        count = len(self._schedule)
        if count == 0:
            raise ValueError("cannot resolve a visit on an empty schedule")
        # operator.index rejects fractional visits instead of truncating them.
        visit = operator.index(absolute_visit)
        if visit < 0:
            raise ValueError("absolute_visit must be non-negative")
        epoch, position = divmod(visit, count)
        if self._visit_policy != "epoch_permute" or epoch == 0:
            return position
        cached = self._visit_epoch_cache
        if cached is None or cached[0] != epoch:
            cached = (epoch, self._build_visit_permutation(epoch))
            self._visit_epoch_cache = cached
        return cached[1][position]

    def _build_visit_permutation(self, epoch):
        """One O(len) deterministic permutation build per epoch transition."""
        rng = np.random.RandomState(
            (int(self._visit_seed) + int(epoch)) % (2 ** 32)
        )
        return tuple(
            int(index) for index in rng.permutation(len(self._schedule))
        )


class FiniteTextBatchPlan(_FiniteVisitMixin):
    """CPU-backed finite text schedule with on-demand MLX materialization."""

    __slots__ = (
        "_rows",
        "_schedule",
        "_widths",
        "max_seq_length",
        "pad_id",
        "minimum_width",
        "pad_to_multiple",
        "label_dtype",
        "_shape_plan",
        "_visit_policy",
        "_visit_seed",
        "_visit_epoch_cache",
        "_cycle_length",
    )

    def __init__(
        self,
        rows,
        schedule,
        *,
        max_seq_length,
        pad_id,
        minimum_width=1,
        pad_to_multiple=0,
        widths=None,
        label_dtype=np.int64,
        visit_policy="identity",
        visit_seed=None,
        cycle_length=None,
    ):
        self._rows = tuple(rows)
        self._schedule = tuple(tuple(batch) for batch in schedule)
        self._widths = None if widths is None else tuple(int(x) for x in widths)
        self.max_seq_length = int(max_seq_length)
        self.pad_id = int(pad_id)
        self.minimum_width = int(minimum_width)
        self.pad_to_multiple = int(pad_to_multiple)
        self.label_dtype = np.dtype(label_dtype)
        self._shape_plan = None
        self._visit_policy = str(visit_policy)
        # Normalized eagerly so visits never depend on ambient RNG state and a
        # reconstructed plan (fresh-process resume) derives identical visits.
        self._visit_seed = (
            None if self._visit_policy == "identity"
            else _normalize_seed(visit_seed)
        )
        self._visit_epoch_cache = None
        # Micro-batches in ONE dataset pass, which len(schedule) is not once a
        # num_batches horizon cycles the plan. Batching drops sub-two-token rows
        # and can expand one source item into several, so only the plan itself
        # knows this count; callback epoch accounting reads it.
        self._cycle_length = (
            None if cycle_length is None else max(1, int(cycle_length))
        )
        if self.max_seq_length < 1:
            raise ValueError("max_seq_length must be positive")
        if self.minimum_width < 0:
            raise ValueError("minimum_width must be non-negative")
        if self.pad_to_multiple < 0:
            raise ValueError("pad_to_multiple must be non-negative")
        if self._widths is not None and len(self._widths) != len(self._schedule):
            raise ValueError("widths must contain one entry per scheduled batch")
        if self._visit_policy not in self._VISIT_POLICIES:
            raise ValueError(
                f"visit_policy must be one of {self._VISIT_POLICIES}, "
                f"got {visit_policy!r}"
            )

    @property
    def rows(self):
        return self._rows

    @property
    def schedule(self):
        return self._schedule

    @property
    def widths(self):
        return self._widths

    def __len__(self):
        return len(self._schedule)

    @property
    def cycle_length(self):
        """Micro-batches in one dataset pass (<= len(self))."""
        return self._cycle_length

    def batch_width(self, index):
        # Explicit widths are authoritative; skip the per-row length scan
        # (constructor validation keeps widths/schedule index-aligned).
        if self._widths is not None:
            return self._widths[int(index)]
        batch_indices = self._schedule[index]
        lengths = [
            0
            if row_index is None
            else min(
                len(self._rows[int(row_index)].input_ids),
                self.max_seq_length,
            )
            for row_index in batch_indices
        ]
        return _finite_text_pad_width(
            max(lengths, default=0),
            pad_to_multiple=self.pad_to_multiple,
            minimum_width=self.minimum_width,
            max_seq_length=self.max_seq_length,
        )

    def batch_family(self, index):
        batch_indices = self._schedule[index]
        real_rows = [
            self._rows[int(row_index)]
            for row_index in batch_indices
            if row_index is not None
        ]
        has_labels = bool(
            (real_rows and real_rows[0].labels is not None)
            or (
                not real_rows
                and self._rows
                and self._rows[0].labels is not None
            )
        )
        batch_size = len(batch_indices)
        return (
            "text_tuple_3",
            ((batch_size, "sequence"), "int32"),
            ((batch_size, 2), "int32"),
            (
                ((batch_size, "sequence"), self.label_dtype.name)
                if has_labels else None
            ),
        )

    def set_shape_plan(self, shape_plan):
        if getattr(shape_plan.report, "action", None) not in ("exact", "bucket"):
            raise ValueError("only exact or bucket shape plans can be installed")
        self._shape_plan = shape_plan

    def materialize(self, index, *, phase=None):
        batch_indices = self._schedule[index]
        selected = [
            None if row_index is None else self._rows[int(row_index)]
            for row_index in batch_indices
        ]
        real_rows = [row for row in selected if row is not None]
        has_labels = bool(
            (real_rows and real_rows[0].labels is not None)
            or (
                not real_rows
                and self._rows
                and self._rows[0].labels is not None
            )
        )
        if any((row.labels is not None) != has_labels for row in real_rows):
            raise ValueError(
                "Unsloth MLX: labeled and unlabeled text rows cannot share a batch."
            )

        lengths = [
            0 if row is None else min(len(row.input_ids), self.max_seq_length)
            for row in selected
        ]
        raw_width = self.batch_width(index)
        width = raw_width
        if self._shape_plan is not None and phase is not None:
            family = self.batch_family(index)
            width = self._shape_plan.endpoint_for(family, raw_width)
            if not self._shape_plan.allows(
                family, raw_width, phase,
            ):
                raise RuntimeError(
                    "Unsloth MLX: compiled text batch signature was not "
                    "admitted by the finite shape plan."
                )
        batch_ids = np.full(
            (len(selected), width), self.pad_id, dtype=np.int32,
        )
        batch_labels = (
            np.full((len(selected), width), -100, dtype=self.label_dtype)
            if has_labels else None
        )
        lengths_info = np.zeros((len(selected), 2), dtype=np.int32)

        for row_index, (row, length) in enumerate(zip(selected, lengths)):
            if row is None:
                continue
            lengths_info[row_index] = (int(row.offset), length)
            batch_ids[row_index, :length] = row.input_ids[:length]
            if batch_labels is not None:
                batch_labels[row_index, :length] = row.labels[:length]

        return (
            mx.array(batch_ids),
            mx.array(lengths_info),
            mx.array(batch_labels) if batch_labels is not None else None,
        )

    def __getitem__(self, index):
        return self.materialize(index)

    def materialize_all(self):
        batches = [self[index] for index in range(len(self))]
        mx.eval(
            [batch for batch, _lengths, _labels in batches]
            + [lengths for _batch, lengths, _labels in batches]
            + [labels for _batch, _lengths, labels in batches if labels is not None]
        )
        return batches


def _finite_text_rows(tokenized, *, with_offsets=False):
    rows = []
    for item in tokenized:
        if with_offsets:
            input_ids, offset = item
            labels = None
        else:
            input_ids, labels = item
            offset = 0
        rows.append(
            _FiniteTextRow(
                tuple(int(token) for token in input_ids),
                int(offset),
                None if labels is None else tuple(int(token) for token in labels),
            )
        )
    return tuple(rows)


def _shuffled_full_batch_schedule(
    row_count,
    batch_size,
    *,
    sort_key,
    num_batches,
    seed,
):
    if row_count < batch_size:
        raise ValueError(
            f"Dataset must have at least batch_size={batch_size}"
            f" examples but only has {row_count}."
        )
    indices = sorted(range(row_count), key=sort_key)
    groups = [
        tuple(indices[start : start + batch_size])
        for start in range(0, row_count - batch_size + 1, batch_size)
    ]
    # Plan-local RNG through _normalize_seed: same permutation stream as the
    # historical np.random.seed(int(seed)) global path for explicit seeds,
    # while ``None`` (and the default creator's previously ambient ``0``) are
    # canonicalized so fresh-process resume can reconstruct the schedule.
    rng = np.random.RandomState(_normalize_seed(seed))
    schedule = []
    while True:
        for group_index in rng.permutation(len(groups)):
            schedule.append(groups[int(group_index)])
            if num_batches is not None and len(schedule) >= num_batches:
                return tuple(schedule), len(groups)
        if num_batches is None:
            return tuple(schedule), len(groups)


def _create_tokenized_text_plan(tokenized, batch_size, max_seq_length,
                                num_batches=None, seed=42, pad_id=0):
    """Plan pretokenized rows with mlx-lm's sorting and shuffle contract."""
    tokenized = [
        row for row in tokenized
        if _labeled_row_has_supervision(row[1], max_seq_length)
    ]
    schedule, cycle_length = _shuffled_full_batch_schedule(
        len(tokenized),
        batch_size,
        sort_key=lambda index: len(tokenized[index][0]),
        num_batches=num_batches,
        seed=seed,
    )
    return FiniteTextBatchPlan(
        _finite_text_rows(tokenized),
        schedule,
        cycle_length=cycle_length,
        max_seq_length=max_seq_length,
        pad_id=pad_id,
        # One reusable shuffled cycle: eligible for epoch-permuted visits.
        # Horizon-expanded/truncated schedules replay stored order (identity).
        visit_policy="epoch_permute" if num_batches is None else "identity",
        visit_seed=seed,
    )


def _create_tokenized_text_batches(tokenized, batch_size, max_seq_length,
                                   num_batches=None, seed=42, pad_id=0):
    """Batch pretokenized text rows with mlx-lm's sorting and shuffle contract."""
    return _create_tokenized_text_plan(
        tokenized,
        batch_size,
        max_seq_length,
        num_batches=num_batches,
        seed=seed,
        pad_id=pad_id,
    ).materialize_all()


def _create_labeled_text_batches(tokenized, batch_size, max_seq_length,
                                 num_batches=None, seed=42, pad_id=0):
    """Batch labeled text rows with mlx-lm's default sorting and shuffle contract."""
    return _create_tokenized_text_batches(
        tokenized,
        batch_size,
        max_seq_length,
        num_batches=num_batches,
        seed=seed,
        pad_id=pad_id,
    )


def _iterate_tokenized_text_batches(tokenized, batch_size, max_seq_length,
                                    seed=42, loop=False, pad_id=0):
    """Yield pretokenized text batches with the same grouping used by materialization."""
    tokenized = [
        row for row in tokenized
        if _labeled_row_has_supervision(row[1], max_seq_length)
    ]
    if len(tokenized) < batch_size:
        raise ValueError(
            f"Dataset must have at least batch_size={batch_size}"
            f" examples but only has {len(tokenized)}."
        )

    idx = sorted(range(len(tokenized)), key=lambda i: len(tokenized[i][0]))
    batch_idx = [
        idx[i : i + batch_size]
        for i in range(0, len(idx) - batch_size + 1, batch_size)
    ]
    if seed is not None:
        np.random.seed(int(seed))

    while True:
        for batch_group_idx in np.random.permutation(len(batch_idx)):
            batch_items = [tokenized[i] for i in batch_idx[batch_group_idx]]
            yield _create_tokenized_text_batch(
                batch_items, max_seq_length, pad_id=pad_id
            )
        if not loop:
            break


def _iterate_labeled_text_batches(tokenized, batch_size, max_seq_length,
                                  seed=42, loop=False, pad_id=0):
    """Yield labeled text batches with the same grouping used by materialization."""
    yield from _iterate_tokenized_text_batches(
        tokenized,
        batch_size,
        max_seq_length,
        seed=seed,
        loop=loop,
        pad_id=pad_id,
    )


def _resize_vlm_images(images, image_size):
    from PIL import Image

    target = (image_size, image_size) if isinstance(image_size, int) else image_size
    resized = []
    for image in images:
        if isinstance(image, Image.Image):
            image = image.convert("RGB")
            if _is_vlm_no_resize_image_size(image_size):
                pass
            elif isinstance(image_size, int):
                # Match UnslothVisionDataCollator resize="min": shrink large
                # images to the model limit, but let processors handle upscaling.
                # Scale on the larger side so tall portrait images (e.g.
                # 512x2048 with a 512 cap) also shrink instead of slipping
                # through on a width-only check.
                width, height = image.size
                side = max(width, height)
                if side > image_size:
                    new_width = max(1, (width * image_size + side // 2) // side)
                    new_height = max(1, (height * image_size + side // 2) // side)
                    image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
            else:
                image = image.resize(target, Image.Resampling.LANCZOS)
            resized.append(image)
        else:
            resized.append(image)
    return resized


def _vlm_vision_part_state(messages):
    bare_placeholder_types = set()
    has_media_payload = False
    if not isinstance(messages, list):
        return bare_placeholder_types, has_media_payload
    for message in messages:
        if not isinstance(message, dict):
            continue
        content = message.get("content", "")
        if not isinstance(content, list):
            continue
        for part in content:
            if not isinstance(part, dict):
                continue
            if part.get("type") not in ("image", "image_url", "input_image", "video"):
                continue
            if any(key in part for key in ("image", "image_url", "input_image", "video")):
                has_media_payload = True
            else:
                bare_placeholder_types.add(part.get("type"))
    return bare_placeholder_types, has_media_payload


def _extract_vlm_images(
    item,
    messages,
    image_size,
    *,
    suppress_process_errors=False,
):
    images = []
    top_level_image = []
    bare_placeholder_types, has_media_payload = _vlm_vision_part_state(messages)
    has_only_bare_image_placeholders = bare_placeholder_types == {"image"}
    if isinstance(item, dict):
        image = item.get("images")
        if image is not None:
            images = image if isinstance(image, list) else [image]
        elif "image" in item:
            image = item.get("image")
            if image is not None:
                top_level_image = image if isinstance(image, list) else [image]

    if not images and isinstance(messages, list):
        for message in messages:
            content = message.get("content", "")
            if not isinstance(content, list):
                continue
            for part in content:
                if isinstance(part, dict) and part.get("type") == "image":
                    image = part.get("image")
                    if image is not None:
                        images.append(image)

    if (
        not images
        and top_level_image
        and has_only_bare_image_placeholders
        and not has_media_payload
    ):
        images = top_level_image

    if not images and isinstance(messages, list):
        try:
            from unsloth_zoo.vision_utils import process_vision_info

            extracted = process_vision_info(messages, return_video_kwargs=True)
            if isinstance(extracted, tuple) and extracted:
                maybe_images = extracted[0]
                if maybe_images is not None:
                    images = maybe_images if isinstance(maybe_images, list) else [maybe_images]
        except Exception:
            if not suppress_process_errors:
                raise

    return _resize_vlm_images(images, image_size)


def _extract_vlm_pc_images(item, prompt_messages, completion_messages, image_size):
    """Extract VLM PC images with CUDA's embedded-then-top-level preference."""
    messages = (prompt_messages or []) + (completion_messages or [])
    if messages:
        images = _extract_vlm_images(
            item if isinstance(item, dict) and item.get("images") is None else {},
            messages,
            image_size,
            suppress_process_errors=True,
        )
        if images:
            return images
        return []

    if isinstance(item, dict) and "images" in item:
        try:
            from unsloth_zoo.vision_utils import process_vision_info

            raw_images = item["images"]
            vision_infos = [{"image": raw_images[i]} for i in range(len(raw_images))]
            extracted = process_vision_info(vision_infos, return_video_kwargs=True)
            images = extracted[0] if isinstance(extracted, tuple) and extracted else None
            if images is None:
                images = []
            elif not isinstance(images, list):
                images = [images]
        except Exception:
            images = []
        return _resize_vlm_images(images, image_size)

    return []


_AUDIO_PART_TYPES = ("audio", "audio_url", "input_audio")

# Repeated placeholders only: begin/end delimiters would corrupt run counting.
_AUDIO_SOFT_TOKEN_STRINGS = (
    "<audio_soft_token>",   # Gemma 3n
    "<|audio|>",            # Gemma 4
    "<|AUDIO|>",            # Qwen2.5-Omni
    "<so_embedding>",       # Nemotron Nano Omni
    # Phi-4-multimodal reuses a spare special token, exposed nowhere else.
    "<|endoftext11|>",
)

class _AudioVersions(NamedTuple):
    """The first mlx-vlm release containing a family's qualified audio path."""

    minimum: str

    def admits(self, installed):
        if not installed:
            return False
        try:
            found = _Version(installed)
            # Only published final releases were probed, and mlx-vlm has shipped
            # no prerelease, post-release or local build in 73 releases.
            if found.is_prerelease or found.is_postrelease or found.local:
                return False
            return _Version(self.minimum) <= found
        except Exception:
            # An unparseable version is not evidence; refusing beats raising.
            return False

    def __str__(self):
        return f">={self.minimum}"


# Families and the mlx-vlm releases their audio path is qualified for.
#
# Probes ran on 0.4.4. gemma3n, phi4mm and minicpmo ship a byte-identical
# processor from 0.4.4 through 0.6.9.
#
# Gemma 4 starts at 0.6.2, not 0.4.4: below that mlx-vlm cannot load the
# checkpoint at all. E2B's KV-shared layers reuse an earlier layer's K/V and
# ship no k_proj/v_proj/k_norm, and mlx-vlm built those modules for every layer
# until Blaizzy/mlx-vlm#1301, so loading died on 60 missing tensors.
#
# The 0.4.4 this replaces was correct when written -- the export before
# 2026-07-06 shipped those projections -- and was invalidated by the checkpoint
# being re-uploaded. A version key cannot express a fact about an artefact, so
# re-measure with `tests/gemma4_audio_version_probe.py` rather than argue.
#
# Measured on macos-14 against mlx-community/gemma-4-e2b-it-4bit @ 2387675275,
# 0.4.4 through 0.6.4: load, placeholder count vs the positions `audio_tower`
# returns at 0.5s/1.0s/2.0s/3.7s, two clips giving two losses. 0.6.1 red,
# 0.6.2-0.6.4 green.
#
# Raw mlx-vlm 0.6.4 fails on these weights -- #1498
# made sanitize unconditional, double-transposing pre-converted convs -- but
# loader.py's `_ensure_audio_conv_sanitize` (PR 879) undoes it, and upstream
# fixed it in 0.6.5 (#1523).
# Unified needs 0.6.5's processor/audio-layout fix; Qwen needs 0.6.7's batched
# mel input and sample-domain length fixes. 0.6.10 is the latest real-model gate.
#
# Nemotron is 0.6.10, not the 0.5.0 that first carried it: below that,
# `sanitize_audio_weights` transposes `sound_encoder.encoder.*` convs
# unconditionally, so a pre-converted weight double-transposes and the load
# fails ((128,3,3,1) -> (128,3,1,3) on 0.5.0/0.6.4/0.6.7, untouched on 0.6.10+).
# `_ensure_audio_conv_sanitize` cannot repair it: it keys on markers in the
# sanitize source, and Nemotron's `Model.sanitize` delegates to a module-level
# function carrying neither.
_AUDIO_QUALIFIED_FAMILIES: "dict[str, _AudioVersions]" = {
    "gemma3n": _AudioVersions("0.4.4"),
    "gemma4": _AudioVersions("0.6.2"),
    "gemma4_unified": _AudioVersions("0.6.5"),
    "nemotron_h_nano_omni": _AudioVersions("0.6.10"),
    "qwen3_omni_moe": _AudioVersions("0.6.7"),
    "phi4mm": _AudioVersions("0.4.4"),
    "minicpmo": _AudioVersions("0.4.4"),
}

# Families probed only on a newer transformers than this package pins, at the
# version the probes ran on. Older releases expand their audio tokens
# differently, so they are refused rather than assumed compatible.
# Redundant now gemma4's floor is 0.6.2 (every mlx-vlm there needs
# transformers>=5.5.0), but kept for hand-assembled environments.
_AUDIO_MIN_TRANSFORMERS = {"gemma4": (5, 5), "gemma4_unified": (5, 5)}

_AUDIO_CAST_HINT = (
    "Cast the dataset column with "
    "datasets.Audio(sampling_rate=<processor rate>) so rows decode to samples "
    "at the rate the model's feature extractor expects."
)


def _audio_family_from_processor(processor):
    """Identify the audio model family behind a processor.

    Returns a lowercase family key drawn from the processor's defining module
    (mlx-vlm processors live in ``mlx_vlm.models.<family>.processing_<family>``)
    with a class-name fallback for wrappers.
    """
    module = getattr(type(processor), "__module__", "") or ""
    for part in module.lower().split("."):
        if part.startswith("processing_"):
            return part[len("processing_"):]
    parts = module.lower().split(".")
    if "models" in parts:
        index = parts.index("models")
        if index + 1 < len(parts):
            return parts[index + 1]
    name = getattr(type(processor), "__name__", "") or ""
    return name.lower().replace("processor", "").strip("_")


@lru_cache(maxsize=1)
def _installed_mlx_vlm_version():
    try:
        from importlib.metadata import version

        return str(version("mlx-vlm"))
    except Exception:
        try:
            import mlx_vlm

            return str(getattr(mlx_vlm, "__version__", "") or "")
        except Exception:
            return ""


def _check_audio_transformers_floor(family):
    """Refuse a family probed only on a newer transformers than is installed."""
    floor = _AUDIO_MIN_TRANSFORMERS.get(family)
    if not floor:
        return
    try:
        import transformers

        version = transformers.__version__
        # PEP 440, not int(split(".")), which raised on "5.5rc1" or a v-prefixed
        # tag. Compared whole, not by `.release`: that reads 5.5rc1 as 5.5, and
        # PEP 440 sorts the prerelease below 5.5.0.
        found = _Version(version)
    except Exception:
        raise NotImplementedError(
            f"Unsloth MLX: audio training for '{family}' requires transformers "
            f"{floor[0]}.{floor[1]} or newer, and the installed version could "
            f"not be determined."
        ) from None
    if found < _Version(f"{floor[0]}.{floor[1]}"):
        raise NotImplementedError(
            f"Unsloth MLX: audio training for '{family}' was verified on "
            f"transformers {floor[0]}.{floor[1]}, but {version} is installed; "
            f"older releases handle its audio token expansion differently. "
            f"Upgrade transformers to train on audio with this model."
        )


# Gemma 4's audio encoder subsamples time through two stride-2, kernel-3 conv
# blocks (SubSampleConvProjection), each padding one frame on either side.
_GEMMA4_AUDIO_SUBSAMPLE_BLOCKS = 2


def _gemma4_audio_frame_mask(extractor, waveform, sampling_rate):
    """The mel frames one clip fills, extracted on its own.

    Alone is the only way to ask: mlx-vlm pads waveforms to the longest in the
    batch before framing, and 0.4.4 derives the mask by subsampling a
    sample-level one, so a shorter clip's valid count moves with whatever else
    it is batched against.
    """
    features = extractor(
        [np.asarray(waveform, dtype=np.float32)],
        sampling_rate=sampling_rate,
        return_attention_mask=True,
    )
    if "input_features_mask" in features:
        return np.asarray(features["input_features_mask"])[0].astype(bool)
    # An extractor that reports no mask leaves the encoder without one too, and
    # Gemma 4 then treats every frame as real audio.
    return np.ones(
        int(np.asarray(features["input_features"]).shape[-2]), dtype=bool,
    )


def _gemma4_audio_encoder_positions(frames):
    for _ in range(_GEMMA4_AUDIO_SUBSAMPLE_BLOCKS):
        kept = (len(frames) + 2 - 3) // 2 + 1
        frames = frames[::2][:kept]
    return int(frames.sum())


def _gemma4_audio_placeholder_count(processor, waveform, sampling_rate):
    """How many audio placeholders one Gemma 4 clip needs.

    Must equal the number of positions the audio tower emits, or the merge has
    nothing to put behind the surplus placeholder. mlx-vlm's processor instead
    counts ``ceil(duration / 40 ms)``: 40 ms is only the nominal frame period,
    so the count runs one over whenever a duration lands near a frame boundary
    (3 of 10 real LibriSpeech utterances).

    The frames are read off the installed extractor rather than recomputed from
    a copy of its framing arithmetic, because that arithmetic changed inside the
    supported span -- mlx-vlm added the reference's semicausal left-pad in
    0.5.0, and a formula assuming it predicts a frame 0.4.4 never produces. The
    extractor's own truncation applies for the same reason: the count has to
    follow the audio the tower is actually given.
    """
    extractor = getattr(processor, "feature_extractor", None)
    if extractor is None:
        raise NotImplementedError(
            f"Unsloth MLX: {type(processor).__name__} has no audio feature "
            f"extractor, so the number of audio placeholders a clip needs "
            f"cannot be determined."
        )
    return _gemma4_audio_encoder_positions(
        _gemma4_audio_frame_mask(extractor, waveform, sampling_rate),
    )


def _trim_gemma4_audio_batch_mask(inputs, clips, processor):
    """Mask each clip to the frames its own audio fills.

    Batch padding otherwise leaves a shorter clip holding frames that are
    entirely silence, which the encoder reports as valid positions and the model
    trains on as speech. Restoring each clip's own mask also puts the valid
    count back in step with the placeholder run written for it.
    """
    extractor = getattr(processor, "feature_extractor", None)
    features = inputs.get("input_features")
    if extractor is None or features is None:
        return inputs
    mask = inputs.get("input_features_mask")
    # An extractor that reports no mask leaves every padded frame looking real,
    # so the batch needs one written for it rather than left out.
    shape = np.asarray(features).shape[:2]
    if mask is not None and np.asarray(mask).shape != shape:
        # Nothing downstream compares these two, and a mask short of its
        # features broadcasts over the rows it does not cover.
        raise ValueError(
            f"Unsloth MLX: {type(processor).__name__} returned an audio mask "
            f"of shape {tuple(np.asarray(mask).shape)} for features of shape "
            f"{tuple(np.asarray(features).shape)}, so audio positions cannot "
            f"be paired with their clips."
        )
    if shape[0] != len(clips):
        # The feature-count check reports this; repairing part of the batch
        # would hide it behind a plausible-looking mask.
        return inputs
    if len(clips) < 2:
        # One clip is extracted the way it will be used, so nothing was padded
        # against a neighbour and its mask already covers only its own audio.
        return inputs
    trimmed = np.zeros(shape, dtype=bool)
    default_rate = audio_extractor_sampling_rate(processor)
    for row, clip in enumerate(clips[:shape[0]]):
        waveform, rate = clip if isinstance(clip, tuple) else (clip, None)
        solo = _gemma4_audio_frame_mask(
            extractor, waveform,
            rate or getattr(clip, "sampling_rate", None) or default_rate,
        )
        keep = min(len(solo), shape[1])
        trimmed[row, :keep] = solo[:keep]
    inputs["input_features_mask"] = (
        trimmed if mask is None else trimmed.astype(np.asarray(mask).dtype)
    )
    return inputs


def _repair_gemma4_audio_processor(processor):
    if not callable(getattr(processor, "_compute_audio_num_tokens", None)):
        raise NotImplementedError(
            f"Unsloth MLX: {type(processor).__name__} does not expose "
            f"_compute_audio_num_tokens, so its audio placeholder count cannot "
            f"be matched to the model's audio encoder. This mlx-vlm release is "
            f"not usable for Gemma 4 audio training."
        )
    # Bound on the instance, not the class: a class-level patch would follow the
    # processor type into every other use of it in this process. Unlike
    # __call__, this one is reached through the instance dict.
    processor._compute_audio_num_tokens = partial(
        _gemma4_audio_placeholder_count, processor,
    )


_AUDIO_PROCESSOR_REPAIRS = {"gemma4": _repair_gemma4_audio_processor}

_AUDIO_BATCH_MASK_REPAIRS = {"gemma4": _trim_gemma4_audio_batch_mask}

_AUDIO_NO_OWN_HOOK = object()


def _audio_count_corrected(processor):
    hook = getattr(processor, "_compute_audio_num_tokens", None)
    return (isinstance(hook, partial)
            and hook.func is _gemma4_audio_placeholder_count)


def _audio_repaired_processor(processor):
    """A processor counting audio placeholders the way its encoder does.

    A copy, because the correction has a second half -- the batch mask -- that
    can only be applied where the collated batch is held. Correcting the shared
    processor in place would hand the count alone to anything else using it,
    including a concurrent collation's own model call, and a corrected count
    meeting an uncorrected mask misaligns a batch that lined up before.
    Components are shared by reference, so the copy costs a dict.
    """
    repair = _AUDIO_PROCESSOR_REPAIRS.get(
        _audio_family_from_processor(processor),
    )
    if repair is None:
        return processor
    corrected = copy.copy(processor)
    # Only an instance-level hook is ours to put back; pinning an inherited one
    # would leave a copy of it shadowing the class's own.
    state = getattr(processor, "__dict__", None) or {}
    own_hook = state.get("_compute_audio_num_tokens", _AUDIO_NO_OWN_HOOK)
    repair(corrected)
    if _audio_count_corrected(processor):
        # The copy shares state with the processor this run was handed, so the
        # correction reached it too. Half of it -- the batch mask -- can only
        # be applied to a batch collated here, and the count alone misaligns a
        # batch that lined up before, so put back what was there and refuse.
        if own_hook is _AUDIO_NO_OWN_HOOK:
            del corrected._compute_audio_num_tokens
        else:
            corrected._compute_audio_num_tokens = own_hook
        raise NotImplementedError(
            f"Unsloth MLX: copying {type(processor).__name__} does not give an "
            f"independent object, so its audio placeholder count cannot be "
            f"corrected without changing the processor this run was handed."
        )
    return corrected


def _repair_audio_batch(inputs, clips, processor):
    repair = _AUDIO_BATCH_MASK_REPAIRS.get(
        _audio_family_from_processor(processor),
    )
    # Only on the processor whose count was corrected: the two describe one
    # contract, so applying either alone puts them back out of step.
    if not clips or repair is None or not _audio_count_corrected(processor):
        return inputs
    return repair(inputs, clips, processor)


def _check_audio_family_gate(processor):
    """Refuse audio rows for families/versions without a verified contract."""
    family = _audio_family_from_processor(processor)
    probed = _AUDIO_QUALIFIED_FAMILIES.get(family)
    installed = _installed_mlx_vlm_version()
    if probed and probed.admits(installed):
        _check_audio_transformers_floor(family)
        return family
    if not _AUDIO_QUALIFIED_FAMILIES:
        raise NotImplementedError(
            f"Unsloth MLX: audio inputs were found in this dataset, but audio "
            f"training is not enabled for any model family yet (this row uses "
            f"'{family}'). Remove the audio content to train on the text and "
            f"image parts of this dataset."
        )
    supported = ", ".join(
        f"{name} (mlx-vlm {versions})"
        for name, versions in sorted(_AUDIO_QUALIFIED_FAMILIES.items())
    )
    if probed:
        raise NotImplementedError(
            f"Unsloth MLX: audio training for '{family}' has only been verified "
            f"on mlx-vlm {probed}, but mlx-vlm "
            f"{installed or 'unknown'} is installed. Pin a verified version to "
            f"train on audio. Verified: {supported}."
        )
    raise NotImplementedError(
        f"Unsloth MLX: audio training is not supported for '{family}'. "
        f"Verified families: {supported}."
    )


def audio_extractor_sampling_rate(processor):
    """The sampling rate this processor's audio feature extractor expects."""
    for holder in (
        getattr(processor, "feature_extractor", None),
        # Some name their audio extractor separately, and only it knows the rate.
        getattr(processor, "audio_processor", None),
        processor,
    ):
        rate = getattr(holder, "sampling_rate", None)
        if rate is None and holder is processor:
            rate = getattr(processor, "audio_sampling_rate", None)
        if rate:
            try:
                return int(rate)
            except (TypeError, ValueError):
                continue
    return None


class AudioInputCapability(NamedTuple):
    """Whether a loaded checkpoint can take audio input.

    ``processor_ok`` and ``model_ok`` are the two halves, each ``True``,
    ``False``, or ``None`` when it was not evaluated. ``capable`` requires both
    to be ``True``, so a call without a model can refute a checkpoint but never
    affirm one. ``reason`` names what was observed.
    """

    capable: bool
    reason: str
    processor_ok: "bool | None"
    model_ok: "bool | None"


# Two pitches two octaves apart, long enough for any pinned extractor's
# framing and short enough that four calls cost a moment.
_AUDIO_PROBE_TONES = (440.0, 1760.0)
_AUDIO_PROBE_SECONDS = 0.2
_AUDIO_PROBE_RATE = 16000
# Marker-free by contract: which marker a processor needs is prompt-rendering
# knowledge, so callers supply their own candidates through `texts`.
_AUDIO_PROBE_TEXT = "Describe the audio."


def _audio_probe_tone(rate, hertz):
    """A fresh mono tone. Fresh matters: a processor keying on buffer identity
    rather than sample values must not see the same object twice."""
    count = max(int(rate * _AUDIO_PROBE_SECONDS), 1)
    time = np.arange(count, dtype=np.float32) / float(rate)
    return (0.25 * np.sin(2.0 * np.pi * hertz * time)).astype(np.float32)


def _audio_probe_fingerprint(value):
    """A content fingerprint of a processor's output.

    Arrays enter by their bytes, so a field that echoes the call rather than the
    audio compares equal and cannot be mistaken for evidence.
    """
    if isinstance(value, Mapping):
        return tuple(
            (str(key), _audio_probe_fingerprint(value[key]))
            for key in sorted(value, key=str)
        )
    if isinstance(value, (list, tuple)):
        return tuple(_audio_probe_fingerprint(item) for item in value)
    if type(value) is _MX_ARRAY_TYPE:
        try:
            value = np.asarray(value)
        except Exception:
            # Only the dtypes numpy has no equivalent for, where float32 is
            # lossless. Casting everything would collapse large exact integers.
            value = np.asarray(value.astype(mx.float32))
    if isinstance(value, np.ndarray):
        if value.dtype == object:
            return ("object_array", value.shape, repr(value.tolist()))
        return ("array", value.shape, str(value.dtype), value.tobytes())
    if hasattr(value, "detach") and hasattr(value, "cpu"):
        return _audio_probe_fingerprint(np.asarray(value.detach().cpu()))
    return ("scalar", repr(value))


def _audio_probe_once(processor, text, kwarg, rate, hertz, held):
    clip = _AudioClip(_audio_probe_tone(rate, hertz), rate)
    # Held for the probe's lifetime so no later buffer can reuse its address.
    held.append(clip)
    payload = _format_vlm_audio_for_processor([[clip]], processor=processor)
    # Answering "not capable" from a payload-shape refusal would report a
    # working checkpoint as unusable.
    return _call_pairing_audio_on_refusal(
        lambda call_kwargs: processor(**call_kwargs),
        {"text": [text], kwarg: payload}, kwarg,
        lambda clips: _audio_payload_as_pairs([clip], processor),
    )


def _audio_probe_processor(processor, texts):
    """Whether audio content demonstrably reaches this processor's output.

    Per candidate text: a discarded warm-up call absorbs one-time state, then
    the same tone twice -- which must agree, or the processor cannot repeat
    itself and its outputs carry no evidence -- then a second tone, which must
    differ. Both tones share duration, dtype and construction, so sample values
    are the only input property that separates them: a processor that sizes its
    output from the clip length, echoes the call, or drops the audio entirely
    produces identical outputs and is refused.
    """
    try:
        kwarg = _vlm_processor_audio_kwarg(processor)
    except Exception:
        return False, "the processor accepts no audio argument"
    rate = audio_extractor_sampling_rate(processor) or _AUDIO_PROBE_RATE
    held = []
    raised = None
    for text in texts:
        try:
            _audio_probe_once(processor, text, kwarg, rate,
                              _AUDIO_PROBE_TONES[0], held)
        except Exception:
            pass  # a warm-up is discarded on any outcome, by design
        try:
            first = _audio_probe_fingerprint(
                _audio_probe_once(processor, text, kwarg, rate,
                                  _AUDIO_PROBE_TONES[0], held))
            again = _audio_probe_fingerprint(
                _audio_probe_once(processor, text, kwarg, rate,
                                  _AUDIO_PROBE_TONES[0], held))
            other = _audio_probe_fingerprint(
                _audio_probe_once(processor, text, kwarg, rate,
                                  _AUDIO_PROBE_TONES[1], held))
        except Exception as exc:
            raised = exc
            continue
        if first != again:
            raised = None
            continue  # not repeatable: its outputs prove nothing either way
        if first != other:
            return True, "audio content changed the processor output"
    if raised is not None:
        return False, f"the processor raised on audio ({type(raised).__name__})"
    return False, (
        "the processor accepted audio and produced no audio-dependent output"
    )


def _model_carries_audio_modules(model):
    """Whether the loaded model has audio machinery, by name.

    A name walk rather than a fixed attribute list: the pinned families spell it
    ``audio_tower``, ``embed_audio``, ``audio_projection_layer``,
    ``audio_encoder`` and ``audio_projection``, and Phi-4 nests its pair under
    an intermediate submodule.
    """
    walk = getattr(model, "named_modules", None)
    if walk is None:
        return False
    for entry in walk():
        name = entry[0] if isinstance(entry, tuple) else entry
        lowered = str(name).lower()
        if (
            "audio" in lowered
            or lowered.startswith("sound_")
            or ".sound_" in lowered
        ):
            return True
    return False


def audio_input_capability(model, processor, texts=None):
    """Whether this loaded checkpoint can take audio input.

    Answered from observed behaviour, per checkpoint: audio content has to
    change what the processor returns, and the model has to carry audio
    modules. Two exports of one family can therefore disagree -- a processor
    whose checkpoint omits the audio half of its preprocessor configuration
    accepts the argument, drops the audio, and is refused here.

    ``texts`` supplies candidate prompts, as one string or a sequence; a
    processor that needs a marker only its own template emits will not answer
    positively without one, and which marker that is belongs to whoever renders
    prompts, not here. The built-in candidate carries none.

    Never raises: anything unevaluable answers not capable, so this cannot fail
    a model load. A positive says audio reaches the processor's output and the
    model has somewhere to put it -- not that features merge correctly, which
    the per-batch checks continue to guard.
    """
    processor_ok = model_ok = None
    try:
        if isinstance(texts, str):
            texts = [texts]
        candidates = [*(texts or ()), _AUDIO_PROBE_TEXT]
        processor_ok, reason = _audio_probe_processor(processor, candidates)
        if model is None:
            return AudioInputCapability(False, reason, processor_ok, None)
        model_ok = _model_carries_audio_modules(model)
        if not model_ok:
            reason = "the model carries no audio modules"
        return AudioInputCapability(
            bool(processor_ok and model_ok), reason, processor_ok, model_ok,
        )
    except BaseException as exc:  # totality: a load must never fail on this
        return AudioInputCapability(
            False, f"the capability check could not run ({type(exc).__name__})",
            processor_ok, model_ok,
        )


class _AudioClip(np.ndarray):
    """A mono waveform that remembers the rate it was decoded at.

    Processors normally take bare waveforms, but some want
    ``(samples, sampling_rate)`` pairs and do not expose a rate of their own, so
    the value verified during extraction has to travel with the samples.

    The rate survives views, slicing and copies, which is all collation does to
    a clip. It does not survive concatenation, stacking, ``np.asarray`` or
    pickling; anything that grows such a step must pass the rate explicitly
    rather than expect it to ride along.
    """

    def __new__(cls, samples, sampling_rate):
        obj = np.asarray(samples, dtype=np.float32).view(cls)
        obj.sampling_rate = int(sampling_rate)
        return obj

    def __array_finalize__(self, obj):
        if obj is not None:
            self.sampling_rate = getattr(obj, "sampling_rate", None)


def _audio_samples_to_mono(samples, *, channel_first):
    """Reduce decoded samples to a 1-D mono waveform.

    ``channel_first`` records the source's documented layout rather than
    guessing from extents: torchcodec returns ``(channels, samples)``, and a
    short clip can legitimately have more channels than samples.
    """
    array = np.asarray(samples)
    if array.ndim == 1:
        return array
    if array.ndim == 2 and channel_first:
        # Mirrors the datasets mono accessor.
        return array.mean(axis=0)
    raise ValueError(
        f"Unsloth MLX: expected a mono waveform, got an array of shape "
        f"{array.shape}. Provide single-channel audio, or let "
        f"datasets.Audio decode the column so channels are handled for you."
    )


def _normalize_audio_clip(clip, expected_rate):
    """Coerce one dataset audio value into a mono waveform at ``expected_rate``.

    Accepts decoded ``{"array", "sampling_rate"}`` mappings (datasets 3.x) and
    decoder objects exposing ``get_all_samples()`` (datasets 4.x). Every form
    must carry its own sampling rate: without one the waveform's duration is
    unknowable, and feeding it to an extractor expecting another rate silently
    changes the features (and, for families whose placeholder budget follows
    clip duration, the number of placeholders too).
    Undecoded values -- ``{"path", "bytes"}`` mappings and bare paths or URLs --
    are refused, since decoding them needs an audio backend this package does
    not depend on and casting the column solves it at the dataset layer.
    """
    if isinstance(clip, (str, os.PathLike)):
        raise ValueError(
            f"Unsloth MLX: audio file paths are not decoded during training. "
            f"{_AUDIO_CAST_HINT}"
        )
    if hasattr(clip, "get_all_samples"):
        # datasets 4.x: rate is fixed at construction, so read once and verify.
        decoded = clip.get_all_samples()
        samples = _audio_samples_to_mono(
            getattr(decoded, "data", decoded), channel_first=True,
        )
        rate = getattr(decoded, "sample_rate", None)
    elif isinstance(clip, dict):
        if clip.get("array") is not None:
            samples = _audio_samples_to_mono(clip["array"], channel_first=False)
            rate = clip.get("sampling_rate")
        elif "path" in clip or "bytes" in clip:
            raise ValueError(
                f"Unsloth MLX: this audio column is undecoded (it carries "
                f"'path'/'bytes'). {_AUDIO_CAST_HINT}"
            )
        else:
            raise ValueError(
                f"Unsloth MLX: unrecognized audio value; expected decoded "
                f"samples with a sampling rate. {_AUDIO_CAST_HINT}"
            )
    else:
        raise ValueError(
            f"Unsloth MLX: audio values must carry their sampling rate, so a "
            f"bare {type(clip).__name__} cannot be used. {_AUDIO_CAST_HINT}"
        )

    if rate is None:
        raise ValueError(
            f"Unsloth MLX: this audio value has no sampling rate. "
            f"{_AUDIO_CAST_HINT}"
        )
    if expected_rate is not None and int(rate) != expected_rate:
        raise ValueError(
            f"Unsloth MLX: audio is sampled at {int(rate)} Hz but this model's "
            f"feature extractor expects {expected_rate} Hz, and resampling is "
            f"not performed during training. {_AUDIO_CAST_HINT}"
        )
    return _AudioClip(np.asarray(samples, dtype=np.float32), int(rate))


def _vlm_audio_part_state(messages):
    bare_placeholders = False
    payloads = []
    if not isinstance(messages, list):
        return bare_placeholders, payloads
    for message in messages:
        if not isinstance(message, dict):
            continue
        content = message.get("content", "")
        if not isinstance(content, list):
            continue
        for part in content:
            if not isinstance(part, dict):
                continue
            # Key-only `{"audio": clip}` too: the template renders a
            # placeholder for it, so skipping it left the row a waveform short.
            if part.get("type") not in _AUDIO_PART_TYPES and not any(
                key in part for key in _AUDIO_PART_TYPES
            ):
                continue
            payload = None
            for key in _AUDIO_PART_TYPES:
                if part.get(key) is not None:
                    payload = part[key]
                    break
            if payload is None:
                bare_placeholders = True
            else:
                payloads.append(payload)
    return bare_placeholders, payloads


def _raw_row_has_audio(item):
    """Best-effort audio detection on an unvalidated row.

    Runs before a formatting function rewrites the row, so the family gate sees
    the data the user actually supplied. Shapes it cannot parse are reported as
    audio-free and left to the normal collation errors.
    """
    if isinstance(item, list):
        # A bare message list is a supported row shape -- _collate_vlm_batch
        # normalizes one -- so it has to be scanned here too, or a formatter
        # that drops its clips leaves the gate nothing to refuse.
        try:
            return any(_vlm_audio_part_state(_normalize_vlm_messages(item)))
        except Exception:
            return False
    if not isinstance(item, dict):
        return False
    if "role" in item and "content" in item:
        # A single message is a supported row shape too -- `_normalize_mlx_
        # messages` wraps one as `[item]`. Scanned here because the lookups
        # below read a row, and `_select_vlm_messages_or_raw` hands such a row
        # straight back, where the identity guard drops it unscanned.
        try:
            if any(_vlm_audio_part_state(_normalize_vlm_messages(item))):
                return True
        except Exception:
            return False
    for key in ("audio", "audios"):
        value = item.get(key)
        if value is not None and (not isinstance(value, list) or value):
            return True
    try:
        for candidate in (item.get("prompt"), item.get("completion"),
                          _select_vlm_messages_or_raw(item)):
            if candidate is item or not isinstance(candidate, (list, dict)):
                continue
            messages = candidate if isinstance(candidate, list) else [candidate]
            if any(_vlm_audio_part_state(_normalize_vlm_messages(messages))):
                return True
    except Exception:
        return False
    return False


def _format_vlm_row_gating_audio(row, formatting_func, processor):
    """Format one row, gating audio a formatter would otherwise hide.

    Callers that format here go on to collate with no formatter, so the
    collation gate would have nothing left to refuse.
    """
    if formatting_func is None:
        return row
    if _raw_row_has_audio(row):
        _check_audio_family_gate(processor)
    return formatting_func(row)


def _extract_vlm_audio(item, messages, processor):
    """Collect this row's audio clips as mono waveforms at the model's rate.

    Sources, in order: embedded message audio parts, then top-level ``audio`` /
    ``audios`` columns. Rows carrying audio are gated to verified families
    before any decoding work happens.
    """
    bare_placeholders, payloads = _vlm_audio_part_state(messages)
    column = []
    if isinstance(item, dict):
        for key in ("audio", "audios"):
            value = item.get(key)
            if value is None:
                continue
            candidate = value if isinstance(value, list) else [value]
            if candidate:
                # An empty column must not shadow a populated alias.
                column = candidate
                break
    if payloads and column:
        raise ValueError(
            "Unsloth MLX: this row carries audio both inside its messages and "
            "in an 'audio'/'audios' column. Keep one source so clips pair with "
            "their placeholders unambiguously."
        )
    if payloads and bare_placeholders:
        raise ValueError(
            "Unsloth MLX: this row mixes audio placeholders that carry a clip "
            "with placeholders that do not. Give every audio placeholder its "
            "own clip so features pair with the right positions."
        )
    clips = list(payloads) or column

    if not clips:
        if bare_placeholders:
            raise ValueError(
                "Unsloth MLX: this row has an audio placeholder but no audio "
                "data. Provide the clip in the message part or an 'audio' column."
            )
        return []

    _check_audio_family_gate(processor)
    expected_rate = audio_extractor_sampling_rate(processor)
    return [_normalize_audio_clip(clip, expected_rate) for clip in clips]


# Payload keys only: masks and size vectors can survive a dropped payload.
_AUDIO_FEATURE_PAYLOAD_KEYS = (
    "input_features", "input_audio_embeds", "audio_features", "sound_clips",
)

# Some image processors keep one tensor per image when aspect-ratio-dependent
# preprocessing produces different spatial shapes. Their vision tower consumes
# that ragged list directly; collapsing to value[0] silently drops later images.
_VLM_RAGGED_MEDIA_PAYLOAD_KEYS = (*_AUDIO_FEATURE_PAYLOAD_KEYS, "pixel_values")


def _assert_audio_features_present(inputs, expected, processor):
    """Fail when a row carried clips but the processor returned no audio tensors.

    A processor that accepts ``audio=`` and silently discards it would otherwise
    stage a placeholder run with nothing behind it, which trains the model on
    text while the placeholders resolve to whatever the merge invents. Masks and
    size vectors do not count: only the feature payload itself does, and it must
    carry one entry per clip so features and placeholder runs stay paired.
    """
    if not expected or not isinstance(inputs, Mapping):
        return
    for key in _AUDIO_FEATURE_PAYLOAD_KEYS:
        value = inputs.get(key)
        if value is None:
            continue
        shape = getattr(value, "shape", None)
        if shape is not None and all(int(dim) for dim in shape):
            found = int(shape[0])
        elif isinstance(value, (list, tuple)) and value:
            found = len(value)
        else:
            continue
        if found != expected:
            raise ValueError(
                f"Unsloth MLX: {type(processor).__name__} returned {found} "
                f"audio feature entr(ies) for {expected} clip(s), so features "
                f"and placeholder runs cannot be paired."
            )
        return
    raise ValueError(
        f"Unsloth MLX: {type(processor).__name__} returned no audio features "
        f"for a batch whose text carries audio placeholders, so those "
        f"placeholders have nothing behind them. The cause is upstream of this "
        f"check -- for instance the checkpoint ships no audio feature extractor "
        f"(look for an audio section in its preprocessor configuration), or a "
        f"placeholder was rendered for a clip the processor never received. "
        f"Otherwise train on the text and image parts of this dataset."
    )


def _image_bounds_per_row(inputs):
    """Per-row image placeholder spans, when the processor states them.

    MiniCPM-V and MiniCPM-o report ``image_bound`` as absolute columns into the
    layout they padded, offsetting it by each row's leading pad count. The
    values are coordinates like ``audio_bounds``, not labels that travel with a
    row, so a repair that moves the tokens invalidates them the same way.
    """
    bounds = inputs.get("image_bound") if isinstance(inputs, Mapping) else None
    if bounds is None:
        return None
    rows = []
    for row in bounds:
        spans = np.asarray(row).reshape(-1, 2) if np.size(row) else np.empty((0, 2))
        rows.append([(int(start), int(end)) for start, end in spans])
    return rows


def _audio_bounds_per_row(inputs):
    """Per-row ``(start, end)`` audio spans, when the processor states them.

    Counting runs of a soft token only verifies alignment when that token means
    "audio". MiniCPM-o repeats ``<unk>`` between its delimiters, which a real
    unknown word in the transcript is indistinguishable from, so its runs carry
    no alignment evidence at all. Processors in that shape report the spans
    themselves, which is a better starting point than counting runs, though not
    a trustworthy one: see ``_assert_audio_bounds_intact`` for how a reported
    span can still be wrong.
    """
    bounds = inputs.get("audio_bounds") if isinstance(inputs, Mapping) else None
    if bounds is None:
        return None
    rows = []
    for row in bounds:
        spans = np.asarray(row).reshape(-1, 2) if np.size(row) else np.empty((0, 2))
        rows.append([(int(start), int(end)) for start, end in spans])
    return rows


def _audio_span_positions_np(inputs, shape):
    """Positions covered by stated audio spans, or None when there are none.

    These hold placeholder tokens, never text to predict, and they cannot be
    found by token id: the marker is not always an audio-specific token --
    MiniCPM-o repeats ``<unk>`` -- so an id-based rule either misses the run or
    masks real unknown words along with it.
    """
    bounds = _audio_bounds_per_row(inputs)
    if not bounds or len(shape) != 2:
        return None
    rows, width = int(shape[0]), int(shape[1])
    positions = np.zeros((rows, width), dtype=bool)
    # Every caller runs after the collation check, which has already refused
    # spans that fall outside their row.
    for row, spans in enumerate(bounds[:rows]):
        for start, end in spans:
            positions[row, int(start):int(end)] = True
    return positions if positions.any() else None


def _assert_audio_bounds_intact(rows, ids, attention_mask, audio_counts,
                                max_seq_length, processor):
    """Reject rows whose stated audio spans cannot be trusted.

    Read off the processor's own spans: one span per clip, each covering at
    least one position inside the row's real content so truncation cannot have
    clipped it, and each naming a placeholder run rather than ordinary text --
    one token repeated, the same token in every span of the batch.
    """
    ids_np = np.asarray(ids)
    if ids_np.ndim == 1:
        ids_np = ids_np.reshape(1, -1)
    if ids_np.ndim != 2:
        raise ValueError(
            f"Unsloth MLX: cannot verify audio alignment against input_ids of "
            f"shape {ids_np.shape}."
        )
    mask_np = None if attention_mask is None else np.asarray(attention_mask)
    if mask_np is not None and mask_np.ndim == 1:
        mask_np = mask_np.reshape(1, -1)
    width = int(ids_np.shape[1])
    if not (len(rows) == len(audio_counts) == int(ids_np.shape[0])):
        raise ValueError(
            f"Unsloth MLX: {type(processor).__name__} reported audio spans for "
            f"{len(rows)} row(s) against {len(audio_counts)} dataset row(s) and "
            f"{ids_np.shape[0]} tokenized row(s), so audio clips cannot be "
            f"paired with their rows."
        )
    total = 0
    marker = None
    for index, (spans, expected) in enumerate(zip(rows, audio_counts)):
        attended = (
            width if mask_np is None
            else int(mask_np[index].astype(bool).sum())
        )
        # Audio-bearing rows only, as in the run path: a stated-span family
        # reports bounds for every row, so an audio-free one would be capped too.
        if expected and max_seq_length and attended > int(max_seq_length):
            # Padding is not the row's own length, so this counts what the model
            # attends -- the same quantity the run check caps.
            raise ValueError(
                f"Unsloth MLX: row {index} is {attended} tokens but "
                f"max_seq_length={max_seq_length}; this processor did not apply "
                f"the truncation it was given, and some divert it to their audio "
                f"feature extractor instead."
            )
        if len(spans) != expected:
            raise ValueError(
                f"Unsloth MLX: row {index} carries {expected} audio clip(s) but "
                f"the processor reported {len(spans)} audio span(s). Every clip "
                f"needs exactly one placeholder in the rendered text, none may "
                f"be dropped by truncation, and no extra may be added."
            )
        for start, end in spans:
            if end <= start:
                raise ValueError(
                    f"Unsloth MLX: row {index} has an audio span ({start}, "
                    f"{end}) that does not run forwards, so its clip has no "
                    f"positions to occupy."
                )
            if start < 0 or end > width:
                raise ValueError(
                    f"Unsloth MLX: row {index} has an audio span ({start}, "
                    f"{end}) outside its {width} position(s), so the span names "
                    f"tokens the row does not have."
                )
            # Attended positions, not their count: a left-padded row holds its
            # content at the top of the range, so comparing against a total
            # rejects spans that are perfectly placed.
            if mask_np is not None and not mask_np[index][start:end].astype(bool).all():
                raise ValueError(
                    f"Unsloth MLX: row {index} has an audio span ({start}, "
                    f"{end}) covering padding, so its clip is not aligned with "
                    f"the tokens the model attends."
                )
            # These processors report spans by pairing the n-th opening
            # delimiter with the n-th closing one, so a delimiter that the
            # rendered text carries of its own shifts every later pair onto
            # ordinary tokens. The span still counts, fits and attends, and only
            # the run it names gives it away: a placeholder run is one token
            # repeated, and the same token in every span.
            run = np.unique(ids_np[index][start:end])
            if run.size != 1 or (marker is not None and run[0] != marker):
                raise ValueError(
                    f"Unsloth MLX: row {index} has an audio span ({start}, "
                    f"{end}) that does not name a placeholder run. The rendered "
                    f"text most likely carries an audio delimiter of its own, "
                    f"which shifts the positions the processor reports."
                )
            marker = run[0]
        total += len(spans)
    return total


def _extractor_window_samples(processor):
    extractor = getattr(processor, "audio_processor", None) or getattr(
        processor, "feature_extractor", None
    )
    samples = getattr(extractor, "n_samples", None)
    try:
        return int(samples) if samples is not None else None
    except (TypeError, ValueError):
        return None


def _audio_delimiter_strings(processor):
    tokenizer = _get_processor_tokenizer(processor)
    convert = getattr(tokenizer, "convert_ids_to_tokens", None)
    if convert is None:
        return ()
    found = []
    for attr in ("audio_start_id", "audio_end_id"):
        token_id = getattr(tokenizer, attr, None)
        if token_id is None:
            continue
        try:
            token = convert(int(token_id))
        except Exception:
            continue
        if isinstance(token, str) and token:
            found.append(token)
    return tuple(found)


def _assert_text_carries_no_audio_delimiters(texts, clips, processor):
    """Reject audio rows whose text already contains the run's delimiters.

    A processor that reports spans finds them by pairing the n-th opening
    delimiter with the n-th closing one, within a row. A delimiter the text
    brought itself is indistinguishable from a generated one, so it shifts the
    pairing onto ordinary tokens, and truncation can drop the generated span and
    leave the foreign one standing in for it. Nothing downstream can tell the
    two apart -- the foreign span attends, sits inside the content, holds a
    repeated marker, and can be any length, including exactly the right one --
    so the text is refused before the processor ever expands it. The pairing is
    per row, so a row carrying no clip has no pairing to disturb.
    """
    delimiters = _audio_delimiter_strings(processor)
    if not delimiters:
        return
    for index, (text, row) in enumerate(zip(texts or (), clips or ())):
        if not row or not isinstance(text, str):
            continue
        for delimiter in delimiters:
            if delimiter in text:
                raise ValueError(
                    f"Unsloth MLX: row {index} already contains {delimiter}, "
                    f"which {type(processor).__name__} generates around the "
                    f"audio it inserts and locates its clips by. Remove it and "
                    f"mark the audio the way the model's template does."
                )


def _assert_audio_clips_fit_the_extractor(clips, processor):
    """Reject clips the audio feature extractor would truncate.

    These processors size the placeholder run from the whole waveform while
    their extractor keeps a fixed window, so a longer clip asks for positions
    whose audio the model never receives: the merge stops at the shorter side
    and the tail keeps ordinary text embeddings, which no count, range or run
    check can see.

    Sizing the run from the waveform also leaves the count one or two above the
    embeddings on ordinary clips, because the two round their framing
    differently. That is upstream's own arithmetic, it happens with the whole
    clip present, and inference merges the same way, so it is not what this
    rejects -- only a clip whose audio is actually cut.
    """
    window = _extractor_window_samples(processor)
    if not window or not clips:
        return
    rate = audio_extractor_sampling_rate(processor)
    for index, row in enumerate(clips):
        for clip in row or ():
            length = int(np.asarray(clip).shape[0])
            if length <= window:
                continue
            seconds = f", {window / rate:.0f}s" if rate else ""
            raise ValueError(
                f"Unsloth MLX: row {index} carries a {length}-sample audio clip "
                f"but {type(processor).__name__} keeps only the first {window} "
                f"samples of one clip ({window}{seconds}), so the row asks for "
                f"more audio positions than the model can fill. Split the clip."
            )


def _assert_audio_runs_intact(inputs, audio_counts, processor, max_seq_length,
                              truncated=True, clips=None):
    """Reject rows whose audio placeholder runs did not survive tokenization.

    The processor expands each clip into a run of soft tokens whose length the
    model matches against its encoder output, so a run that vanished misaligns
    audio features against text positions. Two conditions are enforced per row:
    one surviving placeholder run per clip, and a length within
    ``max_seq_length`` (some processors divert the truncation arguments to their
    audio feature extractor and leave the text over the cap).

    A run that was *shortened* rather than dropped needs the family's
    post-subsampling token budget. Families that state a fixed count per clip
    before the model runs have each of their runs checked against it here.

    Processors that state their spans take a different route, since their run
    carries no identifying token. Those rows are held to the conditions in
    ``_assert_audio_bounds_intact`` instead of the two above, and additionally
    to one the run path has no equivalent of: a clip may not be longer than the
    window its feature extractor keeps.
    """
    ids = inputs.get("input_ids") if isinstance(inputs, Mapping) else None
    if ids is None:
        if not any(audio_counts):
            return
        raise ValueError(
            "Unsloth MLX: the processor returned no input_ids for a batch "
            "containing audio, so audio/text alignment cannot be verified."
        )
    bounds = _audio_bounds_per_row(inputs)
    if bounds is not None:
        # Stated spans beat inferred ones, so they are checked instead of the
        # runs rather than alongside them.
        total_runs = _assert_audio_bounds_intact(
            bounds, ids, inputs.get("attention_mask"), audio_counts,
            max_seq_length if truncated else None, processor,
        )
        _assert_audio_features_present(inputs, total_runs, processor)
        _assert_audio_clips_fit_the_extractor(clips, processor)
        return
    soft_ids = _get_vlm_audio_soft_token_ids(processor)
    if not soft_ids:
        if not any(audio_counts):
            return
        raise ValueError(
            f"Unsloth MLX: could not resolve the audio placeholder token for "
            f"{type(processor).__name__}, so audio/text alignment cannot be "
            f"verified. This model family is not usable for audio training."
        )
    total_runs = _assert_audio_runs_intact_ids(
        ids, inputs.get("attention_mask"), audio_counts, soft_ids,
        max_seq_length if truncated else None,
        budget=_audio_fixed_budget(processor),
    )
    # Placeholders with nothing behind them misalign the sequence however they
    # got there -- e.g. a formatter that kept the text but dropped the clip.
    _assert_audio_features_present(inputs, total_runs, processor)


def _assert_audio_runs_intact_ids(ids, attention_mask, audio_counts, soft_ids,
                                  max_seq_length, budget=None):
    """Run-integrity check over materialized ids (see the caller's contract).

    Returns the total number of surviving placeholder runs in the batch.
    """
    if not soft_ids:
        return 0
    total_runs = 0
    rows = np.asarray(ids)
    attention_mask = (
        np.asarray(attention_mask) if attention_mask is not None else None
    )
    if rows.ndim == 1:
        # Some processors emit a single unbatched row; verify it as one.
        rows = rows[None, :]
    if attention_mask is not None and attention_mask.ndim == 1:
        attention_mask = attention_mask[None, :]
    if rows.ndim != 2:
        raise ValueError(
            f"Unsloth MLX: cannot verify audio alignment against input_ids of "
            f"shape {rows.shape}."
        )
    if rows.shape[0] != len(audio_counts):
        raise ValueError(
            f"Unsloth MLX: the processor returned {rows.shape[0]} row(s) for "
            f"{len(audio_counts)} dataset row(s), so audio clips cannot be "
            f"matched to their rows."
        )
    soft_array = np.array(sorted(soft_ids), dtype=rows.dtype)
    attention = attention_mask
    for index, expected_clips in enumerate(audio_counts):
        if index >= rows.shape[0]:
            continue
        row = rows[index]
        valid = (
            attention[index] > 0 if attention is not None
            else np.ones(row.shape, dtype=bool)
        )
        is_soft = np.isin(row, soft_array) & valid
        begins = is_soft & ~np.concatenate(([False], is_soft[:-1]))
        starts = int(begins.sum())
        total_runs += starts
        if expected_clips and budget:
            # Fixed-budget families merge exactly `budget` per clip, so every
            # run must be that long. Checking the total instead lets a short
            # run hide behind a long one and pairs a clip with the wrong
            # positions.
            ends = is_soft & ~np.concatenate((is_soft[1:], [False]))
            lengths = (np.flatnonzero(ends) - np.flatnonzero(begins) + 1).tolist()
            if any(int(length) != budget for length in lengths):
                raise ValueError(
                    f"Unsloth MLX: row {index} has audio placeholder run(s) of "
                    f"length {[int(length) for length in lengths]} but this "
                    f"model merges {budget} per clip, so its audio cannot be "
                    f"aligned. Check whether the row was truncated, or whether "
                    f"its rendered text carries placeholder tokens of its own."
                )
        if expected_clips and starts != expected_clips:
            raise ValueError(
                f"Unsloth MLX: row {index} carries {expected_clips} audio "
                f"clip(s) but {starts} placeholder run(s) survived "
                f"tokenization. Every clip needs its own placeholder in the "
                f"rendered text, and none may be dropped by truncation."
            )
        # Only rows that carry audio, as the two checks above are: the cap is
        # here so a placeholder run is not cut unnoticed, and an audio-free row
        # has none to cut. An omni checkpoint resolves soft ids whether or not
        # the run uses audio, so without this a plain text or image batch wider
        # than the cap is refused -- which the shape planner states is normal.
        if max_seq_length is None or not expected_clips:
            continue
        if int(valid.sum()) > int(max_seq_length):
            # Some processors divert the truncation kwargs to their audio
            # extractor, leaving the text over the cap.
            raise ValueError(
                f"Unsloth MLX: row {index} is {int(valid.sum())} tokens but "
                f"max_seq_length={max_seq_length}; this processor did not apply "
                f"truncation, so an audio placeholder run could be cut later "
                f"without being detected. Use a shorter clip or raise "
                f"max_seq_length."
            )
    return total_runs


def _vlm_processor_prefers_nested_audio(processor):
    cls = processor.__class__
    marker = f"{getattr(cls, '__module__', '')}.{getattr(cls, '__name__', '')}".lower()
    # A flat list leaves these processors to guess which row owns which clip:
    # they count audio markers in the rendered text, which a chat template need
    # not emit, and hand every clip to row 0 when the count comes up short.
    return any(name in marker for name in ("minicpmo",))


def _call_pairing_audio_on_refusal(invoke, kwargs, audio_kwarg, to_pairs):
    """Call a processor, retrying once as ``(samples, rate)`` pairs.

    Some processors take their audio as pairs and refuse a bare waveform by
    failing to unpack it. The shape is not discoverable in advance, so it is
    corrected from the refusal. A processor that refuses the corrected payload
    too reports its own first refusal rather than the second one; a failure
    while building the pairs is raised as itself, since it says nothing about
    what the processor wanted.
    """
    try:
        return invoke(kwargs)
    except ValueError as error:
        clips = kwargs.get(audio_kwarg)
        if not clips or "unpack" not in str(error):
            raise
        retried = dict(kwargs)
        retried[audio_kwarg] = to_pairs(clips)
        try:
            return invoke(retried)
        except Exception:
            raise error from None


def _mlx_vlm_audio_rate(processor):
    """The rate mlx-vlm assumes this processor's audio is at.

    It resamples a decoded file to ``feature_extractor.sampling_rate`` and
    falls back to 16 kHz; an array it forwards untouched, so this is the rate
    the samples are expected to be at rather than one it enforced. Reading the
    rate from anywhere else risks labelling them with a rate the rest of
    mlx-vlm never assumed. An extractor that states ``None`` takes the same
    fallback, since a pair has to carry a number.
    """
    extractor = getattr(processor, "feature_extractor", None)
    return getattr(extractor, "sampling_rate", None) or 16000


def _audio_payload_as_pairs(clips, processor):
    """The ``(samples, rate)`` form processors that reject bare waveforms want.

    A clip carries the rate it was decoded at; the processor's own extractor
    rate stands in for anything that does not.

    The nested payload a processor like MiniCPM-o is handed keeps its shape: a
    row is a list of clips, not a clip, so pairing it whole would fuse a row
    into one 2-D "clip" carrying no rate -- or raise out of numpy when the
    row's clips differ in length, which reports a payload the processor never
    saw. Rows are paired clip by clip instead.
    """
    default_rate = audio_extractor_sampling_rate(processor)

    def _pair(clip):
        return (np.asarray(clip),
                getattr(clip, "sampling_rate", None) or default_rate)

    return [[_pair(clip) for clip in row] if isinstance(row, (list, tuple))
            else _pair(row)
            for row in clips]


def _format_vlm_audio_for_processor(all_audio, processor=None):
    """Group per-row clips the way this processor assigns them to rows."""
    if not all_audio or not any(all_audio):
        return None
    if processor is not None and _vlm_processor_prefers_nested_audio(processor):
        return [list(clips) if clips else [] for clips in all_audio]
    flattened = []
    for clips in all_audio:
        if clips:
            flattened.extend(clips)
    return flattened or None


def _vlm_processor_audio_kwarg(processor):
    try:
        parameters = inspect.signature(processor.__call__).parameters
    except (TypeError, ValueError):
        return "audio"
    if "audio" in parameters:
        return "audio"
    if "audios" in parameters:
        return "audios"
    if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in parameters.values()):
        return "audio"
    raise ValueError(
        f"Unsloth MLX: {type(processor).__name__} does not accept audio inputs, "
        f"but this dataset carries audio."
    )


def _flatten_vlm_images(all_images):
    flattened = []
    for images in all_images:
        if isinstance(images, (list, tuple)):
            flattened.extend(images)
        else:
            flattened.append(images)
    return flattened


def _nest_vlm_images_by_sample(all_images):
    nested = []
    for images in all_images:
        if images is None:
            nested.append([])
        elif isinstance(images, (list, tuple)):
            nested.append(list(images))
        else:
            nested.append([images])
    return nested


def _vlm_processor_prefers_nested_images(processor):
    cls = processor.__class__
    marker = f"{getattr(cls, '__module__', '')}.{getattr(cls, '__name__', '')}".lower()
    # These processors need images grouped per-prompt; others take a flat list.
    return any(
        name in marker
        for name in (
            "deepseek_vl",
            "falcon",
            "gemma3",
            "gemma3n",
            "idefics",
            "lfm2_vl",
            "minicpmo",
            "mistral",
            "mllama",
            "paligemma",
            "pixtral",
            "smolvlm",
        )
    )


def _format_vlm_images_for_processor(all_images, processor=None, image_layout=None):
    if not any(all_images):
        return None
    if image_layout == "nested":
        return _nest_vlm_images_by_sample(all_images)
    if image_layout == "flat":
        return _flatten_vlm_images(all_images)
    if processor is not None and _vlm_processor_prefers_nested_images(processor):
        return _nest_vlm_images_by_sample(all_images)
    return _flatten_vlm_images(all_images)


# Private key used to pass raw (pre-int32-narrowing) input_ids through
# the VLM batch dict to labels-free / response-mask paths. Stripped from
# model forward kwargs so the backbone never sees it.


# One array per row, and rows hold different clip and image counts. Stacking
# them raises, and the generic fallback below then keeps only the first row --
# which the model indexes per row, so every later row reads row 0's coordinates
# instead of its own. Converted row by row instead, so the ragged shape survives
# and the batch still describes itself to the planner.
_VLM_PER_ROW_MEDIA_KEYS = ("audio_bounds", "image_bound", "tgt_sizes")


def _to_mx_vlm_batch(inputs):
    batch = {}
    for key, value in inputs.items():
        if key == "sound_clips" and isinstance(value, (list, tuple)):
            # Nemotron's outer list is the clip axis. Stacking equal lengths
            # turns it into one 2-D clip, which its extractor downmixes.
            batch[key] = [
                x if isinstance(x, mx.array) else mx.array(np.asarray(x))
                for x in value
            ]
            continue
        if key in _VLM_PER_ROW_MEDIA_KEYS and isinstance(value, (list, tuple)):
            batch[key] = [mx.array(np.asarray(row)) for row in value]
            continue
        if isinstance(value, mx.array):
            batch[key] = value
        elif hasattr(value, "shape"):
            batch[key] = mx.array(value)
        elif isinstance(value, list) and len(value) > 0 and hasattr(value[0], "shape"):
            try:
                batch[key] = mx.stack([
                    mx.array(x) if not isinstance(x, mx.array) else x
                    for x in value
                ])
            except Exception:
                if key in _VLM_RAGGED_MEDIA_PAYLOAD_KEYS and len(value) > 1:
                    # Unequal media shapes do not stack, and dropping to value[0]
                    # would leave one payload behind ids, placeholder runs and
                    # labels for all of them. Keep every entry so model-specific
                    # eager paths can apply their own ragged handling.
                    batch[key] = [
                        x if isinstance(x, mx.array) else mx.array(np.asarray(x))
                        for x in value
                    ]
                else:
                    batch[key] = mx.array(value[0]) if not isinstance(value[0], mx.array) else value[0]
        else:
            batch[key] = value

    for key in ("input_ids", "attention_mask", "token_type_ids", "mm_token_type_ids"):
        if key in batch and not isinstance(batch[key], mx.array):
            batch[key] = mx.array(batch[key])
        if key in batch and len(batch[key].shape) == 1:
            batch[key] = batch[key].reshape((1, -1))

    if "input_ids" in batch:
        # Preserve raw input_ids under a private key BEFORE the int32 narrow
        # so labels-free / response-mask paths can derive labels from the
        # original processor output (wide invalid ids like uint32(2**32-100)
        # would otherwise wrap to -100 and be treated as ignore_index).
        if "labels" not in batch:
            batch[_RAW_INPUT_IDS_FOR_LABELS] = _normalize_cce_label_dtype(
                batch["input_ids"]
            )
        batch["input_ids"] = batch["input_ids"].astype(mx.int32)
    if "attention_mask" in batch:
        batch["attention_mask"] = batch["attention_mask"].astype(mx.int32)
    # Do NOT narrow labels to int32: runtime CCE validates the original
    # dtype before its own narrow. Unsigned dtypes still need widening to
    # int64 so the masking helpers can mx.where the signed -100 sentinel.
    if "labels" in batch:
        batch["labels"] = _normalize_cce_label_dtype(batch["labels"])
    if "token_type_ids" in batch:
        batch["token_type_ids"] = batch["token_type_ids"].astype(mx.int32)
    if "mm_token_type_ids" in batch:
        batch["mm_token_type_ids"] = batch["mm_token_type_ids"].astype(mx.int32)

    return batch


_PYTORCH_ONLY_PROCESSOR_OUTPUT = (
    "Only returning PyTorch tensors is currently supported."
)


def _convert_vlm_processor_output(value, return_tensors):
    """Convert PyTorch-only processor output without changing its containers."""

    import torch

    if isinstance(value, torch.Tensor):
        value = value.detach().cpu()
        return mx.array(value) if return_tensors == "mlx" else value.numpy()
    if isinstance(value, Mapping):
        converted = copy.copy(value)
        for key, item in value.items():
            converted[key] = _convert_vlm_processor_output(item, return_tensors)
        return converted
    if isinstance(value, list):
        return [_convert_vlm_processor_output(item, return_tensors) for item in value]
    if isinstance(value, tuple):
        converted = tuple(
            _convert_vlm_processor_output(item, return_tensors) for item in value
        )
        return (
            type(value)(*converted)
            if hasattr(value, "_fields")
            else type(value)(converted)
        )
    return value


def _call_vlm_processor(processor_call, args, kwargs):
    """Retry only the Transformers fast-processor PyTorch output contract."""

    return_tensors = kwargs.get("return_tensors")
    try:
        return processor_call(*args, **kwargs)
    except ValueError as error:
        if (
            return_tensors not in {"mlx", "np"}
            or str(error) != _PYTORCH_ONLY_PROCESSOR_OUTPUT
        ):
            raise

    retry_kwargs = dict(kwargs)
    retry_kwargs["return_tensors"] = "pt"
    output = processor_call(*args, **retry_kwargs)
    return _convert_vlm_processor_output(output, return_tensors)


_VLM_MM_TOKEN_TYPE_PROCESSOR_MARKERS = (
    "gemma3",
    "gemma4",
    "qwen3_vl",
    "qwen3_5",
)


def _effective_processor_call_owner(cls):
    """Return the first MRO class that supplies the active processor call.

    Keeping this lookup separate makes the distinction between inherited
    behavior and a subclass override explicit at the policy boundary.
    """

    return next(
        (
            candidate
            for candidate in getattr(cls, "__mro__", (cls,))
            if "__call__" in getattr(candidate, "__dict__", {})
        ),
        cls,
    )


def _processor_class_owns_gemma3n_token_types(cls):
    """Recognize the effective Gemma3n processor call across relocation.

    A subclass can live in a custom namespace, but an override can also replace
    the inherited call contract. Classify the first MRO class that actually
    supplies ``__call__`` so both cases keep their own behavior.
    """

    owner = _effective_processor_call_owner(cls)
    # Class names can be regenerated or reused by custom processors. Only the
    # module that supplies the effective call identifies the installed owner.
    module = str(getattr(owner, "__module__", "")).lower()
    # why: remote-code and single-file loads land the marker as a suffix
    # (`...selfcontained.processing_gemma3n`), never as its own path component.
    return "gemma3n" in module


def _vlm_processor_requests_mm_token_type_ids(processor):
    """Return whether the installed processor owns the multimodal type flag.

    Gemma3n builds token types itself and forwards unknown kwargs to its
    tokenizer. Follow the effective call owner for both negative and positive
    classification so relocated inheritance preserves the installed behavior,
    while a subclass override retains its own request contract.
    Concrete wrapper names never authorize or suppress the processor flag.
    """

    cls = processor.__class__
    owner = _effective_processor_call_owner(cls)
    module = str(getattr(owner, "__module__", "")).lower()
    if _processor_class_owns_gemma3n_token_types(cls):
        return False
    marker = f"{module}.{getattr(owner, '__name__', '')}".lower()
    return any(
        owner in marker
        for owner in _VLM_MM_TOKEN_TYPE_PROCESSOR_MARKERS
    )


def _mlx_vlm_process_inputs_adapter(original):
    """Negotiate mlx-vlm's processor boundary: the Transformers PyTorch-only
    output contract, and processors that take audio as (samples, rate) pairs."""

    if getattr(original, "_unsloth_pytorch_processor_output", False):
        return original

    @wraps(original)
    def patched(
        processor,
        prompts,
        images=None,
        audio=None,
        add_special_tokens=False,
        padding=True,
        padding_side="left",
        return_tensors="mlx",
        **kwargs,
    ):
        call_kwargs = dict(
            images=images,
            audio=audio,
            add_special_tokens=add_special_tokens,
            padding=padding,
            padding_side=padding_side,
            return_tensors=return_tensors,
            **kwargs,
        )
        # mlx-vlm sends bare waveforms and refuses tuples, so a processor
        # wanting pairs cannot be reached from the caller at all. The rate it
        # assumes is read only when reshaping, since reaching for it on every
        # request would touch attributes a non-audio processor need not have.
        def _as_pairs(clips):
            rate = _mlx_vlm_audio_rate(processor)
            return [(np.asarray(clip), rate) for clip in clips]

        return _call_pairing_audio_on_refusal(
            lambda kw: _call_vlm_processor(original, (processor, prompts), kw),
            call_kwargs, "audio", _as_pairs,
        )

    patched._unsloth_pytorch_processor_output = True
    return patched


def _drop_unsupported_processor_kwargs(processor, kwargs):
    """Remove keyword arguments this processor's ``__call__`` does not take.

    Processors disagree on which collation keywords they accept, and discovering
    that by exception does not compose: a processor rejecting two of them raises
    again inside the first retry. Filtering up front handles any number of them,
    and a processor whose signature absorbs ``**kwargs`` keeps everything (the
    per-keyword retries below still cover a signature that promises more than it
    honours).
    """
    try:
        params = inspect.signature(processor.__call__).parameters
    except (TypeError, ValueError):
        return kwargs
    if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()):
        return kwargs
    return {k: v for k, v in kwargs.items() if k in params}


def _processor_vlm_inputs(
    processor,
    texts,
    all_images,
    max_seq_length,
    suffixes=None,
    truncation=True,
    padding_side=None,
    all_audio=None,
):
    base_kwargs = dict(
        text=texts,
        padding=True,
        return_tensors="np",
        add_special_tokens=False,
    )
    base_kwargs = _drop_unsupported_processor_kwargs(processor, base_kwargs)
    audio = _format_vlm_audio_for_processor(all_audio, processor=processor)
    audio_kwarg = None
    if audio is not None:
        audio_kwarg = _vlm_processor_audio_kwarg(processor)
        base_kwargs[audio_kwarg] = audio
        # Everything below this line collates through the corrected copy; the
        # caller's processor stays as mlx-vlm made it.
        processor = _audio_repaired_processor(processor)
    if truncation:
        base_kwargs["truncation"] = True
        if max_seq_length is not None:
            base_kwargs["max_length"] = max_seq_length
        if audio is not None:
            # `max_length` is a token budget, but transformers' `_merge_kwargs`
            # fans a flat keyword out to *every* modality that declares it, and
            # `AudioKwargs` declares both `max_length` and `truncation`. So the
            # token cap reaches the audio feature extractor, which reads the
            # same number as a *sample* budget. Gemma 3n shows it plainly: a
            # one-second 16 kHz clip under `max_length=512` comes back as
            # `input_features` of shape (1, 0, 128) -- the waveform cut to 512
            # samples, 0.032s, which frames to nothing -- while `input_ids` is
            # untouched. Every clip longer than `max_seq_length` samples loses
            # its audio that way, which at any realistic cap is every clip.
            #
            # An empty `audio_kwargs` shields the audio modality alone: a
            # modality that appears in kwargs stops reading flat keywords, so
            # the extractor no longer sees the cap while the text path keeps
            # every flat keyword it has always had.
            #
            # Scoping the *text* side instead would take the same switch the
            # other way and silently drop `padding`, `add_special_tokens` and
            # `return_tensors` for the text modality, which returns ragged
            # lists and a doubled BOS. The shield has to go on the side that
            # should not be reading these keywords.
            base_kwargs.update(_drop_unsupported_processor_kwargs(
                processor, {"audio_kwargs": {}},
            ))
    if padding_side is not None:
        base_kwargs["padding_side"] = padding_side
    images = _format_vlm_images_for_processor(all_images, processor=processor)
    if images is not None:
        image_layouts = (
            ("nested", "flat")
            if _vlm_processor_prefers_nested_images(processor)
            else ("flat", "nested")
        )
    else:
        image_layouts = (None,)
    if suffixes is not None and any(suffix is not None for suffix in suffixes):
        base_kwargs["suffix"] = [suffix or "" for suffix in suffixes]
    if _vlm_processor_requests_mm_token_type_ids(processor):
        base_kwargs["return_mm_token_type_ids"] = True

    def _run_layouts():
        first_error = None
        for image_layout in image_layouts:
            proc_kwargs = dict(base_kwargs)
            if image_layout is not None:
                proc_kwargs["images"] = _format_vlm_images_for_processor(
                    all_images,
                    processor=processor,
                    image_layout=image_layout,
                )
            try:
                return _call_vlm_processor(processor, (), proc_kwargs)
            except TypeError as exc:
                if (
                    "audio_kwargs" in str(exc)
                    and "unexpected keyword argument" in str(exc)
                    and "audio_kwargs" in proc_kwargs
                ):
                    # Gemma 4 handles audio itself, then forwards remaining
                    # kwargs to its tokenizer. It therefore rejects the
                    # modality shield used by ProcessorMixin-based families;
                    # its feature extractor never sees the flat text cap.
                    proc_kwargs.pop("audio_kwargs")
                    try:
                        return _call_vlm_processor(processor, (), proc_kwargs)
                    except Exception as retry_exc:
                        if first_error is None:
                            first_error = retry_exc
                        if len(image_layouts) == 1:
                            raise
                        continue
                if (
                    "add_special_tokens" in str(exc)
                    # Bound twice, or not accepted: both mean drop and retry.
                    and ("multiple values" in str(exc)
                         or "unexpected keyword argument" in str(exc))
                    and "add_special_tokens" in proc_kwargs
                ):
                    proc_kwargs.pop("add_special_tokens", None)
                    try:
                        return _call_vlm_processor(processor, (), proc_kwargs)
                    except Exception as retry_exc:
                        if first_error is None:
                            first_error = retry_exc
                        if len(image_layouts) == 1:
                            raise
                        continue
                if "padding_side" in str(exc) and "padding_side" in proc_kwargs:
                    proc_kwargs.pop("padding_side", None)
                    try:
                        return _call_vlm_processor(processor, (), proc_kwargs)
                    except Exception as retry_exc:
                        if first_error is None:
                            first_error = retry_exc
                        if len(image_layouts) == 1:
                            raise
                        continue
                if first_error is None:
                    first_error = exc
                if len(image_layouts) == 1:
                    raise
            except Exception as exc:
                if first_error is None:
                    first_error = exc
                if len(image_layouts) == 1:
                    raise
        raise first_error

    if audio_kwarg is None:
        return _run_layouts()

    def _run_audio_layouts():
        return _repair_audio_batch(
            _run_layouts(), base_kwargs[audio_kwarg], processor,
        )

    def _invoke(kwargs):
        base_kwargs[audio_kwarg] = kwargs[audio_kwarg]
        return _run_audio_layouts()

    return _call_pairing_audio_on_refusal(
        _invoke, {audio_kwarg: audio}, audio_kwarg,
        lambda clips: _audio_payload_as_pairs(clips, processor),
    )


def _as_numpy_vlm_field(inputs, key):
    """Return a processor output field as a 2-D numpy array."""
    value = inputs[key]
    arr = np.asarray(value)
    if arr.ndim == 1:
        arr = arr.reshape(1, -1)
    return arr


# Text-width-aligned arrays a processor authors for itself, beyond the ones the
# pipeline owns in `_VLM_WIDTH_PADDABLE_KEYS`. The deepseek pair place image
# embeddings at these indices.
_VLM_PROCESSOR_TOKEN_ALIGNED_KEYS = ("images_seq_mask",)

# Of those, the ones the compaction may move: inert at zero, which is what the
# gather writes into a vacated slot. That drops the label carriers, which the
# pipeline rebuilds from the repaired ids anyway; ids and mask move on their own.
_VLM_RELOCATABLE_SIDECAR_KEYS = tuple(
    key for key, inert in _VLM_WIDTH_PADDABLE_KEYS.items()
    if inert == 0 and key != "attention_mask"
) + _VLM_PROCESSOR_TOKEN_ALIGNED_KEYS


def _vlm_token_aligned_sidecars(inputs, ids_shape):
    """Return the processor fields whose columns are the token positions.

    Left at the pre-repair columns these mark the wrong tokens: gemma4 builds
    its bidirectional multimodal blocks from `mm_token_type_ids`, the deepseek
    pair place image embeddings at `images_seq_mask` indices. Named, not
    recognised by shape, since a shape does not say what indexes it -- an
    (images, 2) grid matches a two-token batch -- so an unlisted sidecar is left
    alone, as `_vlm_width_survey` also declines to guess.
    """
    sidecars = {}
    for key in _VLM_RELOCATABLE_SIDECAR_KEYS:
        if inputs.get(key) is None:
            continue
        values = _as_numpy_vlm_field(inputs, key)
        if values.shape == ids_shape:
            sidecars[key] = values
    return sidecars


def _right_pad_vlm_rows(inputs, processor):
    """Compact each row's real tokens to the front.

    Causality is all that excludes the pads once the mask is withheld, and it
    excludes a trailing pad, not a leading one. deepseek_vl_v2 and the falcon
    pair left-pad multimodal rows whatever side they are asked for, so the
    layout is repaired rather than demanded.
    """
    value = inputs.get("attention_mask") if hasattr(inputs, "get") else None
    if value is None:
        return inputs
    mask = _as_numpy_vlm_field(inputs, "attention_mask")
    # Content-then-padding, so an interior pad counts as much as a leading one.
    moved = np.any(mask[:, :-1] < mask[:, 1:], axis=1)
    if not moved.any():
        return inputs
    generated = [
        key for key in _VLM_WIDTH_GENERATED_KEYS if inputs.get(key) is not None
    ]
    if generated:
        # Coordinates of the layout the repair replaces, not labels that travel.
        raise ValueError(
            f"Unsloth MLX: {type(processor).__name__} left-padded this batch "
            f"and supplied its own {', '.join(generated)}, which cannot be "
            f"re-derived for the repaired row order."
        )
    bounds = _audio_bounds_per_row(inputs) or ()
    # Only the rows the repair actually moves lose their coordinates, so a row
    # that is already content-first keeps valid spans however its neighbours are
    # padded. Rows with no spans have nothing to invalidate.
    stale = [
        index for index, spans in enumerate(bounds)
        if spans and index < moved.shape[0] and bool(moved[index])
    ]
    if stale:
        # Stated spans are coordinates into the layout the repair replaces, and
        # nothing re-derives them: they would keep naming pre-repair positions
        # and put each clip's audio on whatever tokens moved there. Both ends of
        # a stale span can still be attended, so no later check would catch it.
        raise ValueError(
            f"Unsloth MLX: {type(processor).__name__} did not put row(s) "
            f"{stale} content-first despite being asked for right-padded rows, "
            f"and reports their audio positions as spans, which name the layout "
            f"the repair replaces."
        )
    # Same argument for image spans. `image_bound` is neither width-generated
    # nor token-aligned -- an (images, 2) grid is not the ids shape -- so the
    # sidecar relocation leaves it naming pre-repair columns, and the model
    # would scatter each image's features onto whatever tokens moved there.
    # Silent: the stale columns stay attended, so nothing downstream objects.
    image_stale = [
        index for index, spans in enumerate(_image_bounds_per_row(inputs) or ())
        if spans and index < moved.shape[0] and bool(moved[index])
    ]
    if image_stale:
        raise ValueError(
            f"Unsloth MLX: {type(processor).__name__} did not put row(s) "
            f"{image_stale} content-first despite being asked for right-padded "
            f"rows, and reports their image positions as spans, which name the "
            f"layout the repair replaces."
        )
    ids = _as_numpy_vlm_field(inputs, "input_ids")
    extras = _vlm_token_aligned_sidecars(inputs, ids.shape)
    ids, mask, extras = _flush_vlm_arrays_to_side(
        ids, mask, "right", _vlm_pad_token_id(processor, default=0), extras,
    )
    inputs["input_ids"] = ids
    inputs["attention_mask"] = mask
    for key, values in extras.items():
        inputs[key] = values
    return inputs


def _common_text_prefix(left, right):
    """Return CUDA's shared rendered prompt prefix for VLM PC rows."""
    end = 0
    for lhs, rhs in zip(left, right):
        if lhs != rhs:
            break
        end += 1
    return left[:end]


def _vlm_tokenizer_padding_side(processor):
    """Resolve the tokenizer padding side used by CUDA's VLM collator."""
    tokenizer = _get_processor_tokenizer(processor)
    side = getattr(tokenizer, "padding_side", "right")
    return "left" if side == "left" else "right"


def _vlm_pad_token_id(processor, default=None):
    """Return the processor tokenizer pad id, or ``default`` when it has none."""
    tokenizer = _get_processor_tokenizer(processor)
    pad_id = getattr(tokenizer, "pad_token_id", None)
    if pad_id is None:
        if default is not None:
            return default
        raise ValueError(
            "Tokenizer must define `pad_token_id` for prompt-completion collation."
        )
    return int(pad_id)


def _concat_vlm_token_type_ids(prompt_inputs, completion_inputs, p_ids, c_ids):
    """Concatenate token-type metadata the same way CUDA's collator does."""
    for key in ("token_type_ids", "mm_token_type_ids"):
        if key not in prompt_inputs and key not in completion_inputs:
            continue
        p_tt = (
            _as_numpy_vlm_field(prompt_inputs, key)
            if key in prompt_inputs else np.zeros_like(p_ids)
        )
        c_tt = (
            _as_numpy_vlm_field(completion_inputs, key)
            if key in completion_inputs else np.zeros_like(c_ids)
        )
        return key, np.concatenate((p_tt, c_tt), axis=1)
    return None, None


def _flush_vlm_arrays_to_side(input_ids, attention_mask, side, pad_id, extras):
    """Move non-pad VLM PC tokens to the tokenizer padding side."""
    keep = attention_mask.astype(bool)
    if keep.all():
        return input_ids, attention_mask, extras

    batch, seq_len = input_ids.shape
    counts = keep.sum(axis=1)
    ranks = np.cumsum(keep, axis=1) - 1
    if side == "left":
        dst = (seq_len - counts)[:, None] + ranks
    else:
        dst = ranks

    row_idx, col_src = np.nonzero(keep)
    col_dst = dst[row_idx, col_src].astype(np.int64)

    new_ids = np.full(input_ids.shape, pad_id, dtype=input_ids.dtype)
    new_mask = np.zeros(attention_mask.shape, dtype=attention_mask.dtype)
    new_ids[row_idx, col_dst] = input_ids[row_idx, col_src]
    new_mask[row_idx, col_dst] = 1

    new_extras = {}
    for key, values in extras.items():
        out = np.zeros(values.shape, dtype=values.dtype)
        out[row_idx, col_dst] = values[row_idx, col_src]
        new_extras[key] = out

    max_count = int(counts.max()) if counts.size else 0
    if 0 < max_count < seq_len:
        sl = slice(seq_len - max_count, seq_len) if side == "left" else slice(0, max_count)
        new_ids = new_ids[:, sl]
        new_mask = new_mask[:, sl]
        new_extras = {key: value[:, sl] for key, value in new_extras.items()}

    return new_ids, new_mask, new_extras


def _truncate_vlm_arrays_by_side(input_ids, attention_mask, side, max_seq_length, extras):
    """Truncate VLM PC arrays from the same side as CUDA."""
    if max_seq_length is None or max_seq_length <= 0 or input_ids.shape[1] <= max_seq_length:
        return input_ids, attention_mask, extras
    sl = slice(-max_seq_length, None) if side == "left" else slice(0, max_seq_length)
    return (
        input_ids[:, sl],
        attention_mask[:, sl],
        {key: value[:, sl] for key, value in extras.items()},
    )


def _collate_vlm_prompt_completion_batch(
    items,
    processor,
    max_seq_length,
    image_size,
    ignore_token_ids=None,
    completion_only_loss=None,
    reject_mlx_valued=False,
):
    prompt_texts = []
    completion_texts = []
    all_images = []
    all_audio = []

    for item in items:
        prompt_raw = item.get("prompt", "")
        completion_raw = item.get("completion", "")
        prompt = _normalize_vlm_messages(prompt_raw)
        completion = _normalize_vlm_messages(completion_raw)
        # Coerce a raw prompt to a chat message when the completion is chat-style so
        # both render through one template and split cleanly (avoids None + list).
        if isinstance(completion, list) and isinstance(prompt, str):
            prompt = [{"role": "user", "content": prompt}]
        prompt_messages = prompt if isinstance(prompt, list) else None
        completion_messages = completion if isinstance(completion, list) else None

        if prompt_messages is not None:
            prompt_text = _render_vlm_messages(
                processor,
                prompt_messages,
                add_generation_prompt=True,
            )
        else:
            prompt_text = str(prompt)

        if completion_messages is not None:
            combined = prompt_messages + completion_messages
            prompt_completion_text = _render_vlm_messages(processor, combined)
            images = _extract_vlm_pc_images(
                item, prompt_messages, completion_messages, image_size,
            )
            prompt_text = _common_text_prefix(
                prompt_text, prompt_completion_text,
            )
            completion_text = prompt_completion_text[len(prompt_text):]
        else:
            images = _extract_vlm_pc_images(
                item, prompt_messages, completion_messages, image_size,
            )
            completion_text = str(completion)

        prompt_texts.append(prompt_text)
        completion_texts.append(completion_text)
        all_images.append(images)
        # Audio conditions the response, so it belongs to the prompt half;
        # scanning the completion keeps a misplaced clip from passing the gate.
        if any(_vlm_audio_part_state(completion_messages or [])):
            raise ValueError(
                "Unsloth MLX: audio in the completion half is not supported; "
                "put the audio in the prompt so it conditions the response."
            )
        all_audio.append(
            _extract_vlm_audio(item, prompt_messages or [], processor)
        )

    prompt_inputs = _processor_vlm_inputs(
        processor,
        prompt_texts,
        all_images,
        max_seq_length,
        truncation=False,
        padding_side="left",
        all_audio=all_audio,
    )
    # Untruncated halves: only run presence is checkable until the combine.
    audio_counts = [len(clips) for clips in all_audio]
    if any(audio_counts) and _audio_bounds_per_row(prompt_inputs) is not None:
        # A stated span is an absolute coordinate into the half it was measured
        # on. The combine concatenates the halves and then flushes and truncates
        # the joined rows, either of which can carry the prompt's tokens away
        # from the positions its spans name and put the clip's audio on whatever
        # lands there. Refused for the whole format rather than relocated, and
        # for every row rather than the ones that would move: nothing here has
        # verified a relocation, and this is not the format the family was
        # qualified on.
        raise NotImplementedError(
            f"Unsloth MLX: {type(processor).__name__} reports audio positions as "
            f"spans, which prompt/completion collation can move the tokens out "
            f"from under. Use a single `text`/messages column for audio rows "
            f"with this model."
        )
    _assert_audio_runs_intact(
        prompt_inputs, audio_counts, processor, None, truncated=False,
    )
    audio_budget = _audio_fixed_budget(processor)
    audio_soft_ids = (
        _get_vlm_audio_soft_token_ids(processor) if any(audio_counts) else None
    )
    completion_inputs = _processor_vlm_inputs(
        processor,
        completion_texts,
        [[] for _ in completion_texts],
        max_seq_length,
        truncation=False,
        padding_side="right",
    )

    pc_host_valued = (
        _vlm_inputs_host_valued(prompt_inputs)
        and _vlm_inputs_host_valued(completion_inputs)
    )
    # Snapshot the tokenizer-derived collation scalars while this thread still
    # owns the processor: the carrier transports data, never the live processor.
    flush_side = _vlm_tokenizer_padding_side(processor)
    pad_id = _vlm_pad_token_id(processor)
    if not pc_host_valued and reject_mlx_valued:
        # Processor-owned MLX outputs: materialize their pending graphs here
        # (lazy arrays cannot cross threads) and defer combine + labels.
        _materialize_mlx_values(prompt_inputs, completion_inputs)
        return _HostStagedVLMBatch(
            None, None, host_valued=False,
            ignore_token_ids=ignore_token_ids,
            pc_opaque=(prompt_inputs, completion_inputs, flush_side, pad_id,
                       max_seq_length, completion_only_loss),
            pc_audio=(audio_counts, audio_soft_ids, audio_budget),
        )
    return _combine_vlm_prompt_completion_inputs(
        prompt_inputs, completion_inputs, flush_side, pad_id, max_seq_length,
        ignore_token_ids=ignore_token_ids,
        completion_only_loss=completion_only_loss,
        reject_mlx_valued=reject_mlx_valued,
        audio_counts=audio_counts, audio_soft_ids=audio_soft_ids,
        audio_budget=audio_budget,
    )


def _combine_vlm_prompt_completion_inputs(
    prompt_inputs,
    completion_inputs,
    flush_side,
    pad_id,
    max_seq_length,
    ignore_token_ids=None,
    completion_only_loss=None,
    reject_mlx_valued=False,
    audio_counts=None,
    audio_soft_ids=None,
    audio_budget=None,
):
    """Concatenate prompt/completion processor outputs into one staged batch.

    Runs on the collating thread for host-valued outputs, on the consumer thread
    (via ``pc_opaque``) for MLX-valued ones. Takes the tokenizer-derived
    collation scalars, never the processor itself.
    """
    pc_host_valued = (
        _vlm_inputs_host_valued(prompt_inputs)
        and _vlm_inputs_host_valued(completion_inputs)
    )
    p_ids = _as_numpy_vlm_field(prompt_inputs, "input_ids")
    c_ids = _as_numpy_vlm_field(completion_inputs, "input_ids")
    p_mask = _as_numpy_vlm_field(prompt_inputs, "attention_mask")
    c_mask = _as_numpy_vlm_field(completion_inputs, "attention_mask")
    input_ids = np.concatenate((p_ids, c_ids), axis=1)
    attention_mask = np.concatenate((p_mask, c_mask), axis=1)
    completion_mask = np.concatenate((np.zeros_like(p_mask), c_mask), axis=1)
    token_type_key, token_type_ids = _concat_vlm_token_type_ids(
        prompt_inputs, completion_inputs, p_ids, c_ids,
    )

    extras = {"completion_mask": completion_mask}
    if token_type_key is not None:
        extras[token_type_key] = token_type_ids

    input_ids, attention_mask, extras = _flush_vlm_arrays_to_side(
        input_ids, attention_mask, flush_side, pad_id, extras,
    )
    input_ids, attention_mask, extras = _truncate_vlm_arrays_by_side(
        input_ids, attention_mask, flush_side, max_seq_length, extras,
    )
    # Truncation keeps CUDA's side; the rows still have to arrive right-padded.
    input_ids, attention_mask, extras = _flush_vlm_arrays_to_side(
        input_ids, attention_mask, "right", pad_id, extras,
    )
    if audio_counts and any(audio_counts):
        # Flush + truncate is where a prompt-side run can actually be cut.
        # With the family's fixed budget, since a run cut short still leaves one
        # run per clip and only its length gives it away.
        _assert_audio_runs_intact_ids(
            input_ids, attention_mask, audio_counts, audio_soft_ids,
            max_seq_length, budget=audio_budget,
        )

    combined_inputs = dict(prompt_inputs)
    combined_inputs["input_ids"] = input_ids
    combined_inputs["attention_mask"] = attention_mask
    if token_type_key is not None:
        combined_inputs[token_type_key] = extras[token_type_key]
    completion_only_loss_enabled = (
        True if completion_only_loss is None else bool(completion_only_loss)
    )
    if pc_host_valued and _vlm_ids_integer_host(combined_inputs):
        label_mask = _stage_vlm_label_mask_np(
            combined_inputs, ignore_token_ids=ignore_token_ids,
        )
        if completion_only_loss_enabled:
            label_mask = label_mask | (
                np.asarray(extras["completion_mask"]) == 0
            )
        return _HostStagedVLMBatch(
            combined_inputs, label_mask, ignore_token_ids=ignore_token_ids,
            widen_labels_int64=completion_only_loss_enabled,
        )
    if reject_mlx_valued:
        # Non-stageable producer batches (float/exotic ids) must never reach
        # MLX conversion off the consumer thread.
        _reject_non_integer_host_vlm_ids("the processor")
    batch = _to_mx_vlm_batch(combined_inputs)
    batch["labels"] = _apply_vlm_label_masks(
        batch, ignore_token_ids=ignore_token_ids,
    )
    if completion_only_loss_enabled:
        legacy_np = np.asarray(batch["labels"].tolist(), dtype=np.int64)
        legacy_np[np.asarray(extras["completion_mask"]) == 0] = -100
        batch["labels"] = mx.array(legacy_np)
    return _HostStagedVLMBatch(
        None, None, host_valued=False,
        ignore_token_ids=ignore_token_ids, prefinalized=batch,
    )


def _collate_vlm_batch(items, processor, max_seq_length, image_size,
                       reject_mlx_valued=False,
                       formatting_func=None, ignore_token_ids=None,
                       completion_only_loss=None,
                       return_prompt_completion=False):
    """Collate a batch of VLM samples using the processor directly.

    Mirrors Unsloth's GPU UnslothVisionDataCollator: extract images, resize
    to uniform size, apply_chat_template, then one processor() call for
    tokenization + image processing + padding.
    """
    normalize_vlm_processor_chat_template(processor, strict=False)
    if reject_mlx_valued and any(_contains_mlx_values(item) for item in items):
        # Reject before formatting or the processor touches them off-thread.
        _reject_mlx_valued_vlm("the dataset row")
    if formatting_func is not None:
        # Gate the rows as supplied: a formatter must not hide audio.
        for item in items:
            if _raw_row_has_audio(item):
                _check_audio_family_gate(processor)
                break
    formatted_items = []
    for item in items:
        if formatting_func is not None:
            formatted = formatting_func(item)
            if reject_mlx_valued and _contains_mlx_values(formatted):
                # Formatters can introduce MLX values after the row scan.
                _reject_mlx_valued_vlm("the formatting function")
            item = formatted
        formatted_items.append(item)

    if (
        formatted_items
        and isinstance(formatted_items[0], dict)
        and "prompt" in formatted_items[0]
        and "completion" in formatted_items[0]
    ):
        batch = _collate_vlm_prompt_completion_batch(
            formatted_items, processor, max_seq_length, image_size,
            ignore_token_ids=ignore_token_ids,
            completion_only_loss=completion_only_loss,
            reject_mlx_valued=reject_mlx_valued,
        )
        return (batch, True) if return_prompt_completion else batch

    all_texts = []
    all_images = []
    all_audio = []
    all_suffixes = []

    for item in formatted_items:
        raw = _select_vlm_messages_or_raw(item)
        if raw is item:
            text = render_mlx_chat_example(processor, item, is_vlm=True)
            # A bare message list still carries media parts.
            messages = (
                _normalize_vlm_messages(item if isinstance(item, list) else [item])
                if isinstance(item, (list, dict)) else []
            )
        else:
            messages = _normalize_vlm_messages(raw)
            text = _render_vlm_messages(processor, messages)
        if not text:
            raise ValueError(
                "Unsloth MLX VLM: no text could be rendered for this dataset row. "
                "Provide messages/conversations, a text field, or a formatting_func."
            )
        images = _extract_vlm_images(item, messages, image_size)
        audio = _extract_vlm_audio(item, messages, processor)
        all_texts.append(text)
        all_images.append(images)
        all_audio.append(audio)
        all_suffixes.append(item.get("suffix") if isinstance(item, dict) else None)

    if any(all_audio):
        _assert_text_carries_no_audio_delimiters(all_texts, all_audio, processor)
    inputs = _right_pad_vlm_rows(
        _processor_vlm_inputs(
            processor, all_texts, all_images, max_seq_length,
            suffixes=all_suffixes,
            padding_side="right",
            all_audio=all_audio,
        ),
        processor,
    )
    audio_counts = [len(clips) for clips in all_audio]
    _assert_audio_runs_intact(inputs, audio_counts, processor, max_seq_length,
                              clips=all_audio)
    if _vlm_inputs_host_valued(inputs) and _vlm_ids_integer_host(inputs):
        label_mask = _stage_vlm_label_mask_np(
            inputs, ignore_token_ids=ignore_token_ids,
        )
        staged = _HostStagedVLMBatch(
            inputs, label_mask, ignore_token_ids=ignore_token_ids,
        )
    elif reject_mlx_valued and not _vlm_inputs_host_valued(inputs):
        # The processor itself emitted MLX arrays (mlx-vlm wrappers always do):
        # materialize its pending graphs here (lazy arrays cannot cross threads),
        # carry the payload through untouched, and decide labels at finalize.
        _materialize_mlx_values(inputs)
        staged = _HostStagedVLMBatch(
            inputs, None, host_valued=False,
            ignore_token_ids=ignore_token_ids,
        )
    elif reject_mlx_valued:
        # Host-valued non-integer ids: legacy conversion would run producer-side.
        _reject_non_integer_host_vlm_ids("the processor")
    else:
        # MLX-valued processor outputs: legacy synchronous label path, wrapped
        # so the finalizer stays the only exit to the trainer.
        batch = _to_mx_vlm_batch(inputs)
        batch["labels"] = _apply_vlm_label_masks(
            batch, ignore_token_ids=ignore_token_ids,
        )
        staged = _HostStagedVLMBatch(
            None, None, host_valued=False,
            ignore_token_ids=ignore_token_ids, prefinalized=batch,
        )
    return (staged, False) if return_prompt_completion else staged


def _apply_response_mask_to_vlm_batch(batch_dict, mask_fn, ignore_token_ids=None):
    """Apply response masking to a VLM batch dict, adding 'labels' key.

    Converts input_ids to plain lists, runs the masking closure from
    dataset_utils.train_on_responses_only with the current VLM labels, and
    stores the result as an mx.array in batch_dict["labels"].
    """
    # Prefer the raw (pre-int32-narrowing) input_ids so the masking closure
    # sees original processor ids; wide invalid ids like uint32(2**32-100)
    # would otherwise have already wrapped to -100 in batch_dict["input_ids"].
    raw_input_ids = batch_dict.pop(_RAW_INPUT_IDS_FOR_LABELS, None)
    input_ids = raw_input_ids if raw_input_ids is not None else batch_dict["input_ids"]
    ids_list = input_ids.tolist() if hasattr(input_ids, "tolist") else input_ids
    mask_batch = {"input_ids": ids_list}
    existing_labels = batch_dict.get("labels")
    if existing_labels is not None:
        labels_list = (
            existing_labels.tolist()
            if hasattr(existing_labels, "tolist") else existing_labels
        )
        mask_batch["labels"] = _normalize_numpy_cce_labels(labels_list)
    result = mask_fn(mask_batch)
    labels_list = result["labels"]
    if hasattr(labels_list, "tolist"):
        labels_list = labels_list.tolist()
    # Widen unsigned label dtypes (numpy + mx normalizers) so mx.where with
    # -100 does not crash on uint* and wide invalid ids reach runtime CCE
    # as sentinels instead of wrapping. Then apply image-token + attention
    # masking via the shared helper.
    labels_np = _normalize_numpy_cce_labels(labels_list)
    labels_array = _normalize_cce_label_dtype(mx.array(labels_np))
    batch_dict["labels"] = _apply_vlm_label_masks(
        batch_dict,
        labels=labels_array,
        ignore_token_ids=ignore_token_ids,
    )
    return batch_dict


def _vlm_trainable_label_rows(batch_dict):
    """Return per-row trainability from VLM labels after response masking."""
    if isinstance(batch_dict, _HostStagedVLMBatch):
        if batch_dict.prefinalized is not None:
            return _vlm_trainable_label_rows(batch_dict.prefinalized)
        mask = batch_dict.label_mask
        if mask is None:
            return None
        mask_np = mask if mask.ndim > 1 else mask.reshape(1, -1)
        return [bool(np.any(~row[1:])) for row in mask_np]
    labels = batch_dict.get("labels")
    if labels is None:
        return None
    labels_np = np.asarray(labels.tolist() if hasattr(labels, "tolist") else labels)
    if labels_np.ndim == 1:
        labels_np = labels_np.reshape(1, -1)
    # Loss supervises labels[:, 1:] (causal shift), so the first column never trains.
    return [bool(np.any(row[1:] != -100)) for row in labels_np]


def _build_response_masked_vlm_batch(
    items,
    processor,
    config,
    max_seq_length,
    image_size,
    response_mask_fn=None,
    formatting_func=None,
    ignore_token_ids=None,
    completion_only_loss=None,
    return_prompt_completion=False,
    yield_host_staged=False,
    reject_mlx_valued=False,
    target_width=None,
):
    """Collate VLM rows and apply the CUDA response-mask closure.

    Plain-SFT and prompt/completion streams stage host-side and exit through the
    single ``_finalize_vlm_batch`` call (``yield_host_staged`` defers it for the
    prefetch producer). Response-masked streams run the verbatim legacy
    consumer-side order and are rejected in producer modes.

    ``target_width`` (an installed shape-plan endpoint) splits that finalization
    at the width seam: the finalizer stops after its content phase, the pad lands
    after expansion and response masking so padded tails stay inert, and the
    position phase then runs at the final width.
    """
    staged, is_prompt_completion = _collate_vlm_batch(
        items, processor, max_seq_length, image_size,
        reject_mlx_valued=reject_mlx_valued,
        formatting_func=formatting_func,
        ignore_token_ids=ignore_token_ids,
        completion_only_loss=completion_only_loss,
        return_prompt_completion=True,
    )
    staged.config = config
    # Unplanned batches keep the historical single-pass order, including its
    # failure ordering (a broken batch raises before the response-mask callback).
    phase = None if target_width is None else "content"

    def _seal(batch_dict):
        """Width seam: pad to the planned endpoint, then record positions."""
        if target_width is None:
            return batch_dict
        tokenizer = getattr(processor, "tokenizer", processor)
        batch_dict = _finalize_vlm_batch_width(
            batch_dict, target_width,
            getattr(tokenizer, "pad_token_id", None),
            disposable_keys=_vlm_pipeline_disposable_keys(config),
        )
        return _prepare_vlm_batch_for_compile(
            batch_dict, config, phase="positions",
        )

    if response_mask_fn is not None and not is_prompt_completion:
        # Closure semantics are defined on the converted, compile-prepared
        # tensors (image-token expansion shifts positions), so response masking
        # is consumer-side by nature and staging cannot cover it.
        if yield_host_staged:
            raise ValueError(
                "Unsloth MLX VLM: train_on_responses_only streams are not "
                "covered by the prefetch producer yet; use "
                "streaming_prefetch_batches=0 for response-masked VLM "
                "streams."
            )
        batch_dict = _finalize_vlm_batch(
            staged, keep_raw_carrier=True, phase=phase,
        )
        batch_dict = _apply_response_mask_to_vlm_batch(
            batch_dict,
            response_mask_fn,
            ignore_token_ids=ignore_token_ids,
        )
        batch_dict = _seal(batch_dict)
        if return_prompt_completion:
            return batch_dict, is_prompt_completion
        return batch_dict
    if yield_host_staged:
        if target_width is not None:
            # Staging defers conversion, so the batch has no width to pad yet.
            # The sized planner owns every endpoint and never stages.
            raise ValueError(
                "Unsloth MLX VLM: a planned target_width cannot be applied to "
                "a host-staged batch; finalize on the consumer thread first."
            )
        if return_prompt_completion:
            return staged, is_prompt_completion
        return staged
    batch_dict = _seal(_finalize_vlm_batch(staged, phase=phase))
    if return_prompt_completion:
        return batch_dict, is_prompt_completion
    return batch_dict


def _filter_trainable_vlm_indices(
    dataset,
    indices,
    processor,
    config,
    max_seq_length,
    image_size,
    response_mask_fn,
    formatting_func=None,
    ignore_token_ids=None,
    completion_only_loss=None,
):
    """Filter VLM rows before batching, matching CUDA dataset.filter order."""
    kept_indices = []
    formatted_items = {} if formatting_func is not None else None
    supervision = {}
    removed = 0
    # Formatted rows are kept for the batch builder, so they outlive the rows
    # read after them and carry the same reuse-buffer exposure as the planner.
    media_pins = []
    for idx in indices:
        item = _format_vlm_row_gating_audio(
            dataset[idx], formatting_func, processor,
        )
        batch_dict, is_prompt_completion = _build_response_masked_vlm_batch(
            [item],
            processor,
            config,
            max_seq_length,
            image_size,
            response_mask_fn=response_mask_fn,
            formatting_func=None,
            ignore_token_ids=ignore_token_ids,
            completion_only_loss=completion_only_loss,
            return_prompt_completion=True,
        )
        valid_rows = _vlm_trainable_label_rows(batch_dict)
        # Removal keeps the causal-shift predicate; the checker flag keeps the
        # legacy full-row one (a 1-token row can be good for one and not the other).
        labels = batch_dict.get("labels")
        if labels is None:
            checker_good = True
        else:
            first_row = labels.tolist()[0]
            checker_good = any(int(x) != -100 for x in first_row)
        if is_prompt_completion:
            kept_indices.append(idx)
            supervision[idx] = checker_good
            if formatted_items is not None:
                formatted_items[idx] = _snapshot_formatted_vlm_row(
                    item, _pins=media_pins,
                )
            continue
        if valid_rows is not None and len(valid_rows) == 1 and not valid_rows[0]:
            removed += 1
            continue
        kept_indices.append(idx)
        supervision[idx] = checker_good
        if formatted_items is not None:
            formatted_items[idx] = _snapshot_formatted_vlm_row(
                item, _pins=media_pins,
            )
    _verify_vlm_media_pins(media_pins)
    return kept_indices, removed, formatted_items, supervision


# Deep enough for a chat row (row -> messages -> message -> content -> part);
# the bound keeps a self-referential row from recursing without end.
_VLM_ROW_SNAPSHOT_DEPTH = 8


def _vlm_pil_image_is_decoded(image):
    """True when a PIL image already holds a decoded raster.

    Pillow 11+ raises on ``.im`` before the load and exposes ``._im``; earlier
    releases only expose ``.im``, left as None until then. Reading ``_im``
    first keeps this correct on both, and under ``python -O``.
    """
    for attribute in ("_im", "im"):
        try:
            return getattr(image, attribute) is not None
        except Exception:
            continue
    return True


def _vlm_media_bytes_digest(array):
    """Order-sensitive CRC-32 over every byte of an array-like payload.

    A sparse sample cannot see a mutation that misses its stride, and the
    stride is derivable from the shape, so the probe reads the whole buffer.
    A byte sum and a byte xor are both permutation-invariant, so an in-place
    geometric augmentation over a reused buffer (flip, rotate, roll, channel
    swap -- all exact byte permutations, for float payloads too) left both
    unchanged and the corruption went unreported. CRC-32 is order sensitive,
    and being one C pass rather than two numpy reductions it is also cheaper
    than the pair it replaces: 0.62 ms against 1.40 ms per 1024x1024 RGB
    probe here, against 3.63 ms for blake2b. This is a raw-byte view, so it
    is exact for float payloads, and it is paid once per scheduled slot at
    plan construction.
    """
    flat = np.ascontiguousarray(array).reshape(-1).view(np.uint8)
    return zlib.crc32(memoryview(flat))


def _vlm_media_fingerprint(payload):
    """Content probe for a mutable media payload, or None to skip it.

    Rows are stored by reference, so a dataset that decodes into one reused
    buffer silently rewrites rows already collected. Copying every payload
    instead would cost one image per scheduled slot rather than per row, so
    the plan probes content and reports the corruption rather than paying to
    prevent it. Undecoded PIL handles are still skipped, because probing one
    would force the decode this path exists to defer.
    """
    try:
        if isinstance(payload, _LazyVLMImage):
            # A released handle re-opens its path, so the FILE is the payload
            # and a reused path aliases exactly like a reused buffer. Identity
            # metadata is O(1) where re-reading the bytes would be O(size).
            return ("lazyfile", payload.path, _vlm_file_identity(payload.path))
        if isinstance(payload, np.ndarray):
            return ("ndarray", payload.shape, str(payload.dtype),
                    _vlm_media_bytes_digest(payload))
        if isinstance(payload, (bytes, bytearray)):
            return ("bytes", len(payload),
                    _vlm_media_bytes_digest(np.frombuffer(bytes(payload), dtype=np.uint8)))
        pil_image = sys.modules.get("PIL.Image")
        if pil_image is not None and isinstance(payload, pil_image.Image):
            if not _vlm_pil_image_is_decoded(payload):
                return None
            # Already decoded, so asarray reads the existing raster.
            return ("image", payload.mode, payload.size,
                    _vlm_media_bytes_digest(np.asarray(payload)))
        torch_module = sys.modules.get("torch")
        if torch_module is not None and isinstance(payload, torch_module.Tensor):
            return ("tensor", tuple(payload.shape), str(payload.dtype),
                    _vlm_media_bytes_digest(payload.detach().cpu().numpy()))
        # mlx arrays support in-place __setitem__, so an mlx-native dataset can
        # alias exactly like a numpy one.
        if isinstance(payload, _MX_ARRAY_TYPE):
            return ("mx", payload.shape, str(payload.dtype),
                    _vlm_media_bytes_digest(np.asarray(payload)))
    except Exception:
        # An unprobeable payload is simply not covered by the check.
        return None
    return None


def _verify_vlm_media_pins(pins, *, since_construction=False):
    """Raise when a stored payload changed after the row that holds it was read."""
    for payload, taken in pins:
        if taken is None:
            continue
        if _vlm_media_fingerprint(payload) != taken:
            if isinstance(payload, _LazyVLMImage):
                _raise_vlm_lazy_file_changed(payload.path)
            if since_construction:
                raise ValueError(
                    "Unsloth MLX VLM: a dataset image changed between "
                    "trainer setup and the batch that uses it, so this batch "
                    "would train on pixels the sample no longer holds. "
                    "Batches are built on demand, so a payload mutated in "
                    "place after setup is still live here. Keep dataset "
                    "images immutable for the run, or hand the trainer a copy."
                )
            raise ValueError(
                "Unsloth MLX VLM: a dataset image changed after the row "
                "holding it was read, so stored rows no longer match their "
                "own samples. This happens when __getitem__ decodes into one "
                "reused buffer (or returns a view over one) instead of "
                "returning a fresh image per row. Return a copy from "
                "__getitem__, for example image.copy() or array.copy()."
            )


def _snapshot_formatted_vlm_row(item, _depth=0, _pins=None):
    """Snapshot one stored VLM row. A ``formatting_func`` (or dataset) that
    mutates and returns its argument hands every visit the same object, so
    without this a later visit's mutation would rewrite earlier stored visits.
    Nested containers are rebuilt too, but payloads such as images are only
    ever referenced, never copied. Passing ``_pins`` records a content probe
    per media payload so the caller can verify none was rewritten later."""
    if _depth >= _VLM_ROW_SNAPSHOT_DEPTH:
        return item
    if isinstance(item, dict):
        snapshot = copy.copy(item)
        for key, value in item.items():
            snapshot[key] = _snapshot_formatted_vlm_row(value, _depth + 1, _pins)
        return snapshot
    if isinstance(item, list):
        return [
            _snapshot_formatted_vlm_row(value, _depth + 1, _pins) for value in item
        ]
    if type(item) is tuple:
        # A tuple is immutable but its elements are not, and the image helpers
        # accept a tuple wherever they accept a list. Subclasses (namedtuples)
        # are left alone rather than rebuilt through the wrong constructor.
        return tuple(
            _snapshot_formatted_vlm_row(value, _depth + 1, _pins) for value in item
        )
    if _pins is not None:
        fingerprint = _vlm_media_fingerprint(item)
        if fingerprint is not None:
            _pins.append((item, fingerprint))
    return item


class _FiniteVLMRow:
    """CPU-side formatted VLM item plus its checker-supervision flag.

    ``pins`` keeps this row's media probes alive past construction. The eager
    builder converted every payload to tensors up front, so a caller that
    mutated one afterwards could not reach training; this plan holds the
    payload itself until materialize, so the same probe has to be re-read
    there. The probes cost a stat for a released file and one crc32 pass
    otherwise, both far below the processor call they precede.
    """

    __slots__ = ("item", "checker_good", "pins")

    def __init__(self, item, checker_good=True, pins=()):
        self.item = item
        self.checker_good = bool(checker_good)
        self.pins = pins


def _pinned_finite_vlm_row(item, checker_good=True, *, _all_pins=None, snapshot=True):
    """Build one plan row, keeping its media probes for the materialize check."""
    pins = []
    stored = _snapshot_formatted_vlm_row(item, _pins=pins)
    if _all_pins is not None:
        _all_pins.extend(pins)
    return _FiniteVLMRow(
        stored if snapshot else item,
        checker_good,
        tuple(pins),
    )


# The serializer trusts a genuine mlx.core at import time, the same trust the
# trainer places in mx.compile. Array metadata is read through descriptors
# captured here and validated against a probe array, so later patching of
# mx.array's Python attributes cannot hide or forge shapes/dtypes. If the
# captures are missing or fail the probe, every array leaf degrades to
# unplannable rather than trusting unverifiable reads.
_MX_ARRAY_TYPE = mx.array
_MX_ARRAY_SHAPE = getattr(mx.array, "shape", None)
_MX_ARRAY_DTYPE = getattr(mx.array, "dtype", None)
_MX_DTYPE_TABLE = tuple(
    (dtype_obj, dtype_name)
    for dtype_name in (
        "bool_", "uint8", "uint16", "uint32", "uint64",
        "int8", "int16", "int32", "int64",
        "float16", "float32", "float64", "bfloat16", "complex64",
    )
    for dtype_obj in (getattr(mx, dtype_name, None),)
    if dtype_obj is not None
)
_MX_DTYPE_EQ = getattr(type(getattr(mx, "int32", None)), "__eq__", None)


def _vlm_family_dtype_name(dtype_value):
    """Stable name for a dtype read from an array, or None.

    Dtype reads mint fresh wrapper objects, so identity cannot name them.
    Comparison uses the __eq__ and dtype singletons captured at import, so
    later patching of the Dtype class cannot forge or hide a name.
    """
    if _MX_DTYPE_EQ is None:
        return None
    for candidate, name in _MX_DTYPE_TABLE:
        try:
            if _MX_DTYPE_EQ(dtype_value, candidate) is True:
                return name
        except Exception:
            return None
    return None


def _validate_mx_array_captures():
    if _MX_ARRAY_SHAPE is None or _MX_ARRAY_DTYPE is None:
        return False
    try:
        probe = mx.zeros((3, 7), dtype=mx.int16)
        return (
            tuple(_MX_ARRAY_SHAPE.__get__(probe, _MX_ARRAY_TYPE)) == (3, 7)
            and _vlm_family_dtype_name(
                _MX_ARRAY_DTYPE.__get__(probe, _MX_ARRAY_TYPE)
            ) == "int16"
        )
    except Exception:
        return False


_MX_ARRAY_CAPTURES_VALID = _validate_mx_array_captures()


# First-read-wins tag per type object, held WEAKLY so dynamic per-batch types are
# reclaimed while any recurring type keeps one stable tag: a surveyed family and a
# later drift check always agree within a process. Cross-process equality holds
# only for types with honest introspection (others are unplannable anyway).
_VLM_TYPE_TAG_CACHE = {}


def _vlm_family_type_tag(node_type):
    """First-observation type tag that survives hostile metaclasses: a type
    whose introspection raises still classifies (as "unidentifiable.type"),
    and one whose introspection varies across reads keeps its first observed
    tag for its lifetime."""
    entry = _VLM_TYPE_TAG_CACHE.get(id(node_type))
    if entry is not None and entry[0]() is node_type:
        return entry[1]
    try:
        tag = f"{node_type.__module__}.{node_type.__qualname__}"
    except Exception:
        tag = "unidentifiable.type"
    if len(_VLM_TYPE_TAG_CACHE) >= 256:
        for key in [
            key
            for key, (type_ref, _tag) in _VLM_TYPE_TAG_CACHE.items()
            if type_ref() is None
        ]:
            del _VLM_TYPE_TAG_CACHE[key]
    try:
        _VLM_TYPE_TAG_CACHE[id(node_type)] = (weakref.ref(node_type), tag)
    except TypeError:
        pass
    return tag


def _vlm_family_encode_key(key):
    """Encoding of one dictionary key for ``_vlm_batch_family``.

    ``mx.compile`` records every key's ``__hash__()`` result, so a value
    encoding is safe only where it is at least as fine as that hash within a
    process. That holds for the exact built-ins whose hash is
    value-determined: str/bytes, int/bool, None, non-NaN floats (the bit
    pattern also splits the ``0.0``/``-0.0`` collision), and plain tuples of
    these. Anything else (subclasses overriding ``__hash__``, NaN floats,
    arbitrary hashable objects) could let one family span several compile
    keys, so it is tagged ``unstable_key`` and ``_vlm_family_is_plannable``
    excludes the whole family from shape planning.
    """
    key_type = type(key)
    if key_type is bool or key_type is int:
        return ("int", int(key))
    if key_type is float:
        if key != key:
            return ("unstable_key", "float-nan")
        return ("float", struct.pack("<d", key).hex())
    if key_type is str:
        return ("str", key)
    if key_type is bytes:
        return ("bytes", key)
    if key is None:
        return ("none",)
    if key_type is tuple:
        return ("seq",) + tuple(_vlm_family_encode_key(item) for item in key)
    return ("unstable_key", _vlm_family_type_tag(key_type))



def _audio_fixed_budget(processor, config=None):
    """Placeholders a family emits per clip, when that count is fixed.

    Gemma 3n always merges the same number of positions per clip, padding short
    clips with learned padding embeddings, so the count is known before the
    model runs and a row's placeholders can be checked against it.

    A processor that converts clip duration into a token count has no such
    constant: its ``audio_soft_tokens_per_image`` is an upper bound rather than
    the per-clip budget (Gemma 4 reports 750 while emitting 25 placeholders for
    a one-second clip), so the presence of a per-token duration is what rules
    the check out. Those families are verified against the encoder's own output
    instead.
    """
    if getattr(processor, "audio_ms_per_token", None):
        return None
    for source in (config, getattr(processor, "config", None)):
        value = _config_get(source, "audio_soft_tokens_per_image", None)
        if value:
            return int(value)
    length = getattr(processor, "audio_seq_length", None)
    if length:
        return int(length)
    return None


_AUDIO_TOWER_ATTRS = (
    "audio_tower", "embed_audio", "audio_encoder", "audio_projection",
    "audio_projection_layer", "sound_encoder", "sound_projection",
)
_AUDIO_OUTPUT_ATTRS = ("talker", "code2wav")


_AUDIO_MERGE_SENTINEL = "_unsloth_audio_merge_patched"
_AUDIO_MERGE_HOLDERS = "_unsloth_audio_merge_holders"
_AUDIO_MERGE_ORIGINAL = "_unsloth_audio_merge_original"
# The hold count is read, decided on and written back, which the GIL does not
# make atomic, so two trainers starting close together could both install a
# wrapper and the first to finish would restore the original mid-training.
# Module-level: it is taken twice per run, so contention is irrelevant.
_AUDIO_MERGE_LOCK = threading.Lock()

# Families whose merge walks a flattened feature block with a running
# placeholder count, so a padded row's tail is consumed by the next row. Gemma 3n
# (fixed budget, merges its own padding) and Phi-4 (row by row) must not get it.
_AUDIO_MERGE_PATCH_FAMILIES = frozenset({"gemma4"})


def audio_merge_patch_needed(config):
    """Whether this model family's audio merge must be corrected for training.

    Matched case-insensitively because mlx-vlm lowercases ``model_type`` before
    selecting the module: a checkpoint spelling it differently loads the same
    family and passes the audio gate, so an exact match here would skip the
    correction for a model that needs it.
    """
    model_type = _config_get(config, "model_type")
    return str(model_type).lower() in _AUDIO_MERGE_PATCH_FAMILIES


def _compact_audio_features(embeddings, padding_mask, placeholders_per_row):
    """Concatenate every clip's valid audio embeddings, in clip order.

    The upstream merge flattens the whole padded feature block and walks it with
    a running count of placeholder positions, so a short clip's padding is
    consumed by the placeholders that follow it. Feeding that walk only the
    valid embeddings, in the order the clips appear, makes the count line up
    again -- collation emits clips row by row, so clip order is row order.

    The encoder yields one entry per clip while placeholders are counted per
    text row, and a row may hold several clips or none. Clips are therefore
    assigned to rows in order and each row must be satisfied exactly: a batch
    whose totals happen to agree while individual rows do not is still
    mispaired, and is rejected here rather than trained on.

    ``padding_mask`` marks padded frames (the encoder's own polarity), so valid
    positions are its complement.
    """
    selected = []
    counts = []
    for index in range(embeddings.shape[0]):
        keep = ~np.asarray(padding_mask[index]).astype(bool)
        counts.append(int(keep.sum()))
        if counts[-1]:
            selected.append(embeddings[index][mx.array(np.nonzero(keep)[0])])

    clip = 0
    for row, wanted in enumerate(int(n) for n in placeholders_per_row):
        filled = 0
        while filled < wanted and clip < len(counts):
            filled += counts[clip]
            clip += 1
        if filled != wanted:
            raise ValueError(
                f"Unsloth MLX: row {row} has {wanted} audio placeholder(s) but "
                f"its clips produced {filled} valid audio position(s). Audio "
                f"and text cannot be paired for this row."
            )
    if clip != len(counts):
        raise ValueError(
            f"Unsloth MLX: this batch carries {len(counts)} audio clip(s) but "
            f"only {clip} could be matched to placeholder runs."
        )
    if not selected:
        return embeddings[:0].reshape(0, embeddings.shape[-1])
    return mx.concatenate(selected, axis=0)


def install_audio_merge_patch(model, audio_token_id):
    """Correct a model's audio merge for the duration of training.

    Bound on the instance rather than the class, so a patch cannot leak into
    inference on other models of the same type. Installs are counted: two
    trainers sharing one model both hold a reference, and the correction stays
    until the last of them releases it. Returns True when a hold was taken, so
    every caller that gets True must release exactly once.
    """
    # Capture, install and record are one transition, so all of it is under the
    # lock: split, an installer arriving mid-restore captures the outgoing
    # wrapper as its "original" and the remover overwrites the new one.
    with _AUDIO_MERGE_LOCK:
        holders = getattr(model, _AUDIO_MERGE_HOLDERS, 0)
        if holders:
            # Another run holds it: take a hold so it outlives whoever
            # finishes first.
            setattr(model, _AUDIO_MERGE_HOLDERS, holders + 1)
            return True
        original = model.get_input_embeddings
        had_instance_attr = "get_input_embeddings" in vars(model)
        audio_keys = ("input_features", "input_features_mask",
                      "audio_features", "audio_mask")

        def patched(input_ids=None, pixel_values=None, **kwargs):
            features = kwargs.get("input_features", kwargs.get("audio_features"))
            valid = kwargs.get("input_features_mask")
            if features is None or valid is None:
                return original(input_ids=input_ids, pixel_values=pixel_values, **kwargs)
            # Model builds text and vision embeddings; audio is merged here.
            rest = {k: v for k, v in kwargs.items() if k not in audio_keys}
            result = original(input_ids=input_ids, pixel_values=pixel_values, **rest)
            embeds = getattr(result, "inputs_embeds", result)
            encoded, padding = model.audio_tower(features, ~valid)
            audio_embeds = model.embed_audio(encoded)
            placeholders = np.asarray(input_ids == audio_token_id).sum(axis=1)
            source = _compact_audio_features(audio_embeds, padding, placeholders)
            # Without this cast the merge widens the whole LM input to float32.
            source = source.astype(embeds.dtype)
            mask = mx.broadcast_to(
                mx.expand_dims(input_ids == audio_token_id, -1), embeds.shape,
            )
            merged = _masked_scatter_rowwise(embeds, mask, source)
            if hasattr(result, "inputs_embeds"):
                result.inputs_embeds = merged
                return result
            return merged

        model.get_input_embeddings = patched
        setattr(model, _AUDIO_MERGE_SENTINEL, True)
        setattr(model, _AUDIO_MERGE_HOLDERS, 1)
        # Put back exactly what was there: deleting would discard someone else's
        # instance-level wrapper.
        setattr(model, _AUDIO_MERGE_ORIGINAL, original if had_instance_attr else None)
        return True


def remove_audio_merge_patch(model):
    """Release one hold on the corrected merge, restoring it at the last."""
    with _AUDIO_MERGE_LOCK:
        holders = getattr(model, _AUDIO_MERGE_HOLDERS, 0)
        if holders <= 0:
            return False
        if holders > 1:
            setattr(model, _AUDIO_MERGE_HOLDERS, holders - 1)
            return False
        # Last holder: restore inside the lock with the count drop, for the
        # reason install gives.
        previous = getattr(model, _AUDIO_MERGE_ORIGINAL, None)
        if previous is not None:
            model.get_input_embeddings = previous
        else:
            try:
                del model.get_input_embeddings
            except AttributeError:
                pass
        setattr(model, _AUDIO_MERGE_SENTINEL, False)
        setattr(model, _AUDIO_MERGE_ORIGINAL, None)
        setattr(model, _AUDIO_MERGE_HOLDERS, 0)
        return True


def _masked_scatter_rowwise(embeds, mask, source):
    flat_mask = mask.flatten().astype(mx.int32)
    indices = mx.cumsum(flat_mask) - 1
    flat_source = source.flatten()
    aligned = flat_source[mx.clip(indices, 0, flat_source.size - 1)]
    return mx.where(flat_mask, aligned, embeds.flatten()).reshape(embeds.shape)


def freeze_audio_modules(model):
    """Freeze audio-input towers/projections and audio-output modules.

    Audio towers are inference-only here: their encoders carry fp32 promotions,
    long cumulative reductions and host-synchronizing guards that make them
    poor training subjects, and the model-side merge assumes their output is a
    fixed function of the clip. Audio-output modules are outside this input-only
    training path. LoRA runs freeze everything by default, but a full fine-tune
    would otherwise pull all of these parameters into the optimizer.

    Returns the names of the modules that were frozen.
    """
    frozen = []
    seen = set()
    for attr in _AUDIO_TOWER_ATTRS + _AUDIO_OUTPUT_ATTRS:
        for owner in (
            model,
            getattr(model, "language_model", None),
            getattr(model, "thinker", None),
        ):
            module = getattr(owner, attr, None) if owner is not None else None
            if module is None or not hasattr(module, "freeze"):
                continue
            # Every owner, not just the first: a distinct `thinker.audio_tower`
            # beside a top-level one would otherwise stay trainable. Deduped by
            # identity so an alias is not reported twice.
            if id(module) in seen:
                continue
            seen.add(id(module))
            module.freeze(recurse=True)
            frozen.append(attr)
    return frozen


def _vlm_batch_carries_audio(batch):
    """Whether a prepared VLM batch carries audio feature tensors.

    Audio feature extents vary per clip and belong to no padable axis, so a
    batch carrying them cannot participate in compiled-signature planning.
    """
    if not isinstance(batch, Mapping):
        return False
    for key in _AUDIO_FEATURE_PAYLOAD_KEYS:
        value = batch.get(key)
        if value is None:
            continue
        # An empty payload is how some processors report "no audio here":
        # MiniCPM-o returns audio_features shaped (0, 80, 0) for a text-only
        # batch, which must not route the run eagerly or abort a strict one.
        shape = getattr(value, "shape", None)
        if shape is not None:
            if all(int(dim) for dim in shape):
                return True
            continue
        if not hasattr(value, "__len__") or len(value):
            return True
    return False


def _vlm_batch_family(batch, symbolic_axes=None):
    """Process-stable compile-key family of a prepared VLM batch pytree.

    Mirrors the structure walk ``mx.compile`` uses to key its cache (mlx
    ``python/src/transforms.cpp``), including its container asymmetry: lists
    are read through raw C storage (subclass iteration overrides do not
    participate) while tuples are read through Python iteration (overrides
    do); both share one sequence marker. Dict entries participate in
    insertion order via raw ``dict.items``, non-array constants by exact
    value (bools as ints, floats by bit pattern), and ``mx.array`` leaves by
    rank/shape/dtype. Value encodings apply only to exact built-in types; a
    subclass constant becomes an ``unstable_const`` tag. Where the encodings
    differ this one is finer for every pytree the compile walk accepts, so
    for plannable families (see ``_vlm_family_is_plannable``) equal families
    can never reach distinct compile keys, and families compare equal across
    processes. Structures the compile walk rejects (non-dict mappings, non
    ``mx.array`` leaves carrying shape/dtype, unsupported leaf types) get
    stable ``mapping``/``opaque`` tags and planning skips them.

    ``symbolic_axes`` maps a leaf path to the axis whose extent is replaced
    by the symbolic ``"sequence"`` marker; unmapped arrays keep every
    dimension concrete and so discriminate families exactly.
    """
    def encode(node, path):
        # Dispatch on the raw runtime type, which a lying __class__ cannot mislead,
        # matching the PyDict_Check/PyList_Check calls the compile walk performs.
        node_type = type(node)
        if issubclass(node_type, dict):
            return ("dict",) + tuple(
                (_vlm_family_encode_key(key), encode(value, path + (key,)))
                for key, value in dict.items(node)
            )
        if issubclass(node_type, Mapping):
            tag = _vlm_family_type_tag(node_type)
            try:
                entries = tuple(
                    (_vlm_family_encode_key(key), encode(value, path + (key,)))
                    for key, value in node.items()
                )
            except Exception:
                # mx.compile rejects non-dict mappings unread, so a raising items()
                # must not break surveying; the tag marks the family unplannable.
                return ("mapping", tag, "unreadable")
            return ("mapping", tag) + entries
        if issubclass(node_type, (list, tuple)):
            # transforms.cpp indexes lists raw but iterates tuples through the
            # Python protocol, so every list is eligible while only exact tuples
            # are: a tuple subclass can route iteration through tp_iter that no
            # attribute inspection sees, letting the two walks see different items.
            if issubclass(node_type, tuple) and node_type is not tuple:
                return ("unstable_const", _vlm_family_type_tag(node_type))
            walk = (
                list.__iter__(node)
                if issubclass(node_type, list)
                else tuple.__iter__(node)
            )
            return ("seq",) + tuple(
                encode(item, path + (position,))
                for position, item in enumerate(walk)
            )
        if node_type is _MX_ARRAY_TYPE:
            # Metadata through the validated import-time descriptors and dtype
            # naming by captured equality, so no patchable protocol participates.
            # Unvalidated captures never guess: the leaf opts out instead.
            if not _MX_ARRAY_CAPTURES_VALID:
                return ("unstable_const", _vlm_family_type_tag(node_type))
            shape = _MX_ARRAY_SHAPE.__get__(node, node_type)
            dims = [operator.index(dim) for dim in shape]
            axis = None if symbolic_axes is None else symbolic_axes.get(path)
            if axis is not None:
                dims[operator.index(axis)] = "sequence"
            dtype_name = _vlm_family_dtype_name(
                _MX_ARRAY_DTYPE.__get__(node, node_type)
            )
            if dtype_name is None:
                return ("unstable_const", _vlm_family_type_tag(node_type))
            return ("array", tuple(dims), dtype_name)
        if node_type is bool or node_type is int:
            # transforms.cpp casts constants to int64; anything outside is rejected.
            if not -(2 ** 63) <= node < 2 ** 63:
                return ("opaque", "builtins.int")
            return ("int", int(node))
        if node_type is float:
            return ("float", struct.pack("<d", node).hex())
        if node_type is str:
            return ("str", node)
        if node is None:
            return ("none",)
        if issubclass(node_type, (bool, int, float, str, _MX_ARRAY_TYPE)):
            return ("unstable_const", _vlm_family_type_tag(node_type))
        return ("opaque", _vlm_family_type_tag(node_type))

    return encode(batch, ())


def _vlm_family_is_plannable(family):
    """Whether shape planning may group compiled calls by this family.

    False when any component's compile-key mapping is not one-to-one-or-finer:
    ``unstable_key``/``unstable_const`` (subclass or identity hashing can
    split one family across compile keys) and ``mapping``/``opaque``
    (structures the compile walk rejects). Such a family must never be
    admitted to planning, not even as an exact signature; runs containing
    those batches keep unplanned behavior (eager fallback or strict error).
    """
    if not isinstance(family, tuple) or not family:
        return True
    if family[0] in ("unstable_key", "unstable_const", "mapping", "opaque"):
        return False
    return all(
        _vlm_family_is_plannable(item)
        for item in family
        if isinstance(item, tuple)
    )


def _vlm_family_divergence(expected, observed, path="batch"):
    """Location and description of the first difference between two families
    produced by ``_vlm_batch_family``, or ``None`` when they are equal."""
    if expected == observed:
        return None
    if (
        isinstance(expected, tuple)
        and isinstance(observed, tuple)
        and expected[:1] == observed[:1]
        and expected[:1] and expected[0] in ("dict", "seq")
    ):
        kind = expected[0]
        if len(expected) != len(observed):
            if kind == "dict":
                def _key_names(entries):
                    return {
                        repr(
                            key[1]
                            if key[:1] == ("str",) and len(key) == 2
                            else key
                        )
                        for key, _child in entries
                    }
                expected_keys = _key_names(expected[1:])
                observed_keys = _key_names(observed[1:])
                added = sorted(observed_keys - expected_keys)
                missing = sorted(expected_keys - observed_keys)
                if added or missing:
                    return (
                        f"{path}: runtime batch "
                        + " and ".join(
                            part for part in (
                                added and f"added keys {', '.join(added)}",
                                missing and f"lost keys {', '.join(missing)}",
                            ) if part
                        )
                    )
            return (
                f"{path}: {kind} entry count {len(expected) - 1} in the "
                f"surveyed family vs {len(observed) - 1} at runtime"
            )
        for position, (exp, obs) in enumerate(zip(expected[1:], observed[1:])):
            if kind == "dict":
                (exp_key, exp_child), (obs_key, obs_child) = exp, obs
                if exp_key != obs_key:
                    return (
                        f"{path}: key {position} is {exp_key!r} in the "
                        f"surveyed family vs {obs_key!r} at runtime"
                    )
                step = (
                    exp_key[1]
                    if exp_key[:1] == ("str",) and len(exp_key) == 2
                    else exp_key
                )
                deeper = _vlm_family_divergence(
                    exp_child, obs_child, f"{path}[{step!r}]",
                )
            else:
                deeper = _vlm_family_divergence(exp, obs, f"{path}[{position}]")
            if deeper is not None:
                return deeper
    return f"{path}: surveyed {expected!r} vs runtime {observed!r}"


# Problem kinds already reported, so an unsupported key layout costs one message
# per process rather than one per training step. Both trainer captures sit inside
# the per-batch loop, so without this a run that is otherwise fine emits a warning
# per batch. Keyed on the kind and not the rendered text: the message interpolates
# the offending word, so a value that changes between draws would defeat both the
# `warnings` registry and the stderr fallback below, which has no registry at all.
# A plain set is enough here; two threads racing costs a duplicate message, never
# a lost one.
_reported_unrewindable_keys = set()


def _warn_unrewindable_key(kind, message):
    """Report a key we cannot rewind, at most once per kind, without ever raising.

    Every caller reads the key *before* entering the `try` that a raise here
    would land in: both trainer captures sit above their compile-fallback
    `try`, and `_preserved_preprocessing_rng` captures before it yields. This
    path is documented as declining rather than failing, so under
    `PYTHONWARNINGS=error` (or any filter promoting RuntimeWarning) the
    diagnostic must not become the abort it is warning about.

    Not `catch_warnings` + `simplefilter`: that mutates a process-global filter
    list, and MLX training runs these paths from more than one thread, where it
    would briefly disarm another thread's warnings-as-errors. Falling back to
    stderr keeps the message instead of swallowing it.
    """
    if kind in _reported_unrewindable_keys:
        return
    _reported_unrewindable_keys.add(kind)
    try:
        warnings.warn(message, RuntimeWarning, stacklevel = 3)
    except Exception:
        # A filter promoted the warning, so say it on stderr rather than lose it.
        # Guarded too, though: stderr can be closed (a daemonised Studio backend,
        # or a test runner tearing down its capture) or a stream whose write
        # raises, and this helper is called ABOVE the `try` that would contain
        # such a raise. An unreportable diagnostic must not become the abort.
        try:
            print(message, file = sys.stderr)
        except Exception:
            pass


def _mlx_rng_key():
    """The current MLX PRNG key as its two 32-bit words, or None if unreadable.

    Unreadable covers the torch simulation shim, whose state is a callable;
    deciding that here is what lets the restore below stay unconditional. A
    readable key that is not two words is different: the rewind no longer works
    on the installed mlx, and a bare None would leave every compile fallback
    silently not restoring, so it warns once and declines.
    """
    try:
        words = mx.random.state[0].tolist()
    except Exception:
        return None
    if len(words) != 2:
        _warn_unrewindable_key(
            "word-count",
            f"Unsloth: MLX now exposes a {len(words)}-word random key. Unsloth "
            "can only rewind the two-word form, so a run that falls back from "
            "mx.compile to eager will not have its RNG restored and may diverge "
            "from an eager run of the same seed."
        )
        return None
    return _as_uint32_pair(int(words[0]), int(words[1]))


def _as_uint32_pair(high, low):
    """Both words as uint32, or None if either is not a 32-bit word at all.

    mx.random.seed takes a uint64 and raises outside [0, 2**64), and that raise
    would land in a `finally` or a compile-failure handler. Range-checking here
    is what lets the restore below stay unguarded.

    Range-checked rather than masked, though. A negative reads as the two's
    complement of the uint32 mlx stores, so reinterpreting it loses nothing. A
    value at or above 2**32 is not a 32-bit word under any reading, and masking
    it would turn a key we cannot represent into a plausible wrong one:
    (2**32, 0) would restore as (0, 0), so the fallback would look like it had
    rewound the RNG while actually diverging. Declining says so instead, and is
    the outcome every caller already handles.
    """
    converted = []
    for word in (high, low):
        if not -(2**31) <= word < 2**32:
            _warn_unrewindable_key(
                "word-range",
                f"Unsloth: MLX exposed a random key word of {word}, which is not "
                "a 32-bit word. Unsloth cannot rewind this key, so a run that "
                "falls back from mx.compile to eager will not have its RNG "
                "restored and may diverge from an eager run of the same seed."
            )
            return None
        converted.append(word & 0xFFFFFFFF)
    return (converted[0], converted[1])


def _restore_mlx_rng_key(words):
    """Rewind the PRNG to a key captured by ``_mlx_rng_key``.

    mlx 0.32.1 made ``mx.random.state`` a sentinel that refuses item assignment.
    Upstream builds a key as ``{seed >> 32, (uint32) seed}``, so reseeding with a
    key's own words restores it exactly over the whole unsigned 64-bit range.
    Unguarded on purpose: the range check in ``_as_uint32_pair`` removes the only
    way this can raise, and a blanket ``except`` would be a failure
    indistinguishable from an intentional no-op, which is the defect this fixes.
    """
    if words is None:
        return
    pair = _as_uint32_pair(int(words[0]), int(words[1]))
    if pair is None:
        return
    mx.random.seed((pair[0] << 32) | pair[1])


@contextlib.contextmanager
def _preserved_preprocessing_rng():
    """Run a block without leaving the shared preprocessing RNGs advanced.

    The descriptor survey builds every scheduled batch through the real
    processor just to read shapes; an augmenting processor draws from the
    process-global RNGs while doing so and those draws are never replayed, so
    without this a compile-enabled run would train on a later augmentation
    stream than an eager run from the same seed. Privately owned generators
    stay the caller's responsibility.
    """
    states = []
    try:
        states.append((random.setstate, random.getstate()))
    except Exception:
        pass
    try:
        states.append((np.random.set_state, np.random.get_state()))
    except Exception:
        pass
    torch_module = sys.modules.get("torch")
    if torch_module is not None:
        try:
            states.append((
                torch_module.random.set_rng_state,
                torch_module.random.get_rng_state(),
            ))
        except Exception:
            pass
    mx_state = _mlx_rng_key()
    try:
        yield
    finally:
        for restore, snapshot in states:
            try:
                restore(snapshot)
            except Exception:
                pass
        _restore_mlx_rng_key(mx_state)


def _vlm_file_identity(path):
    """``(device, inode, mtime_ns, size)`` of a file, or None if unreadable.

    A released handle is re-opened from its path, so a dataset that writes
    every sample to ONE shared path would hand every row the last sample's
    pixels. Identity is what makes that visible: ``stat`` is O(1) where
    re-reading the bytes would be O(size) per scheduled slot and decoding
    would be worse still. A file that has become unstat-able reads as None,
    which differs from any real identity and is reported the same way.
    """
    try:
        status = os.stat(path)
    except OSError:
        return None
    return (status.st_dev, status.st_ino, status.st_mtime_ns, status.st_size)


def _raise_vlm_lazy_file_changed(path):
    """Report a released image whose file no longer holds that row's sample."""
    raise ValueError(
        "Unsloth MLX VLM: the file backing a dataset image changed after the "
        f"row holding it was read ({path}), so stored rows no longer match "
        "their own samples. This happens when __getitem__ writes every sample "
        "to one shared path and returns Image.open(path). Write one file per "
        "sample, or return a decoded copy from __getitem__, for example "
        "Image.open(path).copy()."
    )


class _LazyVLMImage:
    """Stand-in for a file-backed PIL handle whose descriptor was released.

    ``PIL.Image.open`` leaves the file open until the raster is loaded, so
    storing one row per scheduled slot would pin one descriptor per row and
    exhaust the process limit on a few hundred rows. The path is re-opened at
    materialization instead, which keeps the plan at O(1) descriptors without
    forcing the O(N) decode that eagerly loading every row would cost.

    The file's identity travels with the path, because a path alone cannot
    tell a per-sample file from one shared scratch file rewritten per row.
    """

    __slots__ = ("path", "identity")

    def __init__(self, path):
        self.path = path
        self.identity = _vlm_file_identity(path)

    def open(self):
        # Checked here as well as at plan build: the file can also be rewritten
        # between building the plan and materializing this row.
        if _vlm_file_identity(self.path) != self.identity:
            _raise_vlm_lazy_file_changed(self.path)
        from PIL import Image as _PIL_Image

        return _PIL_Image.open(self.path)


def _vlm_releasable_image_path(value):
    """Absolute path of an undecoded, PIL-owned, file-backed image, else None.

    Every clause is a reason it would be wrong to release the descriptor:
    a caller-owned stream cannot be re-opened from a path, an already decoded
    raster has no descriptor left to save, and a seeked multi-frame handle
    would come back on frame zero.
    """
    if not getattr(value, "_exclusive_fp", False):
        return None
    if getattr(value, "fp", None) is None:
        return None
    if getattr(value, "_im", None) is not None:
        return None
    filename = getattr(value, "filename", None)
    if not isinstance(filename, str) or not filename:
        return None
    tell = getattr(value, "tell", None)
    if callable(tell):
        try:
            if tell() != 0:
                return None
        except Exception:
            return None
    try:
        # Absolute so a later chdir cannot break the re-open, and checked now
        # so an unreadable source fails at build time rather than mid-epoch.
        path = os.path.abspath(filename)
        if not os.path.isfile(path):
            return None
    except Exception:
        return None
    return path


def _release_vlm_row_image_handles(item, _depth=0):
    """Swap file-backed lazy PIL handles in a stored row for path references.

    Returns ``item`` itself when nothing is releasable, so rows that hold no
    such handle keep their exact identity and behaviour. Never closes the
    payload: the dataset may still own it, so the descriptor is freed only
    when the caller's own reference goes away.
    """
    if _depth >= _VLM_ROW_SNAPSHOT_DEPTH:
        return item
    path = _vlm_releasable_image_path(item)
    if path is not None:
        return _LazyVLMImage(path)
    if isinstance(item, dict):
        released = None
        for key, value in item.items():
            new_value = _release_vlm_row_image_handles(value, _depth + 1)
            if new_value is not value:
                if released is None:
                    released = copy.copy(item)
                released[key] = new_value
        return item if released is None else released
    if isinstance(item, tuple):
        # A stored row can nest media in a tuple; a plain rebuild would also
        # flatten a namedtuple, so reuse the concrete type when it takes an
        # iterable and fall back to positional construction when it does not.
        walked = [_release_vlm_row_image_handles(value, _depth + 1) for value in item]
        if all(new is old for new, old in zip(walked, item)):
            return item
        if type(item) is tuple:
            return tuple(walked)
        try:
            return type(item)(*walked)
        except TypeError:
            return tuple(walked)
    if isinstance(item, list):
        released = None
        for position, value in enumerate(item):
            new_value = _release_vlm_row_image_handles(value, _depth + 1)
            if new_value is not value:
                if released is None:
                    released = list(item)
                released[position] = new_value
        return item if released is None else released
    return item


def _restore_vlm_row_image_handles(item, _depth=0):
    """Re-open the handles ``_release_vlm_row_image_handles`` put aside."""
    if _depth >= _VLM_ROW_SNAPSHOT_DEPTH:
        return item
    if isinstance(item, _LazyVLMImage):
        return item.open()
    if isinstance(item, dict):
        restored = None
        for key, value in item.items():
            new_value = _restore_vlm_row_image_handles(value, _depth + 1)
            if new_value is not value:
                if restored is None:
                    restored = copy.copy(item)
                restored[key] = new_value
        return item if restored is None else restored
    if isinstance(item, tuple):
        # A stored row can nest media in a tuple; a plain rebuild would also
        # flatten a namedtuple, so reuse the concrete type when it takes an
        # iterable and fall back to positional construction when it does not.
        walked = [_restore_vlm_row_image_handles(value, _depth + 1) for value in item]
        if all(new is old for new, old in zip(walked, item)):
            return item
        if type(item) is tuple:
            return tuple(walked)
        try:
            return type(item)(*walked)
        except TypeError:
            return tuple(walked)
    if isinstance(item, list):
        restored = None
        for position, value in enumerate(item):
            new_value = _restore_vlm_row_image_handles(value, _depth + 1)
            if new_value is not value:
                if restored is None:
                    restored = list(item)
                restored[position] = new_value
        return item if restored is None else restored
    return item


class FiniteVLMBatchPlan(_FiniteVisitMixin):
    """CPU-backed finite VLM schedule with on-demand MLX materialization.

    Rows hold formatted dataset items (``formatting_func`` is consumed at
    construction, once per scheduled slot), the schedule holds row positions
    with a mask of distributed pad slots, and the plan-owned cache retains only
    the most recent batch. Visits are identity-only: merged VLM epoch semantics
    replay the stored schedule, so epoch permutation stays a text-plan behavior.
    """

    __slots__ = (
        "_rows",
        "_schedule",
        "_empty_masks",
        "_processor",
        "_config",
        "max_seq_length",
        "_image_size",
        "_response_mask_fn",
        "_ignore_token_ids",
        "_completion_only_loss",
        "_visit_policy",
        "_visit_seed",
        "_visit_epoch_cache",
        "_mru",
        "_descriptors",
        "_audio_flags",
        "_widths",
        "_padable",
        "_forbidden",
        "_shape_plan",
        "_planned_widths",
        "_cycle_length",
    )

    def __init__(
        self,
        rows,
        schedule,
        empty_masks,
        *,
        processor,
        config,
        max_seq_length,
        image_size,
        response_mask_fn=None,
        ignore_token_ids=None,
        completion_only_loss=None,
        cycle_length=None,
    ):
        self._rows = tuple(rows)
        self._schedule = tuple(tuple(int(i) for i in batch) for batch in schedule)
        self._empty_masks = (
            None if empty_masks is None else tuple(
                None if mask is None else tuple(bool(x) for x in mask)
                for mask in empty_masks
            )
        )
        self._processor = processor
        self._config = config
        # ``None`` stays ``None``: the VLM builder reads it as "no cap" (no
        # ``max_length``, truncation a no-op) and the plan only forwards it.
        self.max_seq_length = (
            None if max_seq_length is None else int(max_seq_length)
        )
        self._image_size = image_size
        self._response_mask_fn = response_mask_fn
        self._ignore_token_ids = ignore_token_ids
        self._completion_only_loss = completion_only_loss
        self._cycle_length = (
            None if cycle_length is None else max(1, int(cycle_length))
        )
        self._visit_policy = "identity"
        self._visit_seed = None
        self._visit_epoch_cache = None
        self._mru = None
        self._descriptors = None
        self._audio_flags = None
        self._widths = None
        self._padable = None
        self._forbidden = None
        self._shape_plan = None
        self._planned_widths = None
        if self._empty_masks is not None and (
            len(self._empty_masks) != len(self._schedule)
        ):
            raise ValueError(
                "empty_masks must contain one entry per scheduled batch"
            )
        for batch in self._schedule:
            for row_index in batch:
                if not 0 <= row_index < len(self._rows):
                    raise ValueError(
                        "schedule references a row outside the stored rows"
                    )

    @property
    def rows(self):
        return self._rows

    @property
    def schedule(self):
        return self._schedule

    def __len__(self):
        return len(self._schedule)

    @property
    def cycle_length(self):
        """Micro-batches in one dataset pass (<= len(self))."""
        return self._cycle_length

    def _build_batch(self, index, target_width=None):
        """Build one batch through the complete existing VLM builder,
        right-padded to ``target_width`` when an endpoint is given."""
        # Re-read the probes before the payloads reach the processor: the
        # construction check only covers the read window, and these rows are
        # still the caller's own objects until here.
        for i in self._schedule[index]:
            _verify_vlm_media_pins(self._rows[i].pins, since_construction=True)
        batch_items = [
            _restore_vlm_row_image_handles(self._rows[i].item)
            for i in self._schedule[index]
        ]
        batch_dict = _build_response_masked_vlm_batch(
            batch_items,
            self._processor,
            self._config,
            self.max_seq_length,
            self._image_size,
            response_mask_fn=self._response_mask_fn,
            formatting_func=None,
            ignore_token_ids=self._ignore_token_ids,
            completion_only_loss=self._completion_only_loss,
            target_width=target_width,
        )
        empty = (
            self._empty_masks[index] if self._empty_masks is not None else None
        )
        if empty is not None and any(empty):
            batch_dict = _mask_empty_vlm_padding_rows(
                batch_dict, list(empty), processor=self._processor,
            )
        return batch_dict

    def set_shape_plan(self, shape_plan, planned_widths):
        """Install an admission plan plus each batch's planned event width
        (the width the planner grouped it by; raw for declined batches).
        Invalidates the cache: nothing built before installation may serve a
        planned fetch."""
        if getattr(shape_plan.report, "action", None) not in ("exact", "bucket"):
            raise ValueError("only exact or bucket shape plans can be installed")
        planned_widths = tuple(
            operator.index(width) for width in planned_widths
        )
        if len(planned_widths) != len(self._schedule):
            raise ValueError(
                "planned_widths must contain one entry per scheduled batch"
            )
        self._shape_plan = shape_plan
        self._planned_widths = planned_widths
        self._mru = None

    def materialize(self, index, target_width=None, *, phase=None):
        """Build one batch through the complete existing VLM builder.

        The cache holds only the most recent batch at its exact requested
        width, so a repeated fetch (e.g. a compile-failure retry) is free;
        a fetch it cannot serve drops it before building, so a transition to
        the next batch never holds two. ``target_width``
        right-pads to an explicit endpoint and keeps bypass authority; with
        an installed shape plan, ``phase`` instead resolves the planned
        endpoint, enforces phase-aware admission, and hard-fails on
        structural drift from the surveyed family before the batch reaches a
        compiled call. ``None``/``None`` preserves the historical
        per-batch-maximum padding byte for byte.
        """
        index = operator.index(index)
        check_drift = False
        if (
            target_width is None
            and phase is not None
            and self._shape_plan is not None
        ):
            family = self.batch_family(index)
            event_width = self._planned_widths[index]
            if not self._shape_plan.allows(family, event_width, phase):
                raise RuntimeError(
                    "Unsloth MLX: compiled VLM batch signature was not "
                    "admitted by the finite shape plan."
                )
            target_width = self._shape_plan.endpoint_for(family, event_width)
            check_drift = True
        cached = self._mru
        if cached is not None and cached[0] == (index, target_width):
            _key, cached_batch, drift_checked = cached
            # Cache identity covers shape, not provenance: a batch cached by an
            # explicit-width fetch has not passed the structural proof, so a planned
            # fetch must verify it before the compiled path consumes it.
            if check_drift and not drift_checked:
                self.check_family_drift(index, cached_batch)
                self._mru = (_key, cached_batch, True)
            return cached_batch
        # This fetch cannot be served from the cache, so the cached batch is
        # already dead weight. Release it before the builder allocates its
        # replacement: the trainer clears its own ``batch_data`` reference
        # ahead of every fetch, so this entry is the last thing keeping the
        # previous batch resident, and holding it across the build would put
        # two complete image/text batches in memory at every transition. A
        # same-batch retry is unaffected, having returned above.
        self._mru = None
        cached = None
        batch_dict = self._build_batch(index, target_width=target_width)
        if check_drift:
            self.check_family_drift(index, batch_dict)
        self._mru = ((index, target_width), batch_dict, check_drift)
        return batch_dict

    def __getitem__(self, index):
        return self.materialize(index)

    def materialize_all(self):
        """Eager-list compatibility: build and evaluate every batch."""
        batches = [self.materialize(index) for index in range(len(self))]
        all_tensors = []
        for batch_dict in batches:
            for value in batch_dict.values():
                if isinstance(value, mx.array):
                    all_tensors.append(value)
        if all_tensors:
            mx.eval(all_tensors)
        return batches

    def supervision_counts(self, max_check=100):
        """(all_masked_rows, trainable_rows) over the first ``max_check``
        scheduled rows, from construction-time metadata. Does no processor
        work or materialization, so a caller's distributed reduction is never
        preceded by new rank-local work."""
        seen_bad = 0
        seen_good = 0
        checked = 0
        for batch_index, batch in enumerate(self._schedule):
            empty = (
                self._empty_masks[batch_index]
                if self._empty_masks is not None else None
            )
            for slot, row_index in enumerate(batch):
                padded = bool(empty[slot]) if empty is not None else False
                if padded or not self._rows[row_index].checker_good:
                    seen_bad += 1
                else:
                    seen_good += 1
                checked += 1
                if checked >= max_check:
                    return seen_bad, seen_good
        return seen_bad, seen_good

    def advance_preprocessing(self, visits):
        """Replay the processor over the first ``visits`` visits, discarding
        the batches.

        ``resume_from_checkpoint`` starts the loop past the micro-batches the
        killed run already consumed. The eager builder had produced every one
        of them through the real processor, so a preprocessing pipeline that
        draws from the shared RNGs was already past them when the killed run
        reached this point; a lazy plan that simply skips them would hand the
        first resumed batch the opening draw instead. Rebuilding here (MRU
        dropped, one batch alive at a time) restores that progression exactly,
        the way the streaming path fast-forwards its iterator. Unlike the
        descriptor survey this deliberately does NOT preserve RNG state.

        Visits past the stored schedule replayed prebuilt batches eagerly, so
        the processor ran at most once per scheduled batch however far the
        killed run reached; the count is clamped to match.
        """
        visits = min(operator.index(visits), len(self._schedule))
        if visits <= 0:
            return
        self._mru = None
        for visit in range(visits):
            batch = self._build_batch(self.batch_index_for_visit(visit))
            del batch
        self._mru = None

    def ensure_descriptors(self):
        """Survey every scheduled batch's compile-key family, once.

        The MRU cache is dropped up front and never repopulated here, and each
        batch is released before the next is built, so the survey owns at most
        one batch at a time; repeated calls return the stored descriptors.
        Runs under preserved global preprocessing RNG state, so a stochastic
        processor's augmentation draws are not consumed here. Draw state a
        processor owns privately is out of that preservation's reach and does
        advance by one survey; ``check_family_drift`` names this when the
        difference reaches the shapes.
        """
        if self._descriptors is not None:
            return self._descriptors
        self._mru = None
        families = []
        widths = []
        padable_flags = []
        forbidden_sets = []
        audio_flags = []
        with _preserved_preprocessing_rng():
            for index in range(len(self._schedule)):
                batch = self._build_batch(index)
                width, axes, padable, forbidden = _vlm_width_survey(
                    batch,
                    disposable_keys=_vlm_pipeline_disposable_keys(self._config),
                )
                # Padable batches get symbolic families (batches differing only in
                # text width coincide); declined batches keep every extent concrete.
                family = _vlm_batch_family(
                    batch, symbolic_axes=axes if padable else None,
                )
                carries_audio = _vlm_batch_carries_audio(batch)
                del batch
                audio_flags.append(carries_audio)
                families.append(family)
                widths.append(width)
                padable_flags.append(bool(padable))
                forbidden_sets.append(forbidden)
        self._descriptors = tuple(families)
        self._audio_flags = tuple(audio_flags)
        self._widths = tuple(widths)
        self._padable = tuple(padable_flags)
        self._forbidden = tuple(forbidden_sets)
        return self._descriptors

    @property
    def pad_token_id(self):
        """The tokenizer pad id planned padding would use, or None. Without
        one no batch can be widened, so width planning degrades the run to
        eager before surveying anything."""
        tokenizer = getattr(self._processor, "tokenizer", self._processor)
        return getattr(tokenizer, "pad_token_id", None)

    def carries_audio_hint(self):
        """Whether this plan carries audio, without forcing a full survey.

        Uses the survey when one has run, else builds a single batch. Callers
        that must materialize nothing should survey and ask ``carries_audio``.
        """
        if self._audio_flags is not None:
            return any(self._audio_flags)
        if not len(self._schedule):
            return False
        with _preserved_preprocessing_rng():
            batch = self._build_batch(0)
        try:
            return _vlm_batch_carries_audio(batch)
        finally:
            del batch

    def carries_audio_in(self, indices):
        """Whether any of the named surveyed batches carries audio.

        The whole-plan answer counts batches the schedule drops, and audio
        confined to that tail would route a run eagerly, or abort strict mode,
        over a batch no compiled call reaches -- the same reason family
        admission is restricted to the executed set.
        """
        flags = self._audio_flags
        if flags is None:
            raise RuntimeError(
                "Unsloth MLX: VLM batch families have not been surveyed; "
                "call ensure_descriptors() first."
            )
        return any(flags[index] for index in indices if 0 <= index < len(flags))

    def carries_audio(self):
        """Whether any surveyed batch carries audio feature tensors."""
        if self._audio_flags is None:
            raise RuntimeError(
                "Unsloth MLX: VLM batch families have not been surveyed; "
                "call ensure_descriptors() first."
            )
        return any(self._audio_flags)

    def batch_family(self, index):
        """Surveyed compile-key family for one scheduled batch."""
        if self._descriptors is None:
            raise RuntimeError(
                "Unsloth MLX: VLM batch families have not been surveyed; "
                "call ensure_descriptors() first."
            )
        return self._descriptors[operator.index(index)]

    def batch_width(self, index):
        """Surveyed post-prepare text width for one scheduled batch (None
        when the batch exposes no 2-D input_ids)."""
        if self._descriptors is None:
            raise RuntimeError(
                "Unsloth MLX: VLM batch widths have not been surveyed; "
                "call ensure_descriptors() first."
            )
        return self._widths[operator.index(index)]

    def planned_event_widths(self):
        """Per-batch planner event widths from the survey: padable batches
        take the shared rounded width policy capped at the surveyed maximum
        final width (never ``max_seq_length``, which post-expansion widths may
        exceed) and bumped off the union of untouched-array extents; declined
        batches keep their raw widths. Deterministic given the survey, so
        planning and installation derive identical widths.

        The bump outranks the cap, so an endpoint may land above the surveyed
        maximum: a width the finalizer would reject as an untouched extent is
        no endpoint at all, and stepping up costs a few pad columns (at most
        one per member of the finite union) while declining the capped width
        instead would split one shared endpoint back into one per raw width --
        the signature count this plan exists to bound."""
        if self._descriptors is None:
            raise RuntimeError(
                "Unsloth MLX: VLM batch widths have not been surveyed; "
                "call ensure_descriptors() first."
            )
        forbidden = set()
        padable_widths = []
        for index in range(len(self._schedule)):
            forbidden.update(self._forbidden[index])
            if self._padable[index]:
                padable_widths.append(self._widths[index])
        surveyed_max = max(padable_widths, default=0)
        widths = []
        for index in range(len(self._schedule)):
            raw_width = self._widths[index]
            if self._padable[index]:
                width = _finite_text_pad_width(
                    raw_width,
                    pad_to_multiple=32,
                    minimum_width=2,
                    max_seq_length=surveyed_max,
                )
                while width in forbidden:
                    width += 1
            else:
                width = raw_width
            widths.append(width)
        return tuple(widths)

    def check_family_drift(self, index, batch):
        """Hard-fail when a materialized batch's structure leaves its
        surveyed family. Container structure, dict keys and order, constant
        values, and every array extent outside the detected text axis must
        hold on every visit; that axis is symbolic for padable batches, so
        planned padding is not drift. Value nondeterminism inside
        equal-shaped arrays stays undetected by design."""
        index = operator.index(index)
        _width, axes, padable, _forbidden = _vlm_width_survey(
            batch,
            disposable_keys=_vlm_pipeline_disposable_keys(self._config),
        )
        divergence = _vlm_family_divergence(
            self.batch_family(index),
            _vlm_batch_family(batch, symbolic_axes=axes if padable else None),
        )
        if divergence is not None:
            raise RuntimeError(
                f"Unsloth MLX: VLM batch {index} drifted from its surveyed "
                f"compile family ({divergence}). The data pipeline must "
                f"produce structurally identical batches on every visit. The "
                f"shape survey already built every batch once through the "
                f"processor, with the process RNGs preserved around it, so a "
                f"processor drawing from a generator or counter it owns "
                f"privately arrives at training one survey further along its "
                f"own stream and drifts here; run that pipeline with compile "
                f"disabled."
            )



def _create_vlm_batch_plan(dataset, processor, config, batch_size, max_seq_length,
                       num_batches=None, seed=42, response_mask_fn=None,
                       formatting_func=None, dataset_order="default",
                       num_epochs=None, completion_only_loss=None,
                       image_size=None, comm_group=None,
                       distributed_pad_mode="cycle"):
    """Build the CPU-backed finite VLM batch plan (no materialization).

    Mirrors the eager builder's construction exactly — filtering, formatting,
    epoch/global slicing, rank slicing, and pad-slot resolution — but stores
    row indices and pad masks instead of built batches. Returns ``None`` for
    an empty dataset (the wrapper preserves the historical ``[]``).
    """
    import numpy as np

    if not _vlm_has_sized_index_space(dataset):
        raise ValueError(
            "Unsloth MLX VLM: this path requires a sized dataset exposing "
            "__len__ and __getitem__. Unsized/streaming VLM sources are only "
            "supported for training with streaming=True; unsized VLM "
            "evaluation is a planned follow-up."
        )

    image_size = _resolve_vlm_image_size(image_size, config, processor)
    ignore_token_ids = _get_vlm_ignore_token_ids(processor=processor, config=config)

    schedule = []
    empty_masks = []
    any_empty = False
    seen = 0
    epoch = 0
    global_batch_size = _distributed_global_batch_size(batch_size, comm_group)
    base_seed = _normalize_seed(seed)
    target_epochs = 1 if num_batches is None and num_epochs is None else num_epochs
    base_indices = list(range(len(dataset)))
    total_removed = 0
    formatted_items = None
    _supervision = None
    if response_mask_fn is not None:
        base_indices, total_removed, formatted_items, _supervision = _filter_trainable_vlm_indices(
            dataset,
            base_indices,
            processor,
            config,
            max_seq_length,
            image_size,
            response_mask_fn,
            formatting_func=formatting_func,
            ignore_token_ids=ignore_token_ids,
            completion_only_loss=completion_only_loss,
        )
        if not base_indices and total_removed > 0:
            raise ValueError(
                "Unsloth MLX VLM: no trainable rows remain after "
                "train_on_responses_only masking. Check instruction_part / "
                "response_part and max_seq_length."
            )
    if dataset_order not in (None, "default", "sequential", "torch_randperm"):
        raise ValueError(f"Unsupported MLX VLM dataset_order: {dataset_order!r}")
    if not base_indices:
        return None

    def _epoch_indices(epoch_idx):
        """Return CUDA-style sampler order over the filtered VLM dataset."""
        if dataset_order == "torch_randperm":
            order = _torch_randperm_order(len(base_indices), base_seed + epoch_idx)
            return [base_indices[i] for i in order]
        indices = list(base_indices)
        if dataset_order in (None, "default") and (
            num_batches is not None or epoch_idx > 0
        ):
            rng = np.random.RandomState(base_seed + epoch_idx)
            rng.shuffle(indices)
        return indices

    indices = _epoch_indices(epoch)

    while num_batches is None or len(schedule) < num_batches:
        if seen >= len(indices):
            if num_batches is None and target_epochs is not None and epoch + 1 >= target_epochs:
                break
            epoch += 1
            seen = 0
            indices = _epoch_indices(epoch)

        global_indices = indices[seen : seen + global_batch_size]
        seen += len(global_indices)
        if not global_indices:
            break
        bi = _rank_slice_distributed_batch(
            global_indices,
            batch_size,
            comm_group=comm_group,
            pad_source=indices,
            pad_mode=distributed_pad_mode,
        )
        if not bi:
            break
        empty_rows = [idx is None for idx in bi]
        if any(empty_rows):
            pad_idx = next((idx for idx in bi if idx is not None), None)
            if pad_idx is None:
                pad_idx = global_indices[0]
            resolved = [pad_idx if idx is None else idx for idx in bi]
            any_empty = True
            empty_masks.append(tuple(empty_rows))
        else:
            resolved = list(bi)
            empty_masks.append(None)
        schedule.append(tuple(resolved))

    if total_removed > 0:
        print(
            f"Unsloth: Removed {total_removed} VLM samples where all labels "
            f"were -100 after train_on_responses_only masking."
        )

    if formatted_items is None:
        # One row per scheduled slot, read in schedule order: the eager builder
        # indexed the dataset (and ran the formatter) while building every
        # batch, so a stochastic or epoch-dependent dataset or formatter must
        # refresh on every revisit. Consuming it here still keeps user code out
        # of re-materialization, and each result is snapshotted so a later
        # visit cannot rewrite an earlier one.
        # Media payloads stay referenced: copying them would cost one image per
        # scheduled slot rather than per row. `media_pins` probes their content
        # instead, so a dataset that reuses one decode buffer is reported.
        # The processor also no longer runs between one slot and the next, so a
        # pipeline whose formatter and processor draw the SAME process-global
        # RNG sees a different interleaving than the eager builder gave it.
        # Restoring it would mean processing at construction, which is the
        # memory this plan exists to save.
        media_pins = []
        rows = tuple(
            # Release before pinning, not after: a pin holds its payload so
            # the probe can re-read it, which would keep every row's file
            # open for the whole collection. The released stand-in is
            # pinned by identity instead, which costs a stat and catches a
            # dataset that rewrites one shared path per row.
            _pinned_finite_vlm_row(
                _release_vlm_row_image_handles(
                    _format_vlm_row_gating_audio(
                        dataset[idx], formatting_func, processor,
                    )
                ),
                True if _supervision is None else _supervision[idx],
                _all_pins=media_pins,
            )
            for batch in schedule for idx in batch
        )
        _verify_vlm_media_pins(media_pins)
        remapped = []
        offset = 0
        for batch in schedule:
            remapped.append(tuple(range(offset, offset + len(batch))))
            offset += len(batch)
        schedule = remapped
    else:
        # Compact remap over the filter's already-formatted rows: the eager
        # builder reused those same per-index objects on every visit.
        used = []
        seen_used = set()
        for batch in schedule:
            for idx in batch:
                if idx not in seen_used:
                    seen_used.add(idx)
                    used.append(idx)
        position = {idx: pos for pos, idx in enumerate(used)}
        # The filter already formatted these, so they are referenced rather
        # than snapshotted, but they reach the processor just as late.
        rows = tuple(
            _pinned_finite_vlm_row(
                _release_vlm_row_image_handles(formatted_items[idx]),
                True if _supervision is None else _supervision[idx],
                snapshot=False,
            )
            for idx in used
        )
        schedule = [tuple(position[idx] for idx in batch) for batch in schedule]
    # Micro-batches in ONE dataset pass, counted through the same rank slicing the
    # schedule uses. The trainer needs the exact figure to force the epoch-final
    # optimizer step; without it the dataset-size approximation still fired the
    # epoch callbacks while no update was forced there, so on_epoch_end saw
    # weights missing the epoch's last batch and its gradient crossed the boundary.
    cycle_length = sum(
        1 for start in range(0, len(base_indices), global_batch_size)
        if _rank_slice_distributed_batch(
            base_indices[start : start + global_batch_size],
            batch_size,
            comm_group=comm_group,
            pad_source=base_indices,
            pad_mode=distributed_pad_mode,
        )
    )
    return FiniteVLMBatchPlan(
        rows,
        schedule,
        empty_masks if any_empty else None,
        processor=processor,
        config=config,
        max_seq_length=max_seq_length,
        image_size=image_size,
        response_mask_fn=response_mask_fn,
        ignore_token_ids=ignore_token_ids,
        completion_only_loss=completion_only_loss,
        cycle_length=cycle_length,
    )


def create_vlm_batches(dataset, processor, config, batch_size, max_seq_length,
                       num_batches=None, seed=42, response_mask_fn=None,
                       formatting_func=None, dataset_order="default",
                       num_epochs=None, completion_only_loss=None,
                       image_size=None, comm_group=None,
                       distributed_pad_mode="cycle"):
    """Eager-list compatibility wrapper over the finite VLM batch plan."""
    plan = _create_vlm_batch_plan(
        dataset, processor, config, batch_size, max_seq_length,
        num_batches=num_batches, seed=seed,
        response_mask_fn=response_mask_fn, formatting_func=formatting_func,
        dataset_order=dataset_order, num_epochs=num_epochs,
        completion_only_loss=completion_only_loss, image_size=image_size,
        comm_group=comm_group, distributed_pad_mode=distributed_pad_mode,
    )
    return [] if plan is None else plan.materialize_all()



def _vlm_has_sized_index_space(dataset):
    """True when the VLM batcher can index the dataset (`__len__` + `__getitem__`).

    Both must be declared on the TYPE (instance `__getattr__` proxies do not
    make an object subscriptable), and known iterable-only bases are excluded
    even when they inherit a raising `__getitem__` or declare stream topology.
    Everything else streams lazily; the sized path's permutations and
    response-mask pre-scan require real indexing.
    """
    cls = type(dataset)
    if not callable(getattr(cls, "__len__", None)):
        return False
    if not callable(getattr(cls, "__getitem__", None)):
        return False
    if _is_mlx_hf_iterable_text_source(dataset):
        return False
    torch_data = sys.modules.get("torch.utils.data")
    torch_iterable = getattr(torch_data, "IterableDataset", None)
    if torch_iterable is not None and isinstance(dataset, torch_iterable):
        return False
    return True


def _iterate_lazy_vlm_training_batches(
    dataset, processor, config, batch_size, max_seq_length, *,
    response_mask_fn=None, formatting_func=None, dataset_order="default",
    completion_only_loss=None, image_size=None, comm_group=None,
    require_replayable=False, expected_rows_per_pass=None,
    ignore_token_ids=None, yield_host_staged=False, reject_mlx_valued=False,
    should_stop=None,
):
    """Unsized VLM batches under the lazy text-stream lifecycle contracts.

    Single-process only: every-rank consumption of the global stream is
    intentionally removed and rank-owned dispatch of ragged VLM tensors is a
    planned follow-up. Trainability filtering, label masking, and collation
    reuse the sized-path helpers unchanged.
    """
    if (yield_host_staged or reject_mlx_valued) and response_mask_fn is not None:
        # Zero-touch rejection: no set_epoch, no iterator, no source pull.
        raise ValueError(
            "Unsloth MLX VLM: train_on_responses_only streams are not "
            "covered by the prefetch producer yet; use "
            "streaming_prefetch_batches=0 for response-masked VLM streams."
        )
    if _distributed_rank_size(comm_group)[1] > 1:
        raise ValueError(
            "Unsloth MLX VLM: DDP training with an unsized streaming VLM "
            "source is not supported (every rank would re-consume the global "
            "stream). Use a sized dataset or single-process training; "
            "rank-owned lazy VLM dispatch is a planned follow-up."
        )
    if dataset_order == "torch_randperm":
        raise ValueError(
            "Unsloth MLX VLM: preserve_dataset_order / "
            "dataset_order='torch_randperm' requires a sized "
            "(`__len__`) dataset."
        )
    if dataset_order not in (None, "default", "sequential"):
        raise ValueError(f"Unsupported MLX VLM dataset_order: {dataset_order!r}")

    def _build_batch(items, batch_formatting_func):
        return _build_response_masked_vlm_batch(
            items, processor, config, max_seq_length, image_size,
            response_mask_fn=response_mask_fn,
            formatting_func=batch_formatting_func,
            ignore_token_ids=ignore_token_ids,
            completion_only_loss=completion_only_loss,
            yield_host_staged=yield_host_staged,
            reject_mlx_valued=reject_mlx_valued,
        )

    def _filter_stream_item(item):
        """Return a formatted trainable streaming row, or None to skip it.
        Synchronous response-masked filtering finalizes and runs the legacy
        closure; producer modes reject before reaching here."""
        if response_mask_fn is None:
            return item
        if yield_host_staged or reject_mlx_valued:
            # Producer-destined streams cannot run the consumer-side closure.
            raise ValueError(
                "Unsloth MLX VLM: train_on_responses_only streams are not "
                "covered by the prefetch producer yet; use "
                "streaming_prefetch_batches=0 for response-masked VLM "
                "streams."
            )
        if formatting_func is not None:
            item = formatting_func(item)
        batch_dict, is_prompt_completion = _build_response_masked_vlm_batch(
            [item], processor, config, max_seq_length, image_size,
            response_mask_fn=response_mask_fn,
            formatting_func=None,
            ignore_token_ids=ignore_token_ids,
            completion_only_loss=completion_only_loss,
            return_prompt_completion=True,
        )
        if is_prompt_completion:
            return item
        valid_rows = _vlm_trainable_label_rows(batch_dict)
        if valid_rows is not None and len(valid_rows) == 1 and not valid_rows[0]:
            return None
        return item

    batch_formatting_func = None if response_mask_fn is not None else formatting_func
    source_dataset = _mlx_lazy_text_source(dataset)
    set_epoch = getattr(source_dataset, "set_epoch", None)

    def _set_epoch(value):
        if callable(set_epoch):
            set_epoch(value)

    def _resume_replay_error():
        return RuntimeError(
            "Unsloth MLX VLM: this operation requires a replayable iterable "
            "source; a one-shot iterator cannot be replayed deterministically."
        )

    def _exhaustion_error():
        return RuntimeError(
            "Unsloth MLX VLM: one-shot streaming source is exhausted and "
            "cannot be replayed. Use a replayable iterable or reduce max_steps."
        )

    if require_replayable and isinstance(source_dataset, Iterator):
        raise _resume_replay_error()

    _set_epoch(0)
    current_iterator = iter(source_dataset)
    cached_next_iterator = None
    epoch = 0
    try:
        replayable, cached_next_iterator = _probe_lazy_replayability(
            source_dataset, current_iterator, set_epoch,
            require_replayable, _resume_replay_error,
        )
        while True:
            pending = []
            deferred_final = None
            yielded = False
            source_rows_seen = 0
            prepared_rows_seen = 0
            source_iter = iter(current_iterator)
            while True:
                if should_stop is not None and should_stop():
                    return
                try:
                    item = next(source_iter)
                except StopIteration:
                    break
                if should_stop is not None and should_stop():
                    return  # stop arrived during the blocking pull
                source_rows_seen += 1
                item = _filter_stream_item(item)
                if item is None:
                    if expected_rows_per_pass is not None:
                        raise ValueError(
                            "Unsloth MLX VLM: epoch training requires exactly "
                            "one trainable row per declared source row. Use "
                            "max_steps when rows are filtered."
                        )
                    continue
                prepared_rows_seen += 1
                if (
                    expected_rows_per_pass is not None
                    and source_rows_seen > expected_rows_per_pass
                ):
                    raise ValueError(
                        "Unsloth MLX VLM: the streaming source's declared "
                        "length does not match one trainable row per source "
                        "row. Use max_steps for filtered or expanding streams."
                    )
                pending.append(item)
                if len(pending) < batch_size:
                    continue
                if (
                    expected_rows_per_pass is not None
                    and prepared_rows_seen == expected_rows_per_pass
                ):
                    deferred_final = pending
                    pending = []
                    continue
                yielded = True
                yield _build_batch(pending, batch_formatting_func)
                pending = []

            if should_stop is not None and should_stop():
                return  # skip pass-end validation and flush on cooperative stop
            if expected_rows_per_pass is not None and (
                source_rows_seen != expected_rows_per_pass
                or prepared_rows_seen != expected_rows_per_pass
            ):
                raise ValueError(
                    "Unsloth MLX VLM: the streaming source's declared length "
                    "does not match one trainable row per source row. Use "
                    "max_steps for filtered or expanding streams."
                )
            if deferred_final is not None:
                yielded = True
                yield _build_batch(deferred_final, batch_formatting_func)
                deferred_final = None
            if pending:
                yielded = True
                yield _build_batch(pending, batch_formatting_func)
                pending = []

            exhausted_iterator = current_iterator
            current_iterator = None
            _close_mlx_owned_iterator(exhausted_iterator)
            if not yielded:
                raise ValueError(
                    "Unsloth MLX VLM: streaming dataset produced no trainable rows."
                )
            if replayable is False:
                raise _exhaustion_error()
            epoch += 1
            _set_epoch(epoch)
            if cached_next_iterator is not None:
                current_iterator = cached_next_iterator
                cached_next_iterator = None
                del exhausted_iterator
                continue
            try:
                candidate = iter(source_dataset)
            except Exception as exc:
                if replayable is True:
                    raise RuntimeError(
                        "Unsloth MLX VLM: replayable streaming source failed "
                        f"to create an iterator for epoch {epoch}: {exc}"
                    ) from exc
                raise _exhaustion_error() from exc
            if candidate is exhausted_iterator:
                raise _exhaustion_error()
            current_iterator = candidate
            replayable = True
            del exhausted_iterator
    finally:
        active_iterator = current_iterator
        current_iterator = None
        replay_iterator = cached_next_iterator
        cached_next_iterator = None
        cleanup_iterators = (
            (active_iterator,)
            if replay_iterator is active_iterator
            else (active_iterator, replay_iterator)
        )
        # Close every owned cursor without replacing an in-flight failure.
        for iterator in cleanup_iterators:
            try:
                _close_mlx_owned_iterator(iterator)
            except Exception:
                pass

def iterate_vlm_training_batches(dataset, processor, config, batch_size,
                                  max_seq_length, seed=42,
                                  response_mask_fn=None,
                                  formatting_func=None,
                                  dataset_order="default",
                                  completion_only_loss=None,
                                  image_size=None, comm_group=None,
                                  require_replayable=False,
                                  expected_rows_per_pass=None,
                                  prefetch_batches=0,
                                  prefetch_skip_batches=0,
                                  prefetch_control=None):
    """Streaming VLM batch generator using processor directly. Yields batch
    dicts with input_ids, pixel_values, attention_mask, and optionally labels."""
    import numpy as np

    image_size = _resolve_vlm_image_size(image_size, config, processor)
    ignore_token_ids = _get_vlm_ignore_token_ids(processor=processor, config=config)
    base_seed = _normalize_seed(seed)
    global_batch_size = _distributed_global_batch_size(batch_size, comm_group)

    def _build_batch(items, batch_formatting_func):
        """Build one VLM batch with the selected formatting function."""
        return _build_response_masked_vlm_batch(
            items,
            processor,
            config,
            max_seq_length,
            image_size,
            response_mask_fn=response_mask_fn,
            formatting_func=batch_formatting_func,
            ignore_token_ids=ignore_token_ids,
            completion_only_loss=completion_only_loss,
        )

    if _vlm_has_sized_index_space(dataset):
        if len(dataset) <= 0:
            raise ValueError("Unsloth MLX VLM: streaming dataset produced no rows.")
        base_indices = list(range(len(dataset)))
        total_removed = 0
        formatted_items = None
        if response_mask_fn is not None:
            base_indices, total_removed, formatted_items, _supervision = _filter_trainable_vlm_indices(
                dataset,
                base_indices,
                processor,
                config,
                max_seq_length,
                image_size,
                response_mask_fn,
                formatting_func=formatting_func,
                ignore_token_ids=ignore_token_ids,
                completion_only_loss=completion_only_loss,
            )
            if not base_indices and total_removed > 0:
                raise ValueError(
                    "Unsloth MLX VLM: no trainable rows remain after "
                    "train_on_responses_only masking. Check instruction_part / "
                    "response_part and max_seq_length."
                )
            if total_removed > 0:
                print(
                    f"Unsloth: Removed {total_removed} VLM samples where all "
                    f"labels were -100 after train_on_responses_only masking."
                )
        if not base_indices:
            raise ValueError("Unsloth MLX VLM: streaming dataset produced no rows.")

        def _item(idx):
            return formatted_items[idx] if formatted_items is not None else dataset[idx]

        batch_formatting_func = None if formatted_items is not None else formatting_func
        epoch = 0
        while True:
            if dataset_order == "torch_randperm":
                order = _torch_randperm_order(len(base_indices), base_seed + epoch)
                indices = [base_indices[i] for i in order]
            elif dataset_order == "sequential":
                indices = list(base_indices)
            elif dataset_order in (None, "default"):
                indices = list(base_indices)
                batch_indices = [
                    indices[i : i + global_batch_size]
                    for i in range(0, len(indices), global_batch_size)
                ]
                # Local RNG keeps order reproducible under `seed`; reseed per epoch.
                rng = np.random.default_rng(base_seed + epoch)
                order = rng.permutation(len(batch_indices))
                for b in order:
                    local_indices = _rank_slice_distributed_batch(
                        batch_indices[b],
                        batch_size,
                        comm_group=comm_group,
                        pad_source=indices,
                    )
                    if local_indices:
                        yield _build_batch(
                            [_item(idx) for idx in local_indices],
                            batch_formatting_func,
                        )
                epoch += 1
                continue
            else:
                raise ValueError(f"Unsupported MLX VLM dataset_order: {dataset_order!r}")
            for start in range(0, len(indices), global_batch_size):
                local_indices = _rank_slice_distributed_batch(
                    indices[start : start + global_batch_size],
                    batch_size,
                    comm_group=comm_group,
                    pad_source=indices,
                )
                if local_indices:
                    yield _build_batch(
                        [_item(idx) for idx in local_indices],
                        batch_formatting_func,
                    )
            epoch += 1
    else:
        prefetch_depth = _validate_streaming_prefetch(prefetch_batches)
        if prefetch_depth and _distributed_rank_size(comm_group)[1] == 1:
            # The shared producer stages; the VLM finalizer converts on the
            # consumer thread. Response-masked streams reject at iterator entry.
            prefetcher = _LazyTextPrefetcher(
                None,
                prefetch_depth,
                skip_batches=prefetch_skip_batches,
                finalize=_finalize_vlm_batch,
            )
            prefetcher._make_iterator = (
                lambda pf=prefetcher: _iterate_lazy_vlm_training_batches(
                    dataset, processor, config, batch_size, max_seq_length,
                    response_mask_fn=response_mask_fn,
                    formatting_func=formatting_func,
                    dataset_order=dataset_order,
                    completion_only_loss=completion_only_loss,
                    image_size=image_size,
                    comm_group=None,
                    require_replayable=require_replayable,
                    expected_rows_per_pass=expected_rows_per_pass,
                    ignore_token_ids=ignore_token_ids,
                    yield_host_staged=True,
                    reject_mlx_valued=True,
                    should_stop=pf._stop.is_set,
                )
            )
            if prefetch_control is not None:
                prefetch_control["prefetcher"] = prefetcher
            try:
                yield from prefetcher
            finally:
                prefetcher.close()
            return
        yield from _iterate_lazy_vlm_training_batches(
            dataset, processor, config, batch_size, max_seq_length,
            response_mask_fn=response_mask_fn,
            formatting_func=formatting_func,
            dataset_order=dataset_order,
            completion_only_loss=completion_only_loss,
            image_size=image_size,
            comm_group=comm_group,
            require_replayable=require_replayable,
            expected_rows_per_pass=expected_rows_per_pass,
            ignore_token_ids=ignore_token_ids,
        )


def _prepare_dataset(dataset, tokenizer, dataset_text_field="text",
                     formatting_func=None, chat_template=None,
                     model_name=None, model_type=None,
                     append_eos=True):
    """Wrap a HuggingFace dataset into mlx-lm's dataset classes.

    Uses CacheDataset from mlx_lm while leaving rendered text token-exact.

    If a formatting_func is provided, each item is pre-formatted into a
    ``{"text": ...}`` dict before wrapping.

    ``append_eos`` controls whether the tokenizer's EOS id is appended to
    each encoded row. Default True preserves the pre-PR behavior that
    delegated EOS appending to ``mlx_lm.tuner.datasets.TextDataset`` for
    direct MLX text fine-tuning callers (raw ``{"text": str}`` rows
    without already-rendered EOS). Unsloth passes False because its
    chat-template rendering already includes EOS.

    Returns:
        A CacheDataset ready for ``iterate_batches``.
    """
    from mlx_lm.tuner.datasets import CacheDataset

    normalize_mlx_chat_template(
        tokenizer,
        chat_template=chat_template,
        model_name=model_name,
        model_type=model_type,
        is_vlm=False,
        strict=False,
    )

    # Pre-format items into [{"text": str}, ...] so TextDataset can consume them.
    formatted = []
    for item in dataset:
        if formatting_func is not None:
            result = formatting_func(item)
            texts = collect_mlx_texts(
                tokenizer, result, dataset_text_field=dataset_text_field,
                is_vlm=False,
            )
        else:
            texts = collect_mlx_texts(
                tokenizer, item, dataset_text_field=dataset_text_field,
                is_vlm=False,
            )

        for text in texts:
            if text:
                formatted.append({"text": text})

    if not formatted:
        raise ValueError(
            f"No text data found. Provide a dataset with a '{dataset_text_field}' "
            "column, messages/conversations with a tokenizer chat_template, or "
            "a formatting_func that returns text."
        )

    _eos_id = getattr(tokenizer, "eos_token_id", None) if append_eos else None

    class _StudioTextDataset:
        """TextDataset variant. Optionally appends EOS (mlx-lm parity);
        Unsloth passes append_eos=False because chat templates already render it."""

        def __init__(self, data, tokenizer, text_key="text", eos_id=None):
            self._data = data
            self.tokenizer = tokenizer
            self.text_key = text_key
            self._eos_id = eos_id

        def process(self, item):
            encoded = encode_mlx_text(self.tokenizer, item[self.text_key])
            if (
                self._eos_id is not None
                and (not encoded or encoded[-1] != self._eos_id)
            ):
                encoded = list(encoded) + [int(self._eos_id)]
            return (encoded, 0)

        def __getitem__(self, idx):
            return self._data[idx]

        def __len__(self):
            return len(self._data)

    return CacheDataset(
        _StudioTextDataset(formatted, tokenizer, text_key="text", eos_id=_eos_id)
    )


def _create_default_text_plan(
    dataset,
    batch_size,
    max_seq_length,
    *,
    num_batches=None,
    seed=42,
):
    """Build the CPU equivalent of mlx-lm's finite text batch schedule."""
    schedule, cycle_length = _shuffled_full_batch_schedule(
        len(dataset),
        batch_size,
        sort_key=dataset.itemlen,
        num_batches=num_batches,
        seed=seed,
    )
    rows = _finite_text_rows(
        [dataset[index] for index in range(len(dataset))],
        with_offsets=True,
    )
    return FiniteTextBatchPlan(
        rows,
        schedule,
        cycle_length=cycle_length,
        max_seq_length=max_seq_length,
        pad_id=0,
        # Match mlx-lm iterate_batches padding (1 + 32*ceil(len/32)) so the
        # default text path keeps mlx-lm's causal-shift contract and bounded
        # signatures, like the distributed/streaming builders.
        minimum_width=2,
        pad_to_multiple=32,
        visit_policy="epoch_permute" if num_batches is None else "identity",
        visit_seed=seed,
    )


def _create_text_batch_plan(dataset, tokenizer, batch_size, max_seq_length,
                            num_batches=None, seed=42,
                            dataset_text_field="text", formatting_func=None,
                            chat_template=None, model_name=None,
                            model_type=None, append_eos=True,
                            completion_only_loss=None,
                            assistant_only_loss=False, comm_group=None,
                            distributed_pad_mode="cycle"):
    """Build a finite CPU-backed text batch plan.

    Uses iterate_batches from mlx_lm for efficient dynamic-padding batching:
    samples are sorted by length, grouped into batches, and padded to the
    max length within each batch (rounded up to the nearest multiple of 32),
    capped at max_seq_length.

    Tokenization is delegated to mlx_lm's TextDataset (appends EOS, etc.)
    so behaviour matches ``mlx_lm.lora`` exactly.

    In DDP, ``batch_size`` remains the local per-rank micro-batch size. The
    optional ``comm_group`` is used only to derive a global batch for sharding,
    then tail global batches are padded so every rank yields the same number
    of local batches.

    Public callers use :func:`create_batches`, which eagerly materializes this
    plan for compatibility. Finite training retains the plan and indexes it.
    """
    dataset = _ensure_reiterable_text_dataset(dataset)
    tokenized, saw_pretokenized = _prepare_pretokenized_text_dataset(
        dataset,
        completion_only_loss=completion_only_loss,
        assistant_only_loss=assistant_only_loss,
    )
    if saw_pretokenized:
        return _create_tokenized_text_plan(
            tokenized,
            batch_size,
            max_seq_length,
            num_batches=num_batches,
            seed=seed,
            pad_id=_mlx_text_pad_id(tokenizer),
        )
    if assistant_only_loss:
        _validate_mlx_text_assistant_only_dataset(dataset)

    if completion_only_loss is not False or assistant_only_loss:
        normalize_mlx_chat_template(
            tokenizer,
            chat_template=chat_template,
            model_name=model_name,
            model_type=model_type,
            is_vlm=False,
            strict=False,
        )
        tokenized = _prepare_labeled_text_dataset(
            dataset,
            tokenizer,
            dataset_text_field=dataset_text_field,
            formatting_func=formatting_func,
            append_eos=append_eos,
            completion_only_loss=completion_only_loss,
            assistant_only_loss=assistant_only_loss,
        )
        if tokenized:
            return _create_tokenized_text_plan(
                tokenized,
                batch_size,
                max_seq_length,
                num_batches=num_batches,
                seed=seed,
                pad_id=_mlx_text_pad_id(tokenizer),
            )
        if assistant_only_loss:
            raise ValueError(
                "Unsloth MLX: assistant_only_loss=True produced no "
                "assistant-labeled text rows."
            )
        if completion_only_loss is True:
            raise ValueError(
                "Unsloth MLX: text completion_only_loss=True requires "
                "prompt/completion rows."
            )
        if _prompt_completion_formatter_conflict(
            dataset, formatting_func, completion_only_loss
        ):
            raise ValueError(
                "Unsloth MLX: a formatting_func was provided for a prompt/completion "
                "dataset, which drops the completion boundary needed for the default "
                "completion-only loss. Apply your formatting before passing the "
                "dataset, or set completion_only_loss=False."
            )

    ds = _prepare_dataset(
        dataset, tokenizer, dataset_text_field, formatting_func,
        chat_template=chat_template,
        model_name=model_name,
        model_type=model_type,
        append_eos=append_eos,
    )

    if _distributed_rank_size(comm_group)[1] > 1:
        return _create_distributed_text_plan(
            ds, batch_size, max_seq_length,
            num_batches=num_batches,
            seed=seed,
            comm_group=comm_group,
            distributed_pad_mode=distributed_pad_mode,
            tokenizer=tokenizer,
        )
    return _create_default_text_plan(
        ds,
        batch_size,
        max_seq_length,
        num_batches=num_batches,
        seed=seed,
    )


def create_batches(dataset, tokenizer, batch_size, max_seq_length,
                   num_batches=None, seed=42, dataset_text_field="text",
                   formatting_func=None, chat_template=None,
                   model_name=None, model_type=None, append_eos=True,
                   completion_only_loss=None, assistant_only_loss=False,
                   comm_group=None, distributed_pad_mode="cycle"):
    """Pre-tokenize and eagerly batch a HuggingFace dataset for MLX."""
    return _create_text_batch_plan(
        dataset=dataset,
        tokenizer=tokenizer,
        batch_size=batch_size,
        max_seq_length=max_seq_length,
        num_batches=num_batches,
        seed=seed,
        dataset_text_field=dataset_text_field,
        formatting_func=formatting_func,
        chat_template=chat_template,
        model_name=model_name,
        model_type=model_type,
        append_eos=append_eos,
        completion_only_loss=completion_only_loss,
        assistant_only_loss=assistant_only_loss,
        comm_group=comm_group,
        distributed_pad_mode=distributed_pad_mode,
    ).materialize_all()


def _distributed_rank_size(comm_group=None):
    """Return ``(rank, world_size)`` for an optional MLX distributed group."""
    if comm_group is None:
        return 0, 1
    rank = int(comm_group.rank())
    world_size = int(comm_group.size())
    if world_size < 1:
        raise ValueError(f"Invalid MLX distributed world_size={world_size}.")
    if rank < 0 or rank >= world_size:
        raise ValueError(
            f"Invalid MLX distributed rank={rank} for world_size={world_size}."
        )
    return rank, world_size


def _distributed_global_batch_size(local_batch_size, comm_group=None):
    """Return the global micro-batch size implied by local batch and world."""
    _, world_size = _distributed_rank_size(comm_group)
    return int(local_batch_size) * world_size


def _rank_slice_distributed_batch(
    items,
    local_batch_size,
    comm_group=None,
    pad_source=None,
    pad_mode="cycle",
):
    """Return this rank's local slice from one global DDP micro-batch.

    Tail global batches are padded so every rank executes the same number of
    micro-batches and collectives stay aligned. Training uses ``cycle`` to keep
    full batches; eval can use ``empty`` so padded rows do not contribute tokens.
    """
    rank, world_size = _distributed_rank_size(comm_group)
    items = list(items)
    if world_size <= 1:
        return items

    target_size = int(local_batch_size) * world_size
    if target_size <= 0:
        raise ValueError("local_batch_size must be positive for distributed batching.")
    if pad_mode not in ("cycle", "empty"):
        raise ValueError(f"Unsupported distributed pad mode: {pad_mode!r}.")
    if len(items) > target_size:
        items = items[:target_size]
    if len(items) < target_size:
        if not items:
            return []
        if pad_mode == "empty":
            items.extend([None] * (target_size - len(items)))
        else:
            source = list(pad_source) if pad_source is not None else list(items)
            if not source:
                return []
            pad_pos = 0
            while len(items) < target_size:
                items.append(source[pad_pos % len(source)])
                pad_pos += 1
    return items[rank:target_size:world_size]


def _make_text_batch_from_items(batch_items, tokenizer, max_seq_length):
    """Tokenize raw rows and pad to the mlx-lm rule (finalized MLX batch)."""
    return _finalize_text_batch(
        _stage_text_batch_from_items(batch_items, tokenizer, max_seq_length)
    )


def _stage_text_batch_from_items(batch_items, tokenizer, max_seq_length, host_valued=True):
    """Build a text training batch from tokenized items."""
    valid_items = [item for item in batch_items if item is not None]
    with_offsets = bool(
        valid_items
        and isinstance(valid_items[0], tuple)
        and len(valid_items[0]) == 2
    )
    batch = []
    offsets = []
    lengths = []
    for item in batch_items:
        if item is None:
            batch.append([])
            offsets.append(0)
            lengths.append(0)
        elif with_offsets:
            ids, offset = item
            batch.append(ids)
            offsets.append(offset)
            lengths.append(len(ids))
        else:
            batch.append(item)
            offsets.append(0)
            lengths.append(len(item))
    if max(lengths) > max_seq_length:
        print(
            f"[WARNING] Some sequences are longer than {max_seq_length} tokens. "
            f"The longest sentence {max(lengths)} will be truncated to {max_seq_length}. "
            "Consider pre-splitting your data to save memory."
        )
    pad_id = getattr(tokenizer, "pad_token_id", None)
    pad_id = 0 if pad_id is None else int(pad_id)
    max_length = _finite_text_pad_width(
        max(lengths),
        pad_to_multiple=32,
        minimum_width=2,
        max_seq_length=max_seq_length,
    )
    batch_ids = []
    truncated_lengths = []
    for ids, length in zip(batch, lengths):
        truncated_length = min(length, max_seq_length)
        truncated_lengths.append(truncated_length)
        batch_ids.append(
            list(ids)[:truncated_length]
            + [pad_id] * (max_length - truncated_length)
        )
    return _HostStagedTextBatch(
        np.asarray(batch_ids, dtype=np.int32),
        np.asarray(list(zip(offsets, truncated_lengths)), dtype=np.int32),
        None,
        host_valued,
    )


def _mask_empty_vlm_padding_rows(batch_dict, empty_rows, processor=None):
    """Mask synthetic VLM eval padding labels so they do not affect metrics.

    Keep input_ids and attention_mask unchanged: VLM processors may have
    already attached row-aligned image features, and the forward still needs a
    valid text/vision row. Labels alone exclude the row from eval loss.
    """
    if not any(empty_rows):
        return batch_dict
    row_mask = np.asarray(empty_rows, dtype=bool)
    value = batch_dict.get("labels")
    if value is None or not hasattr(value, "shape"):
        return batch_dict
    if int(value.shape[0]) != int(row_mask.shape[0]):
        return batch_dict
    arr = np.asarray(
        value.tolist() if hasattr(value, "tolist") else value,
        dtype=np.int64,
    )
    arr[row_mask] = -100
    batch_dict["labels"] = mx.array(arr)
    return batch_dict


def _create_distributed_text_plan(
    dataset,
    batch_size,
    max_seq_length,
    *,
    num_batches=None,
    seed=42,
    comm_group=None,
    distributed_pad_mode="cycle",
    tokenizer=None,
):
    """Distributed variant of mlx-lm's length-sorted text batch iterator."""
    # Length is measured on the tokenized row. CacheDataset.itemlen returns
    # len(raw_row), which for the {"text": ...} rows _prepare_dataset produces
    # is the dict key count (1), not the token count, so it cannot gate the
    # two-token minimum below. Reading dataset[idx][0] yields the processed
    # token ids (mirroring _iter_tokenized_text_rows) and caches the processed
    # row on the CacheDataset, so the batch build below reuses it.
    len_fn = lambda idx: len(dataset[idx][0])
    # Drop rows with fewer than two tokens (no causal target). Length sorting
    # places these shortest rows first, so without this filter an all-short
    # first global microbatch would sum to zero supervised tokens and trip the
    # zero-supervised-token abort in trainer.py.
    idx = sorted((i for i in range(len(dataset)) if len_fn(i) >= 2), key=len_fn)
    if not idx:
        raise ValueError(
            "Unsloth MLX: distributed text dataset has no rows with at least 2 "
            "tokens (need an input and a causal target)."
        )

    global_batch_size = _distributed_global_batch_size(batch_size, comm_group)
    batch_idx = [
        idx[i : i + global_batch_size]
        for i in range(0, len(idx), global_batch_size)
    ]
    rng = np.random.RandomState(_normalize_seed(seed))

    schedule = []
    # Micro-batches in ONE dataset pass. Every permutation visits all global
    # batches and a local slice is non-empty regardless of visit order, so this
    # holds for every pass even if num_batches truncates the first one.
    cycle_length = sum(
        1 for group in batch_idx
        if _rank_slice_distributed_batch(
            group,
            batch_size,
            comm_group=comm_group,
            pad_source=idx,
            pad_mode=distributed_pad_mode,
        )
    )
    while True:
        indices = rng.permutation(len(batch_idx))
        for i in indices:
            local_idx = _rank_slice_distributed_batch(
                batch_idx[i],
                batch_size,
                comm_group=comm_group,
                pad_source=idx,
                pad_mode=distributed_pad_mode,
            )
            if not local_idx:
                continue
            schedule.append(tuple(local_idx))
            if num_batches is not None and len(schedule) >= num_batches:
                break
        if num_batches is not None and len(schedule) >= num_batches:
            break
        if num_batches is None:
            break

    rows = _finite_text_rows(
        [dataset[index] for index in range(len(dataset))],
        with_offsets=True,
    )
    pad_id = getattr(tokenizer, "pad_token_id", None)
    return FiniteTextBatchPlan(
        rows,
        schedule,
        cycle_length=cycle_length,
        max_seq_length=max_seq_length,
        pad_id=0 if pad_id is None else int(pad_id),
        minimum_width=2,
        pad_to_multiple=32,
        # Same normalized seed on every rank keeps DDP visit vectors aligned.
        visit_policy="epoch_permute" if num_batches is None else "identity",
        visit_seed=seed,
    )


def _create_distributed_text_batches(
    dataset,
    batch_size,
    max_seq_length,
    *,
    num_batches=None,
    seed=42,
    comm_group=None,
    distributed_pad_mode="cycle",
    tokenizer=None,
):
    """Eager compatibility wrapper for distributed text batching."""
    return _create_distributed_text_plan(
        dataset,
        batch_size,
        max_seq_length,
        num_batches=num_batches,
        seed=seed,
        comm_group=comm_group,
        distributed_pad_mode=distributed_pad_mode,
        tokenizer=tokenizer,
    ).materialize_all()


def _torch_randperm_order(length, seed):
    try:
        import torch
    except Exception as exc:
        raise ImportError(
            "Unsloth MLX: dataset_order='torch_randperm' requires torch so MLX "
            "Unsloth can mirror CUDA Unsloth batch order."
        ) from exc
    generator = torch.Generator()
    generator.manual_seed(3407 if seed is None else int(seed))
    return torch.randperm(length, generator=generator).tolist()


def _finite_epoch_batch_budget(cycle_length, num_epochs, grad_accum):
    """Translate fractional epochs into HF-style accumulation windows."""
    accum = max(1, int(grad_accum or 1))
    per_epoch = max(1, math.ceil(cycle_length / accum))
    budget = max(1, math.ceil(float(num_epochs) * per_epoch))
    whole, rem = divmod(budget, per_epoch)
    return whole * cycle_length + rem * accum


def _finite_row_schedule(
    row_count,
    batch_size,
    *,
    order_for_epoch,
    num_batches=None,
    num_epochs=None,
    grad_accum=None,
    comm_group=None,
):
    """Build a finite, epoch-bounded microbatch schedule from row indices."""
    global_batch_size = _distributed_global_batch_size(batch_size, comm_group)

    def batches_for_epoch(epoch):
        order = list(order_for_epoch(epoch))
        batches = []
        for start in range(0, row_count, global_batch_size):
            chunk = _rank_slice_distributed_batch(
                order[start : start + global_batch_size],
                batch_size,
                comm_group=comm_group,
                pad_source=order,
            )
            if chunk:
                batches.append(tuple(chunk))
        return tuple(batches)

    return _finite_batch_schedule(
        batches_for_epoch,
        num_batches=num_batches,
        num_epochs=num_epochs,
        grad_accum=grad_accum,
    )


def _finite_batch_schedule(
    batches_for_epoch,
    *,
    num_batches=None,
    num_epochs=None,
    grad_accum=None,
):
    """Build a finite horizon from already-bounded epoch microbatches."""
    first_batches = tuple(tuple(batch) for batch in batches_for_epoch(0))
    cycle_length = len(first_batches)
    if cycle_length == 0:
        return (), 0
    target = num_batches
    if target is None:
        target = (
            cycle_length
            if num_epochs is None
            else _finite_epoch_batch_budget(cycle_length, num_epochs, grad_accum)
        )
    schedule = []
    epoch = 0
    while len(schedule) < target:
        batches = (
            first_batches
            if epoch == 0
            else tuple(tuple(batch) for batch in batches_for_epoch(epoch))
        )
        if len(batches) != cycle_length:
            raise ValueError("finite epoch schedules must have a stable batch count")
        for batch in batches:
            schedule.append(batch)
            if len(schedule) >= target:
                break
        epoch += 1
    return tuple(schedule), cycle_length


def _create_ordered_text_plan(
    dataset,
    tokenizer,
    batch_size,
    max_seq_length,
    num_batches=None,
    seed=None,
    dataset_order="sequential",
    dataset_text_field="text",
    formatting_func=None,
    chat_template=None,
    model_name=None,
    model_type=None,
    num_epochs=None,
    grad_accum=None,
    append_eos=True,
    completion_only_loss=None,
    assistant_only_loss=False,
    comm_group=None,
):
    """Plan text batches with an explicit dataset order.

    Unsloth uses this to mirror CUDA's effective sampler stream without
    changing generic mlx-lm batching behavior.

    In DDP, ``batch_size`` remains local to each rank. ``comm_group`` expands
    the ordered stream into global micro-batches, pads the final global batch
    if needed, and returns only this rank's local slice.
    """

    labeled = False
    tokenized = []
    dataset = _ensure_reiterable_text_dataset(dataset)
    tokenized_pairs, saw_pretokenized = _prepare_pretokenized_text_dataset(
        dataset,
        completion_only_loss=completion_only_loss,
        assistant_only_loss=assistant_only_loss,
    )
    if saw_pretokenized:
        for ids, labels in tokenized_pairs:
            ids = list(ids)[:max_seq_length]
            labels = list(labels)[:max_seq_length] if labels is not None else None
            if len(ids) >= 2:
                tokenized.append((ids, labels))
        labeled = True
    elif assistant_only_loss:
        _validate_mlx_text_assistant_only_dataset(dataset)

    if not labeled and (completion_only_loss is not False or assistant_only_loss):
        normalize_mlx_chat_template(
            tokenizer,
            chat_template=chat_template,
            model_name=model_name,
            model_type=model_type,
            is_vlm=False,
            strict=False,
        )
        for ids, labels in _prepare_labeled_text_dataset(
            dataset,
            tokenizer,
            dataset_text_field=dataset_text_field,
            formatting_func=formatting_func,
            append_eos=append_eos,
            completion_only_loss=completion_only_loss,
            assistant_only_loss=assistant_only_loss,
        ):
            ids = list(ids)[:max_seq_length]
            labels = list(labels)[:max_seq_length]
            if len(ids) >= 2:
                tokenized.append((ids, labels))
        labeled = bool(tokenized)
        if completion_only_loss is True and not labeled:
            raise ValueError(
                "Unsloth MLX: text completion_only_loss=True requires "
                "prompt/completion rows."
            )
        if not labeled and _prompt_completion_formatter_conflict(
            dataset, formatting_func, completion_only_loss
        ):
            raise ValueError(
                "Unsloth MLX: a formatting_func was provided for a prompt/completion "
                "dataset, which drops the completion boundary needed for the default "
                "completion-only loss. Apply your formatting before passing the "
                "dataset, or set completion_only_loss=False."
            )

    if not labeled:
        ds = _prepare_dataset(
            dataset, tokenizer, dataset_text_field, formatting_func,
            chat_template=chat_template,
            model_name=model_name,
            model_type=model_type,
            append_eos=append_eos,
        )

        for row in ds:
            ids = row[0] if isinstance(row, (tuple, list)) else row
            ids = list(ids)[:max_seq_length]
            if len(ids) >= 2:
                tokenized.append(ids)

    if labeled:
        tokenized = [
            row for row in tokenized
            if _labeled_row_has_supervision(row[1], max_seq_length)
        ]

    if not tokenized:
        raise ValueError(
            "Unsloth MLX: ordered dataset produced no trainable token sequences "
            "(need at least two tokens after formatting/truncation)."
        )

    def make_order(epoch):
        base_seed = _normalize_seed(seed)
        if dataset_order == "torch_randperm":
            return _torch_randperm_order(len(tokenized), base_seed + epoch)
        if dataset_order not in (None, "sequential"):
            raise ValueError(f"Unsupported MLX dataset_order: {dataset_order!r}")
        return list(range(len(tokenized)))

    schedule, cycle_length = _finite_row_schedule(
        len(tokenized),
        batch_size,
        order_for_epoch=make_order,
        num_batches=num_batches,
        num_epochs=num_epochs,
        grad_accum=grad_accum,
        comm_group=comm_group,
    )

    if labeled:
        rows = _finite_text_rows(tokenized)
    else:
        rows = tuple(
            _FiniteTextRow(tuple(int(token) for token in input_ids))
            for input_ids in tokenized
        )
    pad_id = getattr(tokenizer, "pad_token_id", None)
    return FiniteTextBatchPlan(
        rows,
        schedule,
        cycle_length=cycle_length,
        max_seq_length=max_seq_length,
        pad_id=0 if pad_id is None else int(pad_id),
        minimum_width=2,
    )


def create_ordered_batches(dataset, tokenizer, batch_size, max_seq_length,
                           num_batches=None, seed=None, dataset_order="sequential",
                           dataset_text_field="text",
                           formatting_func=None, chat_template=None,
                           model_name=None, model_type=None,
                           num_epochs=None, grad_accum=None, append_eos=True,
                           completion_only_loss=None, assistant_only_loss=False,
                           comm_group=None):
    """Eagerly create text batches with an explicit dataset order."""
    return _create_ordered_text_plan(
        dataset=dataset,
        tokenizer=tokenizer,
        batch_size=batch_size,
        max_seq_length=max_seq_length,
        num_batches=num_batches,
        seed=seed,
        dataset_order=dataset_order,
        dataset_text_field=dataset_text_field,
        formatting_func=formatting_func,
        chat_template=chat_template,
        model_name=model_name,
        model_type=model_type,
        num_epochs=num_epochs,
        grad_accum=grad_accum,
        append_eos=append_eos,
        completion_only_loss=completion_only_loss,
        assistant_only_loss=assistant_only_loss,
        comm_group=comm_group,
    ).materialize_all()


def _iter_tokenized_text_rows(dataset, tokenizer, dataset_text_field="text",
                              formatting_func=None, append_eos=True,
                              max_seq_length=None):
    eos_id = getattr(tokenizer, "eos_token_id", None) if append_eos else None
    for item in dataset:
        if formatting_func is not None:
            item = formatting_func(item)
        texts = collect_mlx_texts(
            tokenizer,
            item,
            dataset_text_field=dataset_text_field,
            is_vlm=False,
        )
        for text in texts:
            ids = encode_mlx_text(tokenizer, text)
            if eos_id is not None and (not ids or ids[-1] != eos_id):
                ids = list(ids) + [int(eos_id)]
            if max_seq_length is not None:
                ids = list(ids)[:max_seq_length]
            if len(ids) >= 2:
                yield (ids, 0)


def _apply_mlx_response_mask_to_text_row(input_ids, labels, mask_fn, state=None):
    """Apply the CUDA response-marker closure to one tokenized text row."""
    mask_batch = {"input_ids": [list(input_ids)]}
    if labels is not None:
        # The shared CUDA closure accepts tensor-like labels with ``tolist``.
        mask_batch["labels"] = np.asarray([labels], dtype=np.int64)
    result = mask_fn(mask_batch)
    masked = result.get("labels") if isinstance(result, Mapping) else None
    if isinstance(masked, mx.array) and state is not None:
        if state.get("reject_mlx_valued"):
            raise ValueError(
                "Unsloth MLX: the response mask returned an MLX array; the "
                "prefetch producer must not convert MLX values off the "
                "consumer thread. Use streaming_prefetch_batches=0."
            )
        state["host_valued"] = False
    if hasattr(masked, "tolist"):
        masked = masked.tolist()
    if not isinstance(masked, (list, tuple)) or len(masked) != 1:
        raise ValueError(
            "Unsloth MLX: train_on_responses_only masking must return one "
            "labels row for each input_ids row."
        )
    masked = _coerce_mlx_token_list(masked[0], "labels", state=state)
    if len(masked) != len(input_ids):
        raise ValueError(
            "Unsloth MLX: train_on_responses_only labels must match "
            "input_ids length."
        )
    return list(input_ids), masked


def _iter_lazy_tokenized_text_rows(
    dataset,
    tokenizer,
    *,
    dataset_text_field="text",
    formatting_func=None,
    append_eos=True,
    completion_only_loss=None,
    assistant_only_loss=False,
    max_seq_length=None,
    response_mask_fn=None,
    state=None,
    include_source=False,
):
    """Normalize an unsized source one row at a time and lock its schema."""
    state = {} if state is None else state
    reject_rows = bool(state.get("reject_mlx_valued"))
    eos_id = getattr(tokenizer, "eos_token_id", None) if append_eos else None
    saw_usable_this_pass = False
    completion_labels_seen_this_pass = False

    def _output(source, input_ids, labels):
        if include_source:
            return source, input_ids, labels
        return input_ids, labels

    if completion_only_loss is not None:
        state.setdefault(
            "pretokenized_completion_only_loss",
            completion_only_loss,
        )

    def _require_assistant_conversation(row):
        if assistant_only_loss and not _is_mlx_sft_conversational_row(row):
            raise ValueError(
                "You set `assistant_only_loss=True`, but the dataset is not "
                "conversational. This option is only supported for "
                "conversational datasets."
            )

    def _validate_state(kind, labels, *, usable=True, completion_mode=False):
        nonlocal saw_usable_this_pass, completion_labels_seen_this_pass
        schema = state.get("schema")
        has_labels = labels is not None
        label_state = state.get("label_state")
        validate_locked_state = usable or saw_usable_this_pass
        if validate_locked_state and schema is not None and schema != kind:
            raise ValueError(
                "Unsloth MLX: pretokenized text rows with 'input_ids' cannot "
                "be mixed with rows that need text formatting/tokenization."
            )
        if (
            validate_locked_state
            and label_state is not None
            and label_state != has_labels
        ):
            raise ValueError(
                "Unsloth MLX: streaming text rows with labels or masks must "
                "not be mixed with rows that do not provide labels."
            )
        if completion_mode is True:
            if has_labels:
                completion_labels_seen_this_pass = True
            elif completion_labels_seen_this_pass:
                raise ValueError(
                    "Unsloth MLX: streaming text rows with labels or masks must "
                    "not be mixed with rows that do not provide labels."
                )
        if not usable:
            return
        if schema is None:
            state["schema"] = kind
        state.setdefault(
            "pretokenized_completion_only_loss",
            completion_mode,
        )
        if label_state is None:
            state["label_state"] = has_labels
        saw_usable_this_pass = True

    def _resolve_completion_mode(item_has_boundary, row_has_boundary=False):
        if completion_only_loss is not None:
            return completion_only_loss
        if item_has_boundary or row_has_boundary:
            # Resolve from the row's own shape: inheriting a plain-text row's
            # False would silently train prompt tokens, order-dependently.
            state["pretokenized_completion_only_loss"] = True
            return True
        if "pretokenized_completion_only_loss" in state:
            return state["pretokenized_completion_only_loss"]
        return False

    def _filtered_label_observation(
        completion_mode,
        has_completion_boundary=False,
    ):
        # Empty label-owned rows have no labels yet are not an unlabeled schema
        # transition; a non-None sentinel preserves that.
        label_owned = response_mask_fn is not None or assistant_only_loss or (
            completion_mode is True and has_completion_boundary
        )
        return () if label_owned else None

    for item in dataset:
        if reject_rows and _contains_mlx_values(item):
            # Reject before any parse, truthiness probe, or formatter call.
            _reject_mlx_valued_text("the dataset row")
        item_has_completion_boundary = (
            isinstance(item, Mapping)
            and "prompt" in item
            and "completion" in item
        )
        formatter_applied = False
        formatter_needs_completion_boundary = False
        source_rows = item if (
            isinstance(item, list) and not _looks_like_mlx_chat_messages(item)
        ) else [item]
        if not source_rows:
            # Validate the original logical row, before any formatter runs.
            source_rows = [None]
        source_has_input_ids = any(
            isinstance(row, Mapping) and "input_ids" in row
            for row in source_rows
        )
        if (
            assistant_only_loss
            and formatting_func is not None
            and "assistant_source_checked" not in state
        ):
            # Eager/SFT contract: validate the first original sample once, then
            # every formatter result below. Pretokenized rows bypass both.
            if not source_has_input_ids:
                _require_assistant_conversation(item)
            state["assistant_source_checked"] = True
        if formatting_func is not None and not source_has_input_ids:
            formatted = formatting_func(item)
            if reject_rows and _contains_mlx_values(formatted):
                # Formatters can introduce MLX values after the row scan.
                _reject_mlx_valued_text("the formatting function")
            formatter_applied = True
            formatter_needs_completion_boundary = (
                completion_only_loss is None
                and item_has_completion_boundary
            )
            source_rows = formatted if (
                isinstance(formatted, list)
                and not _looks_like_mlx_chat_messages(formatted)
            ) else [formatted]
        if not source_rows:
            # An empty formatter list expands to zero rows, not one invalid row.
            row_completion_only_loss = _resolve_completion_mode(
                item_has_completion_boundary
            )
            _validate_state(
                "raw",
                _filtered_label_observation(
                    row_completion_only_loss,
                    item_has_completion_boundary,
                ),
                usable=False,
                completion_mode=row_completion_only_loss,
            )
            continue

        for row in source_rows:
            prepared_source = item if isinstance(item, Mapping) else row
            row_has_completion_boundary = (
                isinstance(row, Mapping)
                and "prompt" in row
                and "completion" in row
            )
            row_completion_only_loss = _resolve_completion_mode(
                item_has_completion_boundary,
                row_has_completion_boundary,
            )
            tokenized = _tokenize_mlx_pretokenized_row(
                row,
                completion_only_loss=row_completion_only_loss,
                assistant_only_loss=assistant_only_loss,
                state=state,
            )
            if tokenized is not None:
                ids, labels = tokenized
                source_labels = labels
                if max_seq_length is not None:
                    ids = ids[:max_seq_length]
                    labels = (
                        labels[:max_seq_length] if labels is not None else None
                    )
                    source_labels = (
                        source_labels[:max_seq_length]
                        if source_labels is not None else None
                    )
                source_usable = (
                    len(ids) >= 2
                    and _labeled_row_has_supervision(source_labels, len(ids))
                )
                if response_mask_fn is not None:
                    ids, labels = _apply_mlx_response_mask_to_text_row(
                        ids, labels, response_mask_fn, state=state,
                    )
                usable = len(ids) >= 2 and _labeled_row_has_supervision(
                    labels, len(ids)
                )
                if (
                    formatter_applied
                    and row_completion_only_loss is True
                    and source_labels is None
                    and source_usable
                ):
                    if formatter_needs_completion_boundary:
                        raise ValueError(
                            "Unsloth MLX: a formatting_func was provided for a "
                            "prompt/completion dataset, which drops the completion "
                            "boundary needed for the default completion-only loss. "
                            "Apply your formatting before passing the dataset, or set "
                            "completion_only_loss=False."
                        )
                    raise ValueError(
                        "Unsloth MLX: formatting_func produced pretokenized "
                        "input_ids without labels or completion_mask while "
                        "completion-only loss is active."
                    )
                _validate_state(
                    "pretokenized",
                    source_labels,
                    usable=usable,
                    completion_mode=row_completion_only_loss,
                )
                if usable:
                    yield _output(prepared_source, ids, labels)
                continue

            _require_assistant_conversation(row)
            labeled = None
            if row_completion_only_loss is not False or assistant_only_loss:
                labeled = _tokenize_mlx_prompt_completion_row(
                    tokenizer,
                    row,
                    dataset_text_field=dataset_text_field,
                    append_eos=append_eos,
                    completion_only_loss=row_completion_only_loss,
                    assistant_only_loss=assistant_only_loss,
                    state=state,
                )
                if labeled is None and assistant_only_loss:
                    labeled = _tokenize_mlx_assistant_messages_row(tokenizer, row, state=state)
            if labeled is not None:
                ids, labels = labeled
                if max_seq_length is not None:
                    ids = ids[:max_seq_length]
                    labels = labels[:max_seq_length]
                if response_mask_fn is not None:
                    ids, labels = _apply_mlx_response_mask_to_text_row(
                        ids, labels, response_mask_fn, state=state,
                    )
                usable = len(ids) >= 2 and _labeled_row_has_supervision(
                    labels, len(ids)
                )
                _validate_state(
                    "raw",
                    labels,
                    usable=usable,
                    completion_mode=row_completion_only_loss,
                )
                if usable:
                    yield _output(prepared_source, ids, labels)
                continue
            if assistant_only_loss:
                raise ValueError(
                    "You set `assistant_only_loss=True`, but the dataset is not "
                    "conversational. This option is only supported for "
                    "conversational datasets."
                )
            texts = None
            if formatter_applied:
                texts = collect_mlx_texts(
                    tokenizer,
                    row,
                    dataset_text_field=dataset_text_field,
                    is_vlm=False,
                )
                if not texts:
                    _validate_state(
                        "raw",
                        _filtered_label_observation(
                            row_completion_only_loss,
                            item_has_completion_boundary
                            or row_has_completion_boundary,
                        ),
                        usable=False,
                        completion_mode=row_completion_only_loss,
                    )
                    continue

            if texts is None:
                texts = collect_mlx_texts(
                    tokenizer,
                    row,
                    dataset_text_field=dataset_text_field,
                    is_vlm=False,
                )
            if not texts:
                _validate_state(
                    "raw",
                    _filtered_label_observation(
                        row_completion_only_loss,
                        item_has_completion_boundary
                        or row_has_completion_boundary,
                    ),
                    usable=False,
                    completion_mode=row_completion_only_loss,
                )
                continue
            for text in texts:
                ids = list(encode_mlx_text(tokenizer, text, state=state))
                if eos_id is not None and (not ids or ids[-1] != eos_id):
                    ids.append(int(eos_id))
                if max_seq_length is not None:
                    ids = ids[:max_seq_length]
                source_usable = len(ids) >= 2
                labels = None
                if response_mask_fn is not None:
                    ids, labels = _apply_mlx_response_mask_to_text_row(
                        ids, None, response_mask_fn, state=state,
                    )
                usable = len(ids) >= 2 and _labeled_row_has_supervision(
                    labels, len(ids)
                )
                if (
                    source_usable
                    and formatter_needs_completion_boundary
                    and row_completion_only_loss is True
                ):
                    raise ValueError(
                        "Unsloth MLX: a formatting_func was provided for a "
                        "prompt/completion dataset, which drops the completion "
                        "boundary needed for the default completion-only loss. "
                        "Apply your formatting before passing the dataset, or set "
                        "completion_only_loss=False."
                    )
                if source_usable and row_completion_only_loss is True:
                    raise ValueError(
                        "Unsloth MLX: text completion_only_loss=True requires "
                        "prompt/completion rows for streaming text training."
                    )
                _validate_state(
                    "raw",
                    labels,
                    usable=usable,
                    completion_mode=row_completion_only_loss,
                )
                if usable:
                    yield _output(prepared_source, ids, labels)


def _close_mlx_owned_iterator(iterator):
    """Close an iterator owned by the lazy text pipeline when supported."""
    if iterator is None:
        return
    close = getattr(iterator, "close", None)
    if callable(close):
        close()



def _probe_lazy_replayability(source_dataset, current_iterator, set_epoch,
                              require_replayable, resume_error):
    """Classify a lazy source's replayability; prove it when resume needs it.

    Returns ``(replayable, cached_next_iterator)``; ``replayable`` is True /
    False / None (unknown until first restart), and the cached proven-fresh
    traversal is retained only for sources without ``set_epoch`` (epoch-aware
    sources recreate after ``set_epoch`` advances).
    """
    if isinstance(source_dataset, Iterator):
        replayable = False
    elif _is_mlx_hf_iterable_text_source(source_dataset):
        replayable = True
    else:
        replayable = None
    cached_next_iterator = None
    if require_replayable:
        if replayable is False:
            raise resume_error()
        if replayable is None:
            try:
                candidate = iter(source_dataset)
            except Exception as exc:
                raise resume_error() from exc
            if candidate is current_iterator:
                raise resume_error()
            if not callable(set_epoch):
                cached_next_iterator = candidate
            else:
                _close_mlx_owned_iterator(candidate)
            replayable = True
    return replayable, cached_next_iterator



def _validate_streaming_prefetch(value):
    """Validate streaming_prefetch_batches before source consumption."""
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(
            "Unsloth MLX: streaming_prefetch_batches must be an integer >= 0 "
            f"(got {value!r})."
        )
    if value < 0:
        raise ValueError(
            "Unsloth MLX: streaming_prefetch_batches must be >= 0 "
            f"(got {value})."
        )
    return value


_PREFETCH_ITEM = "item"
_PREFETCH_END = "end"
_PREFETCH_ERROR = "error"


class _LazyTextPrefetcher:
    """Bounded single-producer prefetch over host-staged text batches.

    The producer thread owns source consumption and host staging; MLX
    finalization runs only on the consumer thread. A queue slot is reserved
    BEFORE staging each batch so read-ahead is exactly the configured depth.
    Cancellation is cooperative, and a bounded join that times out marks the
    prefetcher ORPHANED; while the orphan lives the trainer refuses to reuse the
    shared preprocessing objects.
    """

    _JOIN_TIMEOUT = 5.0
    _QUIESCE_TIMEOUT = 30.0

    def __init__(self, make_iterator, depth, skip_batches=0,
                 finalize=None, include_epoch=False):
        self._make_iterator = make_iterator
        self._depth = int(depth)
        self._skip_batches = int(skip_batches)
        self._finalize = finalize or _finalize_text_batch
        self._include_epoch = include_epoch
        self._slots = threading.BoundedSemaphore(self._depth)
        self._envelopes = _queue_module.Queue()
        self._stop = threading.Event()
        self._pause = threading.Event()
        self._quiescent = threading.Event()
        self._ready = threading.Event()
        self._done = threading.Event()
        self._thread = None
        self.orphaned = False
        self._closed = False
        self._lifecycle_lock = threading.Lock()
        self._close_lock = threading.Lock()

    # -- producer side ----------------------------------------------------
    def _run(self):
        iterator = None
        try:
            iterator = self._make_iterator()
            for _ in range(self._skip_batches):
                if self._stop.is_set():
                    return
                try:
                    next(iterator)  # resume fast-forward on the producer thread
                except StopIteration:
                    if self._stop.is_set():
                        return  # cooperative stop during skip, not exhaustion
                    raise RuntimeError(
                        "Unsloth: streaming dataset exhausted while "
                        "fast-forwarding to the resume position. Dataset may "
                        "be shorter than the killed run consumed."
                    ) from None
            self._ready.set()
            while not self._stop.is_set():
                if self._pause.is_set():
                    self._quiescent.set()
                    while self._pause.is_set() and not self._stop.is_set():
                        time.sleep(0.005)
                    self._quiescent.clear()
                    continue
                if not self._slots.acquire(timeout=0.05):
                    continue  # queue full: stay responsive to stop/pause
                try:
                    staged = next(iterator)
                except StopIteration:
                    self._slots.release()
                    self._envelopes.put((_PREFETCH_END, None))
                    return
                except BaseException as exc:  # positioned via FIFO envelope
                    self._slots.release()
                    self._envelopes.put((_PREFETCH_ERROR, exc))
                    return
                self._envelopes.put((_PREFETCH_ITEM, staged))
        except BaseException as exc:
            self._envelopes.put((_PREFETCH_ERROR, exc))
        finally:
            self._ready.set()
            try:
                if iterator is not None:
                    try:
                        _close_mlx_owned_iterator(iterator)
                    except Exception:
                        pass
            finally:
                # quiesce() treats _done as proof the thread is finished with
                # the shared objects, so publish it only after cleanup.
                self._done.set()

    def _ensure_started(self):
        with self._lifecycle_lock:
            # One lock covers the closed check and thread publication, so a
            # concurrent close() cannot report "clean" then see a new producer.
            if self._closed or self._stop.is_set():
                raise StopIteration
            if self._thread is None:
                self._thread = threading.Thread(
                    target=self._run, name="unsloth-mlx-prefetch", daemon=True,
                )
                self._thread.start()
        while not self._ready.wait(timeout=0.1):
            if self._closed or self._stop.is_set():
                raise StopIteration

    # -- consumer side ----------------------------------------------------
    def __iter__(self):
        return self

    def __next__(self):
        self._ensure_started()
        while True:
            try:
                kind, payload = self._envelopes.get(timeout=0.5)
            except _queue_module.Empty:
                if self._stop.is_set():
                    raise StopIteration
                continue
            break
        if kind == _PREFETCH_ITEM:
            self._slots.release()
            if self._include_epoch:
                staged, epoch = payload
                return self._finalize(staged), epoch
            return self._finalize(payload)
        if kind == _PREFETCH_END:
            raise StopIteration
        raise payload

    # -- lifecycle --------------------------------------------------------
    def quiesce(self):
        """RUNNING -> PAUSE_REQUESTED -> QUIESCENT; bounded, actionable."""
        if self._thread is None or not self._thread.is_alive():
            return
        self._pause.set()
        deadline = time.monotonic() + self._QUIESCE_TIMEOUT
        while True:
            if self._quiescent.wait(timeout=0.05):
                return
            if self._done.is_set():
                return  # a terminated producer is trivially quiescent
            if time.monotonic() >= deadline:
                self._pause.clear()
                raise RuntimeError(
                    "Unsloth MLX: the prefetch producer did not quiesce (it "
                    "may be blocked inside the tokenizer or source). Use "
                    "streaming_prefetch_batches=0 for this run."
                )

    def resume(self):
        self._pause.clear()

    def close(self):
        """Join the producer, then release any queued batches once it is
        confirmed dead. Terminal, idempotent, safe under concurrent callers.
        Returns True when the producer terminated (queue drained), False when it
        overran the join and is a live orphan. Join, classification, and drain
        run under one lock, so a True return guarantees the queue was drained
        before it was reported and no concurrent closer can see it half-drained.
        ``orphaned`` is set conservatively before the join, so an interrupted
        join leaves a live producer classified as an orphan."""
        # Conservative orphan up front: an interrupt during the lock, join, or
        # drain then leaves the producer unresolved rather than falsely clean.
        self.orphaned = True
        with self._lifecycle_lock:
            self._stop.set()
            self._pause.clear()
            self._closed = True
            thread = self._thread
        with self._close_lock:
            if thread is not None and thread.is_alive():
                thread.join(timeout=self._JOIN_TIMEOUT)
            terminated = thread is None or not thread.is_alive()
            if terminated:
                # A joined-dead thread never writes again, so this cannot lose
                # a batch. Clear the flag only after the drain, so an interrupt
                # mid-drain still leaves a conservative orphan.
                self._drain_envelopes()
                self.orphaned = False
            return terminated

    def _drain_envelopes(self):
        """Discard queued batches so their payloads (device tensors for opaque
        VLM outputs) are released at close instead of being retained until the
        consumer generator is collected."""
        while True:
            try:
                self._envelopes.get_nowait()
            except _queue_module.Empty:
                return

    def orphan_alive(self):
        return self.orphaned and self._thread is not None and self._thread.is_alive()


def _validate_streaming_length_window(value):
    """Validate streaming_text_length_window_batches before source consumption."""
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(
            "Unsloth MLX: streaming_text_length_window_batches must be an "
            f"integer >= 1 (got {value!r})."
        )
    if value < 1:
        raise ValueError(
            "Unsloth MLX: streaming_text_length_window_batches must be >= 1 "
            f"(got {value})."
        )
    return value


def _lazy_window_sort_key(item, max_seq_length):
    """Window grouping key: exact truncated prepared-token length."""
    if item is None:
        return 0
    return min(len(item[0]), max_seq_length)


def _window_batch_permutation(seed, epoch, window_ordinal, count):
    """Deterministic batch-order permutation for one flushed window."""
    mix = (int(seed) * 1_000_003 + int(epoch) * 9_973 + int(window_ordinal)) % (2 ** 32)
    return np.random.RandomState(mix).permutation(count)


def _iterate_lazy_text_training_batches(
    dataset,
    tokenizer,
    batch_size,
    max_seq_length,
    *,
    dataset_text_field="text",
    formatting_func=None,
    dataset_order="default",
    append_eos=True,
    completion_only_loss=None,
    assistant_only_loss=False,
    response_mask_fn=None,
    comm_group=None,
    require_replayable=False,
    repeat=True,
    distributed_pad_mode="cycle",
    expected_rows_per_pass=None,
    include_epoch=False,
    length_window_batches=1,
    window_seed=0,
    yield_host_staged=False,
    reject_mlx_valued=False,
    should_stop=None,
):
    """Yield text batches without materializing an unsized source.

    ``sequential`` order and ``length_window_batches=1`` emit exact source
    order. Default order with a window > 1 pools that many global micro-batches
    of trainable rows, stable-sorts them by truncated prepared-token length, and
    emits the full chunks in a seeded deterministic permutation (partial chunk
    last). Custom replayable sources must return independent fresh traversals
    from ``iter(source)``; resume validation may create one non-consuming
    iterator ahead of the serving iterator.
    """
    if dataset_order == "torch_randperm":
        raise ValueError(
            "Unsloth MLX: dataset_order='torch_randperm' is not supported for "
            "an unsized streaming text source."
        )
    if dataset_order not in (None, "default", "sequential"):
        raise ValueError(f"Unsupported MLX dataset_order: {dataset_order!r}")

    length_window = _validate_streaming_length_window(length_window_batches)
    if dataset_order == "sequential":
        # Sequential contract: exact source order, length grouping off.
        length_window = 1
    window_seed = _normalize_seed(window_seed)
    # Cycle padding only feeds direct multi-rank slicing; single-process and
    # rank-0 owner iterators must not retain a pass-long first batch.
    needs_padding_source = _distributed_rank_size(comm_group)[1] > 1

    prepared_view = (
        dataset if isinstance(dataset, _MLXIterableTokenizedDatasetView) else None
    )
    if prepared_view is not None:
        tokenizer = prepared_view._tokenizer
    source_dataset = _mlx_lazy_text_source(dataset)
    global_batch_size = _distributed_global_batch_size(batch_size, comm_group)
    state = {"reject_mlx_valued": True} if reject_mlx_valued else {}
    epoch = 0
    set_epoch = getattr(source_dataset, "set_epoch", None)

    def _set_epoch(value):
        if callable(set_epoch):
            set_epoch(value)

    def _resume_replay_error():
        return RuntimeError(
            "Unsloth MLX: this operation requires a replayable iterable text "
            "source; a one-shot iterator cannot be replayed deterministically."
        )

    def _exhaustion_error():
        return RuntimeError(
            "Unsloth MLX: one-shot streaming text source is exhausted and "
            "cannot be replayed. Use a replayable iterable or reduce max_steps."
        )

    if require_replayable and isinstance(source_dataset, Iterator):
        raise _resume_replay_error()

    _set_epoch(0)
    current_iterator = iter(source_dataset)
    cached_next_iterator = None
    try:
        replayable, cached_next_iterator = _probe_lazy_replayability(
            source_dataset, current_iterator, set_epoch,
            require_replayable, _resume_replay_error,
        )

        def _make_batch(local_items):
            if state.get("schema") == "raw" and state.get("label_state") is False:
                return _stage_text_batch_from_items(
                    [
                        None if item is None else item[0]
                        for item in local_items
                    ],
                    tokenizer,
                    max_seq_length,
                    host_valued=state.get("host_valued", True),
                )
            return _stage_tokenized_text_batch(
                local_items,
                max_seq_length,
                pad_id=_mlx_text_pad_id(tokenizer),
                labels_expected=state.get("label_state"),
                host_valued=state.get("host_valued", True),
            )

        def _yield_value(local_items):
            staged = _make_batch(local_items)
            batch = staged if yield_host_staged else _finalize_text_batch(staged)
            return (batch, epoch) if include_epoch else batch

        while True:
            pending = []
            deferred_final = None
            padding_source = []
            yielded = False
            source_rows_seen = 0
            prepared_rows_seen = 0
            window_rows = []
            window_ordinal = 0

            def _flush_window():
                # Stable sort by truncated length, chunk, then seeded-permute
                # the FULL chunks only, so a partial chunk always emits last.
                nonlocal window_rows, window_ordinal, yielded
                if not window_rows:
                    return
                order = sorted(
                    range(len(window_rows)),
                    key=lambda i: (
                        _lazy_window_sort_key(window_rows[i], max_seq_length),
                        i,
                    ),
                )
                chunks = [
                    [window_rows[i] for i in order[start:start + global_batch_size]]
                    for start in range(0, len(order), global_batch_size)
                ]
                full = len(chunks)
                if chunks and len(chunks[-1]) < global_batch_size:
                    full -= 1
                emit = list(_window_batch_permutation(
                    window_seed, epoch, window_ordinal, full,
                )) + list(range(full, len(chunks)))
                window_ordinal += 1
                window_rows = []
                for chunk_index in emit:
                    # Release each chunk as emitted to stay within the window.
                    chunk = chunks[chunk_index]
                    chunks[chunk_index] = None
                    local_items = _rank_slice_distributed_batch(
                        chunk,
                        batch_size,
                        comm_group=comm_group,
                        pad_source=padding_source,
                        pad_mode=distributed_pad_mode,
                    )
                    chunk = None
                    yielded = True
                    yield _yield_value(local_items)
                    local_items = None

            def _tokenized_rows(source):
                if prepared_view is not None:
                    return prepared_view._iter_tokenized_rows(
                        source, state=state,
                    )
                return _iter_lazy_tokenized_text_rows(
                    source,
                    tokenizer,
                    dataset_text_field=dataset_text_field,
                    formatting_func=formatting_func,
                    append_eos=append_eos,
                    completion_only_loss=completion_only_loss,
                    assistant_only_loss=assistant_only_loss,
                    max_seq_length=max_seq_length,
                    response_mask_fn=response_mask_fn,
                    state=state,
                )

            def _exactly_one_prepared_row_per_source():
                nonlocal source_rows_seen
                for item in pass_source:
                    source_rows_seen += 1
                    if source_rows_seen > expected_rows_per_pass:
                        raise ValueError(
                            "Unsloth MLX: epoch training requires exactly one "
                            "trainable text row per declared source row. Use "
                            "max_steps when the source exceeds its declared length."
                        )
                    prepared = _tokenized_rows((item,))
                    missing = object()
                    first = next(prepared, missing)
                    extra = next(prepared, missing)
                    _close_mlx_owned_iterator(prepared)
                    if first is missing or extra is not missing:
                        raise ValueError(
                            "Unsloth MLX: epoch training requires exactly one "
                            "trainable text row per declared source row. Use "
                            "max_steps when rows expand or are filtered."
                        )
                    yield first

            def _stoppable(source):
                # Cancellation lands between source rows: checked before each
                # pull (so a stop costs no extra blocking read) and after it.
                iterator = iter(source)
                while True:
                    if should_stop():
                        return
                    try:
                        source_item = next(iterator)
                    except StopIteration:
                        return
                    if should_stop():
                        return
                    yield source_item

            pass_source = (
                _stoppable(current_iterator)
                if should_stop is not None else current_iterator
            )
            row_iterator = (
                _exactly_one_prepared_row_per_source()
                if expected_rows_per_pass is not None
                else _tokenized_rows(pass_source)
            )
            rows_pending = iter(row_iterator)
            while True:
                if should_stop is not None and should_stop():
                    return
                try:
                    row = next(rows_pending)
                except StopIteration:
                    break
                prepared_rows_seen += 1
                if (
                    expected_rows_per_pass is not None
                    and (
                        source_rows_seen != prepared_rows_seen
                        or source_rows_seen > expected_rows_per_pass
                    )
                ):
                    raise ValueError(
                        "Unsloth MLX: epoch training requires exactly one "
                        "trainable text row per declared source row. Use "
                        "max_steps when rows expand or are filtered."
                    )
                if needs_padding_source and len(padding_source) < global_batch_size:
                    padding_source.append(row)
                pending.append(row)
                if len(pending) < global_batch_size:
                    continue
                if length_window > 1:
                    window_rows.extend(pending)
                    pending = []
                    if len(window_rows) >= length_window * global_batch_size and (
                        expected_rows_per_pass is None
                        or prepared_rows_seen < expected_rows_per_pass
                    ):
                        yield from _flush_window()
                    continue
                if (
                    expected_rows_per_pass is not None
                    and prepared_rows_seen == expected_rows_per_pass
                ):
                    deferred_final = pending
                    pending = []
                    continue
                local_items = _rank_slice_distributed_batch(
                    pending,
                    batch_size,
                    comm_group=comm_group,
                    pad_source=padding_source,
                    pad_mode=distributed_pad_mode,
                )
                yielded = True
                yield _yield_value(local_items)
                pending = []

            if should_stop is not None and should_stop():
                return  # cooperative stop: skip pass-end flush and validation
            if expected_rows_per_pass is not None and (
                source_rows_seen != expected_rows_per_pass
                or prepared_rows_seen != expected_rows_per_pass
            ):
                raise ValueError(
                    "Unsloth MLX: the streaming text source's declared length "
                    "does not match one trainable row per source row. Use "
                    "max_steps for filtered or expanding streams."
                )

            if length_window > 1:
                window_rows.extend(pending)
                pending = []
                yield from _flush_window()

            if deferred_final is not None:
                local_items = _rank_slice_distributed_batch(
                    deferred_final,
                    batch_size,
                    comm_group=comm_group,
                    pad_source=padding_source,
                    pad_mode=distributed_pad_mode,
                )
                yielded = True
                yield _yield_value(local_items)

            if pending:
                local_items = _rank_slice_distributed_batch(
                    pending,
                    batch_size,
                    comm_group=comm_group,
                    pad_source=padding_source,
                    pad_mode=distributed_pad_mode,
                )
                yielded = True
                yield _yield_value(local_items)

            exhausted_iterator = current_iterator
            current_iterator = None
            _close_mlx_owned_iterator(exhausted_iterator)
            if not yielded:
                raise ValueError(
                    "Unsloth MLX: streaming text source produced no trainable rows."
                )
            if not repeat:
                return
            if replayable is False:
                raise _exhaustion_error()
            epoch += 1
            _set_epoch(epoch)
            if cached_next_iterator is not None:
                current_iterator = cached_next_iterator
                cached_next_iterator = None
                del exhausted_iterator
                continue
            try:
                candidate = iter(source_dataset)
            except Exception as exc:
                if replayable is True:
                    raise RuntimeError(
                        "Unsloth MLX: replayable streaming text source failed to "
                        f"create an iterator for epoch {epoch}: {exc}"
                    ) from exc
                raise _exhaustion_error() from exc
            if candidate is exhausted_iterator:
                raise _exhaustion_error()
            current_iterator = candidate
            replayable = True
            del exhausted_iterator
    finally:
        active_iterator = current_iterator
        current_iterator = None
        replay_iterator = cached_next_iterator
        cached_next_iterator = None
        cleanup_iterators = (
            (active_iterator,)
            if replay_iterator is active_iterator
            else (active_iterator, replay_iterator)
        )
        # Close every owned cursor without replacing an in-flight failure. The
        # epoch-boundary close above stays strict and still surfaces errors.
        for iterator in cleanup_iterators:
            try:
                _close_mlx_owned_iterator(iterator)
            except Exception:
                pass


def _pad_dispatched_text_batch(
    batch,
    target_size,
    *,
    pad_id,
    pad_mode,
    cycle_source=None,
):
    """Pad one owner-built global text batch before rank dispatch."""
    input_ids, lengths, labels = batch
    row_count = int(input_ids.shape[0])
    if row_count >= target_size:
        return input_ids[:target_size], lengths[:target_size], (
            None if labels is None else labels[:target_size]
        )
    if row_count == 0:
        raise ValueError("Unsloth MLX: cannot dispatch an empty text batch.")
    if pad_mode not in ("cycle", "empty"):
        raise ValueError(f"Unsupported distributed pad mode: {pad_mode!r}.")

    missing = target_size - row_count
    if pad_mode == "empty":
        padded_ids = mx.full(
            (missing, int(input_ids.shape[1])), int(pad_id), dtype=input_ids.dtype,
        )
        padded_lengths = mx.zeros(
            (missing, int(lengths.shape[1])), dtype=lengths.dtype,
        )
        padded_labels = (
            None
            if labels is None
            else mx.full(
                (missing, int(labels.shape[1])), -100, dtype=labels.dtype,
            )
        )
    else:
        source_ids, source_lengths, source_labels = cycle_source or batch
        if (labels is None) != (source_labels is None):
            raise ValueError(
                "Unsloth MLX: streaming text labels changed within one pass."
            )
        source_rows = int(source_ids.shape[0])
        indices = mx.array(
            [index % source_rows for index in range(missing)], dtype=mx.int32,
        )
        padded_ids = mx.take(source_ids, indices, axis=0)
        padded_lengths = mx.take(source_lengths, indices, axis=0)
        padded_labels = (
            None
            if source_labels is None
            else mx.take(source_labels, indices, axis=0)
        )

    width = max(int(input_ids.shape[1]), int(padded_ids.shape[1]))

    def _pad_width(value, fill):
        missing_width = width - int(value.shape[1])
        if missing_width <= 0:
            return value
        padding = mx.full(
            (int(value.shape[0]), missing_width), fill, dtype=value.dtype,
        )
        return mx.concatenate((value, padding), axis=1)

    input_ids = _pad_width(input_ids, int(pad_id))
    padded_ids = _pad_width(padded_ids, int(pad_id))
    if labels is not None:
        labels = _pad_width(labels, -100)
        padded_labels = _pad_width(padded_labels, -100)
    return (
        mx.concatenate((input_ids, padded_ids), axis=0),
        mx.concatenate((lengths, padded_lengths), axis=0),
        None
        if labels is None
        else mx.concatenate((labels, padded_labels), axis=0),
    )


def _iterate_dispatched_lazy_text_training_batches(
    dataset,
    tokenizer,
    batch_size,
    max_seq_length,
    *,
    comm_group,
    distributed_pad_mode="cycle",
    **kwargs,
):
    """Dispatch rank-0-owned lazy text batches to all data-parallel ranks.

    The owner retains the first global batch of the pass only to keep legacy
    cycle-padding deterministic. Non-owner ranks never touch the source, so the
    supplied source is interpreted as the global, unsharded stream.
    """
    rank, world_size = _distributed_rank_size(comm_group)
    target_size = int(batch_size) * world_size
    if target_size <= 0:
        raise ValueError("batch_size must be positive for distributed batching.")
    if distributed_pad_mode not in ("cycle", "empty"):
        raise ValueError(
            f"Unsupported distributed pad mode: {distributed_pad_mode!r}."
        )

    owner_iterator = None
    owner_contract_error = None
    owner_tokenizer = tokenizer
    if rank == 0:
        try:
            if isinstance(dataset, _MLXIterableTokenizedDatasetView):
                owner_tokenizer = dataset._tokenizer
            source_distribution = getattr(
                _mlx_lazy_text_source(dataset), "_distributed", None,
            )
            if int(getattr(source_distribution, "world_size", 1)) > 1:
                owner_contract_error = ValueError(
                    "Unsloth MLX: distributed lazy text dispatch requires the "
                    "global unsharded Hugging Face iterable. Pass the source "
                    "before split_dataset_by_node(); MLX owns rank partitioning."
                )
        except BaseException as exc:
            # Defer even interrupts: peers block in the dispatch collective
            # below, so rank 0 must broadcast the failure status before it
            # unwinds. Re-raised through the loop's rank-0 path.
            owner_contract_error = exc
        owner_iterator = _iterate_lazy_text_training_batches(
            dataset,
            owner_tokenizer,
            target_size,
            max_seq_length,
            comm_group=None,
            distributed_pad_mode=distributed_pad_mode,
            include_epoch=True,
            **kwargs,
        )
    cycle_source = None
    cycle_epoch = None
    try:
        while True:
            owner_error = None
            epoch = 0
            rows = 0
            width = 0
            has_labels = 0
            status = 0
            # Drop the previous fetch before pulling, so dispatch never holds
            # two batches alongside the window.
            owner_batch = input_ids = lengths = labels = None
            if rank == 0:
                try:
                    if owner_contract_error is not None:
                        raise owner_contract_error
                    owner_batch, epoch = next(owner_iterator)
                    if cycle_epoch != epoch:
                        cycle_epoch = epoch
                        cycle_source = owner_batch
                    owner_batch = _pad_dispatched_text_batch(
                        owner_batch,
                        target_size,
                        pad_id=_mlx_text_pad_id(owner_tokenizer),
                        pad_mode=distributed_pad_mode,
                        cycle_source=cycle_source,
                    )
                    input_ids, lengths, labels = owner_batch
                    rows = int(input_ids.shape[0])
                    width = int(input_ids.shape[1])
                    has_labels = int(labels is not None)
                    status = 1
                except StopIteration:
                    pass
                except BaseException as exc:
                    # Synchronize interrupts too: peers are entering the all_sum
                    # below and would hang if rank 0 unwound past it. The
                    # original error is re-raised on rank 0 after the sync.
                    owner_error = exc
                    status = -1

            metadata = mx.array(
                [status, rows, width, has_labels]
                if rank == 0 else [0, 0, 0, 0],
                dtype=mx.int32,
            )
            metadata = mx.distributed.all_sum(metadata, group=comm_group)
            mx.eval(metadata)
            status, rows, width, has_labels = (
                int(value) for value in metadata.tolist()
            )
            if status < 0:
                if owner_error is not None:
                    raise owner_error
                raise RuntimeError(
                    "Unsloth MLX: rank 0 failed while reading the global "
                    "streaming text source before batch dispatch."
                )
            if status == 0:
                return
            if rows != target_size or width <= 0:
                raise RuntimeError(
                    "Unsloth MLX: rank-0 streaming text dispatch produced "
                    f"invalid global batch shape ({rows}, {width})."
                )

            if rank != 0:
                input_ids = mx.zeros((rows, width), dtype=mx.int32)
                lengths = mx.zeros((rows, 2), dtype=mx.int32)
                labels = (
                    mx.zeros((rows, width), dtype=mx.int64)
                    if has_labels else None
                )
            input_ids = mx.distributed.all_sum(input_ids, group=comm_group)
            lengths = mx.distributed.all_sum(lengths, group=comm_group)
            if has_labels:
                labels = mx.distributed.all_sum(labels, group=comm_group)
                mx.eval(input_ids, lengths, labels)
            else:
                mx.eval(input_ids, lengths)
            yield (
                input_ids[rank:target_size:world_size],
                lengths[rank:target_size:world_size],
                None
                if labels is None
                else labels[rank:target_size:world_size],
            )
    finally:
        _close_mlx_owned_iterator(owner_iterator)


def _iterate_ordered_text_training_batches(dataset, tokenizer, batch_size,
                                           max_seq_length, seed=42,
                                           dataset_text_field="text",
                                           formatting_func=None,
                                           dataset_order="default",
                                           append_eos=True,
                                           comm_group=None):
    base_seed = _normalize_seed(seed)
    global_batch_size = _distributed_global_batch_size(batch_size, comm_group)

    def _yield_local_batch(chunk, pad_source):
        local_items = _rank_slice_distributed_batch(
            chunk,
            batch_size,
            comm_group=comm_group,
            pad_source=pad_source,
        )
        if local_items:
            return _make_text_batch_from_items(
                local_items,
                tokenizer,
                max_seq_length,
            )
        return None

    if hasattr(dataset, "__len__"):
        tokenized = list(_iter_tokenized_text_rows(
            dataset,
            tokenizer,
            dataset_text_field=dataset_text_field,
            formatting_func=formatting_func,
            append_eos=append_eos,
            max_seq_length=max_seq_length,
        ))
        if not tokenized:
            raise ValueError(
                "Unsloth MLX: streaming dataset produced no trainable text rows."
            )
        epoch = 0
        while True:
            indices = list(range(len(tokenized)))
            if dataset_order == "torch_randperm":
                order = _torch_randperm_order(len(tokenized), base_seed + epoch)
            elif dataset_order == "sequential":
                order = indices
            elif dataset_order in (None, "default"):
                indices = sorted(indices, key=lambda i: len(tokenized[i][0]))
                chunks = [
                    indices[i : i + global_batch_size]
                    for i in range(0, len(indices), global_batch_size)
                ]
                rng = np.random.default_rng(base_seed + epoch)
                for chunk_idx in rng.permutation(len(chunks)):
                    batch = _yield_local_batch(
                        [tokenized[i] for i in chunks[chunk_idx]],
                        tokenized,
                    )
                    if batch is not None:
                        yield batch
                epoch += 1
                continue
            else:
                raise ValueError(f"Unsupported MLX dataset_order: {dataset_order!r}")
            for start in range(0, len(order), global_batch_size):
                chunk = order[start : start + global_batch_size]
                batch = _yield_local_batch(
                    [tokenized[i] for i in chunk],
                    tokenized,
                )
                if batch is not None:
                    yield batch
            epoch += 1
        return

    if dataset_order == "torch_randperm":
        raise ValueError(
            "Unsloth MLX: dataset_order='torch_randperm' requires a sized "
            "streaming dataset so each epoch can be replayed deterministically."
        )
    if dataset_order not in (None, "default", "sequential"):
        raise ValueError(f"Unsupported MLX dataset_order: {dataset_order!r}")

    while True:
        pending = []
        yielded = False
        for row in _iter_tokenized_text_rows(
            dataset,
            tokenizer,
            dataset_text_field=dataset_text_field,
            formatting_func=formatting_func,
            append_eos=append_eos,
            max_seq_length=max_seq_length,
        ):
            pending.append(row)
            if len(pending) >= global_batch_size:
                batch = _yield_local_batch(pending, pending)
                if batch is not None:
                    yielded = True
                    yield batch
                pending = []
        if pending:
            batch = _yield_local_batch(pending, pending)
            if batch is not None:
                yielded = True
                yield batch
        if not yielded:
            raise ValueError(
                "Unsloth MLX: streaming dataset produced no trainable text rows. "
                "If resuming, use a replayable iterable rather than a one-shot iterator."
            )


def iterate_training_batches(dataset, tokenizer, batch_size, max_seq_length,
                             seed=42, dataset_text_field="text",
                             formatting_func=None, chat_template=None,
                             model_name=None, model_type=None,
                             append_eos=True, completion_only_loss=None,
                             assistant_only_loss=False, dataset_order="default",
                             comm_group=None, require_replayable=False,
                             response_mask_fn=None, repeat=True,
                             distributed_pad_mode="cycle",
                             expected_rows_per_pass=None,
                             length_window_batches=1,
                             prefetch_batches=0,
                             prefetch_skip_batches=0,
                             prefetch_control=None):
    """Streaming batch generator for MLX training.

    Map-style datasets retain the existing mlx-lm batching behavior. Unsized
    text sources are normalized and tokenized incrementally, retaining at most
    ``length_window_batches`` global micro-batches of prepared rows (plus the
    rank-0 owner's pass-long cycle-padding batch under DDP). Default order with
    a window > 1 emits length-grouped, seeded-permuted batches; ``sequential``
    and window 1 preserve exact source order. Yields ``(batch, lengths, labels)``
    like create_batches, with ``labels`` None unless text prompt/completion
    masking is active.
    """
    from mlx_lm.tuner.trainer import iterate_batches

    if _is_mlx_lazy_text_source(dataset):
        tokenizer = normalize_mlx_chat_template(
            tokenizer,
            chat_template=chat_template,
            model_name=model_name,
            model_type=model_type,
            is_vlm=False,
            strict=False,
        )
        lazy_batch_kwargs = dict(
            dataset_text_field=dataset_text_field,
            formatting_func=formatting_func,
            dataset_order=dataset_order,
            append_eos=append_eos,
            completion_only_loss=completion_only_loss,
            assistant_only_loss=assistant_only_loss,
            response_mask_fn=response_mask_fn,
            require_replayable=require_replayable,
            repeat=repeat,
            expected_rows_per_pass=expected_rows_per_pass,
            length_window_batches=length_window_batches,
            window_seed=seed,
        )
        prefetch_depth = _validate_streaming_prefetch(prefetch_batches)
        if prefetch_depth and _distributed_rank_size(comm_group)[1] == 1:
            prefetcher = _LazyTextPrefetcher(
                None,
                prefetch_depth,
                skip_batches=prefetch_skip_batches,
            )
            prefetcher._make_iterator = (
                lambda pf=prefetcher: _iterate_lazy_text_training_batches(
                    dataset, tokenizer, batch_size, max_seq_length,
                    comm_group=None, distributed_pad_mode=distributed_pad_mode,
                    yield_host_staged=True, reject_mlx_valued=True,
                    should_stop=pf._stop.is_set,
                    **lazy_batch_kwargs,
                )
            )
            if prefetch_control is not None:
                prefetch_control["prefetcher"] = prefetcher
            try:
                yield from prefetcher
            finally:
                prefetcher.close()
            return
        if _distributed_rank_size(comm_group)[1] > 1:
            yield from _iterate_dispatched_lazy_text_training_batches(
                dataset,
                tokenizer,
                batch_size,
                max_seq_length,
                comm_group=comm_group,
                distributed_pad_mode=distributed_pad_mode,
                **lazy_batch_kwargs,
            )
        else:
            yield from _iterate_lazy_text_training_batches(
                dataset,
                tokenizer,
                batch_size,
                max_seq_length,
                comm_group=comm_group,
                distributed_pad_mode=distributed_pad_mode,
                **lazy_batch_kwargs,
            )
        return

    dataset = _ensure_reiterable_text_dataset(dataset)
    tokenized, saw_pretokenized = _prepare_pretokenized_text_dataset(
        dataset,
        completion_only_loss=completion_only_loss,
        assistant_only_loss=assistant_only_loss,
    )
    if saw_pretokenized:
        yield from _iterate_tokenized_text_batches(
            tokenized,
            batch_size,
            max_seq_length,
            seed=seed,
            loop=True,
            pad_id=_mlx_text_pad_id(tokenizer),
        )
        return
    if assistant_only_loss:
        _validate_mlx_text_assistant_only_dataset(dataset)

    # Normalize once (capturing the return, which may swap the tokenizer) so
    # both the labeled path below and the default/ordered path share it and we
    # never double-normalize a plain-text dataset (completion_only_loss=None
    # enters the labeled block, finds no prompt/completion rows, and falls
    # through here).
    tokenizer = normalize_mlx_chat_template(
        tokenizer,
        chat_template=chat_template,
        model_name=model_name,
        model_type=model_type,
        is_vlm=False,
        strict=False,
    )

    if completion_only_loss is not False or assistant_only_loss:
        tokenized = _prepare_labeled_text_dataset(
            dataset,
            tokenizer,
            dataset_text_field=dataset_text_field,
            formatting_func=formatting_func,
            append_eos=append_eos,
            completion_only_loss=completion_only_loss,
            assistant_only_loss=assistant_only_loss,
        )
        if tokenized:
            yield from _iterate_labeled_text_batches(
                tokenized,
                batch_size,
                max_seq_length,
                seed=seed,
                loop=True,
                pad_id=_mlx_text_pad_id(tokenizer),
            )
            return
        if assistant_only_loss:
            raise ValueError(
                "Unsloth MLX: assistant_only_loss=True produced no "
                "assistant-labeled text rows."
            )
        if completion_only_loss is True:
            raise ValueError(
                "Unsloth MLX: text completion_only_loss=True requires "
                "prompt/completion rows for streaming text training."
            )
        if _prompt_completion_formatter_conflict(
            dataset, formatting_func, completion_only_loss
        ):
            raise ValueError(
                "Unsloth MLX: a formatting_func was provided for a prompt/completion "
                "dataset, which drops the completion boundary needed for the default "
                "completion-only loss. Apply your formatting before passing the "
                "dataset, or set completion_only_loss=False."
            )

    if (
        _distributed_rank_size(comm_group)[1] <= 1
        and dataset_order in (None, "default")
    ):
        ds = _prepare_dataset(
            dataset, tokenizer, dataset_text_field, formatting_func,
            chat_template=None,
            model_name=model_name,
            model_type=model_type,
            append_eos=append_eos,
        )

        for batch, lengths_info in iterate_batches(
            ds, batch_size, max_seq_length,
            loop=True,
            seed=seed,
        ):
            max_length = int(mx.max(lengths_info[:, 1]).item())
            batch = batch[:, :max_length]
            yield batch, lengths_info, None
        return

    yield from _iterate_ordered_text_training_batches(
        dataset,
        tokenizer,
        batch_size,
        max_seq_length,
        seed=seed,
        dataset_text_field=dataset_text_field,
        formatting_func=formatting_func,
        dataset_order=dataset_order,
        append_eos=append_eos,
        comm_group=comm_group,
    )


def _inherit_target_permissions(tmp_file, target):
    """Carry an existing target's access bits onto the temp file replacing it.

    os.replace() installs the temp file's inode, so the destination's mode and
    group would otherwise be dropped for whatever the temp file was created with.
    An in-place write kept both, so without this a re-save widens a deliberately
    restricted adapter (0600 -> 0644 under the usual umask), and in a directory
    that is not setgid it also moves the file to the writer's primary group,
    which is how collaborators lose access to a group-shared checkpoint.

    First save has no target to inherit from; the umask default is then correct.

    Only mode and group are carried. Restoring a different owner needs privileges
    we do not have, and POSIX ACLs have no interface in the standard library, so
    a checkpoint relying on either is outside what this can preserve.
    """
    try:
        info = os.stat(str(target))
    except OSError:
        return  # First save, or an unreadable target; the umask default stands.
    try:
        # Group before mode: chown clears the setgid bit on some systems, so
        # applying the mode afterwards is what keeps it. Owner is left alone.
        os.chown(str(tmp_file), -1, info.st_gid)
    except OSError:
        pass  # Not a member of that group, or a filesystem without ownership.
    try:
        os.chmod(str(tmp_file), info.st_mode & 0o7777)
    except OSError:
        pass  # Filesystem that will not take a chmod.


def _save_adapter_artifacts(model, path, tensors, adapter_config=None):
    # Refuse to write adapter_config.json without adapters.safetensors next
    # to it; mlx-lm reload chokes on the missing weights file.
    if not tensors:
        raise ValueError(
            "Unsloth: _save_adapter_artifacts() requires non-empty "
            "tensors; use save_lora_adapters() or "
            "save_trainable_adapters() at the public entry point."
        )
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)

    # mx.load() arrays stay file-backed, so saving over the source truncates them
    # mid-read (mlx 0.32.1: "[read] Unable to read from file"). Re-saving into the
    # directory an adapter came from is the ordinary switch/merge path.
    target = path / "adapters.safetensors"
    mx.eval(*tensors.values())
    tmp_file = target.with_name(f"{target.stem}.tmp{target.suffix}")
    try:
        mx.save_safetensors(str(tmp_file), tensors)
        _inherit_target_permissions(tmp_file, target)
        os.replace(tmp_file, target)
    except BaseException:
        tmp_file.unlink(missing_ok=True)
        raise

    adapter_config = _enrich_mlx_adapter_config(model, adapter_config or {})
    if adapter_config:
        with open(path / "adapter_config.json", "w", encoding="utf-8") as f:
            json.dump(adapter_config, f, indent=2)


def _extract_mlx_lora_parameters(model):
    """Extract global rank, scale, and dropout from the model's first LoRA module."""
    rank, scale, dropout = 8, 1.0, 0.0
    for _, m in iter_mlx_lora_modules(model):
        a_tensor = m.lora_a
        a_shape = tuple(getattr(a_tensor, "shape", ()))
        # Switch LoRA layouts vary across mlx-lm versions; lora_b's last axis is
        # always `rank`, so prefer it when num_experts is declared. Plain
        # LoRALinear uses (in_dims, rank) where rank is shape[-1].
        b_tensor = getattr(m, "lora_b", None)
        b_shape = tuple(getattr(b_tensor, "shape", ())) if b_tensor is not None else ()
        if hasattr(m, "num_experts") and len(b_shape) >= 3:
            rank = int(b_shape[-1])
        elif len(a_shape) >= 3:
            rank = int(a_shape[-2])
        elif len(a_shape) >= 2:
            rank = int(a_shape[-1])
        scale = getattr(m, "scale", 1.0)

        dropout = _read_mlx_lora_dropout(m)
        break
    return rank, scale, dropout


def iter_mlx_lora_modules(model):
    """Yield (module_name, module) for each module that owns a complete LoRA pair.

    mlx-lm reload only recreates lowercase lora_a / lora_b wrappers, so we
    skip uppercase or half-built modules that cannot be reloaded.
    """
    for module_name, module in model.named_modules():
        if hasattr(module, "lora_a") and hasattr(module, "lora_b"):
            yield module_name, module


def collect_mlx_lora_adapter_tensors(model):
    """Collect tensors for every module exposing a complete LoRA attr pair.

    Anchors on the modules themselves so substring-`lora_` paths (e.g.
    ``router.lora_gate.weight``) are not exported, and so callers can
    still detect LoRA after reload/freeze when trainable_parameters()
    no longer lists adapter tensors.
    """
    parameters = dict(mlx.utils.tree_flatten(model.parameters()))
    adapter_keys = set()
    for module_name, module in iter_mlx_lora_modules(model):
        prefix = f"{module_name}." if module_name else ""
        adapter_keys.add(f"{prefix}lora_a")
        adapter_keys.add(f"{prefix}lora_b")
        adapter_keys.add(f"{prefix}lora_a.weight")
        adapter_keys.add(f"{prefix}lora_b.weight")
        # Include DoRA magnitude `m`, gated on the DoRA class name so a
        # future LoRA wrapper with an unrelated `m` attribute isn't exported.
        if hasattr(module, "m") and type(module).__name__.startswith("DoRA"):
            adapter_keys.add(f"{prefix}m")
    return {name: value for name, value in parameters.items() if name in adapter_keys}


# Wrapped base / quantization tensor suffixes (LoRALinear, DoRALinear,
# LoRAEmbedding) that are reload-leaked state we must drop from adapter
# saves. `.linear.bias` and `.bias` are intentionally NOT here: those are
# legitimate trainable user state.
_LORA_WRAPPED_BASE_SUFFIXES = (
    ".weight",
    ".scales",
    ".biases",
    ".linear.weight",
    ".linear.scales",
    ".linear.biases",
    ".embedding.weight",
    ".embedding.scales",
    ".embedding.biases",
)

# Same wrapped-base set for the rare root-level LoRA wrapper case where
# the empty module prefix means we cannot match by suffix alone.
_ROOT_LORA_WRAPPED_BASE_KEYS = frozenset({
    "weight", "scales", "biases",
    "linear.weight", "linear.scales", "linear.biases",
    "embedding.weight", "embedding.scales", "embedding.biases",
})


def _is_base_tensor_inside_lora_module(
    key, lora_module_prefixes, has_root_lora_module=False,
):
    """True when `key` looks like the wrapped base tensor of a LoRA module.

    Prefix-match against LoRA module names + suffix whitelist of base /
    quantization tensor names. `has_root_lora_module` separately covers
    a root-level wrapper where the empty-name prefix is intentionally
    omitted from `lora_module_prefixes` to avoid matching every key.
    """
    matches_prefix = lora_module_prefixes and any(
        key.startswith(p) for p in lora_module_prefixes
    )
    if matches_prefix:
        return key.endswith(_LORA_WRAPPED_BASE_SUFFIXES)
    if has_root_lora_module:
        return key in _ROOT_LORA_WRAPPED_BASE_KEYS
    return False


def save_trainable_adapters(model, path, adapter_config=None):
    """Save the current trainable parameter tree for training checkpoints.

    Includes all LoRA adapter tensors (frozen or not). Excludes wrapped
    base weights INSIDE a LoRA module (reload-leaked state that would
    reintroduce the original Unsloth adapter-export bloat).
    """
    trainable = dict(mlx.utils.tree_flatten(model.trainable_parameters()))
    adapter_tensors = collect_mlx_lora_adapter_tensors(model)
    _lora_module_names = [name for name, _ in iter_mlx_lora_modules(model)]
    lora_module_prefixes = tuple(f"{name}." for name in _lora_module_names if name)
    has_root_lora_module = any(name == "" for name in _lora_module_names)

    tensors = dict(adapter_tensors)
    for key, value in trainable.items():
        if key in adapter_tensors:
            continue
        if _is_base_tensor_inside_lora_module(
            key, lora_module_prefixes, has_root_lora_module,
        ):
            continue
        tensors[key] = value

    if not tensors:
        raise ValueError(
            "Unsloth: save_trainable_adapters() found no trainable or LoRA "
            "parameters to save. The model may be fully frozen without LoRA."
        )
    _save_adapter_artifacts(model, path, tensors, adapter_config=adapter_config)


def save_optimizer_state(optimizer, path):
    """Save MLX optimizer state (Adam/AdamW m,v moments, step, learning_rate)
    to ``<path>/optimizer_state.safetensors`` so training can resume from a
    checkpoint with identical optimizer dynamics.

    The optimizer's ``.state`` is a nested dict whose leaves are ``mx.array``,
    except that a quantized first moment is a 3-element list that ``tree_flatten``
    decomposes into ``<param>.m.0/.1/.2``. Either way the flattened values are all
    arrays, so the whole tree serializes cleanly with ``mx.save_safetensors``.

    ``group_size``/``bits`` live on the optimizer instance rather than in the state
    tree, so they are written as safetensors metadata; without them a resume cannot
    tell how the packed moments were laid out.
    """
    import os
    os.makedirs(path, exist_ok=True)
    flat = dict(mlx.utils.tree_flatten(optimizer.state))
    target = f"{path}/optimizer_state.safetensors"
    # load_optimizer_state() hands back mx.load()'s file-backed arrays, so checkpointing
    # where a resume came from truncates the source under them. Write beside, replace.
    if flat:
        mx.eval(*flat.values())
    # ".tmp.safetensors", not ".safetensors.tmp": mx.save_safetensors appends
    # ".safetensors" to any path lacking it, silently writing a third file.
    tmp_target = f"{path}/optimizer_state.tmp.safetensors"
    try:
        if hasattr(optimizer, "group_size") and hasattr(optimizer, "bits"):
            metadata = {
                "quantized_moment_group_size" : str(optimizer.group_size),
                "quantized_moment_bits"       : str(optimizer.bits),
            }
            try:
                mx.save_safetensors(tmp_target, flat, metadata = metadata)
            except TypeError:
                # backend without metadata support; fall through
                mx.save_safetensors(tmp_target, flat)
        else:
            mx.save_safetensors(tmp_target, flat)
        _inherit_target_permissions(tmp_target, target)
        os.replace(tmp_target, target)
    except BaseException:
        try:
            os.remove(tmp_target)
        except OSError:
            pass
        raise


def load_optimizer_state(optimizer, path):
    """Inverse of save_optimizer_state. Loads
    ``<path>/optimizer_state.safetensors`` and replaces ``optimizer.state``
    with the unflattened tree.

    Raises FileNotFoundError if the file is missing -- a resume request with
    no optimizer state is a hard error, not silent fall-back, because resuming
    with a fresh optimizer would silently restart Adam's moment estimates.

    Reconciles a quantized first moment with the optimizer being resumed into.
    Loading packed moments into a plain Adam/AdamW would otherwise reach
    ``b1 * m`` on a list and raise a bare ``TypeError`` from inside mlx, and a
    group_size mismatch would only surface as a dequantize shape error.
    """
    from .optimizers_quantized import (
        state_has_quantized_moments,
        unpack_quantized_moments,
    )

    state_path = f"{path}/optimizer_state.safetensors"
    # Metadata form first: loading twice would keep two full copies of a
    # multi-GB optimizer checkpoint live at once. Backends without the flag (the
    # torch shim) still return a bare dict, so check the shape of what came back
    # rather than trusting the kwarg to have been honoured.
    metadata = {}
    try:
        loaded = mx.load(state_path, return_metadata=True)
    except TypeError:
        loaded = mx.load(state_path)
    if isinstance(loaded, tuple) and len(loaded) == 2:
        flat, metadata = loaded
    else:
        flat = loaded
    state = mlx.utils.tree_unflatten(list(flat.items()))

    if state_has_quantized_moments(state):
        saved_group = int((metadata or {}).get(
            "quantized_moment_group_size", getattr(optimizer, "group_size", 64),
        ))
        saved_bits = int((metadata or {}).get(
            "quantized_moment_bits", getattr(optimizer, "bits", 8),
        ))
        if not hasattr(optimizer, "group_size"):
            # Resuming an 8-bit checkpoint into a plain optimizer.
            state = unpack_quantized_moments(state, saved_group, saved_bits)
        elif (optimizer.group_size, optimizer.bits) != (saved_group, saved_bits):
            print(
                f"Unsloth: optimizer checkpoint packs its first moment with "
                f"group_size={saved_group}, bits={saved_bits}; adopting those over "
                f"group_size={optimizer.group_size}, bits={optimizer.bits}."
            )
            optimizer.group_size, optimizer.bits = saved_group, saved_bits

    optimizer.state = state


def save_trainer_state(trainer_state, path):
    """Save trainer scalar state to ``<path>/trainer_state.json``.

    ``trainer_state`` is a plain dict (JSON-serializable). Currently:
      - ``global_step``: int, the step the checkpoint represents
      - ``train_loss_history``: list[float], for UI continuity
      - ``best_metric``/``best_step``: best-model tracking (may be null)
      - ``es_patience_counter``: int, early-stopping no-improve count
    Kept separate from the safetensors blob because these are scalars/lists,
    not tensors, and JSON is easier to inspect.
    """
    import json
    import os
    os.makedirs(path, exist_ok=True)
    with open(f"{path}/trainer_state.json", "w") as f:
        json.dump(trainer_state, f, indent=2)


def load_trainer_state(path):
    """Inverse of save_trainer_state. Returns the dict, or raises
    FileNotFoundError if not present (resume requires it)."""
    import json
    with open(f"{path}/trainer_state.json", "r") as f:
        return json.load(f)


def save_lora_adapters(model, path, adapter_config=None):
    """Save LoRA adapter weights (lora_a / lora_b only) to disk.

    Args:
        model: MLX model with LoRA-wrapped modules.
        path: Directory to save adapters.
        adapter_config: Optional dict with LoRA config metadata.
    """
    adapter_tensors = collect_mlx_lora_adapter_tensors(model)
    if not adapter_tensors:
        raise ValueError(
            "Unsloth: no MLX LoRA adapter tensors were found to save. "
            "The model may have no LoRA layers, or adapters may have been "
            "merged. Use save_trainable_adapters() to checkpoint non-LoRA "
            "trainable state instead."
        )
    _save_adapter_artifacts(
        model, path, adapter_tensors, adapter_config=adapter_config
    )


def _infer_snapshot_commit(path):
    if not path:
        return None
    parts = os.path.normpath(str(path)).split(os.sep)
    try:
        index = parts.index("snapshots")
    except ValueError:
        return None
    if index + 1 >= len(parts):
        return None
    return parts[index + 1] or None


def _effective_mlx_quantization_map(model):
    from mlx_lm.models.switch_layers import QuantizedSwitchLinear

    quantized_types = [
        nn.QuantizedLinear,
        nn.QuantizedEmbedding,
        QuantizedSwitchLinear,
    ]
    vlm_switch_module = sys.modules.get("mlx_vlm.models.switch_layers")
    if vlm_switch_module is not None:
        quantized_types.append(vlm_switch_module.QuantizedSwitchLinear)
    # Drop non-class placeholders a stand-in runtime exports, else isinstance() raises.
    quantized_types = tuple(t for t in quantized_types if isinstance(t, type))

    quantized = {}
    config = getattr(model, "_config", None)
    if isinstance(config, dict):
        quantized.update(_quantization_config_to_path_map(
            config.get("quantization") or config.get("quantization_config")
        ))
    quantized.update(_quantization_config_to_path_map(
        getattr(model, "_unsloth_quantization_config", None)
    ))
    for name, module in model.named_modules():
        if not name:
            continue
        # isinstance, not an exact class-name match: a training-time subclass of
        # the quantized layer (e.g. NEFTune's _NEFTuneEmbed) must still be
        # recognised, else embed_tokens is silently dropped from the map.
        if not isinstance(module, quantized_types):
            continue
        name = _canonical_mlx_quantization_path(name)
        entry = {}
        for key in ("bits", "group_size", "mode"):
            if hasattr(module, key):
                value = getattr(module, key)
                try:
                    value = int(value)
                except (TypeError, ValueError):
                    pass
                entry[key] = value
        quantized[name] = entry
    return quantized


def _quantization_config_to_path_map(config):
    if not isinstance(config, dict):
        return {}
    defaults = {
        key: config.get(key)
        for key in ("bits", "group_size", "mode")
        if config.get(key) is not None
    }
    if defaults and "mode" not in defaults:
        defaults["mode"] = "affine"
    reserved = {
        "bits", "group_size", "mode", "quant_method", "skip_vision",
        "skip_projector", "skip_lm_head",
    }
    quantized = {}
    for name, value in config.items():
        if name in reserved or not isinstance(value, dict):
            continue
        entry = dict(defaults)
        entry.update(value)
        if "bits" not in entry or "group_size" not in entry:
            continue
        if "mode" not in entry:
            entry["mode"] = "affine"
        quantized[_canonical_mlx_quantization_path(str(name))] = {
            key: int(item) if key in ("bits", "group_size") else item
            for key, item in entry.items()
            if key in ("bits", "group_size", "mode")
        }
    return quantized


def _canonical_mlx_quantization_path(path):
    for suffix in (".linear", ".embedding"):
        if path.endswith(suffix):
            return path[:-len(suffix)]
    return path


def _strip_mlx_quantization_metadata(config):
    if not isinstance(config, dict):
        return config
    stripped = {}
    for key, value in config.items():
        if key in {"quantization", "quantization_config"}:
            continue
        if isinstance(value, dict):
            value = _strip_mlx_quantization_metadata(value)
        stripped[key] = value
    return stripped


def _get_mlx_config_quantization(model):
    config = getattr(model, "_config", None)
    if not isinstance(config, dict):
        return None
    return config.get("quantization") or config.get("quantization_config")


def _get_mlx_dropout_probability(drop):
    if drop is None:
        return 0.0
    # MLX nn.Dropout stores keep-prob as _p_1; shims may also set a stale .p,
    # so _p_1 wins when numeric and we fall back to .p otherwise.
    p1 = getattr(drop, "_p_1", None)
    if p1 is not None:
        try:
            return float(1.0 - float(p1))
        except (TypeError, ValueError):
            pass
    p = getattr(drop, "p", None)
    if p is not None:
        try:
            return float(p)
        except (TypeError, ValueError):
            pass
    return 0.0


def _read_mlx_lora_dropout(module):
    """Read configured adapter dropout while a preference run has it disabled."""
    drop = getattr(module, "dropout", None)
    original = getattr(
        drop, "_unsloth_preference_original_probability", None,
    )
    if original is not None:
        return float(original)
    return _get_mlx_dropout_probability(drop)


def _coerce_mlx_lora_scale(scale, default=1.0):
    """Return a Python float from an mlx-lm LoRA wrapper's `.scale` attribute.

    LoRASwitchLinear stores per-expert mx.array scales; raw float()/.item()
    raise. Read the first broadcast value (= alpha/r for every expert) so
    we don't silently lose the trained alpha/r by defaulting to 1.0.
    """
    if scale is None:
        return float(default)

    try:
        return float(scale)
    except Exception:
        pass

    if hasattr(scale, "item"):
        try:
            return float(scale.item())
        except Exception:
            pass

    # LoRASwitchLinear per-expert mx.array: first broadcast value = alpha/r.
    try:
        flat = scale.reshape((-1,))
        first = flat[0]
        if hasattr(first, "item"):
            return float(first.item())
        return float(first)
    except Exception:
        return float(default)


def _infer_mlx_lora_rank(module):
    lora_a = getattr(module, "lora_a", None)
    lora_b = getattr(module, "lora_b", None)

    # mlx-lm sometimes wraps tensors in nn.Linear layers; unwrap to .weight.
    is_layer = False
    if lora_a is not None and not hasattr(lora_a, "shape") and hasattr(lora_a, "weight"):
        lora_a = lora_a.weight
        is_layer = True
    if lora_b is not None and not hasattr(lora_b, "shape") and hasattr(lora_b, "weight"):
        lora_b = lora_b.weight
        is_layer = True

    lora_a_shape = tuple(lora_a.shape) if lora_a is not None and hasattr(lora_a, "shape") else ()
    lora_b_shape = tuple(lora_b.shape) if lora_b is not None and hasattr(lora_b, "shape") else ()
    # Both halves required; a half-built module is not a reliable rank source.
    if not lora_a_shape or not lora_b_shape:
        return None

    # MoE/switch: lora_a (..., rank, in_dims); lora_b (..., out_dims, rank).
    if len(lora_a_shape) >= 3:
        if len(lora_b_shape) != len(lora_a_shape):
            return None
        rank = lora_a_shape[-2]
        if lora_b_shape[-1] != rank:
            return None
        if lora_a_shape[:-2] != lora_b_shape[:-2]:
            return None
        return int(rank)

    # mlx-lm < 0.28.3 flattened experts into lora_a's leading dimension.
    if len(lora_a_shape) == 2 and len(lora_b_shape) == 3:
        experts, _, rank = lora_b_shape
        return int(rank) if lora_a_shape[0] == experts * rank else None

    if len(lora_a_shape) < 2 or len(lora_b_shape) < 2:
        return None

    # Standard 2D LoRA, two conventions:
    # 1. mlx-lm layer: lora_a (rank, in), lora_b (out, rank)
    if is_layer:
        if lora_a_shape[0] == lora_b_shape[-1]:
            return int(lora_a_shape[0])
        return None

    # 2. Raw array: lora_a (in, rank), lora_b (rank, out)
    if lora_a_shape[-1] == lora_b_shape[0]:
        return int(lora_a_shape[-1])

    return None


def _sync_mlx_lora_keys(adapter_config, lora_parameters):
    """Mirror `unsloth_mlx_lora_module_paths` into `lora_parameters["keys"]`.

    mlx-lm.load_adapters() reads `lora_parameters.keys` to pick which
    submodules to wrap on reload. Mirror the authoritative path list when
    present (an empty list is its own valid pin); otherwise drop a stale
    caller-supplied `keys` so mlx-lm falls back to its scan default.
    """
    if "unsloth_mlx_lora_module_paths" in adapter_config:
        lora_parameters["keys"] = list(
            adapter_config.get("unsloth_mlx_lora_module_paths") or []
        )
    else:
        lora_parameters.pop("keys", None)
    return lora_parameters


def _enrich_mlx_adapter_config(model, adapter_config):
    adapter_config = dict(adapter_config or {})
    hf_repo = getattr(model, "_hf_repo", None) or adapter_config.get("base_model_name_or_path")
    if hf_repo:
        adapter_config["base_model_name_or_path"] = hf_repo

    base_revision = getattr(model, "_unsloth_base_revision", None)
    if base_revision is not None:
        adapter_config["base_model_revision"] = base_revision
    else:
        adapter_config.pop("base_model_revision", None)

    base_commit = (
        getattr(model, "_unsloth_base_commit_hash", None)
        or _infer_snapshot_commit(getattr(model, "_src_path", None))
    )
    if base_commit is not None:
        adapter_config["base_model_commit_hash"] = base_commit
    else:
        adapter_config.pop("base_model_commit_hash", None)

    quant_config = getattr(model, "_unsloth_quantization_config", None)
    quant_policy = getattr(model, "_unsloth_quantization_policy", None)
    quant_source = getattr(model, "_unsloth_quantized_source", None)
    config_quantization = _get_mlx_config_quantization(model)
    if quant_config is None and config_quantization is not None:
        quant_config = config_quantization
    if quant_source is None and config_quantization is not None:
        quant_source = "mlx_config"
    if quant_config is not None:
        adapter_config["base_quantization_config"] = quant_config
    else:
        adapter_config.pop("base_quantization_config", None)
    if quant_policy is not None:
        adapter_config["base_quantization_policy"] = quant_policy
    else:
        adapter_config.pop("base_quantization_policy", None)
    if quant_source is not None:
        adapter_config["base_quantized_source"] = quant_source
    else:
        adapter_config.pop("base_quantized_source", None)

    resolved_map = _effective_mlx_quantization_map(model)
    if resolved_map:
        adapter_config["base_resolved_quantization_map"] = resolved_map
        adapter_config["base_resolved_quantization_map_supports_switch"] = True
        adapter_config.pop("base_quantization_map", None)
    else:
        adapter_config.pop("base_resolved_quantization_map", None)
        adapter_config.pop("base_resolved_quantization_map_supports_switch", None)
        adapter_config.pop("base_quantization_map", None)

    requires_runtime = False
    if quant_source == "runtime":
        requires_runtime = True
    if isinstance(quant_policy, dict) and quant_policy.get("has_callable_predicate"):
        requires_runtime = True
    if resolved_map and quant_source != "mlx_config":
        requires_runtime = True
    adapter_config["requires_unsloth_mlx_runtime_quantization"] = bool(requires_runtime)

    # Only stamp LoRA fields when the live model has LoRA modules (or the
    # caller declared a lora/dora artifact); otherwise mlx-lm.load_adapters()
    # would inject LoRA wrappers before binding full-precision weights and
    # break reload.
    has_lora_modules = any(True for _ in iter_mlx_lora_modules(model))
    declared_lora_artifact = (
        has_lora_modules
        and adapter_config.get("fine_tune_type") in {"lora", "dora"}
    )
    # Override a stale caller fine_tune_type="full" when LoRA modules are
    # live, else mlx-lm reload would skip LoRA wrapping and drop tensors.
    if has_lora_modules and adapter_config.get("fine_tune_type") == "full":
        adapter_config["fine_tune_type"] = "lora"
        declared_lora_artifact = True
    # Detect DoRA so we stamp 'dora' instead of 'lora'; otherwise mlx-lm's
    # load_adapters() rebuilds plain LoRA and the saved q_proj.m magnitude
    # tensor silently drops via strict=False.
    has_dora_modules = any(
        type(module).__name__.startswith("DoRA")
        for _, module in iter_mlx_lora_modules(model)
    )
    if has_lora_modules or declared_lora_artifact:
        # Saved tensor shapes are authoritative: always re-derive
        # rank/scale/dropout from live modules so a stale caller
        # `lora_parameters` (e.g. rank=99) cannot survive. The path-
        # filtered walker below owns the explicit-paths case so we do
        # not borrow rank from an unselected module.
        _has_explicit_paths_hint = "unsloth_mlx_lora_module_paths" in adapter_config
        if has_lora_modules and not _has_explicit_paths_hint:
            rank, scale, dropout = _extract_mlx_lora_parameters(model)
            adapter_config["lora_parameters"] = {
                "rank": rank,
                "scale": scale,
                "dropout": dropout,
            }
        elif "lora_parameters" not in adapter_config and not _has_explicit_paths_hint:
            rank, scale, dropout = _extract_mlx_lora_parameters(model)
            adapter_config["lora_parameters"] = {
                "rank": rank,
                "scale": scale,
                "dropout": dropout,
            }
        # Mirror lora_parameters to top-level for mlx-vlm; overwrite
        # caller-supplied top-level rank/scale/dropout so stale values
        # cannot shadow the canonical ones.
        if "lora_parameters" in adapter_config:
            lora_parameters = adapter_config["lora_parameters"]
            for key in ("rank", "scale", "dropout"):
                if key in lora_parameters:
                    adapter_config[key] = lora_parameters[key]
        # mlx-lm.load_adapters() reads num_layers off the config.
        if "num_layers" not in adapter_config:
            try:
                layers = _get_transformer_layers(model)
                if layers and len(layers) > 0:
                    adapter_config["num_layers"] = len(layers)
            except Exception:
                pass
        # Derive fine_tune_type from the live model so a stale caller value
        # (e.g. 'dora' over plain LoRA) cannot survive; otherwise mlx-lm
        # would expect a `m` tensor and drop every adapter via strict=False.
        adapter_config["fine_tune_type"] = "dora" if has_dora_modules else "lora"
        adapter_config["peft_type"] = "LORA"
    else:
        # Full fine-tune: stamp 'full' explicitly so reload routes to the
        # no-LoRA path (mlx-lm defaults missing fine_tune_type to 'lora').
        adapter_config["fine_tune_type"] = "full"
        for _stale in (
            "peft_type", "lora_parameters", "rank", "scale", "dropout",
            "num_layers", "unsloth_mlx_lora_module_paths",
        ):
            adapter_config.pop(_stale, None)

    # Persist module paths + rank/scale/dropout so reload reproduces logits.
    # The walker below backfills lora_parameters via _infer_mlx_lora_rank
    # and respects explicit caller path filters.
    try:
        # Reuse the loader-side normalizer so save/load accept the same
        # shapes (str / list / tuple / set / dict / pathlib.Path).
        from .loader import _normalize_mlx_lora_module_paths
        # distinguish "caller passed nothing" from "caller passed [] / None".
        has_explicit_paths = "unsloth_mlx_lora_module_paths" in adapter_config
        raw_explicit_paths = (
            adapter_config.get("unsloth_mlx_lora_module_paths")
            if has_explicit_paths else None
        )
        if has_explicit_paths:
            explicit_paths = _normalize_mlx_lora_module_paths(raw_explicit_paths)
            adapter_config["unsloth_mlx_lora_module_paths"] = explicit_paths
        else:
            explicit_paths = None
        # Empty explicit list pins caller topology but should NOT suppress
        # global parameter inference; treat empty as "no filter".
        explicit_path_set = set(explicit_paths) if explicit_paths else None

        lora_paths = []
        lora_rank = None
        lora_scale = None
        lora_dropout = None
        # Track whether an explicit filter selected any real live module:
        # if it did but rank inference failed, refusing the caller fallback
        # below is what prevents persisting stale rank=8 placeholders.
        selected_lora_seen = False
        for name, module in iter_mlx_lora_modules(model):
            lora_paths.append(name)
            inferred_rank = _infer_mlx_lora_rank(module)
            # Only infer from caller-selected modules so an unrelated LoRA
            # cannot write the wrong language-tower params.
            if explicit_path_set is not None and name not in explicit_path_set:
                continue
            selected_lora_seen = True
            if inferred_rank is None:
                continue
            if lora_rank is None:
                lora_rank = inferred_rank
                lora_scale = _coerce_mlx_lora_scale(
                    getattr(module, "scale", 1.0),
                )
                lora_dropout = _read_mlx_lora_dropout(module)

        # Auto-fill only when the caller did not supply the key.
        if lora_paths and not has_explicit_paths:
            adapter_config["unsloth_mlx_lora_module_paths"] = lora_paths

        # Live LoRA module state describes the tensors being saved, so an
        # inferable live rank ALWAYS overrides caller scalar metadata.
        existing_lora_parameters = dict(adapter_config.get("lora_parameters") or {})
        has_caller_lora_metadata = any(
            key in existing_lora_parameters or key in adapter_config
            for key in ("rank", "scale", "dropout")
        )
        # When the caller pinned explicit paths that selected real modules
        # but rank inference failed everywhere, do NOT fall back to caller
        # metadata; it is stale by construction.
        allow_caller_metadata_fallback = not (
            explicit_path_set is not None
            and selected_lora_seen
            and lora_rank is None
        )

        if lora_rank is not None:
            lora_parameters = existing_lora_parameters
            lora_parameters.update({
                "rank": lora_rank,
                "scale": lora_scale,
                "dropout": lora_dropout,
            })
            # Mirror the authoritative path list under `keys` so mlx-lm.
            # load_adapters() does not interpret a missing `keys` as "scan
            # every Linear/Embedding/Switch layer".
            lora_parameters = _sync_mlx_lora_keys(adapter_config, lora_parameters)
            adapter_config["lora_parameters"] = lora_parameters
            adapter_config["rank"] = lora_rank
            adapter_config["scale"] = lora_scale
            adapter_config["dropout"] = lora_dropout
            adapter_config.setdefault("peft_type", "LORA")
            adapter_config.setdefault("fine_tune_type", "lora")
            # mlx-lm.load_adapters() attr-accesses `config.num_layers` on
            # a SimpleNamespace, so the key MUST be present. -1 is the
            # legacy "all layers" sentinel for the no-detect case.
            if "num_layers" not in adapter_config:
                layers = _get_transformer_layers(model)
                try:
                    n_layers = len(layers) if layers is not None else -1
                except TypeError:
                    n_layers = -1
                if n_layers <= 0:
                    n_layers = -1
                adapter_config["num_layers"] = n_layers
        elif has_caller_lora_metadata and allow_caller_metadata_fallback:
            # Caller-supplied metadata path: copy top-level rank/scale/dropout
            # into lora_parameters (or vice versa) and backfill missing keys
            # from inferred values so mlx-lm.load_adapters sees a complete dict.
            lora_parameters = existing_lora_parameters
            for key in ("rank", "scale", "dropout"):
                if key not in lora_parameters and key in adapter_config:
                    lora_parameters[key] = adapter_config[key]
            # Rank first because it gates the final write below.
            inferred_fallbacks = (
                ("rank", lora_rank, None),
                ("scale", lora_scale, 1.0),
                ("dropout", lora_dropout, 0.0),
            )
            for key, inferred_value, default_value in inferred_fallbacks:
                if key in lora_parameters:
                    continue
                if inferred_value is None and default_value is None:
                    # No inferred value AND no safe default (rank); leave absent.
                    continue
                lora_parameters[key] = (
                    inferred_value if inferred_value is not None else default_value
                )
            if "rank" in lora_parameters:
                lora_parameters = _sync_mlx_lora_keys(adapter_config, lora_parameters)
                adapter_config["lora_parameters"] = lora_parameters
                for key in ("rank", "scale", "dropout"):
                    if key in lora_parameters:
                        adapter_config[key] = lora_parameters[key]
                adapter_config.setdefault("peft_type", "LORA")
                adapter_config.setdefault("fine_tune_type", "lora")
                # Same -1 sentinel as the main branch.
                if "num_layers" not in adapter_config:
                    layers = _get_transformer_layers(model)
                    try:
                        n_layers = len(layers) if layers is not None else -1
                    except TypeError:
                        n_layers = -1
                    if n_layers <= 0:
                        n_layers = -1
                    adapter_config["num_layers"] = n_layers
    except (TypeError, ValueError, AttributeError) as _enrich_exc:
        # Surface enrichment failures so the user knows adapter_config
        # metadata may be incomplete on reload.
        import warnings as _warnings
        _warnings.warn(
            f"Unsloth MLX: skipped LoRA metadata enrichment "
            f"({_enrich_exc!r}); reloaded adapters may use placeholder "
            f"rank/scale until adapter_config is rewritten.",
            stacklevel=2,
        )
    return adapter_config


def _config_to_plain_python(value):
    """Recursively convert config dataclasses and containers to plain Python."""
    import dataclasses

    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        value = dataclasses.asdict(value)
    elif isinstance(value, dict):
        value = copy.deepcopy(value)
    elif isinstance(value, (list, tuple)):
        return [_config_to_plain_python(item) for item in value]
    else:
        return value

    if isinstance(value, dict):
        return {
            key: _config_to_plain_python(item)
            for key, item in value.items()
        }
    return value


def _get_model_config(model):
    """Extract config dict from an MLX model.

    mlx-lm stores the raw config dict at model._config when loaded.
    mlx-vlm exposes config dataclasses at model.config.
    Falls back to reconstructing from model.args dataclass.
    """
    import dataclasses

    # Prefer the raw config dict stashed by our loader
    if hasattr(model, "_config") and isinstance(model._config, dict):
        return _config_to_plain_python(model._config)

    if hasattr(model, "config"):
        config = model.config
        if isinstance(config, dict) or (
            dataclasses.is_dataclass(config) and not isinstance(config, type)
        ):
            return _config_to_plain_python(config)
        if hasattr(config, "to_dict"):
            config = config.to_dict()
            if isinstance(config, dict):
                return _config_to_plain_python(config)

    # Reconstruct from the ModelArgs dataclass
    if hasattr(model, "args"):
        if dataclasses.is_dataclass(model.args) and not isinstance(model.args, type):
            return _config_to_plain_python(model.args)

    return {}


def _get_src_path(model):
    """Get the original model source path/repo for copying auxiliary files."""
    return getattr(model, "_src_path", None)


def _save_mlx_config(config, config_path, *, is_vlm=False):
    """Save MLX config using the backend-aware upstream helper."""
    config = copy.deepcopy(config)
    if is_vlm:
        if "quantization" in config:
            config["quantization_config"] = config["quantization"]
        from mlx_vlm.utils import save_config as save_vlm_config
        save_vlm_config(config, config_path)
    else:
        from mlx_lm.utils import save_config as save_lm_config
        save_lm_config(config, config_path)


def _has_vision_config(config):
    """Return whether a raw or thinker-wrapped VLM config has vision settings."""
    if not isinstance(config, dict):
        return False
    thinker_config = config.get("thinker_config")
    return (
        "vision_config" in config
        or (
            isinstance(thinker_config, dict)
            and "vision_config" in thinker_config
        )
    )


class _MlxVlmSanitizeProxy:
    """Minimal instance shim for mlx-vlm class sanitize methods."""
    def __init__(self, config):
        self.config = config
        self.args = config


def _copy_mlx_vlm_sanitize_weights(weights):
    """Copy MLX arrays before replaying sanitizer transforms."""
    return {
        key: mx.array(value) if isinstance(value, mx.array) else value
        for key, value in weights.items()
    }


def _call_mlx_vlm_sanitize(cls, config, weights):
    """Call an mlx-vlm sanitize method with its expected signature."""
    sanitize = getattr(cls, "sanitize", None)
    if sanitize is None:
        return weights

    weights = _copy_mlx_vlm_sanitize_weights(weights)
    params = inspect.signature(sanitize).parameters
    if len(params) == 1:
        return sanitize(weights)
    return sanitize(_MlxVlmSanitizeProxy(config), weights)


def _add_mlx_vlm_sanitize_step(steps, module):
    """Append a real mlx-vlm module sanitizer once, preserving order."""
    if module is None or getattr(module, "sanitize", None) is None:
        return
    if all(existing is not module for existing, _ in steps):
        steps.append((module, None))


def _get_mlx_vlm_model_sanitize_pipelines(model):
    """Build sanitizer pipelines from a loaded mlx-vlm model and submodules."""
    if model is None:
        return []

    # Submodule-only sanitizers (wrapper without its own sanitize) still
    # need replay pipelines, so the wrapper step is optional.
    model_step = [(model, None)] if getattr(model, "sanitize", None) is not None else []
    pipelines = [model_step] if model_step else []

    extra_steps = []
    for attr in ("thinker", "vision_tower", "vision_model", "vision_encoder", "visual"):
        _add_mlx_vlm_sanitize_step(extra_steps, getattr(model, attr, None))

    thinker = getattr(model, "thinker", None)
    for attr in ("vision_tower", "vision_model", "vision_encoder", "visual"):
        _add_mlx_vlm_sanitize_step(extra_steps, getattr(thinker, attr, None))

    for idx in range(len(extra_steps)):
        pipelines.append(model_step + extra_steps[: idx + 1])

    return pipelines


def _get_nested_config(config, *names):
    """Walk nested config attributes, returning None for missing segments."""
    cur = config
    for name in names:
        cur = getattr(cur, name, None)
        if cur is None:
            return None
    return cur


def _build_mlx_vlm_sanitize_steps(config):
    """Build class-based mlx-vlm sanitizer steps from a saved VLM config."""
    if not _has_vision_config(config):
        return []

    try:
        from mlx_vlm.utils import get_model_and_args, update_module_configs

        config_copy = copy.deepcopy(config)
        model_module, model_type = get_model_and_args(config_copy)
        config_copy.setdefault("text_config", config_copy.pop("llm_config", {}))
        config_copy.setdefault("vision_config", {})
        config_copy.setdefault("audio_config", {})

        model_config = model_module.ModelConfig.from_dict(config_copy)
        try:
            model_config = update_module_configs(
                model_config,
                model_module,
                config_copy,
                ["text", "vision", "perceiver", "projector", "audio"],
            )
        except Exception:
            pass
    except Exception:
        return []

    steps = []
    if hasattr(model_module, "Model"):
        steps.append((model_module.Model, model_config))

    thinker_config = _get_nested_config(model_config, "thinker_config")
    if thinker_config is not None:
        thinker_cls = getattr(model_module, "Thinker", None)
        if thinker_cls is None:
            try:
                thinker_mod = importlib.import_module(
                    f"mlx_vlm.models.{model_type}.thinker"
                )
                thinker_cls = getattr(thinker_mod, "Thinker", None)
            except Exception:
                thinker_cls = None
        if thinker_cls is not None:
            steps.append((thinker_cls, thinker_config))

    vision_config = (
        _get_nested_config(model_config, "vision_config")
        or _get_nested_config(model_config, "thinker_config", "vision_config")
    )
    if vision_config is not None and hasattr(model_module, "VisionModel"):
        steps.append((model_module.VisionModel, vision_config))

    return [
        (cls, step_config)
        for cls, step_config in steps
        if getattr(cls, "sanitize", None) is not None
    ]


def _build_mlx_vlm_sanitize_pipelines(config, model=None):
    """Combine real-model and config-derived sanitizer replay pipelines."""
    pipelines = _get_mlx_vlm_model_sanitize_pipelines(model)
    class_steps = _build_mlx_vlm_sanitize_steps(config)
    if class_steps:
        pipelines.append(class_steps)
    return pipelines


def _apply_mlx_vlm_sanitizers(steps, weights):
    """Replay a sanitizer pipeline and return None if any step rejects it."""
    sanitized = dict(weights)
    for cls, config in steps:
        try:
            sanitized = _call_mlx_vlm_sanitize(cls, config, sanitized)
        except Exception:
            return None
    return sanitized


def _vlm_gguf_name_candidates(name):
    """Yield HF/llama.cpp tensor-name candidates for an MLX VLM tensor."""
    candidates = []

    def add(value):
        if value not in candidates:
            candidates.append(value)

    # An encoder MLX keeps at the top level sits under "model." in the HF layout these
    # converters read. llama.cpp drops a tensor whose name it does not recognize, so a
    # missed prefix costs the mmproj its projector and only fails at load time.
    if name.startswith(
        (
            "audio_tower.",
            "vision_tower.",
            "vision_adapter.",
            "vision_projection.",
            "embed_audio.",
            "embed_vision.",
        )
    ):
        add(f"model.{name}")

    if name.startswith("thinker.vision_tower."):
        suffix = name[len("thinker.vision_tower."):]
        add(f"thinker.visual.{suffix}")
    if name.startswith("model.vision_tower."):
        suffix = name[len("model.vision_tower."):]
        add(f"model.visual.{suffix}")
    if name.startswith("vision_tower."):
        suffix = name[len("vision_tower."):]
        add(f"visual.{suffix}")
        add(f"model.visual.{suffix}")
        add(f"model.language_model.visual.{suffix}")
        add(f"vit.{suffix}")

    # Pre-fold text-tower names. Key-gated sanitizers (Qwen3.5) shift only under
    # these, so they are what lets the replay recover the shift from an
    # already-converted MLX checkpoint, where the measurement comes back bare.
    if name.startswith("language_model.model."):
        suffix = name[len("language_model.model."):]
        add(f"model.language_model.{suffix}")
    if name.startswith("language_model.lm_head"):
        add(name[len("language_model."):])

    add(name)
    return candidates


def _vlm_gguf_layout_candidates(name, tensor):
    """The candidates that only move axes, named apart so a caller can tell one won.

    A permutation of equally sized axes leaves the shape alone, so a caller comparing
    shapes cannot see it; the MoE pass reads this directory next and would move those
    axes a second time."""
    shape = getattr(tensor, "shape", ())
    if len(shape) == 5:
        return [mx.transpose(tensor, (0, 4, 1, 2, 3))]
    if len(shape) == 4:
        return [mx.transpose(tensor, (0, 3, 1, 2))]
    if len(shape) == 3 and "depthwise_conv1d.weight" in name:
        return [mx.transpose(tensor, (0, 2, 1))]
    return []


def _vlm_gguf_tensor_candidates(name, tensor, norm_offset=1.0):
    """Yield HF-layout tensor candidates for an MLX VLM tensor."""
    candidates = _vlm_gguf_layout_candidates(name, tensor)
    shape = getattr(tensor, "shape", ())

    if norm_offset and len(shape) == 1 and mx.issubdtype(tensor.dtype, mx.floating):
        candidates.append(tensor - norm_offset)

    candidates.append(tensor)
    return candidates


def _has_vlm_gguf_tensor_candidate(name, tensor):
    """Return whether a tensor shape can require HF-layout recovery."""
    shape = getattr(tensor, "shape", ())
    if len(shape) in (4, 5) or (
        len(shape) == 3 and "depthwise_conv1d.weight" in name
    ):
        return True
    if len(shape) == 1:
        dtype = getattr(tensor, "dtype", None)
        return dtype is not None and mx.issubdtype(dtype, mx.floating)
    return False


def _has_vlm_gguf_rewrite_candidate(name, tensor):
    """Return whether a tensor can differ between mlx-vlm and GGUF layouts."""
    if any(candidate_name != name for candidate_name in _vlm_gguf_name_candidates(name)):
        return True
    return _has_vlm_gguf_tensor_candidate(name, tensor)


def _mlx_tensors_identical(actual, expected):
    """Same dtype and same bits, not numeric equality."""
    held = getattr(actual, "dtype", None)
    wanted = getattr(expected, "dtype", None)
    if (held is None) != (wanted is None) or (held is not None and held != wanted):
        return False
    if held is not None and getattr(actual, "shape", None) == getattr(expected, "shape", None):
        try:
            # Flattened first: a scalar cannot be viewed as another-sized type.
            return bool(mx.all(mx.view(mx.reshape(actual, (-1,)), mx.uint8)
                               == mx.view(mx.reshape(expected, (-1,)), mx.uint8)))
        except Exception:
            pass
    return _mlx_arrays_match(actual, expected)


def _mlx_arrays_match(actual, expected):
    """Compare MLX-like arrays without assuming a concrete backend type."""
    shape = getattr(actual, "shape", None)
    if shape != getattr(expected, "shape", None):
        return False
    if actual is expected:
        return True
    if shape is None:
        return actual == expected
    try:
        result = mx.all(actual == expected)
        item = getattr(result, "item", None)
        return bool(item() if callable(item) else result)
    except Exception:
        return False


def _is_mlx_vlm_sanitize_step(value):
    """Return whether a value is one sanitizer step tuple."""
    return isinstance(value, tuple) and len(value) == 2


def _normalize_mlx_vlm_sanitize_pipelines(sanitize_steps):
    """Normalize legacy step lists and multi-pipeline sanitizer inputs."""
    if not sanitize_steps:
        return []
    if all(_is_mlx_vlm_sanitize_step(step) for step in sanitize_steps):
        return [sanitize_steps]
    return sanitize_steps


def _rewrite_mlx_vlm_tensor_for_gguf(name, tensor, sanitize_steps, norm_offset=1.0):
    """Invert mlx-vlm sanitizers to recover HF tensor names/layouts for GGUF."""
    if not _has_vlm_gguf_rewrite_candidate(name, tensor):
        return name, tensor, False

    for candidate_name in _vlm_gguf_name_candidates(name):
        for candidate_tensor in _vlm_gguf_tensor_candidates(
            name, tensor, norm_offset
        ):
            for pipeline in _normalize_mlx_vlm_sanitize_pipelines(sanitize_steps):
                sanitized = _apply_mlx_vlm_sanitizers(
                    pipeline,
                    {candidate_name: candidate_tensor},
                )
                if not sanitized or len(sanitized) != 1:
                    continue
                sanitized_name, sanitized_tensor = next(iter(sanitized.items()))
                if sanitized_name != name:
                    continue
                if not _mlx_arrays_match(sanitized_tensor, tensor):
                    continue
                changed = (
                    candidate_name != name
                    or not _mlx_arrays_match(candidate_tensor, tensor)
                )
                if not changed:
                    continue
                return candidate_name, candidate_tensor, True

    return name, tensor, False


# Distinct from None, which is a real measurement (source unreadable).
_UNMEASURED = object()


_MLX_NORM_OFFSET_TOLERANCE = 1e-6
_MLX_NORM_OFFSET_PROBE = 1.0


def _mlx_norm_offset_probe(weights, fill):
    """Replace every 1-D float weight with ``fill``, passing the rest through.

    Keys, shapes and dtypes survive, and every real sanitizer gate reads only
    those, so the replay reproduces the gate while carrying a value we chose.
    """
    return {
        key: (
            mx.zeros(value.shape, dtype=value.dtype) + fill
            if value.ndim == 1 and mx.issubdtype(value.dtype, mx.floating)
            else value
        )
        for key, value in weights.items()
    }


def _mlx_constant_1d_value(value):
    """Return the single value a 1-D float array holds, or None if it varies."""
    if getattr(value, "ndim", None) != 1:
        return None
    if not mx.issubdtype(value.dtype, mx.floating):
        return None
    # mx.min refuses a zero-size reduce, and the raise would discard every
    # offset measured alongside this one.
    if value.shape[0] == 0:
        return None
    low = mx.min(value).item()
    high = mx.max(value).item()
    # A sanitizer dividing by a weight the probe zeroed returns inf or NaN, and
    # NaN fails every comparison, so the spread check below would read it as
    # constant and the export would subtract it into a real weight.
    if not math.isfinite(low) or not math.isfinite(high):
        return None
    if abs(low - high) > _MLX_NORM_OFFSET_TOLERANCE:
        return None
    return low


def _mlx_sanitize_probe(model, weights):
    """Replay ``model.sanitize`` where its writes to ``self`` cannot escape.

    Sanitizers are not pure: phi4mm caches its split LoRA weights on the
    instance and gemma3_text pops the ``lm_head`` submodule for a tied
    checkpoint, so measuring on the model itself would rebuild it out of the
    probe halfway through an export. A model that cannot be copied is left
    unmeasured; the caller treats that as unmeasurable, which is what the export
    did before this existed.
    """
    return copy.copy(model).sanitize(weights)


def _mlx_sanitizer_norm_offsets(model):
    """Measure the constants a model's sanitizer ADDS to its 1-D float weights.

    The MTP families shift RMSNorm weights by +1 on load, gated on the source
    checkpoint's contents rather than the model class, so replay the real
    sanitizer over two probes -- 1-D floats all zero, then all one -- and keep a
    key only where the output rose by the difference. Rising is what makes the
    constant an ADDED one, so a sanitizer that invents a 1-D tensor the source
    never held (Inkling's expert scales) or transforms one non-additively is
    rejected. None means unmeasurable, not unshifted.
    """
    src_path = _get_src_path(model)
    sanitize = getattr(model, "sanitize", None)
    if src_path is None or not callable(sanitize):
        return None

    try:
        weights = {}
        for weight_file in sorted(Path(src_path).glob("*.safetensors")):
            weights.update(mx.load(str(weight_file)))
        if not weights:
            return None

        zeroed = _mlx_sanitize_probe(model, _mlx_norm_offset_probe(weights, 0.0))
        candidates = {}
        for key, value in zeroed.items():
            offset = _mlx_constant_1d_value(value)
            if offset is None or abs(offset) <= _MLX_NORM_OFFSET_TOLERANCE:
                continue
            candidates[key] = (value, offset)
        if not candidates:
            # Nothing to confirm. Shifting nothing is the common case, so skip
            # the second replay rather than pay for it on every model.
            return {}

        raised = _mlx_sanitize_probe(
            model, _mlx_norm_offset_probe(weights, _MLX_NORM_OFFSET_PROBE)
        )

        offsets = {}
        for key, (value, offset) in candidates.items():
            raised_value = raised.get(key)
            if getattr(raised_value, "shape", None) != value.shape:
                continue
            delta = _mlx_constant_1d_value(raised_value - value)
            if delta is None:
                continue
            if abs(delta - _MLX_NORM_OFFSET_PROBE) > _MLX_NORM_OFFSET_TOLERANCE:
                continue
            offsets[key] = offset
    except Exception as exc:
        print(f"Unsloth: Could not measure MLX norm offsets ({exc}); continuing.")
        return None

    return offsets


def _sync_gguf_nextn_layer_config(config, model):
    """Align speculative-layer config metadata with exported MLX layers."""
    if model is None or not isinstance(config, dict):
        return False

    layers = _get_transformer_layers(model)
    if layers is None:
        return False
    try:
        actual_layers = len(layers)
    except Exception:
        return False

    thinker_config = config.get("thinker_config")
    text_configs = [
        config.get("text_config"),
        config.get("language_config"),
        (
            thinker_config.get("text_config")
            if isinstance(thinker_config, dict)
            else None
        ),
    ]
    changed = False
    for text_config in text_configs:
        if not isinstance(text_config, dict):
            continue
        num_hidden_layers = text_config.get("num_hidden_layers")
        if not isinstance(num_hidden_layers, int):
            continue

        actual_nextn = actual_layers - num_hidden_layers
        for key in (
            "num_nextn_predict_layers",
            "mtp_num_hidden_layers",
            "nextn_predict_layers",
        ):
            num_nextn = text_config.get(key)
            if not isinstance(num_nextn, int) or num_nextn <= 0:
                continue
            if actual_layers < num_hidden_layers:
                continue
            if actual_nextn >= num_nextn:
                continue
            if actual_nextn > 0:
                text_config[key] = actual_nextn
            else:
                text_config.pop(key, None)
            changed = True

    return changed


def _prepare_mlx_gguf_export_directory(
    path, model=None, replay_sanitizers=True, norm_offsets=_UNMEASURED,
    relaid_out=None,
):
    """Restore HF tensor names, layouts and norm convention in the export dir.

    ``replay_sanitizers`` gates the VLM-only name/layout inversion; the norm correction
    always runs. ``norm_offsets`` is one source measurement shared by every pass, and
    ``relaid_out`` collects the names whose axes this pass moved, for the same reason."""
    path = Path(path)
    config_path = path / "config.json"
    if not config_path.exists():
        return 0
    with open(config_path, "r") as f:
        config = json.load(f)
    config_changed = _sync_gguf_nextn_layer_config(config, model)
    sanitize_steps = (
        _build_mlx_vlm_sanitize_pipelines(config, model=model)
        if replay_sanitizers
        else []
    )
    if norm_offsets is _UNMEASURED:
        norm_offsets = _mlx_sanitizer_norm_offsets(model)
    if not sanitize_steps and not norm_offsets:
        if config_changed:
            with open(config_path, "w") as f:
                json.dump(config, f, indent=4)
        return 0

    rewritten = 0
    name_map = {}
    for file in sorted(path.glob("*.safetensors")):
        tensors = mx.load(str(file))
        updated = {}
        file_rewritten = 0
        for name, tensor in tensors.items():
            original_tensor = tensor
            # An empty measurement is ambiguous: an already-converted MLX
            # source shifts nothing at load yet still holds shifted norms.
            offset = 1.0 if not norm_offsets else norm_offsets.get(name, 0.0)
            new_name, tensor, changed = _rewrite_mlx_vlm_tensor_for_gguf(
                name, tensor, sanitize_steps, offset
            )
            # The replay cannot observe a gate that spans the whole checkpoint,
            # so a value it left alone is one the measurement has to recover.
            if (
                norm_offsets
                and offset
                and _mlx_arrays_match(tensor, original_tensor)
            ):
                tensor = tensor - offset
                changed = True
            if new_name in updated:
                raise RuntimeError(
                    f"Unsloth: duplicate tensor name after GGUF rewrite: {new_name}"
                )
            # Which candidate won, not what the shape says: a permutation of equally
            # sized axes leaves the shape alone. The MoE pass reads this directory
            # after this one, and an adjacent-axis move is its own inverse, so
            # replaying the sanitizer over a second inversion hands back what is on
            # disk and the confirmation accepts it, transposed off HF layout.
            if relaid_out is not None and changed and any(
                _mlx_arrays_match(tensor, candidate)
                for candidate in _vlm_gguf_layout_candidates(name, original_tensor)
            ):
                relaid_out.add(new_name)
            updated[new_name] = tensor
            name_map[name] = new_name
            file_rewritten += int(changed)
        if file_rewritten:
            # mx.load() arrays may be file-backed; saving over the source can
            # truncate them before they materialize, so write beside and replace.
            mx.eval(*updated.values())
            tmp_file = file.with_name(f"{file.stem}.tmp{file.suffix}")
            mx.save_safetensors(str(tmp_file), updated, metadata={"format": "mlx"})
            os.replace(tmp_file, file)
            rewritten += file_rewritten

    index_path = path / "model.safetensors.index.json"
    if rewritten and index_path.exists():
        with open(index_path, "r") as f:
            index_data = json.load(f)
        weight_map = {}
        for name, shard in index_data.get("weight_map", {}).items():
            new_name = name_map.get(name, name)
            if new_name in weight_map:
                raise RuntimeError(
                    f"Unsloth: duplicate index tensor name after GGUF rewrite: {new_name}"
                )
            weight_map[new_name] = shard
        index_data["weight_map"] = dict(sorted(weight_map.items()))
        with open(index_path, "w") as f:
            json.dump(index_data, f, indent=4)

    if config_changed:
        with open(config_path, "w") as f:
            json.dump(config, f, indent=4)

    return rewritten


# mlx-lm stacks per-expert HF tensors into one SwitchLinear name llama.cpp cannot map.
# Legacy leaf names first, identity last: only they name tensors the converter reads.
_MOE_EXPERT_GROUPS = ("experts", "mlp")
_MOE_EXPERT_LEAF_ALIASES = (
    {"gate_proj": "w1", "down_proj": "w2", "up_proj": "w3"},
    {"fc1": "up_proj", "fc2": "down_proj"},
    {},
)
_MOE_EXPERT_PARAMS = ("weight", "bias")


def _is_mlx_switch_expert_module(module):
    num_experts = getattr(module, "num_experts", None)
    if not isinstance(num_experts, int):
        return False
    shape = getattr(getattr(module, "weight", None), "shape", None)
    return shape is not None and len(shape) == 3 and shape[0] == num_experts


def _mlx_stacked_expert_tensor_names(model, tensor_names):
    named_modules = getattr(model, "named_modules", None)
    if not callable(named_modules):
        return {}

    stacked = {}
    for path, module in named_modules():
        if not path or not _is_mlx_switch_expert_module(module):
            continue
        # LoRA keeps the base SwitchLinear at ".linear", lengthening the module path.
        while path and f"{path}.weight" not in tensor_names:
            path = path.rsplit(".", 1)[0] if "." in path else ""
        if not path or path.count(".") < 2:
            continue
        for param in _MOE_EXPERT_PARAMS:
            name = f"{path}.{param}"
            if name in tensor_names:
                stacked[name] = module.num_experts
    return stacked


class _MlxReplayedSanitizers:
    """Sanitizers replayed in order, leaving no module of the model changed: Gemma 3
    ties its head and drops `lm_head` if handed no `lm_head.weight`."""

    def __init__(self, owners, held):
        self.owners = tuple(owners)
        self.held = tuple(held)

    def sanitize(self, weights):
        # An mlx `Module` is a dict of parameters/children plus plain attributes.
        state = [(module, dict(module) if isinstance(module, dict) else None,
                  dict(vars(module))) for module in self.held]
        try:
            for owner in self.owners:
                weights = owner.sanitize(weights)
                # A failed replay writes nothing: the export is then what it was without this pass.
                if not isinstance(weights, Mapping):
                    raise TypeError("sanitize did not return a mapping")
            return weights
        finally:
            for module, items, attributes in state:
                if items is not None:
                    # Through `dict`: `Module.update` reads a nested parameter tree.
                    dict.clear(module)
                    dict.update(module, items)
                vars(module).clear()
                vars(module).update(attributes)


def _mlx_moe_sanitizers(model):
    """Sanitizers that may own an MoE block's expert stacking, composition first."""
    owners = []
    for owner in (model, getattr(model, "vision_tower", None),
                  getattr(model, "language_model", None),
                  getattr(model, "text_model", None)):
        if owner is None or getattr(owner, "sanitize", None) is None:
            continue
        if all(existing is not owner for existing in owners):
            owners.append(owner)
    if len(owners) < 2:
        return [_MlxReplayedSanitizers(owners, owners)]
    return [_MlxReplayedSanitizers(owners, owners)] + [
        _MlxReplayedSanitizers([owner], owners) for owner in owners
    ]


def _mlx_moe_sanitized_probe(sanitizer, probe):
    """Replay a probe, copying the tensors a sanitizer writing in place could reach:
    mlx-vlm offsets a norm weight with `+=`, writing through to the caller's tensor and
    to every later tensor sharing that shape-cached marker. 1-D only, as wider copies
    would cost a synchronization."""
    if _mlx_sanitizer_writes_in_place(sanitizer):
        probe = {
            name: mx.array(tensor) if getattr(tensor, "ndim", 0) == 1 else tensor
            for name, tensor in probe.items()
        }
    return sanitizer.sanitize(dict(probe))


def _mlx_augmented_assignment(instruction):
    """Both spellings: 3.11 replaced `INPLACE_*` with `BINARY_OP`, and we support 3.9."""
    return (instruction.opname.startswith("INPLACE_")
            or (instruction.opname == "BINARY_OP"
                and instruction.argrepr.endswith("=")))


def _mlx_sanitizer_writes_in_place(sanitizer):
    """Whether a sanitizer's code holds an augmented assignment, which may write
    through. From bytecode, since measuring costs the synchronization this avoids."""
    if getattr(sanitizer, "_writes_in_place", None) is None:
        sanitizer._writes_in_place = any(
            _mlx_augmented_assignment(instruction)
            for code in _mlx_sanitizer_code([sanitizer])
            for instruction in dis.get_instructions(code)
        )
    return sanitizer._writes_in_place


def _mlx_moe_expert_names(name, num_experts, group, leaf_alias, parent=("", "")):
    base, param = name.rsplit(".", 1)
    prefix, _container, leaf = base.rsplit(".", 2)
    replaced, replacement = parent
    if replaced:
        if replaced not in prefix:
            return None
        prefix = prefix.replace(replaced, replacement)
    leaf = leaf_alias.get(leaf, leaf)
    return [f"{prefix}.{group}.{e}.{leaf}.{param}" for e in range(num_experts)]


_GGUF_TEXT_TOWER_NAMESPACE = "language_model.model"


def _mlx_moe_dropped_the_gguf_namespace_in_the_tower(name, renamed):
    """Whether this rename keeps a text tower but drops the namespace llama.cpp maps it
    under: the converter strips `language_model.` and looks the rest up under `model.`,
    so a rename off `language_model.model.` moves the tensor out of the tables."""
    return (name.startswith(_GGUF_TEXT_TOWER_NAMESPACE + ".")
            and renamed.startswith("language_model.")
            and not renamed.startswith(_GGUF_TEXT_TOWER_NAMESPACE + "."))


def _mlx_moe_parent_substitutions(renames):
    """The module relocations a set of proved renames is made of."""
    substitutions = [("", "")]
    for name, renamed in renames.items():
        head = len(os.path.commonprefix([name, renamed]))
        tail = len(os.path.commonprefix([name[::-1], renamed[::-1]]))
        replaced, replacement = name[head:len(name) - tail], renamed[head:len(renamed) - tail]
        if replaced and (replaced, replacement) not in substitutions:
            substitutions.append((replaced, replacement))
    return substitutions


def _mlx_moe_probe_tensor(shape, value):
    """A tiny marker of the same rank as a per-expert slice."""
    return mx.full(tuple(min(dim, 2) for dim in shape), value, dtype=mx.float32)


def _mlx_moe_probe_is_stacked_in_order(stacked, num_experts):
    shape = getattr(stacked, "shape", None)
    if shape is None or len(shape) < 1 or shape[0] != num_experts:
        return False
    try:
        markers = mx.reshape(stacked, (num_experts, -1))[:, 0]
        return bool(
            mx.array_equal(markers, mx.arange(num_experts, dtype=markers.dtype))
        )
    except Exception:
        return False


def _candidate_mlx_moe_unstack_plans(stacked, parents=(("", ""),)):
    """Yield per-expert naming plans to try, most trustworthy first."""
    for parent in parents:
        for group in _MOE_EXPERT_GROUPS:
            for leaf_alias in _MOE_EXPERT_LEAF_ALIASES:
                plan = {
                    name: _mlx_moe_expert_names(
                        name, num_experts, group, leaf_alias, parent
                    )
                    for name, num_experts in stacked.items()
                }
                if all(names is not None for names in plan.values()):
                    yield plan


def _build_mlx_moe_expert_unstack_plan(model, stacked, staged, parents=(("", ""),)):
    """Recover per-expert HF names, then prove them by replaying sanitize()."""
    sanitizers = _mlx_moe_sanitizers(model)
    # Sanitizers read non-expert weights too, so replay against the whole checkpoint.
    others = {name: tensor for name, tensor in staged.items() if name not in stacked}
    for plan in _candidate_mlx_moe_unstack_plans(stacked, parents):
        probe = dict(others)
        for name, expert_names in plan.items():
            slice_shape = tuple(staged[name].shape)[1:]
            for expert, expert_name in enumerate(expert_names):
                probe[expert_name] = _mlx_moe_probe_tensor(slice_shape, expert)
        if len(probe) != len(others) + sum(len(v) for v in plan.values()):
            continue
        for sanitizer in sanitizers:
            try:
                sanitized = _mlx_moe_sanitized_probe(sanitizer, probe)
            except Exception:
                continue
            if all(
                _mlx_moe_probe_is_stacked_in_order(sanitized.get(name), stacked[name])
                for name in plan
            ):
                return plan
    return None


# From the sanitizer's constant pool, not a table, so unanticipated architectures work.
_MOE_VOCABULARY_DEPTH = 5
_MOE_VOCABULARY_UBIQUITY = 0.5
_MOE_VOCABULARY_CALLS = 2


def _mlx_sanitizer_own_functions(found, package, mentioned):
    """The package's own functions one global name reaches, only those named beside a class."""
    def owned(value):
        return (inspect.isfunction(value)
                and (getattr(value, "__module__", "") or "").split(".")[0] == package)

    if isinstance(found, type):
        return [value for name, value in vars(found).items()
                if name in mentioned and owned(value)]
    return [found] if owned(found) else []


def _mlx_sanitizer_code(sanitizers):
    """Every code object a sanitizer reaches inside the model's own package; a walk
    into mlx or numpy would cost a vocabulary of everything and prove nothing."""
    reached, walked = [], set()

    def walk(function, calls):
        code = getattr(function, "__code__", None)
        if code is None or code in walked:
            return
        walked.add(code)
        reached.append(code)
        if calls >= _MOE_VOCABULARY_CALLS:
            return
        package = (getattr(function, "__module__", "") or "").split(".")[0]
        namespace = getattr(function, "__globals__", None) or {}
        # Descend into nested code objects: before PEP 709 (3.12) a comprehension gets
        # its own, hiding from `co_names` the helper a rename is spelled in.
        names, mentioned, pending = [], set(), [code]
        while pending:
            current = pending.pop(0)
            for name in current.co_names:
                if name not in mentioned:
                    mentioned.add(name)
                    names.append(name)
            pending.extend(const for const in current.co_consts
                           if hasattr(const, "co_consts"))
        for name in names:
            for called in _mlx_sanitizer_own_functions(
                namespace.get(name), package, mentioned
            ):
                walk(called, calls + 1)

    for sanitizer in sanitizers:
        for owner in getattr(sanitizer, "owners", (sanitizer,)):
            walk(getattr(type(owner), "sanitize", None), 0)
    return reached


def _mlx_sanitizer_constants(codes, keep):
    found = []

    def collect(obj, depth):
        if depth > _MOE_VOCABULARY_DEPTH:
            return
        if keep(obj):
            found.append(obj)
        if isinstance(obj, (tuple, list, frozenset)):
            for item in obj:
                collect(item, depth + 1)
        elif hasattr(obj, "co_consts"):
            for item in obj.co_consts:
                collect(item, depth + 1)

    for code in codes:
        collect(code, 0)
    return found


def _mlx_sanitizer_vocabulary(sanitizers):
    found = _mlx_sanitizer_constants(
        _mlx_sanitizer_code(sanitizers), lambda obj: isinstance(obj, str))
    return sorted({f for f in found if len(f) > 1 and not f.isspace()})


def _mlx_sanitizer_fusion_groups(sanitizers):
    """Each tuple of names a sanitizer holds, with the fragments beside it. A fuser
    names its inputs in one tuple in concatenation order, so the tuple is the group."""
    def named(obj):
        return (isinstance(obj, tuple) and 1 < len(obj) <= _MOE_SPLIT_PARTS
                and len(set(obj)) == len(obj)
                and all(isinstance(item, str) and len(item) > 1 for item in obj))

    found = {}
    for code in _mlx_sanitizer_code(sanitizers):
        groups = _mlx_sanitizer_constants([code], named)
        if not groups:
            continue
        fragments = {f for f in _mlx_sanitizer_constants(
            [code], lambda obj: isinstance(obj, str))
            if len(f) > 1 and not f.isspace()}
        for group in groups:
            found.setdefault(tuple(group), set()).update(fragments)
    return [(group, sorted(fragments)) for group, fragments in sorted(found.items())]


def _mlx_moe_rename_candidates(vocabulary, names, ubiquity=_MOE_VOCABULARY_UBIQUITY):
    """Substitutions worth trying, as (replaced, replacement) pairs; ``ubiquity`` of 1
    offers every fragment, right once ``names`` is already narrowed."""
    limit = max(1, int(len(names) * ubiquity))
    for replaced in vocabulary:
        carried = [name for name in names if replaced in name]
        if not carried:
            continue
        # A fragment on most tensors names the checkpoint's shape, not a block layout,
        # unless every carrier starts with it: a relocated namespace, as in qwen4_exp.
        relocation = len(carried) > limit
        if relocation and not all(name.startswith(replaced) for name in carried):
            continue
        # A relocation moves a namespace, so only its own components reordered are offered.
        components = sorted(part for part in replaced.split(".") if part)
        for replacement in vocabulary:
            if replacement == replaced:
                continue
            if relocation and sorted(
                part for part in replacement.split(".") if part
            ) != components:
                continue
            yield replaced, replacement
        # Deletion: mlx-lm appends `.weight` to a name carried bare.
        yield replaced, ""


def _mlx_moe_renamed(names, replaced, replacement):
    """Apply one substitution, keeping only the names it changes."""
    renamed = {}
    for name in names:
        if replaced in name:
            candidate = name.replace(replaced, replacement)
            if candidate != name:
                renamed[name] = candidate
    return renamed if len(set(renamed.values())) == len(renamed) else {}


# Two probes, as (base, spread): tensor n is marked base + n * spread. One cannot tell a
# doubled 1-D tensor from an offset one; two alike could not tell a constant from a swap.
_MOE_PROBE_MARKERS = ((3.0, 1.0), (5.0, 7.0))

def _mlx_moe_replay_marker(shape, value):
    """A marker for replay measurement: 1-D whole, since a shift along one reads as a
    constant from a truncated corner; wider ones truncated, and counted rather than
    filled so an axis move still shows."""
    if len(shape) == 1:
        return mx.full(shape, value, dtype=mx.float32)
    shape = tuple(min(dim, 2) for dim in shape)
    size = 1
    for dim in shape:
        size *= dim
    return mx.reshape(mx.arange(size, dtype=mx.float32), shape) + value


def _mlx_moe_constant_offset(sanitized, marker):
    # Identity settles almost every tensor; the comparison below costs a sync each.
    if sanitized is marker:
        return 0.0
    if sanitized is None or tuple(getattr(sanitized, "shape", ())) != tuple(marker.shape):
        return None
    try:
        difference = mx.reshape(sanitized.astype(mx.float32) - marker, (-1,))
        if not bool(mx.all(difference == difference[0])):
            return None
        constant = float(difference[0])
        # Only a full-width probe proves a constant, so wider ones must be untouched.
        if constant and len(marker.shape) != 1:
            return None
        return constant
    except Exception:
        return None


# Axis pairs an mlx-lm sanitizer moves, (source, destination) HF to MLX: Kimi Linear
# stores KDA convolutions (d_inner, d_conv, 1) for (d_inner, 1, d_conv).
_MOE_TENSOR_LAYOUTS = ((2, 1), (1, 0), (2, 0))


def _mlx_moe_replay_match(sanitized, marker):
    """What a sanitizer did to one marker: a constant added and an axis moved, or None.
    Measured with the name, since a re-laid-out tensor cannot be inverted by renaming."""
    if sanitized is marker:
        return 0.0, None
    if sanitized is None:
        return None
    constant = _mlx_moe_constant_offset(sanitized, marker)
    if constant is not None:
        return constant, None
    shape = tuple(getattr(sanitized, "shape", ()))
    if sorted(shape) != sorted(tuple(marker.shape)):
        return None
    for source, destination in _MOE_TENSOR_LAYOUTS:
        if max(source, destination) >= len(marker.shape):
            continue
        if _mlx_arrays_match(sanitized, mx.moveaxis(marker, source, destination)):
            return 0.0, (source, destination)
    return None


def _mlx_moe_replayed_corrections(sanitizers, proposal, staged, markers=None, required=()):
    """For each saved tensor a sanitizer still produces, how it produced it: step3p5
    stores a norm weight one greater, Kimi Linear's KDA convolutions transposed."""
    markers = {} if markers is None else markers
    for sanitizer in sanitizers:
        corrections, replays = {}, []
        for base, spread in _MOE_PROBE_MARKERS:
            probe = {}
            # A distinct value per tensor, so a swap of two same-shaped ones shows.
            for position, (name, proposed) in enumerate(proposal.items()):
                shape, value = tuple(staged[name].shape), base + position * spread
                if (shape, value) not in markers:
                    markers[shape, value] = _mlx_moe_replay_marker(shape, value)
                probe[proposed] = markers[shape, value]
            try:
                sanitized = _mlx_moe_sanitized_probe(sanitizer, probe)
            except Exception:
                replays = []
                break
            # Nothing below recovers a missing name, so bail on the first replay.
            if not required <= set(sanitized):
                replays = []
                break
            replays.append((probe, sanitized))
        if not replays:
            continue
        for name, proposed in proposal.items():
            found = {
                _mlx_moe_replay_match(sanitized.get(name), probe[proposed])
                for probe, sanitized in replays
            }
            if len(found) == 1 and None not in found:
                corrections[name] = found.pop()
        if corrections:
            return corrections
    return {}


def _completed_mlx_moe_rename_candidate(candidate, corrections, unproven, vocabulary, replay):
    """Finish a candidate with a second substitution on what it missed."""
    for replaced, replacement in _mlx_moe_rename_candidates(
        vocabulary, [candidate[name] for name in unproven], ubiquity=1
    ):
        repaired = dict(candidate)
        fixed = _mlx_moe_renamed(
            [candidate[name] for name in unproven], replaced, replacement
        )
        if not fixed:
            continue
        for name in unproven:
            repaired[name] = fixed.get(candidate[name], candidate[name])
        # Restoring a name to the one already saved proves nothing.
        if any(repaired[name] == name for name in unproven):
            continue
        if len(set(repaired.values())) != len(repaired):
            continue
        repaired_corrections = replay(repaired, unproven)
        if unproven <= set(repaired_corrections):
            return repaired, repaired_corrections
    return candidate, corrections


# Splits reached here are in two (gate/up, or MLA key/value); DBRX's per-expert split
# belongs to the stack family. Widening costs a factor of the vocabulary per part.
_MOE_MERGE_PARTS = 2
_MOE_MERGE_PROBE_WIDTHS = (2, None)
_MOE_MERGE_ROUNDS = 4
# A group of one is carried through under its restored name rather than merged.
_MOE_MERGE_KEPT = ((None,), 0, False)


def _mlx_moe_moved_shape(shape, layout):
    """The shape a part has once the sanitizer's axis move is undone."""
    if layout is None:
        return tuple(shape)
    return tuple(mx.moveaxis(mx.zeros(tuple(shape)), layout[1], layout[0]).shape)


def _mlx_moe_group_recipe(parts, recipe):
    """A group's recipe: the merge, or the identity for a lone part."""
    return (parts,) + (recipe if len(parts) > 1 else _MOE_MERGE_KEPT)


def _mlx_moe_merged(parts, recipe):
    """Rebuild the checkpoint tensor a sanitizer split into `parts`. A share means it
    instead fused several into one part, so what comes back is one slice of it."""
    _, layouts, axis, flattened, *share = recipe
    merged = mx.concatenate(
        [
            part if layout is None else mx.moveaxis(part, layout[1], layout[0])
            for part, layout in zip(parts, layouts)
        ],
        axis=axis,
    )
    if flattened:
        shape = tuple(merged.shape)
        leading = 1
        for dim in shape[: axis + 1]:
            leading *= dim
        merged = mx.reshape(merged, (leading,) + shape[axis + 1 :])
    if share and share[0] is not None:
        index, count = share[0]
        merged = mx.split(merged, count, axis=axis)[index]
    return merged


def _mlx_moe_merge_recipes(shapes):
    ranks = {len(shape) for shape in shapes}
    if len(ranks) != 1:
        return
    rank = ranks.pop()
    choices = [None] + [layout for layout in _MOE_TENSOR_LAYOUTS if max(layout) < rank]
    for layouts in itertools.product(choices, repeat=len(shapes)):
        moved = [
            _mlx_moe_moved_shape(shape, layout)
            for shape, layout in zip(shapes, layouts)
        ]
        for axis in range(rank):
            if any(
                shape[:axis] + shape[axis + 1 :]
                != moved[0][:axis] + moved[0][axis + 1 :]
                for shape in moved
            ):
                continue
            # A reshape hides the difference between a merge and its flattening, so flatter first.
            for flattened in (True, False):
                if flattened and (axis == 0 or axis + 1 == rank):
                    continue
                yield layouts, axis, flattened


def _mlx_moe_merge_groups(staged, substitutions):
    """The staged tensors each substituted name collects, in substitution order:
    checkpoint order would let one layer collect its parts the other way round."""
    groups = {}
    for name in staged:
        for rank, (replaced, replacement) in enumerate(substitutions):
            # First match only: `up_proj` sits inside `gate_up_proj`, splitting a group in two.
            if replaced in name:
                target = name.replace(replaced, replacement)
                if target != name:
                    groups.setdefault(target, []).append((rank, name))
                break
    return {
        target: [name for _, name in sorted(parts)] for target, parts in groups.items()
    }


def _mlx_moe_merge_arrivals(staged, vocabulary):
    """For each staged name, the names one substitution could restore it to."""
    arrivals = {}
    for replaced, replacement in _mlx_moe_rename_candidates(vocabulary, list(staged)):
        for name, target in _mlx_moe_renamed(staged, replaced, replacement).items():
            if target not in staged:
                arrivals.setdefault(name, {}).setdefault(target, (replaced, replacement))
    return arrivals


def _proved_mlx_moe_merge_recipe(sanitizer, staged, groups, recipes, width,
                                 native=False):
    """The recipe under which the sanitizer reproduces every merged part, else the name
    of a tensor it wanted and did not find."""
    merged_parts = {part for parts in groups.values() for part in parts}
    others, floor_probe = {}, {}
    for position, (name, tensor) in enumerate(staged.items()):
        dtype = getattr(tensor, "dtype", mx.float32) if native else mx.float32
        marker = mx.full(tuple(tensor.shape), float(position), dtype=dtype)
        floor_probe[name] = marker
        if name not in merged_parts:
            others[name] = marker
    # The floor: a sanitizer can drop a sibling once the fused tensor is present.
    try:
        # Must go through the probe helper: `floor_probe` shares marker objects with
        # `others`, so an in-place `+=` measures the floor one step ahead.
        floor = _mlx_moe_sanitized_probe(sanitizer, floor_probe)
    except Exception:
        return
    kept = {name: floor[name] for name in others if name in floor}

    for recipe in recipes:
        probe, expected, seed = {}, {}, 0
        try:
            for target, parts in groups.items():
                markers = []
                for part in parts:
                    shape = tuple(staged[part].shape)
                    if width is not None:
                        shape = shape[:-1] + (min(shape[-1], width),)
                    size = 1
                    for dim in shape:
                        size *= dim
                    marker = mx.reshape(
                        mx.arange(seed, seed + size, dtype=mx.float32), shape
                    )
                    if native:
                        marker = marker.astype(staged[part].dtype)
                    markers.append(marker)
                    expected[part] = marker
                    seed += size
                probe[target] = _mlx_moe_merged(
                    markers, _mlx_moe_group_recipe(parts, recipe)
                )
        except Exception:
            # A truncated probe only fits recipes leaving the last axis alone.
            continue
        probe.update(others)
        try:
            sanitized = _mlx_moe_sanitized_probe(sanitizer, probe)
        except KeyError as missing:
            yield None, missing.args[0] if missing.args else None
            continue
        except Exception:
            continue
        if any(
            not _mlx_arrays_match(sanitized.get(name), value)
            for name, value in kept.items()
        ):
            continue
        # A group at a time: comparing materializes both sides.
        proved = True
        for target, parts in groups.items():
            for part in parts:
                proved = proved and _mlx_arrays_match(
                    sanitized.pop(part, None), expected.pop(part)
                )
            probe.pop(target, None)
            if not proved:
                break
        if proved:
            yield recipe, None
            return


def _proved_mlx_moe_merge_plan(sanitizers, staged, arrivals, target, substitutions,
                               attempted):
    """The rewrite one set of substitutions proves, completed from what it fails on."""
    count = len(substitutions)
    for _ in range(_MOE_MERGE_ROUNDS):
        groups = _mlx_moe_merge_groups(staged, substitutions)
        parts = groups.get(target)
        if not parts or len(parts) != count or set(groups) & set(staged):
            return None
        shapes = [tuple(staged[part].shape) for part in parts]
        # A recipe is an arrangement, not a size, so groups agree on rank and not extent.
        ranks = {len(shape) for shape in shapes}
        if any(
            {len(staged[part].shape) for part in group} != ranks
            for group in groups.values()
            if len(group) > 1
        ):
            return None
        # Keyed by the grouping, not the target, and only once worth replaying.
        grouping = tuple(sorted((t, tuple(g)) for t, g in groups.items()))
        if grouping in attempted:
            return None
        attempted.add(grouping)
        wanted = None
        for width in _MOE_MERGE_PROBE_WIDTHS:
            for sanitizer in sanitizers:
                for recipe, missing in _proved_mlx_moe_merge_recipe(
                    sanitizer, staged, groups, _mlx_moe_merge_recipes(shapes), width
                ):
                    if recipe is None:
                        wanted = wanted or missing
                        continue
                    # A float32 corner can support a recipe the tensor contradicts: confirm natively.
                    if not any(
                        confirmed is not None
                        for confirmed, _ in _proved_mlx_moe_merge_recipe(
                            sanitizer, staged, groups, [recipe], None, native=True
                        )
                    ):
                        continue
                    return {
                        merged: _mlx_moe_group_recipe(group, recipe)
                        for merged, group in groups.items()
                    }
        # A sanitizer popping a sibling throws naming what it wanted: read the companion off it.
        claimed = {part for group in groups.values() for part in group}
        companion = next(
            (
                arrivals[name][wanted]
                for name in staged
                if wanted in arrivals.get(name, ()) and name not in claimed
            ),
            None,
        )
        if companion is None or companion in substitutions:
            return None
        substitutions = substitutions + [companion]
    return None


def _build_mlx_moe_merge_plan(model, staged, sanitizers=None):
    """Recover checkpoint tensors a sanitizer split into several staged ones, as
    GraniteMoE's fused gate/up projection no rename reaches."""
    owned = _mlx_moe_sanitizers(model)
    vocabulary = _mlx_sanitizer_vocabulary(owned)
    if not vocabulary:
        return {}
    # The vocabulary stays the model's own: a wrapped sanitizer has no fragments.
    sanitizers = sanitizers or owned
    arrivals = _mlx_moe_merge_arrivals(staged, vocabulary)
    collected = {}
    for name, targets in arrivals.items():
        for target in targets:
            collected.setdefault(target, []).append(name)

    attempted = set()
    for target, sources in collected.items():
        for chosen in itertools.permutations(sources, _MOE_MERGE_PARTS):
            if len({len(staged[name].shape) for name in chosen}) != 1:
                continue
            substitutions = [arrivals[name][target] for name in chosen]
            if len({replaced for replaced, _ in substitutions}) != len(chosen):
                continue
            plan = _proved_mlx_moe_merge_plan(
                sanitizers, staged, arrivals, target, substitutions, attempted
            )
            if plan:
                return plan
    return {}


class _MlxRelabelledSanitizer:
    """A sanitizer relabelled to spell its output the way a proved rename does."""

    def __init__(self, inner, renames):
        self.inner, self.renames = inner, renames
        self.owners = getattr(inner, "owners", (inner,))

    def sanitize(self, weights):
        return {self.renames.get(name, name): tensor
                for name, tensor in self.inner.sanitize(weights).items()}


def _build_mlx_moe_renamed_merge_plan(model, staged, renames):
    """Merges the checkpoint still needs once the renames have been proved: splitting
    plus relocating leaves no staged name one substitution from the checkpoint's, but
    the proved name is one away (Qwen3-VL-MoE)."""
    if not renames:
        return {}
    renamed = {renames.get(name, name): tensor for name, tensor in staged.items()}
    # Two staged tensors under one name is not a checkpoint.
    if len(renamed) != len(staged):
        return {}
    merges = _build_mlx_moe_merge_plan(
        model, renamed,
        [_MlxRelabelledSanitizer(sanitizer, renames)
         for sanitizer in _mlx_moe_sanitizers(model)],
    )
    staged_names = {proved: name for name, proved in renames.items()}
    restored = {}
    for target, (parts, *recipe) in merges.items():
        parts = [staged_names.get(part, part) for part in parts]
        # A group no rename touched was already covered by the first search.
        if all(part not in renames for part in parts):
            continue
        restored[target] = (parts, *recipe)
    return restored


def _mlx_moe_expert_stacks(staged):
    """Staged names alike but for one component spelling a run of experts. DBRX builds
    each with an f-string, so no fragment stands for the index and the run identifies
    them."""
    runs = {}
    for name in staged:
        components = name.split(".")
        for position, component in enumerate(components):
            if component.isdigit() and str(int(component)) == component:
                key = (".".join(components[:position]),
                       ".".join(components[position + 1:]))
                runs.setdefault(key, {})[int(component)] = name
    return {key: [found[index] for index in range(len(found))]
            for key, found in runs.items()
            if len(found) > 1 and sorted(found) == list(range(len(found)))}


def _mlx_moe_stack_recipes(rank, count):
    """Every concatenation of the parts one split produced, all arranged alike: every
    expert is split the same way, so the search stays layouts times axes rather than
    layouts to the expert count."""
    choices = [None] + [layout for layout in _MOE_TENSOR_LAYOUTS
                        if max(layout) < rank]
    for layout in choices:
        for axis in range(rank):
            for flattened in (True, False):
                if flattened and (axis == 0 or axis + 1 == rank):
                    continue
                yield (layout,) * count, axis, flattened


def _proved_mlx_moe_expert_stack(sanitizers, staged, heads, tail, fragment,
                                 recipes):
    """The rewrite one fragment proves, for every group of experts it names."""
    stripped = fragment.strip(".")
    if not stripped or "." in stripped:
        return None
    # DBRX's converter reads the fused name only without the `.weight` mlx-lm appends.
    for trimmed in (False, True):
        groups = {}
        for head, parts in heads.items():
            target = ".".join(filter(None, (head, stripped, tail)))
            if trimmed:
                if not target.endswith(".weight"):
                    break
                target = target[: -len(".weight")]
            groups[target] = parts
        # Short when the spelling did not apply to every head.
        if len(groups) != len(heads):
            continue
        # A group cannot rebuild its own part, and the floor holds the parts out.
        if any(target in parts for target, parts in groups.items()):
            continue
        for width in _MOE_MERGE_PROBE_WIDTHS:
            for sanitizer in sanitizers:
                for recipe, _ in _proved_mlx_moe_merge_recipe(
                    sanitizer, staged, groups, recipes, width
                ):
                    if recipe is None or not any(
                        confirmed is not None
                        for confirmed, _ in _proved_mlx_moe_merge_recipe(
                            sanitizer, staged, groups, [recipe], None, native=True
                        )
                    ):
                        continue
                    return {target: (parts, *recipe)
                            for target, parts in groups.items()}
    return None


def _build_mlx_moe_expert_stack_plan(model, staged):
    """Recover a checkpoint tensor a sanitizer split into one tensor per expert: DBRX's
    parts are told apart by index, so the run of indices finds the group."""
    sanitizers = _mlx_moe_sanitizers(model)
    vocabulary = _mlx_sanitizer_vocabulary(sanitizers)
    if not vocabulary:
        return {}
    # Grouping by the tail separates a run of expert indices from one of layer indices.
    by_tail = {}
    for (head, tail), parts in _mlx_moe_expert_stacks(staged).items():
        by_tail.setdefault(tail, {})[head] = parts

    plan = {}
    for tail, heads in sorted(by_tail.items()):
        ranks = {len(staged[part].shape) for parts in heads.values() for part in parts}
        counts = {len(parts) for parts in heads.values()}
        if len(ranks) != 1 or len(counts) != 1:
            continue
        recipes = list(_mlx_moe_stack_recipes(ranks.pop(), counts.pop()))
        for fragment in vocabulary:
            proved = _proved_mlx_moe_expert_stack(
                sanitizers, staged, heads, tail, fragment, recipes
            )
            if proved:
                plan.update(proved)
                break
    return plan


# How many tensors one staged tensor splits back into; longer is a name table.
_MOE_SPLIT_PARTS = 4


def _mlx_moe_split_recipes(rank, count):
    """Every way one staged tensor could be the concatenation of `count` parts. Both
    directions of every axis move, unlike a merge's: a merge undoes what the sanitizer
    did to a part it was given, a split does it to one it hands over."""
    moves = [layout for layout in _MOE_TENSOR_LAYOUTS if max(layout) < rank]
    # Moved layouts first, identity last: where both replay the moved one is right.
    for layout in moves + [(after, before) for before, after in moves] + [None]:
        for axis in range(rank):
            yield (layout,), axis


def _proved_mlx_moe_name_split(sanitizer, staged, source, proposals, recipes):
    """The naming and recipe under which the sanitizer fuses parts into `source`: the
    names are new, so what must come back is the one tensor they were built into."""
    others = {name: mx.full(tuple(tensor.shape), float(position), dtype=mx.float32)
              for position, (name, tensor) in enumerate(staged.items())
              if name != source}
    try:
        floor = sanitizer.sanitize(dict(others))
    except Exception:
        return None
    kept = {name: floor[name] for name in others if name in floor}

    shape = tuple(staged[source].shape)
    for layouts, axis in recipes:
        for targets in proposals:
            if shape[axis] % len(targets):
                continue
            part = shape[:axis] + (shape[axis] // len(targets),) + shape[axis + 1:]
            size, seed, markers = 1, 0, []
            for dim in part:
                size *= dim
            for _ in targets:
                markers.append(mx.reshape(
                    mx.arange(seed, seed + size, dtype=mx.float32), part))
                seed += size
            try:
                expected = mx.concatenate(markers, axis=axis)
                layout = layouts[0]
                probe = dict(others)
                for name, marker in zip(targets, markers):
                    probe[name] = (marker if layout is None
                                   else mx.moveaxis(marker, layout[0], layout[1]))
                sanitized = sanitizer.sanitize(probe)
            except Exception:
                continue
            if not _mlx_arrays_match(sanitized.get(source), expected):
                continue
            if any(not _mlx_arrays_match(sanitized.get(name), value)
                   for name, value in kept.items()):
                continue
            return targets, layouts, axis
    return None


def _build_mlx_moe_name_split_plan(model, staged, claimed):
    """Recover checkpoint tensors a sanitizer fused into one staged tensor, as glm5_next
    does a layer's three KDA convolutions. Each part is a share of what it came from."""
    sanitizers = _mlx_moe_sanitizers(model)
    groups = _mlx_sanitizer_fusion_groups(sanitizers)
    if not groups:
        return {}

    plan = {}
    for source in sorted(staged):
        if source in claimed or _kept_for_the_gguf_converter(source):
            continue
        rank = len(staged[source].shape)
        # Names first: string work, unlike a replay.
        proposals = []
        for group, fragments in groups:
            for replaced in fragments:
                if replaced not in source or replaced in group:
                    continue
                targets = [source.replace(replaced, name) for name in group]
                if len(set(targets)) != len(targets) or any(
                    name == source or name in staged for name in targets
                ):
                    continue
                if targets not in proposals:
                    proposals.append(targets)
        if not proposals:
            continue
        recipes = list(_mlx_moe_split_recipes(rank, len(proposals[0])))
        for sanitizer in sanitizers:
            proved = _proved_mlx_moe_name_split(
                sanitizer, staged, source, proposals, recipes)
            if proved is None:
                continue
            targets, layouts, axis = proved
            for index, name in enumerate(targets):
                plan[name] = ([source], layouts, axis, False, (index, len(targets)))
            break
    return plan


def _mlx_moe_merge_placement(files, merges):
    """Which shard receives each merged tensor, and which holds each part. Rewriting a
    shard drops the parts it held, so a merge goes in the first of its parts'."""
    owned, owner, anchors = {}, {}, {}
    if merges:
        consumed = {part for parts, *_ in merges.values() for part in parts}
        for file in files:
            for name in mx.load(str(file)):
                if name in consumed:
                    owner[name] = file
        for target, recipe in merges.items():
            anchor = min(recipe[0], key=lambda part: files.index(owner[part]))
            owned.setdefault(owner[anchor], {})[target] = recipe
            anchors[target] = anchor
    return owned, owner, anchors


def _mlx_moe_written_order(files, plan, merges, owned):
    """Every name the rewrite writes, in the order it will be read back in. Asked, not
    predicted: order depends on the names alone, so a file of one byte apiece answers
    it without writing the checkpoint again."""
    consumed = {part for parts, *_ in merges.values() for part in parts}
    order = []
    with tempfile.TemporaryDirectory() as directory:
        probe = Path(directory) / "order.safetensors"
        for file in files:
            names = []
            for name in mx.load(str(file)):
                if name not in consumed:
                    names.extend(plan.get(name) or (name,))
            names.extend(owned.get(file, ()))
            if not names:
                continue
            mx.save_safetensors(
                str(probe), {name: mx.zeros((1,), dtype=mx.uint8) for name in names}
            )
            order.extend(mx.load(str(probe)))
    return order


def _mlx_moe_shard_merges(file, tensors, owner, owned):
    """Every merged tensor one shard receives, built from the shards holding the parts.
    A call, not a block, so the shards it read are released when it returns."""
    built, loaded = {}, {}
    for target, recipe in owned.items():
        parts = recipe[0]
        values = {}
        for part_file in {owner[part] for part in parts}:
            if part_file == file:
                shard = tensors
            else:
                # Cached: one shard can anchor a merge per layer, a descriptor apiece if reopened.
                shard = loaded.get(part_file)
                if shard is None:
                    shard = loaded[part_file] = mx.load(str(part_file))
            values.update({part: shard[part] for part in parts
                           if owner[part] == part_file})
        built[target] = _mlx_moe_merged([values[part] for part in parts], recipe)
    return built


def _mlx_moe_rewritten_checkpoint(staged, plan, offsets, layouts, merges):
    """The names and tensors the rewrite writes, or None if two collide: colliding
    reconstructions land in different shards and the index picks by position."""
    consumed = {part for parts, *_ in merges.values() for part in parts}
    written = {
        target: _mlx_moe_merged([staged[part] for part in recipe[0]], recipe)
        for target, recipe in merges.items()
    }
    for name, tensor in staged.items():
        if name in consumed:
            continue
        offset = offsets.get(name)
        if offset:
            tensor = (tensor - offset).astype(tensor.dtype)
        layout = layouts.get(name)
        if layout:
            tensor = mx.moveaxis(tensor, layout[1], layout[0])
        expert_names = plan.get(name) or (name,)
        values = ((tensor,) if len(expert_names) == 1
                  else [tensor[expert] for expert in range(len(expert_names))])
        for expert_name, value in zip(expert_names, values):
            if expert_name in written:
                return None
            written[expert_name] = value
    return written


def _confirmed_mlx_moe_rewrite(sanitizers, files, plan, offsets, layouts, merges,
                               restored=(), owned=None):
    """Whether replaying the whole rewrite hands the staged checkpoint back.

    On the checkpoint, not markers, which bfloat16's eight bits cannot tell apart, and
    all at once, since reconstructions proved singly need not hold together. The floor
    is doing nothing: what the sanitizer already fails to reproduce is not the
    rewrite's to lose, but everything the rewrite claims must come back."""
    claimed = set(plan) | set(offsets) | set(layouts)
    claimed.update(part for parts, *_ in merges.values() for part in parts)
    order = _mlx_moe_written_order(files, plan, merges, owned or {})
    for sanitizer in sanitizers:
        floor = _mlx_moe_floor_names(sanitizer, files, claimed)
        if floor is None:
            continue
        # Which written names each staged tensor accounts for, to release both early.
        produced, required = {}, floor - set(restored)
        for file in files:
            for name in mx.load(str(file)):
                produced[name] = tuple(plan.get(name) or (name,))
        for parts, *_ in merges.values():
            for part in parts[:-1]:
                produced[part] = ()
        for target, (parts, *_) in merges.items():
            produced[parts[-1]] = (target,)
        # Replaying reversed falsifies the assumption that sanitize reads a mapping.
        forwards = _replayed_mlx_moe_rewrite(
            sanitizer, files, plan, offsets, layouts, merges, produced, required,
            order, reverse=False)
        if forwards is _MOE_REWRITE_COLLIDES:
            return False
        if forwards is None:
            continue
        # Compared as the second replay produces it, holding one residue not both.
        if _replayed_mlx_moe_rewrite(
            sanitizer, files, plan, offsets, layouts, merges, produced, required,
            order, reverse=True, mirrored=forwards
        ) is not None:
            return True
    return False


def _mlx_moe_floor_names(sanitizer, files, claimed):
    """Every staged name the rewrite has to hand back, or None if it cannot run."""
    required = set()
    try:
        floor = sanitizer.sanitize(_mlx_staged_checkpoint(files))
        for file in files:
            for name, tensor in mx.load(str(file)).items():
                if name in claimed or _mlx_tensors_identical(
                    floor.pop(name, None), tensor
                ):
                    required.add(name)
                tensor = None
    except Exception:
        return None
    return required


_MOE_REWRITE_COLLIDES = object()


def _replayed_mlx_moe_rewrite(sanitizer, files, plan, offsets, layouts, merges,
                              produced, required, order, reverse, mirrored=None):
    """Replay the rewritten checkpoint once, against the shards as they stand.

    Answers with the residue the shards could not account for; given `mirrored` (the
    other replay's residue), each is compared as produced. None says this replay did not
    hand the checkpoint back, disagreed, or could not run; `_MOE_REWRITE_COLLIDES` says
    the plan wants one name twice. Only one replay may be alive: each holds every
    shard."""
    try:
        written = _mlx_moe_rewritten_checkpoint(
            _mlx_staged_checkpoint(files), plan, offsets, layouts, merges)
        if written is None:
            return _MOE_REWRITE_COLLIDES
        # Read-back order follows the rewritten names, not the staged order.
        written = {name: written[name] for name in
                   (reversed(order) if reverse else order) if name in written}
        out = sanitizer.sanitize(dict(written))
        # One at a time, dropped from every mapping holding it.
        unaccounted = {}
        for file in files:
            for name, tensor in mx.load(str(file)).items():
                replayed = out.pop(name, None)
                if name in required:
                    if not _mlx_tensors_identical(replayed, tensor):
                        return None
                elif not _kept_mlx_moe_residue(unaccounted, mirrored, name,
                                               _mlx_tensor_held(replayed)):
                    return None
                tensor = replayed = None
                for written_name in produced[name]:
                    written.pop(written_name, None)
        for name in list(out):
            if not _kept_mlx_moe_residue(unaccounted, mirrored, name,
                                         _mlx_tensor_held(out.pop(name))):
                return None
        # Leftovers: a name the other replay produced and this one did not.
        if mirrored:
            return None
    except Exception:
        return None
    return unaccounted


def _kept_mlx_moe_residue(unaccounted, mirrored, name, tensor):
    """Hold one residue for the other replay, or hold it to what that one left. Name
    before value: one the other replay never produced is a disagreement."""
    if mirrored is None:
        unaccounted[name] = tensor
        return True
    if name not in mirrored:
        return False
    return _mlx_tensors_identical(mirrored.pop(name), tensor)


def _mlx_tensor_held(tensor):
    """A copy owning its memory, since a replay's output can be a view of a shard."""
    if tensor is None:
        return None
    held = mx.array(tensor)
    mx.eval(held)
    return held


def _build_mlx_moe_rename_plan(model, staged, split_plan, exclude=()):
    """Recover names and values a sanitizer changed, proving each by replaying it."""
    sanitizers = _mlx_moe_sanitizers(model)
    vocabulary = _mlx_sanitizer_vocabulary(sanitizers)
    if not vocabulary:
        return {}, {}, {}

    # A relocated MoE block renames experts and router together.
    claimed = {}
    for name, expert_names in (split_plan or {}).items():
        for expert_name in expert_names:
            claimed[expert_name] = mx.zeros(
                tuple(staged[name].shape)[1:], dtype=staged[name].dtype
            )

    # One cache for the whole search: every candidate re-marks the same shapes.
    markers = {}

    def replay(proposal, required=frozenset()):
        probe = dict(proposal)
        probe.update((name, name) for name in claimed)
        return _mlx_moe_replayed_corrections(
            sanitizers, probe, {**staged, **claimed}, markers, required
        )

    claimed_names = frozenset(claimed)

    def produced_once(proposal):
        """Whether every name it produces is distinct from the others and the split's:
        two landing on one reach the replay through a single probe entry."""
        produced = proposal.values()
        return len(set(produced)) == len(proposal) and claimed_names.isdisjoint(produced)

    # Stacked expert tensors are recovered by splitting, so hold them out here.
    held = set(split_plan or {}) | set(exclude)
    open_names = [name for name in staged if name not in held]
    proposal = {name: name for name in open_names}
    # The floor: whatever the sanitizer reproduces from the checkpoint must survive.
    corrections = replay(proposal)
    baseline = set(corrections)
    for replaced, replacement in _mlx_moe_rename_candidates(vocabulary, open_names):
        renamed = _mlx_moe_renamed(proposal.values(), replaced, replacement)
        if not renamed:
            continue
        candidate = {
            name: renamed.get(proposed, proposed)
            for name, proposed in proposal.items()
        }
        recovered = {name for name, p in candidate.items() if p != name}
        # Recovered names may be refined, never dropped: mapping one back passes by vacancy.
        if not produced_once(candidate):
            continue
        if not recovered >= {name for name, p in proposal.items() if p != name}:
            continue
        candidate_corrections = replay(candidate, baseline - recovered)
        # One relocation can move two ways at once (Kimi Linear), so complete on what missed.
        unproven = (baseline | recovered) - set(candidate_corrections)
        if unproven and unproven <= recovered:
            candidate, candidate_corrections = _completed_mlx_moe_rename_candidate(
                candidate, candidate_corrections, unproven, vocabulary, replay
            )
            if not produced_once(candidate):
                continue
            recovered = {name for name, p in candidate.items() if p != name}
        # `recovered` stops a name the sanitizer drops being renamed on no evidence.
        if set(candidate_corrections) >= baseline | recovered:
            proposal, corrections = candidate, candidate_corrections
    # Where several spellings replay alike, prefer the loaded checkpoint's namespace.
    restored = {name: _GGUF_TEXT_TOWER_NAMESPACE + renamed[len("language_model"):]
                for name, renamed in proposal.items()
                if _mlx_moe_dropped_the_gguf_namespace_in_the_tower(name, renamed)}
    if restored:
        candidate = {**proposal, **restored}
        recovered = {name for name, p in candidate.items() if p != name}
        candidate_corrections = replay(candidate, set(corrections) - recovered)
        # Against what the search settled on: the floor is met by construction.
        if (produced_once(candidate)
                and set(candidate_corrections) >= set(corrections) | recovered):
            proposal, corrections = candidate, candidate_corrections
    constants = {name: constant for name, (constant, _) in corrections.items() if constant}
    layouts = {name: layout for name, (_, layout) in corrections.items() if layout}
    renames = {name: p for name, p in proposal.items() if p != name}
    return renames, constants, layouts


# The per-layer projections llama.cpp maps under `model.layers.{bid}.`, as mlx-lm
# spells them. Deliberately wider than any one architecture needs.
_GGUF_MAPPED_LAYER_LEAVES = frozenset((
    "self_attn.q_proj", "self_attn.k_proj", "self_attn.v_proj", "self_attn.o_proj",
    "mlp.gate_proj", "mlp.up_proj", "mlp.down_proj",
))


def _kept_for_the_gguf_converter(name):
    """Whether this is a name the rewrite leaves alone.

    Exactness would need llama.cpp's own per-architecture table, so this reads the HF
    layer prefix and errs towards keeping: taking away a name the converter reads
    breaks a working export (mlx-lm rebuilds dense Hunyuan's `mlp.gate_and_up_proj`)."""
    parts = name.split(".")
    return (len(parts) > 4 and parts[0] == "model" and parts[1] == "layers"
            and parts[2].isdigit()
            and ".".join(parts[3:-1]) in _GGUF_MAPPED_LAYER_LEAVES)


def _mlx_staged_checkpoint(files):
    """Every staged tensor, read afresh from the shards."""
    staged = {}
    for file in files:
        staged.update(mx.load(str(file)))
    return staged


def _mlx_staged_tensor_stubs(files):
    # Planning never reads a value, so stand-ins let each shard close again.
    staged = {}
    for file in files:
        for name, tensor in mx.load(str(file)).items():
            staged[name] = mx.zeros(tensor.shape, dtype=tensor.dtype)
    return staged


def _plan_mlx_moe_gguf_rewrite(model, files, source_norm_offsets=None,
                               source_layouts=()):
    staged = _mlx_staged_tensor_stubs(files)
    stacked = _mlx_stacked_expert_tensor_names(model, staged)
    # A block relocation shows as ordinary renames on its router and shared experts.
    parents = _mlx_moe_parent_substitutions(
        _build_mlx_moe_rename_plan(model, staged, None, exclude=stacked)[0]
    )
    # Architectures llama.cpp already maps stacked (Llama 4) have no names to recover.
    split = (
        _build_mlx_moe_expert_unstack_plan(model, stacked, staged, parents)
        if stacked
        else None
    )
    # Split tensors have no staged counterpart to rename: rebuild first, then exclude.
    merges = _build_mlx_moe_expert_stack_plan(model, staged)
    merges.update(_build_mlx_moe_merge_plan(model, staged))
    consumed = {part for parts, *_ in merges.values() for part in parts}
    renames, offsets, layouts = _build_mlx_moe_rename_plan(
        model, staged, split, exclude=consumed
    )
    # Splitting plus relocating needs the relocation proved first.
    late = _build_mlx_moe_renamed_merge_plan(model, staged, renames)
    # A part enters its merge as the checkpoint holds it, so drop its own rename.
    for parts, *_ in late.values():
        for part in parts:
            renames.pop(part, None)
            offsets.pop(part, None)
            layouts.pop(part, None)
    merges.update(late)
    # A fused tensor has no staged counterpart, so drop its rename: parts carry it now.
    fused = _build_mlx_moe_name_split_plan(
        model, staged,
        set(merges) | {part for parts, *_ in merges.values() for part in parts}
        | set(split or {}))
    for parts, *_ in fused.values():
        for part in parts:
            renames.pop(part, None)
            offsets.pop(part, None)
            layouts.pop(part, None)
    merges.update(fused)
    plan = dict(split or {})
    # A rename is a one-name split, so the rewrite below needs no second path.
    plan.update((name, [renamed]) for name, renamed in renames.items())
    # Never subtract twice from what the source measurement already covered.
    offsets = {
        name: constant
        for name, constant in offsets.items()
        if name not in (source_norm_offsets or {})
    }
    # Nor move an axis the pass before this one already moved back.
    layouts = {name: layout for name, layout in layouts.items()
               if name not in (source_layouts or ())}
    # Never take away a name the converter already reads.
    plan = {name: names for name, names in plan.items()
            if not _kept_for_the_gguf_converter(name)}
    merges = {target: recipe for target, recipe in merges.items()
              if not any(_kept_for_the_gguf_converter(part) for part in recipe[0])}
    return plan, offsets, layouts, merges


def _prepare_moe_gguf_export_directory(
    path, model=None, source_norm_offsets=_UNMEASURED, source_layouts=()
):
    """Restore the MoE tensor names and values llama.cpp converters read."""
    path = Path(path)
    files = sorted(path.glob("*.safetensors"))
    # One shared measurement, so the two passes cannot disagree about the source.
    if source_norm_offsets is _UNMEASURED:
        source_norm_offsets = _mlx_sanitizer_norm_offsets(model)
    plan, offsets, layouts, merges = _plan_mlx_moe_gguf_rewrite(
        model, files, source_norm_offsets, source_layouts
    )
    if not plan and not merges and not offsets and not layouts:
        return 0

    owned, owner, anchors = _mlx_moe_merge_placement(files, merges)
    if not _confirmed_mlx_moe_rewrite(
        _mlx_moe_sanitizers(model), files, plan, offsets, layouts, merges,
        source_norm_offsets or {}, owned,
    ):
        return 0

    name_map = {}
    consumed = {part: target for target, (parts, *_) in merges.items() for part in parts}
    # A split's anchor collects its targets; otherwise the index loses all but one.
    for target, anchor in sorted(anchors.items()):
        name_map[anchor] = name_map.get(anchor, ()) + (target,)
    for target, anchor in sorted(anchors.items()):
        for part in merges[target][0]:
            if part != anchor and part not in name_map:
                name_map[part] = ()

    for file in files:
        # One shard at a time: the mx.eval below materializes all of it.
        tensors = mx.load(str(file))
        if file not in owned and not any(
            name in plan or name in offsets or name in layouts or name in consumed
            for name in tensors
        ):
            continue
        updated = _mlx_moe_shard_merges(file, tensors, owner, owned.get(file, {}))
        for name, tensor in tensors.items():
            if name in consumed:
                continue
            offset = offsets.get(name)
            if offset:
                tensor = (tensor - offset).astype(tensor.dtype)
            layout = layouts.get(name)
            if layout:
                tensor = mx.moveaxis(tensor, layout[1], layout[0])
            expert_names = plan.get(name)
            if expert_names is None:
                updated[name] = tensor
                if offset or layout:
                    name_map[name] = (name,)
                continue
            if len(expert_names) == 1:
                updated[expert_names[0]] = tensor
            else:
                for expert, expert_name in enumerate(expert_names):
                    updated[expert_name] = tensor[expert]
            name_map[name] = expert_names
        # mx.load() arrays may be file-backed: write beside the source and replace.
        mx.eval(*updated.values())
        tmp_file = file.with_name(f"{file.stem}.tmp{file.suffix}")
        mx.save_safetensors(str(tmp_file), updated, metadata={"format": "mlx"})
        os.replace(tmp_file, file)
        del updated, tensors

    index_path = path / "model.safetensors.index.json"
    if name_map and index_path.exists():
        with open(index_path, "r") as f:
            index_data = json.load(f)
        weight_map = {}
        for name, shard in index_data.get("weight_map", {}).items():
            for expert_name in name_map.get(name, (name,)):
                weight_map[expert_name] = shard
        index_data["weight_map"] = dict(sorted(weight_map.items()))
        with open(index_path, "w") as f:
            json.dump(index_data, f, indent=4)

    return len(name_map)


_CORE_SAVE_FILENAMES = {
    "config.json",
    "model.safetensors.index.json",
    "README.md",
    ".gitattributes",
}
_MODEL_WEIGHT_SUFFIXES = (
    ".safetensors",
    ".bin",
    ".gguf",
    ".h5",
    ".msgpack",
    ".onnx",
    ".pt",
    ".pth",
)
_MODEL_SIDECAR_SUFFIXES = (".json", ".jinja", ".model", ".txt", ".py")


def _copy_source_sidecars(src_path, path):
    """Copy non-weight source sidecars that tokenizer/model saves may omit."""
    copied = 0
    src_path = Path(src_path)
    path = Path(path)
    if not src_path.is_dir():
        return copied
    for source in src_path.iterdir():
        if not source.is_file():
            continue
        name = source.name
        if name in _CORE_SAVE_FILENAMES:
            continue
        if name.startswith("model-") or name.startswith("pytorch_model"):
            continue
        suffix = source.suffix
        if suffix in _MODEL_WEIGHT_SUFFIXES:
            continue
        if suffix not in _MODEL_SIDECAR_SUFFIXES:
            continue
        target = path / name
        if target.exists():
            continue
        shutil.copy2(source, target)
        copied += 1
    return copied

def _fuse_mlx_module(module, dequantize):
    """Call ``module.fuse()`` regardless of how the flag is spelled.

    mlx-lm renamed it from ``de_quantize`` (0.28.3) to ``dequantize`` (0.28.4)
    and the supported range spans both, so pick the spelling the installed
    implementation accepts. A flagless ``fuse()`` (mlx-vlm's ``ExtendedLmHead``)
    has nothing to dequantize and ``save_merged_model`` dequantizes afterwards.
    """
    fuse = module.fuse
    try:
        parameters = inspect.signature(fuse).parameters
    except (TypeError, ValueError):
        # C extensions can hide their signature; assume the current spelling.
        return fuse(dequantize=dequantize)

    for name in ("dequantize", "de_quantize"):
        if name in parameters:
            return fuse(**{name: dequantize})
    if any(p.kind is inspect.Parameter.VAR_KEYWORD for p in parameters.values()):
        return fuse(dequantize=dequantize)
    return fuse()

def save_merged_model(model, tokenizer, path, dequantize=False):
    """Fuse LoRA weights and save the full merged model.

    Produces an HF-compatible directory with sharded safetensors,
    config.json, tokenizer files, and a model card. The output can
    be reloaded with ``mlx_lm.load()`` or uploaded to HuggingFace Hub.

    Args:
        model: MLX model with LoRA layers.
        tokenizer: Tokenizer to save alongside.
        path: Directory to save merged model.
        dequantize: If True, dequantize quantized layers when fusing
            (saves as fp16/bf16 — needed for GGUF). If False, keep the
            base quantization (smaller checkpoint, only meaningful when
            the base was quantized).
    """
    from mlx_lm.utils import save_model, create_model_card, dequantize_model
    from mlx.utils import tree_unflatten

    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)

    # Fuse LoRA weights into base model (mlx-lm pattern)
    model.eval()
    fused_linears = [
        (n, _fuse_mlx_module(m, dequantize))
        for n, m in model.named_modules()
        if hasattr(m, "fuse")
    ]
    if fused_linears:
        model.update_modules(tree_unflatten(fused_linears))

    if dequantize:
        model = dequantize_model(model)
        cfg = getattr(model, "_config", None)
        if isinstance(cfg, dict):
            model._config = _strip_mlx_quantization_metadata(cfg)

    de_lora_model = model

    # Save sharded safetensors + index.json
    save_model(path, de_lora_model, donate_model=False)

    # Save config.json
    config = _get_model_config(model)
    if config:
        is_vlm = _is_vlm_model(model) or _has_vision_config(config)
        _save_mlx_config(
            config,
            path / "config.json",
            is_vlm=is_vlm,
        )

    # Save tokenizer
    tokenizer.save_pretrained(str(path))

    src_path = _get_src_path(model)
    if src_path is not None:
        _copy_source_sidecars(src_path, path)

    # Model card
    hf_repo = getattr(model, "_hf_repo", None)
    try:
        create_model_card(path, hf_repo)
    except Exception:
        # hf_repo missing on Hub — write a minimal card
        readme = path / "README.md"
        if not readme.exists():
            readme.write_text("---\nlibrary_name: mlx\ntags:\n- mlx\n- unsloth\n---\n")

    print(f"Unsloth: Merged model saved to {path}")


def _ensure_hub_repo_visibility(api, repo_id, private):
    """create_repo + update_repo_settings + verify on failure.

    private=None  : skip the visibility update entirely (Hub policy).
    private=False : soft-fail on update error (stuck-private is not a leak).
    private=True  : verify via repo_info on update failure; only raise when
                    the repo is confirmed non-private (covers tokens lacking
                    write:repo_settings on a just-created private repo).
    """
    _create_repo_kwargs = {"repo_id": repo_id, "exist_ok": True}
    if private is not None:
        _create_repo_kwargs["private"] = bool(private)
    api.create_repo(**_create_repo_kwargs)

    if private is None:
        return

    try:
        api.update_repo_settings(
            repo_id=repo_id,
            private=bool(private),
            repo_type="model",
        )
        return
    except Exception as exc:
        if not bool(private):
            print(f"Unsloth: Could not update repo visibility ({exc}); continuing.")
            return

        # private=True: verify before blocking the upload.
        try:
            info = api.repo_info(repo_id=repo_id, repo_type="model")
            if bool(getattr(info, "private", False)):
                return
        except Exception:
            pass

        raise RuntimeError(
            "Unsloth: private=True was requested but the Hub "
            f"repo {repo_id!r} visibility could not be confirmed "
            "private (likely token lacks `write:repo_settings` or "
            "the repo is owned by another user). Refusing to upload "
            "to avoid publishing artifacts to an existing public "
            "repository."
        ) from exc


# Module-level constants so _caller_wants_commit_metadata can distinguish
# "caller explicitly wants this Unsloth default" from "caller wants their
# own commit string"; same pattern as push_to_hub_merged.
_LORA_DEFAULT_COMMIT_MESSAGE = "Trained with Unsloth"
_LORA_DEFAULT_COMMIT_DESCRIPTION = "Upload LoRA adapters trained with Unsloth 2x faster"


def _push_lora_adapters_to_hub(
    save_directory,
    repo_id=None,
    token=None,
    private=None,
    tags=None,
    commit_message=None,
    commit_description=None,
    create_pr=False,
    revision=None,
):
    """Upload an already-written LoRA adapter directory to the Hub.

    Mirrors push_to_hub_merged's repo / commit / privacy / tag / upload
    semantics, but skips the merged save_model fallback so it does not
    overwrite adapters.safetensors with a full merged model.
    """
    from huggingface_hub import HfApi

    save_directory = Path(save_directory)
    if repo_id is None:
        repo_id = save_directory.name

    # Capture caller intent BEFORE backfilling defaults. Treat the Unsloth
    # default strings the same as None so an outer wrapper that forwards
    # the default verbatim is not mistaken for a custom request (the
    # upload_large_folder fallback cannot preserve commit metadata).
    _caller_wants_commit_metadata = bool(
        create_pr
        or commit_message not in (None, _LORA_DEFAULT_COMMIT_MESSAGE)
        or commit_description not in (None, _LORA_DEFAULT_COMMIT_DESCRIPTION)
    )

    # Match push_to_hub_merged's commit conventions so the history is
    # recognizable across CUDA and MLX backends.
    if commit_message is None:
        commit_message = _LORA_DEFAULT_COMMIT_MESSAGE
    if "Unsloth" not in commit_message:
        commit_message = (commit_message + " (Trained with Unsloth)").lstrip()
    if commit_description is None:
        commit_description = _LORA_DEFAULT_COMMIT_DESCRIPTION
    elif "Unsloth 2x faster" not in commit_description:
        commit_description += " (Trained with Unsloth 2x faster)"

    api = HfApi(token=token)
    _ensure_hub_repo_visibility(api, repo_id, private)

    if tags:
        try:
            from huggingface_hub import ModelCard
            card_path = save_directory / "README.md"
            # Seed a minimal card: fresh adapter dirs have no README, so
            # ModelCard.load() would otherwise raise and tags would be lost.
            if not card_path.exists():
                card_path.write_text(
                    "---\n"
                    "library_name: mlx\n"
                    "tags:\n"
                    "- mlx\n"
                    "- unsloth\n"
                    "---\n",
                    encoding="utf-8",
                )
            card = ModelCard.load(card_path)
            existing = list(getattr(card.data, "tags", None) or [])
            merged = list(dict.fromkeys(existing + list(tags) + ["mlx", "unsloth"]))
            card.data.tags = merged
            card.save(card_path)
        except Exception as exc:
            print(f"Unsloth: Could not set tags in model card ({exc}); continuing.")

    # Allow-list adapter-relevant files only; prevents accidentally pushing
    # stale merged-model artifacts or external GGUF exports under the LoRA
    # adapter repo (data-leak guard for the public-by-default case).
    _lora_allow_patterns = [
        "adapters.safetensors",
        "adapter_config.json",
        # `adapter_model.safetensors` is intentionally excluded: MLX writes
        # `adapters.safetensors`, so a matching PEFT file is stale by
        # definition and would corrupt the remote artifact.
        "tokenizer.json",
        "tokenizer_config.json",
        "special_tokens_map.json",
        "tokenizer.model",
        "chat_template.jinja",
        "chat_template.json",
        "preprocessor_config.json",
        "processor_config.json",
        "added_tokens.json",
        "vocab.json",
        "merges.txt",
        "spiece.model",
        "config.json",
        "generation_config.json",
        "README.md",
        ".gitattributes",
    ]

    # Prefer upload_folder for LoRA dirs (small, single commit honours
    # commit_message / create_pr / revision); upload_large_folder is the
    # last-resort fallback when upload_folder is unavailable.
    try:
        api.upload_folder(
            folder_path=str(save_directory),
            repo_id=repo_id,
            repo_type="model",
            commit_message=commit_message,
            commit_description=commit_description,
            create_pr=create_pr,
            revision=revision,
            allow_patterns=_lora_allow_patterns,
        )
    except (AttributeError, TypeError) as exc:
        # Refuse to fall back to upload_large_folder when the caller asked
        # for commit metadata it cannot preserve.
        if _caller_wants_commit_metadata:
            raise RuntimeError(
                "Unsloth: upload_folder() failed but commit metadata or "
                "create_pr=True was requested; upload_large_folder() "
                "cannot preserve commit_message, commit_description, or "
                "create a PR. Upgrade huggingface_hub or retry without "
                "those kwargs."
            ) from exc
        api.upload_large_folder(
            folder_path=str(save_directory),
            repo_id=repo_id,
            repo_type="model",
            revision=revision,
            allow_patterns=_lora_allow_patterns,
        )
    print(f"Unsloth: Pushed LoRA adapters to https://huggingface.co/{repo_id}")


def save_pretrained_merged(
    model,
    tokenizer,
    save_directory,
    save_method="lora",
    push_to_hub=False,
    token=None,
    private=None,
    tags=None,
    repo_id=None,
    commit_message=None,
    commit_description=None,
    create_pr=False,
    revision=None,
):
    """Save the model in HF-compatible format using the requested method.

    This mirrors the CUDA path's ``model.save_pretrained_merged()``.

    Args:
        model: MLX model (with optional LoRA layers).
        tokenizer: Tokenizer to save alongside.
        save_directory: Output directory path.
        save_method: One of:
            - ``"lora"``: save adapter weights only (smallest, default).
            - ``"merged_16bit"``: fuse LoRA into base, dequantize, save full
              fp16/bf16 model. Needed for GGUF / llama.cpp downstream.
            - ``"merged_4bit"``: fuse LoRA into base while keeping the
              base's 4-bit quantization. Only meaningful for QLoRA.
        push_to_hub: If True, upload to HuggingFace Hub after saving.
        token: HuggingFace token for pushing.
        private: Whether the HF repo should be private.
        tags: Additional tags for the model card.
        repo_id: HuggingFace repo ID. If None, uses save_directory name.
        commit_message: Commit title for the upload.
        commit_description: Optional longer commit body.
        create_pr: If True, push to a PR branch instead of main.
        revision: Target branch (defaults to main).
    """
    method = (save_method or "lora").lower().replace(" ", "_")
    if method not in ("lora", "merged_16bit", "merged_4bit"):
        raise ValueError(
            f"Unsloth: Unknown save_method {save_method!r}. "
            f"Use 'lora', 'merged_16bit', or 'merged_4bit'."
        )

    if method == "lora":
        adapter_tensors = collect_mlx_lora_adapter_tensors(model)
        if not adapter_tensors:
            raise ValueError(
                "Unsloth: save_method='lora' but the model has no LoRA "
                "layers — there's nothing to save. Use 'merged_16bit' instead."
            )
        # Preserve intentionally trainable non-LoRA tensors OUTSIDE any
        # LoRA module; exclude wrapped base weights INSIDE a LoRA module
        # so reload-trainable q_proj.weight cannot leak through the save.
        trainable = dict(mlx.utils.tree_flatten(model.trainable_parameters()))
        adapter_keys = set(adapter_tensors)
        lora_module_prefixes = tuple(
            f"{name}." for name, _ in iter_mlx_lora_modules(model) if name
        )
        # Route to save_trainable_adapters when an external param or an
        # intentionally trainable non-base param under a LoRA module (e.g.
        # q_proj.bias) is present. _is_base_tensor_inside_lora_module
        # treats wrapped `.weight`/`.scales`/`.biases` (+ `.linear.*`) as
        # reload-leaks; everything else under a LoRA prefix is user state.
        has_root_lora_module = any(
            name == "" for name, _ in iter_mlx_lora_modules(model)
        )
        has_non_lora_trainable = any(
            key not in adapter_keys
            and not _is_base_tensor_inside_lora_module(
                key, lora_module_prefixes, has_root_lora_module,
            )
            for key in trainable
        )
        if has_non_lora_trainable:
            save_trainable_adapters(model, save_directory)
        else:
            save_lora_adapters(model, save_directory)
        try:
            tokenizer.save_pretrained(str(save_directory))
        except Exception:
            pass
    else:
        # merged_16bit → dequantize fused weights to fp16/bf16
        # merged_4bit  → keep base quantization (LoRA absorbed)
        save_merged_model(
            model, tokenizer, save_directory,
            dequantize=(method == "merged_16bit"),
        )

    if push_to_hub:
        if method == "lora":
            # LoRA artifacts must NOT route through push_to_hub_merged: it
            # would fall back to save_merged_model() (no index.json) and
            # overwrite adapters.safetensors with a full merged model.
            _push_lora_adapters_to_hub(
                save_directory,
                repo_id=repo_id,
                token=token,
                private=private,
                tags=tags,
                commit_message=commit_message,
                commit_description=commit_description,
                create_pr=create_pr,
                revision=revision,
            )
        else:
            push_to_hub_merged(
                model, tokenizer, save_directory,
                repo_id=repo_id,
                token=token, private=private, tags=tags,
                commit_message=commit_message or "Trained with Unsloth",
                commit_description=commit_description or (
                    "Upload model trained with Unsloth 2x faster"
                ),
                create_pr=create_pr,
                revision=revision,
            )


def _is_trusted_local_llama_cpp_dir(llama_cpp_folder):
    """Whether we may `pip install` a package out of this llama.cpp checkout.

    Installing a local directory runs its build backend, so only a checkout we
    manage (~/.unsloth) or one the operator named via UNSLOTH_LLAMA_CPP_PATH
    qualifies. A CWD-relative ./llama.cpp does not: the working directory is not
    always the operator's, and gguf is on the package index anyway.
    """
    from unsloth_zoo.llama_cpp import UNSLOTH_HOME

    def _canonical(path):
        # realpath so a symlinked home (or macOS' /tmp -> /private/tmp) compares
        # equal; normcase so Windows' case-insensitive paths do too.
        return os.path.normcase(os.path.realpath(path))

    def _contains(parent, child):
        parent = _canonical(parent)
        # Trailing separator: "~/.unsloth-evil" is not inside "~/.unsloth".
        # join(parent, "") keeps a root parent as "/" rather than "//".
        return child == parent or child.startswith(os.path.join(parent, ""))

    try:
        real_folder = _canonical(llama_cpp_folder)
        if _contains(UNSLOTH_HOME, real_folder): return True
        # Raw and stripped: LLAMA_CPP_DEFAULT_DIR uses the variable verbatim
        # while Studio strips it, so both spellings must read as trusted.
        raw = os.environ.get("UNSLOTH_LLAMA_CPP_PATH") or ""
        for operator_path in (raw, raw.strip()):
            if operator_path and _contains(operator_path, real_folder): return True
    except Exception:
        # Untrusted on any error; the index fallback still installs gguf.
        pass
    return False


def _install_llama_cpp_macos(llama_cpp_folder=None):
    """Install llama.cpp on macOS by cloning and building with cmake."""
    import subprocess
    if llama_cpp_folder is None:
        # The managed checkout, not a CWD-relative "llama.cpp", so we never build
        # or install out of whatever sits in the working directory.
        from unsloth_zoo.llama_cpp import LLAMA_CPP_DEFAULT_DIR
        llama_cpp_folder = LLAMA_CPP_DEFAULT_DIR

    def _clone():
        print("Unsloth: Cloning llama.cpp...")
        subprocess.run(
            ["git", "clone", "https://github.com/ggml-org/llama.cpp", llama_cpp_folder],
            check=True,
        )

    if not os.path.exists(llama_cpp_folder):
        _clone()
    elif not os.path.isfile(os.path.join(llama_cpp_folder, "CMakeLists.txt")):
        # The folder exists but is not a llama.cpp source tree -- e.g. a prior
        # prebuilt install left binaries + a marker (and no CMakeLists.txt). cmake
        # would fail against it, so replace it with a fresh source checkout before
        # building. A real source tree (CMakeLists.txt present) is kept and rebuilt.
        #
        # Only ever delete a directory we recognise as our own managed prebuilt
        # install (carries UNSLOTH_PREBUILT_INFO.json) AND that lives in a
        # safe-to-delete location (under ~/.unsloth or the legacy ./llama.cpp).
        # Reuse the same guards the generic installer uses so a user-pointed
        # UNSLOTH_LLAMA_CPP_PATH that happens to be a non-source directory is
        # never wiped out from under the caller.
        from unsloth_zoo.llama_cpp import _is_safe_to_delete, UNSLOTH_PREBUILT_INFO_FILENAME
        is_prebuilt_install = os.path.isfile(
            os.path.join(llama_cpp_folder, UNSLOTH_PREBUILT_INFO_FILENAME)
        )
        if not (is_prebuilt_install and _is_safe_to_delete(llama_cpp_folder)):
            raise RuntimeError(
                f"Unsloth: '{llama_cpp_folder}' exists but is not a llama.cpp source "
                f"tree, and is not a recognised Unsloth prebuilt install in a managed "
                f"location, so it will not be removed.\n"
                f"Please point the build at a fresh directory or manually remove it."
            )
        print("Unsloth: Existing prebuilt llama.cpp install is not a source tree; re-cloning for the source build...")
        shutil.rmtree(llama_cpp_folder, ignore_errors=True)
        _clone()

    # Install deps; prefer gguf from the cloned repo to stay in sync, but only
    # from a trusted checkout. Otherwise take the index copy, which keeps the
    # export working without building an unvetted local package.
    gguf_py_dir = os.path.join(llama_cpp_folder, "gguf-py")
    if os.path.exists(gguf_py_dir) and _is_trusted_local_llama_cpp_dir(llama_cpp_folder):
        subprocess.run(
            [sys.executable, "-m", "pip", "install", gguf_py_dir,
             "protobuf", "sentencepiece"],
            check=True, capture_output=True,
        )
    else:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "gguf",
             "protobuf", "sentencepiece"],
            check=True, capture_output=True,
        )

    # Build with cmake (Metal support on macOS)
    build_dir = os.path.join(llama_cpp_folder, "build")
    print("Unsloth: Building llama.cpp with cmake...")

    def _run_build_step(cmd, description):
        # capture_output keeps a successful build quiet, but on failure cmake's
        # stdout/stderr would be swallowed inside CalledProcessError and the user
        # would see a bare non-zero exit with no build log. Surface the captured
        # output in the RuntimeError so macOS build failures are debuggable (this
        # mirrors how the Linux source-build path in llama_cpp.py reports errors).
        try:
            subprocess.run(cmd, check=True, capture_output=True, text=True)
        except subprocess.CalledProcessError as exc:
            details = ""
            if exc.stdout: details += f"\n--- stdout ---\n{exc.stdout}"
            if exc.stderr: details += f"\n--- stderr ---\n{exc.stderr}"
            raise RuntimeError(
                f"Unsloth: {description} failed (exit {exc.returncode}).{details}"
            ) from exc

    _run_build_step(
        ["cmake", llama_cpp_folder, "-B", build_dir,
         # macOS uses a single-config generator, so the build type must be set
         # at configure time; --config Release on the build step is ignored and
         # the binaries would otherwise be built unoptimized (very slow).
         "-DCMAKE_BUILD_TYPE=Release",
         "-DBUILD_SHARED_LIBS=OFF", "-DGGML_METAL=ON"],
        "llama.cpp cmake configure",
    )

    import psutil
    n_jobs = psutil.cpu_count() or 4
    targets = ["llama-quantize", "llama-cli", "llama-gguf-split"]
    target_args = []
    for t in targets:
        target_args += ["--target", t]

    _run_build_step(
        ["cmake", "--build", build_dir, "--config", "Release",
         f"-j{n_jobs}", "--clean-first"] + target_args,
        "llama.cpp cmake build",
    )

    # Copy binaries to llama.cpp root
    bin_dir = os.path.join(build_dir, "bin")
    if os.path.exists(bin_dir):
        import glob as globmod
        for binary in globmod.glob(os.path.join(bin_dir, "llama-*")):
            shutil.copy(binary, llama_cpp_folder)

    print("Unsloth: llama.cpp installed successfully.")


# Markers naming a repackaging, not a different model. The imatrix is published against the base,
# so these peel one per match, repeatedly, after the verbatim name is tried: -unsloth-bnb-4bit
# goes all the way down. \d+-?bit covers both spellings mlx-community uses (-4bit and -4-bit).
_REPACKAGED_MODEL_SUFFIX = re.compile(
    r"-(?:\d+-?bit|int\d+|bf16|fp16|f16|fp8|mxfp4|float16|float32|mlx|awq|gptq|hqq|bnb|unsloth)$",
    re.IGNORECASE,
)


def _exported_gguf_files(save_directory, imatrix_source=None):
    """The *.gguf files this export produced, excluding a caller-supplied imatrix.

    imatrix_file may point inside save_directory. It is copied out before use, but the original
    stays put, and both the summary and the Hub upload glob save_directory, so without this it
    would be published as though it were an exported model.
    """
    files = sorted(Path(save_directory).glob("*.gguf"))
    if imatrix_source is None:
        return files
    return [f for f in files if not _is_same_file(f, imatrix_source)]


def _is_same_file(a, b):
    """True when two paths name one file, asked of the filesystem rather than of the strings.

    The on-disk spelling is the filesystem's to choose: a case-insensitive mount folds case, APFS
    stores NFD, and a symlink defeats equality outright. The fallback covers a path already gone.
    """
    try:
        return os.path.samefile(a, b)
    except OSError:
        a, b = os.path.abspath(str(a)), os.path.abspath(str(b))
        norm = lambda p: unicodedata.normalize("NFC", os.path.normcase(p))
        return norm(a) == norm(b)


def _gguf_imatrix_repo_candidates(model):
    """unsloth/<base>-GGUF repo ids that may ship an upstream imatrix for this model."""
    repos = []
    sources = (
        getattr(model, "_hf_repo", None),
        # Text models keep their config as a dict in _config; VLMs expose an object as .config.
        _config_get(getattr(model, "_config", None), "_name_or_path"),
        _config_get(getattr(model, "config", None), "_name_or_path"),
    )
    for raw in sources:
        name = str(raw or "").strip()
        if not name or os.path.isdir(name):
            continue
        if name.endswith("-GGUF"):
            stems = [name]
        else:
            stem = name.split("/")[-1]
            stems = [stem]
            while True:
                stripped = _REPACKAGED_MODEL_SUFFIX.sub("", stems[-1])
                if stripped == stems[-1] or not stripped:
                    break
                stems.append(stripped)
            stems = [f"unsloth/{s}-GGUF" for s in stems]
        for repo in stems:
            if repo not in repos:
                repos.append(repo)
    return repos


_GGUF_SHARD_SUFFIX = re.compile(r"-\d{5}-of-\d{5}\.gguf$", re.IGNORECASE)


def _gguf_shard_family(first_file, produced_files):
    """`first_file` plus the shards llama.cpp wrote for the same `--outfile`.

    A vision projector is a separate `--outfile` and so carries a different stem.
    Grouping by stem keeps it out without pattern-matching filenames, which would
    misfire on a model legitimately named `example-mmproj-model`.
    """
    def shard_stem(path):
        name = os.path.basename(path)
        match = _GGUF_SHARD_SUFFIX.search(name)
        return name[: match.start()] if match else None

    stem = shard_stem(first_file)
    if stem is None:
        return [first_file]
    return [f for f in produced_files if shard_stem(f) == stem]
def save_pretrained_gguf(
    model,
    tokenizer,
    save_directory,
    quantization_method="fast_quantized",
    first_conversion=None,
    token=None,
    imatrix_file=None,
):
    """Save LoRA-fused model in GGUF format for llama.cpp inference.

    Follows the same pipeline as unsloth's CUDA path:
    1. Merge LoRA and save as HF-compatible safetensors
    2. Install/check llama.cpp
    3. Download and patch convert_hf_to_gguf.py
    4. Convert safetensors -> GGUF (bf16/f16 intermediate)
    5. Quantize to target format if needed

    Args:
        model: MLX model (with or without LoRA).
        tokenizer: Tokenizer to save alongside.
        save_directory: Output directory for GGUF file(s).
        quantization_method: Quantization to apply. Options:
            "not_quantized" - bf16, no quantization
            "fast_quantized" - q8_0 (fast, good quality)
            "quantized" - q4_k_m (small, fast inference)
            Or any llama.cpp quant type: q2_k, q3_k_m, q4_k_m, q5_k_m,
            q6_k, q8_0, f16, bf16, f32, etc.
        first_conversion: Optional override for the intermediate GGUF
            dtype produced by convert_hf_to_gguf before llama-quantize
            compresses it to ``quantization_method``. Pass ``"f32"`` /
            ``"f16"`` / ``"bf16"`` to force a specific intermediate
        token: HuggingFace token for reading the upstream imatrix.
        imatrix_file: None = off; a path = that file; True = download the
            upstream unsloth/<base>-GGUF imatrix. Quants that need one
            whatever the model are refused up front (IMATRIX_REQUIRED_QUANTS);
            the rest are left to llama.cpp.
    """
    from unsloth_zoo.llama_cpp import (
        convert_to_gguf,
        quantize_gguf,
        quant_requires_imatrix,
        resolve_imatrix_file,
        check_llama_cpp,
        install_llama_cpp,
        LLAMA_CPP_DEFAULT_DIR,
        _download_convert_hf_to_gguf,
    )

    # Map friendly names to llama.cpp quant types
    quant_map = {
        "not_quantized": "bf16",
        "fast_quantized": "q8_0",
        "quantized": "q4_k_m",
        None: "q8_0",
    }
    quant_type = quant_map.get(quantization_method, quantization_method)
    # Normalize once so every later comparison agrees. The direct-conversion test below and the
    # gate on llama-quantize used to normalize differently, so "Q4_K_M" lost its imatrix to a run
    # that then went ahead without it.
    quant_type = str(quant_type).strip().lower()

    # Captured before the drop guard can clear imatrix_file: the path may sit inside
    # save_directory, and must not be reported or uploaded as a file this export produced.
    imatrix_source = None
    if isinstance(imatrix_file, (str, os.PathLike)):
        imatrix_source = os.path.expanduser(os.fspath(imatrix_file))

    # Ahead of the output directory and the merge: llama-quantize only refuses these ~10 minutes in.
    if quant_requires_imatrix(quant_type) and not imatrix_file:
        raise RuntimeError(
            f"Unsloth: '{quant_type}' cannot be quantized without an importance matrix. "
            "Pass imatrix_file=True to fetch the upstream Unsloth imatrix, or "
            "imatrix_file='/path/to/imatrix.(dat|gguf)' to use your own."
        )

    save_directory = Path(save_directory)
    save_directory.mkdir(parents=True, exist_ok=True)

    # Apple Silicon always supports bf16
    model_dtype = "bf16"

    # Determine first_conversion (intermediate GGUF format before quantizing)
    if first_conversion is None:
        if quant_type in ("bf16", "f16", "f32"):
            first_conversion = quant_type
        else:
            # k-quants and q8_0 go through a bf16 intermediate, then llama-quantize
            first_conversion = "bf16"
    else:
        first_conversion = str(first_conversion).strip().lower()

    # llama-quantize runs only when the target differs from the direct conversion. Without it an
    # imatrix has nothing to weight, so drop it rather than resolve an unusable one.
    if imatrix_file and (
        quant_type in ("bf16", "f16", "f32") or first_conversion == quant_type
    ):
        warnings.warn(
            f"Unsloth: ignoring imatrix_file -- '{quant_type}' is written by direct conversion, "
            "so llama-quantize never runs."
        )
        imatrix_file = None

    # An imatrix named like a file this export writes is destroyed by it: the outputs overwrite by
    # name and the intermediate is then deleted, while resolution has already copied it out, so the
    # export succeeds having eaten the caller's input. Refuse rather than relocate; where their
    # file belongs is their call. Checked even if the drop guard cleared imatrix_file: same loss.
    if imatrix_source is not None:
        base = save_directory / (getattr(model, "_hf_repo", None) or "model").split("/")[-1]
        for out in (f"{base}.{first_conversion.upper()}.gguf", f"{base}.{quant_type.upper()}.gguf"):
            if _is_same_file(imatrix_source, out):
                raise RuntimeError(
                    f"Unsloth: imatrix_file '{imatrix_source}' is also where this export writes "
                    f"'{os.path.basename(out)}', so the export would overwrite it.\n"
                    "Move the imatrix outside save_directory, or rename it."
                )

    # GGUF conversion requires torch (used by llama.cpp's convert_hf_to_gguf.py)
    try:
        import torch  # noqa: F401
    except ImportError:
        raise ImportError(
            "Unsloth: GGUF export requires PyTorch.\n"
            "Install via: pip install torch\n"
            "torch is only needed for GGUF export, not for training."
        )

    # Step 1: Save merged model to a temp HF-format directory
    with tempfile.TemporaryDirectory() as tmp_dir:
        # Before the merge so a bad path fails in seconds, and outside save_directory so the
        # result is never mistaken for an exported model.
        imatrix = resolve_imatrix_file(
            imatrix_file,
            dest_dir=os.path.join(tmp_dir, "imatrix"),
            repo_candidates=_gguf_imatrix_repo_candidates(model),
            token=token,
        )

        tmp_path = Path(tmp_dir) / "merged"
        is_vlm_model = _is_vlm_model(model)
        print("Unsloth: Merging LoRA weights and saving to 16-bit...")
        save_merged_model(model, tokenizer, tmp_path, dequantize=True)
        # Measured once so both passes subtract against the same answer.
        norm_offsets = _mlx_sanitizer_norm_offsets(model)
        relaid_out = set()
        rewritten = _prepare_mlx_gguf_export_directory(
            tmp_path, model=model, replay_sanitizers=is_vlm_model,
            norm_offsets=norm_offsets, relaid_out=relaid_out,
        )
        # Must run after the norm pass, whose offsets are keyed by the saved names.
        rewritten += _prepare_moe_gguf_export_directory(
            tmp_path, model=model, source_norm_offsets=norm_offsets,
            source_layouts=relaid_out,
        )
        if rewritten:
            print(
                f"Unsloth: Rewrote {rewritten} MLX tensors "
                "for llama.cpp GGUF export."
            )

        # Restore architectures from the original HF config since mlx-vlm's
        # save_config strips that key. convert_to_gguf reconciles MTP metadata
        # with the exported tensor names for every save path.
        _config_path = tmp_path / "config.json"
        if _config_path.exists():
            _cfg = json.loads(_config_path.read_text())
            _changed = False
            # Restore architectures from the original HF config
            if "architectures" not in _cfg:
                _orig_cfg_path = getattr(tokenizer, "name_or_path", None)
                if _orig_cfg_path:
                    _orig_cfg_file = os.path.join(_orig_cfg_path, "config.json")
                    if os.path.exists(_orig_cfg_file):
                        _orig_cfg = json.load(open(_orig_cfg_file))
                        if "architectures" in _orig_cfg:
                            _cfg["architectures"] = _orig_cfg["architectures"]
                            _changed = True
            if _changed:
                _config_path.write_text(json.dumps(_cfg, indent=2))

        # Step 2: Ensure llama.cpp is installed.
        llama_cpp_folder = LLAMA_CPP_DEFAULT_DIR
        try:
            quantizer_location, converter_location = check_llama_cpp(llama_cpp_folder)
        except Exception:
            print("Unsloth: Installing llama.cpp (this only happens once)...")
            try:
                # Prefer the shared installer on every platform: it tries a
                # prebuilt llama.cpp archive first and only then compiles.
                # gpu_support=False everywhere: GGUF export only needs the CPU-only
                # llama-quantize, so no GPU/CUDA build is required. On macOS the
                # flag is moot anyway -- the installer returns the same universal
                # unslothai/llama.cpp macOS/Metal bundle regardless, and the macOS
                # source-build fallback below compiles with Metal on its own.
                # install_llama_cpp also creates ~/.unsloth before cloning, so a
                # fresh machine is fine.
                quantizer_location, converter_location = install_llama_cpp(
                    llama_cpp_folder,
                    gpu_support = False,
                )
            except RuntimeError as exc:
                # The source-build fallback resolves missing system build-deps via
                # apt-get, which does not exist on macOS. Both raise sites for that
                # (do_we_need_sudo and install_package) end with the same phrase
                # "Is this NOT a Linux / Mac based computer?", so match on that shared
                # suffix rather than one variant. Only when the prebuilt was
                # unavailable AND we hit that macOS-only failure do we build from
                # source with cmake + Metal via the macOS helper, then re-probe for
                # the freshly built binaries.
                if (
                    sys.platform != "darwin"
                    or "Is this NOT a Linux / Mac based computer?" not in str(exc)
                ):
                    raise
                _install_llama_cpp_macos(llama_cpp_folder)
                quantizer_location, converter_location = check_llama_cpp(llama_cpp_folder)
        llama_cpp_folder = os.path.dirname(converter_location)

        # Step 3: Download and patch convert_hf_to_gguf.py.
        # why: always go through the wrapper so UNSLOTH_LLAMA_CPP_SCRIPTS_DIR
        # is honored even when a cached converter file exists.
        converter = os.path.join(llama_cpp_folder, "unsloth_convert_hf_to_gguf.py")
        supported_text_archs = None
        supported_vision_archs = None
        with _LLAMA_CPP_PATCHER_ENV_LOCK:
            old_scripts_dir = os.environ.get("UNSLOTH_LLAMA_CPP_SCRIPTS_DIR")
            if old_scripts_dir is None:
                os.environ["UNSLOTH_LLAMA_CPP_SCRIPTS_DIR"] = llama_cpp_folder
            try:
                result = _download_convert_hf_to_gguf()
            finally:
                if old_scripts_dir is None:
                    os.environ.pop("UNSLOTH_LLAMA_CPP_SCRIPTS_DIR", None)
                else:
                    os.environ["UNSLOTH_LLAMA_CPP_SCRIPTS_DIR"] = old_scripts_dir
        if isinstance(result, tuple) and len(result) >= 3:
            converter, supported_text_archs, supported_vision_archs = result[:3]
        elif isinstance(result, str):
            converter = result

        # Step 4: Get model name for output filename
        hf_repo = getattr(model, "_hf_repo", None)
        if hf_repo:
            model_name = hf_repo.split("/")[-1]
        else:
            model_name = "model"

        output_base = str(save_directory / model_name)

        # Step 5: Convert HF -> GGUF
        print(f"Unsloth: Converting to GGUF format...")
        kwargs = dict(
            model_name=output_base,
            input_folder=str(tmp_path),
            model_dtype=model_dtype,
            quantization_type=first_conversion,
            converter_location=converter,
            is_vlm=is_vlm_model,
            is_gpt_oss=False,
            print_output=True,
        )
        if supported_text_archs is not None:
            kwargs["supported_text_archs"] = supported_text_archs
            kwargs["supported_vision_archs"] = supported_vision_archs
        gguf_py_dir = os.path.join(llama_cpp_folder, "gguf-py")
        has_local_gguf = os.path.isdir(gguf_py_dir)
        original_pythonpath = os.environ.get("PYTHONPATH")
        if has_local_gguf:
            os.environ["PYTHONPATH"] = (
                gguf_py_dir
                if not original_pythonpath
                else gguf_py_dir + os.pathsep + original_pythonpath
            )
        try:
            produced_files, _ = convert_to_gguf(**kwargs)
        finally:
            if has_local_gguf:
                if original_pythonpath is None:
                    os.environ.pop("PYTHONPATH", None)
                else:
                    os.environ["PYTHONPATH"] = original_pythonpath

        # Step 6: Quantize if the target quant differs from first_conversion
        if quant_type not in ("bf16", "f16", "f32") and first_conversion != quant_type:
            quantizer = quantizer_location
            if not produced_files:
                raise RuntimeError(
                    "Unsloth: the GGUF converter reported no output file to quantize."
                )
            # What the converter reported, never the requested --outfile name: past
            # --split-max-size it writes shards instead, and llama.cpp finds the rest
            # from shard 1's split.count. The model always converts before any projector.
            base_gguf = produced_files[0]
            base_files = _gguf_shard_family(base_gguf, produced_files)
            final_gguf = f"{output_base}.{quant_type.upper()}.gguf"

            print(f"Unsloth: Quantizing to {quant_type}...")
            quantize_gguf(
                input_gguf=base_gguf,
                output_gguf=final_gguf,
                quant_type=quant_type,
                quantizer_location=quantizer,
                print_output=True,
                imatrix=imatrix,
            )
            # Remove the intermediate, every shard of it, to save space
            for stale in base_files:
                if stale == final_gguf or not os.path.exists(stale):
                    continue
                os.remove(stale)
                print(f"Unsloth: Removed intermediate {Path(stale).name}")

    # List produced files
    gguf_files = _exported_gguf_files(save_directory, imatrix_source)
    for f in gguf_files:
        size_gb = f.stat().st_size / (1024**3)
        print(f"Unsloth: Saved {f.name} ({size_gb:.2f} GB)")
    print(f"Unsloth: GGUF export complete -> {save_directory}")


_PUSH_MERGED_DEFAULT_COMMIT_MESSAGE = "Trained with Unsloth"
_PUSH_MERGED_DEFAULT_COMMIT_DESCRIPTION = "Upload model trained with Unsloth 2x faster"


def push_to_hub_merged(
    model,
    tokenizer,
    save_directory,
    repo_id=None,
    token=None,
    private=None,
    tags=None,
    commit_message=_PUSH_MERGED_DEFAULT_COMMIT_MESSAGE,
    commit_description=_PUSH_MERGED_DEFAULT_COMMIT_DESCRIPTION,
    create_pr=False,
    revision=None,
):
    """Push merged model to HuggingFace Hub.

    Args:
        model: MLX model.
        tokenizer: Tokenizer.
        save_directory: Local path with saved model (or where to save).
        repo_id: HuggingFace repo ID (e.g. "username/model-name").
            If None, uses save_directory as repo_id.
        token: HuggingFace token.
        private: Whether repo should be private.
        tags: Additional tags appended to the model card.
        commit_message: Commit title for the upload.
        commit_description: Optional longer commit body.
        create_pr: If True, push to a PR branch instead of main.
        revision: Target branch (defaults to main).
    """
    from huggingface_hub import HfApi

    save_directory = Path(save_directory)

    # Save first if not already saved
    if not (save_directory / "model.safetensors.index.json").exists():
        save_merged_model(model, tokenizer, save_directory)

    if repo_id is None:
        repo_id = save_directory.name

    # Capture caller intent BEFORE backfilling defaults; upload_large_folder
    # cannot preserve commit_message / commit_description / create_pr (only
    # those three force the upload_folder route). Treat None and the
    # Unsloth default strings the same so a wrapper forwarding the default
    # is not mistaken for a custom request.
    _caller_wants_commit_metadata = bool(
        create_pr
        or commit_message not in (None, _PUSH_MERGED_DEFAULT_COMMIT_MESSAGE)
        or commit_description not in (None, _PUSH_MERGED_DEFAULT_COMMIT_DESCRIPTION)
    )

    # Match the GPU path's "(Trained with Unsloth)" suffix convention so
    # the commit history is recognizable across both backends.
    if commit_message is None:
        commit_message = ""
    if "Unsloth" not in commit_message:
        commit_message = (commit_message + " (Trained with Unsloth)").lstrip()
    if commit_description is None:
        commit_description = "Upload model trained with Unsloth 2x faster"
    elif "Unsloth 2x faster" not in commit_description:
        commit_description += " (Trained with Unsloth 2x faster)"

    api = HfApi(token=token)
    _ensure_hub_repo_visibility(api, repo_id, private)

    if tags:
        try:
            from huggingface_hub import ModelCard
            card_path = save_directory / "README.md"
            # Seed a minimal card: fresh dirs without one would crash
            # ModelCard.load() and silently lose the requested tags.
            if not card_path.exists():
                card_path.write_text(
                    "---\n"
                    "library_name: mlx\n"
                    "tags:\n"
                    "- mlx\n"
                    "- unsloth\n"
                    "---\n",
                    encoding="utf-8",
                )
            card = ModelCard.load(card_path)
            existing = list(getattr(card.data, "tags", None) or [])
            merged = list(dict.fromkeys(existing + list(tags) + ["mlx", "unsloth"]))
            card.data.tags = merged
            card.save(card_path)
        except Exception as exc:
            print(f"Unsloth: Could not set tags in model card ({exc}); continuing.")

    # upload_large_folder resumes / chunks (good for multi-GB merges) but
    # drops commit_message / commit_description / create_pr; route through
    # upload_folder when the caller asked for any of those.
    if _caller_wants_commit_metadata:
        try:
            api.upload_folder(
                folder_path=str(save_directory),
                repo_id=repo_id,
                repo_type="model",
                commit_message=commit_message,
                commit_description=commit_description,
                create_pr=create_pr,
                revision=revision,
            )
        except (AttributeError, TypeError) as exc:
            # Refuse to fall back to upload_large_folder; it cannot preserve
            # commit_message / commit_description / create_pr.
            if _caller_wants_commit_metadata:
                raise RuntimeError(
                    "Unsloth: upload_folder() failed but commit metadata "
                    "or create_pr=True was requested; upload_large_folder() "
                    "cannot preserve commit_message, commit_description, or "
                    "create a PR. Upgrade huggingface_hub or retry without "
                    "those kwargs."
                ) from exc
            api.upload_large_folder(
                folder_path=str(save_directory),
                repo_id=repo_id,
                repo_type="model",
                revision=revision,
            )
    else:
        try:
            api.upload_large_folder(
                folder_path=str(save_directory),
                repo_id=repo_id,
                repo_type="model",
                revision=revision,
            )
        except (AttributeError, TypeError):
            api.upload_folder(
                folder_path=str(save_directory),
                repo_id=repo_id,
                repo_type="model",
                commit_message=commit_message,
                commit_description=commit_description,
                create_pr=create_pr,
                revision=revision,
            )
    print(f"Unsloth: Pushed to https://huggingface.co/{repo_id}")


def push_to_hub_gguf(
    model,
    tokenizer,
    save_directory,
    repo_id,
    quantization_method="fast_quantized",
    token=None,
    private=None,
    first_conversion=None,
    imatrix_file=None,
):
    """Export to GGUF and push to HuggingFace Hub.

    Args:
        model: MLX model.
        tokenizer: Tokenizer.
        save_directory: Local path for GGUF output.
        repo_id: HuggingFace repo ID.
        quantization_method: GGUF quantization type.
        token: HuggingFace token.
        private: Whether repo should be private.
        first_conversion: Optional intermediate GGUF dtype passed through to
            save_pretrained_gguf. Placed after the pre-existing arguments so
            positional callers keep their meaning.
        imatrix_file: Importance matrix passed through to save_pretrained_gguf.
    """
    from huggingface_hub import HfApi

    save_directory = Path(save_directory)

    # Export to GGUF
    save_pretrained_gguf(
        model,
        tokenizer,
        save_directory,
        quantization_method=quantization_method,
        first_conversion=first_conversion,
        token=token,
        imatrix_file=imatrix_file,
    )

    # Upload GGUF files
    api = HfApi(token=token)
    # Same fail-loud private=True rule as the LoRA / merged paths so a
    # private=True request never silently leaks GGUF shards public.
    _ensure_hub_repo_visibility(api, repo_id, private)

    gguf_files = _exported_gguf_files(
        save_directory,
        os.path.expanduser(os.fspath(imatrix_file))
        if isinstance(imatrix_file, (str, os.PathLike)) else None,
    )
    for gguf_file in gguf_files:
        api.upload_file(
            path_or_fileobj=str(gguf_file),
            path_in_repo=gguf_file.name,
            repo_id=repo_id,
        )

    print(f"Unsloth: GGUF pushed to https://huggingface.co/{repo_id}")
