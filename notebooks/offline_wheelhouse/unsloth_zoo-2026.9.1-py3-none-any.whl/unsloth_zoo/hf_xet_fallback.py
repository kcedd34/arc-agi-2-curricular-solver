# Unsloth Zoo - Utilities for Unsloth
# Copyright 2023-present Daniel Han-Chen, Michael Han-Chen & the Unsloth team. All rights reserved.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Xet-primary HF downloads with a Xet retry, then an automatic HTTP fallback, on a stall or a fault.

Xet (``hf_xet``) is fast but can hang with no progress, no exception, and an un-killable native thread.
``HF_HUB_DISABLE_XET`` is read at import time, so the fallback runs in a fresh ``spawn`` child (not a
thread) that sets the env before importing ``huggingface_hub``. Cached files short-circuit with no
child; deterministic errors (401/403/404/disk-full) and cancellation propagate without a fallback.

The transport also changes on a transient fault, a crash and an incomplete snapshot, not only on a
stall, and on Xet an UNRECOGNIZED error counts as transient: hf_xet reports a CAS fault as a bare
``RuntimeError`` whose Rust error chain this package does not own, and treating that as deterministic
skipped the HTTP rung entirely. HTTP is the last rung and gets ``UNSLOTH_HTTP_ATTEMPTS`` children
(default 2, ``UNSLOTH_HTTP_RETRY_BACKOFF`` seconds apart) of its own, because the Xet bridge CDN serves
Xet-backed blobs over plain HTTP too and one degraded CDN therefore fails both rungs. Exhausting them
raises ``DownloadTransportError``, a ``DownloadStallError``, so a caller's guard around the
supervised download cannot be bypassed by a retryable CDN error and fall through to the unguarded
in-process load.

A DATA-phase stall spends one more Xet child (``UNSLOTH_XET_ATTEMPTS``, default 2) before the
transport changes, since that hang is usually a wedged CAS stream that clears on a fresh process.
The retry RE-RUNS the transfer rather than resuming it: ``xet_get`` never passes the ``resume_size``
the HTTP branch uses, so the file is rebuilt from offset zero. It keeps everything already finalized
into a blob (for a snapshot, every completed shard), so the cost is replaying the in-flight file.
``snapshot_download_with_xet_fallback`` warms a whole repo in a killable child before Unsloth's
in-process load; ``hf_hub_download_with_xet_fallback`` does a single file. Unsloth cache / secret /
process helpers are used best-effort (imported only if present) or injected. The child sets
``UNSLOTH_ZOO_DISABLE_GPU_INIT=1`` for unsloth_zoo's lightweight import path (no torch / transformers).
"""

from __future__ import annotations

import builtins
import errno
import importlib.util
import math
import multiprocessing as mp
import logging
import os
import queue
import re
import signal
import sys
import threading
import time
from pathlib import Path
from typing import Any, Callable, Optional

from unsloth_zoo.hf_cache_state import (
    INCOMPLETE_SUFFIX,
    _ROOT_MODEL_SHARD_INDEX_RE,
    _ROOT_MODEL_VARIANT_WEIGHT_RE,
    _as_pattern_list,
    _component_index_weight_probe,
    _diffusers_component_shards_incomplete,
    _diffusers_declared_component_specs,
    _filter_paths,
    _has_glob,
    _has_incomplete_canonical_root_shards,
    _has_incomplete_variant_root_shards,
    _index_variant_token,
    _index_weight_probe,
    _is_canonical_component_shard_index,
    _is_canonical_weight_shard_index,
    _is_loadable_weight_file,
    _read_format_kept,
    _selected_shard_index_incomplete,
    _sentence_transformers_subfolder_incomplete,
    _weight_shard_index_complete,
    blob_bytes_present,
    repo_cache_dir_name,
    has_active_incomplete_blobs,
    hf_cache_root,
    iter_active_repo_cache_dirs,
    request_can_include_weights,
    requested_named_files_present,
    snapshot_dir_is_complete,
    snapshot_has_requested_broken_symlinks,
)

logger = logging.getLogger(__name__)

# Explicit list keeps stdlib imports out of Unsloth's `import *` re-export shim.
__all__ = [
    "DownloadStallError",
    "DownloadTransportError",
    "hf_hub_download_with_xet_fallback",
    "snapshot_download_with_xet_fallback",
    "start_watchdog",
    "get_hf_download_state",
    "is_hf_xet_available",
    "xet_force_disabled",
    "child_should_disable_xet",
    "is_data_phase_stall",
    "xet_attempts",
    "http_attempts",
    "DEFAULT_STALL_TIMEOUT",
    "DEFAULT_CONNECT_TIMEOUT",
    "DEFAULT_HTTP_STALL_TIMEOUT",
    "DEFAULT_XET_ATTEMPTS",
    "DEFAULT_HTTP_ATTEMPTS",
    "DEFAULT_HTTP_RETRY_BACKOFF",
]

_CTX = mp.get_context("spawn")

# Stall thresholds are tiered by phase. Once a partial exists, 30s of a frozen byte count is a hung
# Xet transfer, since Xet writes continuously. BEFORE any partial exists the child is still doing
# DNS + TLS + metadata, legitimately slow on a congested link, so that phase gets a longer leash.
# HTTP keeps the patient threshold: it is the last resort, and killing it has nowhere left to go.
DEFAULT_STALL_TIMEOUT = 30.0
DEFAULT_CONNECT_TIMEOUT = 90.0
DEFAULT_HTTP_STALL_TIMEOUT = 180.0
# How often the watchdog measures. Detection latency is up to one interval on top of the timeout,
# so this has to be well under DEFAULT_STALL_TIMEOUT to honour it.
DEFAULT_POLL_INTERVAL = 5.0

# Xet attempts before dropping to HTTP. A wedged transfer is usually transient and clears on a fresh
# child, so one extra attempt often saves the whole HTTP re-download. Only a DATA-phase stall is
# retried, bounding the extra wait to one stall_timeout; 1 restores the straight-to-HTTP ladder.
DEFAULT_XET_ATTEMPTS = 2
# Past this the ladder just burns time before the transport that would have worked.
_MAX_XET_ATTEMPTS = 8

# HTTP attempts before the ladder gives up. The Xet bridge CDN serves Xet-backed blobs over plain
# HTTP too, so a degraded CDN fails BOTH rungs and a single HTTP child would turn a retryable blip
# into a hard failure. 1 restores the single-attempt HTTP rung.
DEFAULT_HTTP_ATTEMPTS = 2
_MAX_HTTP_ATTEMPTS = 8
# Wait between HTTP children so a CDN shedding load is not hit again at once. 0 means "retry at
# once", not "junk"; ``UNSLOTH_HTTP_RETRY_BACKOFF`` overrides.
DEFAULT_HTTP_RETRY_BACKOFF = 5.0
# Ceiling on that wait: past a few minutes the ladder just holds the caller hostage, and past
# PY_TIMEOUT_MAX ``time.sleep`` / ``Event.wait`` raise OverflowError, which is not a
# DownloadStallError and so escapes the caller's guard into the unguarded in-process load.
_MAX_HTTP_RETRY_BACKOFF = 300.0
# hub's short-download error: a bare EnvironmentError, so nothing in its TYPE says "network".
_HUB_CONSISTENCY_ERROR_RE = re.compile(
    r"consistency check failed: file should be of size", re.IGNORECASE
)

# "The disk cannot take it" errnos, read defensively: which errno names exist is a platform property
# (CPython #ifdefs each one), so a bare errno.EDQUOT would be an AttributeError on a build without it.
_DISK_FULL_ERRNOS = frozenset(
    code for code in (getattr(errno, name, None) for name in ("ENOSPC", "EDQUOT"))
    if code is not None
)

# A child buffering from the network grows RSS at roughly the wire rate. Well above allocator noise
# but far below one poll's worth of even a thin link (20 Mbit/s is ~12 MB per 5s tick), so a
# genuinely hung child cannot drift past it.
_RSS_PROGRESS_EPSILON = 4 * 1024 * 1024
# Growth below _RSS_PROGRESS_EPSILON but above this is a child receiving, just slowly: 4 MiB over a
# 30s deadline is a 1.12 Mbit/s floor, and xet only touches the file at head-of-line boundaries, so
# a slower link (tethered mobile, rural DSL, throttled corporate egress) has flat disk AND
# sub-epsilon RSS growth at once and was being killed mid-transfer. The window moves rather than the
# epsilon, which the frozen-child case needs as noise margin. 256 KiB over 30s is about 68 kbit/s,
# below any link a download could finish on and far above allocator drift (measured 0 KiB over 32s
# for a wedged child in a socket retry loop).
_RSS_SLOW_LINK_EPSILON = 256 * 1024

# Absolute cap on how long peer liveness may keep resetting the connect clock. The case protected is
# "queued behind one live download" and the hub lock is per blob, so the wait is bounded by a single
# blob: a ~5GB shard on a slow link is well under an hour. Without a cap, a continuous series of
# UNRELATED same-repo downloads suppresses the clock forever and a genuinely hung child never falls
# back, because the parent cannot tell which blob its child is waiting for.
PEER_SUPPRESSION_CEILING = 3600.0
# How often a "still downloading" status is pushed to the UI (independent of the measure rate).
DEFAULT_HEARTBEAT_INTERVAL = 30.0
DEFAULT_GRACE_PERIOD = 10.0
_POLL_INTERVAL = 0.5


def _env_seconds(name: str, default: float) -> float:
    """Read a positive finite float override from the environment; ignore junk rather than crash a load.

    ``nan`` and ``inf`` parse as floats and pass a ``value <= 0`` test, but every consumer of this
    value ends up in ``time.sleep`` / ``Event.wait`` / a deadline comparison, where ``nan`` makes
    every comparison False (no deadline ever fires) and ``inf`` raises OverflowError. Reject both.
    """
    raw = os.environ.get(name)
    if not raw:
        return default
    try:
        value = float(raw)
    except (TypeError, ValueError):
        logger.warning("Ignoring non-numeric %s=%r", name, raw)
        return default
    if not math.isfinite(value) or value <= 0:
        logger.warning("Ignoring non-positive or non-finite %s=%r", name, raw)
        return default
    return value


def xet_attempts() -> int:
    """Xet attempts to spend before HTTP, from ``UNSLOTH_XET_ATTEMPTS``.

    Junk / non-positive falls back to the default rather than failing a download, and the value is
    clamped so a typo cannot park a user on a dead transport for an hour. ``0`` is NOT "disable Xet"
    -- ``UNSLOTH_DISABLE_XET`` already means that.
    """
    raw = os.environ.get("UNSLOTH_XET_ATTEMPTS")
    if not raw:
        return DEFAULT_XET_ATTEMPTS
    try:
        value = int(str(raw).strip())
    except (TypeError, ValueError):
        logger.warning("Ignoring non-integer UNSLOTH_XET_ATTEMPTS=%r", raw)
        return DEFAULT_XET_ATTEMPTS
    if value <= 0:
        logger.warning("Ignoring non-positive UNSLOTH_XET_ATTEMPTS=%r", raw)
        return DEFAULT_XET_ATTEMPTS
    return min(value, _MAX_XET_ATTEMPTS)


def http_attempts() -> int:
    """HTTP attempts to spend before failing, from ``UNSLOTH_HTTP_ATTEMPTS``.

    Same junk / non-positive handling and clamp as ``xet_attempts``. Spent only on a transient
    transport failure or a crash: an HTTP STALL still raises on the first verdict, since the patient
    HTTP threshold has already waited out everything a retry would wait for again.
    """
    raw = os.environ.get("UNSLOTH_HTTP_ATTEMPTS")
    if not raw:
        return DEFAULT_HTTP_ATTEMPTS
    try:
        value = int(str(raw).strip())
    except (TypeError, ValueError):
        logger.warning("Ignoring non-integer UNSLOTH_HTTP_ATTEMPTS=%r", raw)
        return DEFAULT_HTTP_ATTEMPTS
    if value <= 0:
        logger.warning("Ignoring non-positive UNSLOTH_HTTP_ATTEMPTS=%r", raw)
        return DEFAULT_HTTP_ATTEMPTS
    return min(value, _MAX_HTTP_ATTEMPTS)


def _http_retry_backoff() -> float:
    """Seconds to wait between HTTP children, from ``UNSLOTH_HTTP_RETRY_BACKOFF``.

    Not ``_env_seconds``: that treats non-positive as junk, which is right for a timeout but wrong
    here, where 0 is the meaningful "retry at once" a test harness or a CI run actually reaches for
    and silently restoring the full default would be a surprise. Only negative / non-finite /
    unparseable falls back, and the result is clamped to ``_MAX_HTTP_RETRY_BACKOFF``.

    ``float()`` accepts ``nan`` and ``inf`` and both survive a ``value < 0`` test, so they have to be
    rejected by name: this value is handed to ``time.sleep`` / ``Event.wait``, where ``nan`` raises
    ValueError and ``inf`` raises OverflowError. Neither is a ``DownloadStallError``, so an escaping
    one would be swallowed by the caller as "could not pre-download, continuing with the normal load"
    -- the exact fall-through ``DownloadTransportError`` exists to prevent.
    """
    raw = os.environ.get("UNSLOTH_HTTP_RETRY_BACKOFF")
    if not raw:
        return DEFAULT_HTTP_RETRY_BACKOFF
    try:
        value = float(str(raw).strip())
    except (TypeError, ValueError):
        logger.warning("Ignoring non-numeric UNSLOTH_HTTP_RETRY_BACKOFF=%r", raw)
        return DEFAULT_HTTP_RETRY_BACKOFF
    if not math.isfinite(value) or value < 0:
        logger.warning("Ignoring negative or non-finite UNSLOTH_HTTP_RETRY_BACKOFF=%r", raw)
        return DEFAULT_HTTP_RETRY_BACKOFF
    return min(value, _MAX_HTTP_RETRY_BACKOFF)


def is_data_phase_stall(message: str) -> bool:
    """Whether a watchdog verdict fired AFTER bytes had flowed.

    "did not start" is the pre-first-byte trip, as likely slow metadata or a cache lock as a broken
    Xet; the others mean the transfer moved and then wedged, which a fresh child usually recovers
    from. Excluding one wording rather than allow-listing the rest fails cheaply (no retry) if a
    future verdict is worded differently. The retry ladder and the health tracker share this rule so
    a stall cannot be worth retrying but not worth recording, or the reverse.
    """
    return "did not start" not in (message or "")


# Serializes the parent-env (and __main__.__file__) mutation around a child spawn so
# concurrent downloads cannot observe each other's transport env.
_SPAWN_ENV_LOCK = threading.Lock()

# Sentinel: "__main__.__file__ untouched for this spawn" (distinct from a saved None).
_UNSET = object()

# HF boolean env convention, case-insensitive.
_TRUTHY = {"1", "true", "yes", "on"}


def _is_true(value: Optional[str]) -> bool:
    return value is not None and str(value).strip().lower() in _TRUTHY


def _safe_status(callback: Optional[Callable[[str], None]], message: str) -> None:
    """Invoke a status callback; swallow its exceptions so a disconnected client cannot kill the
    daemon watchdog thread (stopping stall detection)."""
    if callback is None:
        return
    try:
        callback(message)
    except Exception as e:
        logger.debug("watchdog status callback raised (ignored): %s", e)


def _xet_health_or_none():
    """The machine's Xet verdict, or ``None`` when it cannot be determined.

    ``probe = False`` deliberately: on the download path a network probe would add latency to every
    request, so only the cheap local signals (RAM floor, remembered verdict) are consulted; probing
    is for an explicit preflight. Imported lazily and defensively -- a health check must never stop a
    download starting, so any failure degrades to "no opinion" and the Xet-first ladder runs.
    """
    try:
        from .hf_xet_health import xet_health

        return xet_health(probe = False)
    except Exception as e:
        logger.debug("Xet health check unavailable: %s", e)
        return None


def _xet_log_dir() -> Optional[str]:
    """Where hf_xet writes its own logs: ``HF_XET_LOG_DEST`` if pointed at a directory, else the
    ``logs/`` subdir of the active Xet cache (hf_xet's default)."""
    dest = os.environ.get("HF_XET_LOG_DEST")
    if dest:
        # An empty value means "log to console"; a file path is not a directory we can scan.
        return dest if os.path.isdir(dest) else None
    try:
        from .hf_cache import _active_caches

        _, _, xet_cache = _active_caches()
        return str(xet_cache / "logs") if xet_cache is not None else None
    except Exception:
        return None


def _xet_failure_reason(summary: str) -> str:
    """Attach hf_xet's own ERROR/WARN lines to *summary* so the recorded verdict says WHY."""
    try:
        from .hf_xet_tuning import scan_xet_log

        # Scrubbed like any other child error: a reqwest failure Displays the full URL, and CAS/S3
        # reads use presigned URLs carrying an X-Amz-Signature. This reason is persisted to the
        # health state and shown in the UI for 24h.
        messages = [
            _default_scrub_secrets(m)
            for m in scan_xet_log(_xet_log_dir(), max_messages = 2)
        ]
    except Exception:
        messages = []
    return f"{summary}: {' | '.join(messages)}" if messages else summary


def _record_xet_outcome(ok: bool, reason: str = "") -> None:
    """Report a finished Xet attempt to the health tracker; never raises."""
    try:
        from .hf_xet_health import record_xet_outcome

        record_xet_outcome(ok, reason)
    except Exception as e:
        logger.debug("Could not record Xet outcome: %s", e)


class DownloadStallError(RuntimeError):
    """Raised when no download progress is observed for too long. Unsloth re-imports this canonical type."""


class DownloadTransportError(DownloadStallError):
    """Raised when every transport failed with a transient transport error (CDN 5xx, CAS fault, child
    crash) rather than a hang.

    A SUBCLASS of DownloadStallError deliberately: the guard a caller puts around the supervised
    download is ``except DownloadStallError``, and the whole point of the supervised child is that
    control must not reach the in-process load, which still has Xet enabled and no watchdog. Raising a
    bare RuntimeError here let a retryable CDN blip be swallowed as "could not pre-download, continuing
    with the normal load" and become the unbounded silent hang this module exists to prevent. Still a
    RuntimeError, so an existing ``except RuntimeError`` keeps matching.
    """


def is_hf_xet_available() -> bool:
    """True iff the ``hf_xet`` extra is importable (Hub uses it automatically)."""
    try:
        return importlib.util.find_spec("hf_xet") is not None
    except Exception:
        return False


def xet_force_disabled() -> bool:
    """Whether the user asked to force HTTP up front via ``UNSLOTH_DISABLE_XET`` /
    ``UNSLOTH_STABLE_DOWNLOADS`` / ``HF_HUB_DISABLE_XET``."""
    return (
        _is_true(os.environ.get("UNSLOTH_DISABLE_XET"))
        or _is_true(os.environ.get("UNSLOTH_STABLE_DOWNLOADS"))
        or _is_true(os.environ.get("HF_HUB_DISABLE_XET"))
    )


def child_should_disable_xet(config: dict) -> bool:
    """Single source of truth for the per-worker Xet env flip."""
    return bool(config.get("disable_xet"))


def _default_scrub_secrets(text: str, hf_token: Optional[str] = None) -> str:
    """Best-effort redaction of a token / bearer credential from an error string."""
    if not text:
        return text
    out = text
    # token=True ("use cached token") is common; only a real string token can be substring-redacted.
    if isinstance(hf_token, str) and hf_token:
        out = out.replace(hf_token, "***")
    out = re.sub(r"hf_[A-Za-z0-9]{8,}", "***", out)
    out = re.sub(r"([Bb]earer\s+)[A-Za-z0-9._\-]+", r"\1***", out)
    # Redact the query of a presigned S3/CAS blob URL (temporary creds in the query string); keep
    # non-signed URLs (e.g. ...?download=true).
    def _redact_signed_query(match: "re.Match") -> str:
        base, query = match.group(1), match.group(2)
        if re.search(
            r"(X-Amz-|[Ss]ignature|(?:^|&)(?:sig|token|key|Expires|Policy|Key-Pair-Id)=)",
            query,
        ):
            return f"{base}?***"
        return match.group(0)

    # Stop the query at whitespace OR a structural delimiter (quote/bracket/brace/paren/angle/pipe): a
    # URL embedded in JSON / a dict repr has no trailing whitespace, so a greedy [^\s]* would swallow the
    # closing "} and corrupt the log line. Signed-query values percent-encode these chars, so a genuine
    # presigned URL is still fully redacted.
    out = re.sub(
        r"(https?://[^\s?]+)\?([^\s\"'()<>{}|[\]]*)", _redact_signed_query, out
    )
    return out


def _broken_link_has_active_partner(link: Path, *, active_grace: float) -> bool:
    """SPARE a dangling snapshot symlink iff a sibling is still writing its target blob. Discriminator
    is a FRESH ``.incomplete`` partner of the target, NOT the link mtime: our killed child's partner was
    static for the full stall timeout and is purged first (no partner -> link cleared), while a sibling
    mid-download still has a growing partner (link spared)."""
    try:
        target = Path(os.readlink(link))
        if not target.is_absolute():
            target = link.parent / target
        incomplete_partner = target.with_name(target.name + INCOMPLETE_SUFFIX)
        if incomplete_partner.is_file():
            return time.time() - incomplete_partner.stat().st_mtime < active_grace
    except OSError:
        return False
    return False


def _link_incomplete_partner_name(link: Path) -> Optional[str]:
    """The ``<hash>.incomplete`` basename for a dangling symlink's target blob, or None."""
    try:
        target = Path(os.readlink(link))
        return target.name + INCOMPLETE_SUFFIX
    except OSError:
        return None


def _clear_partials(
    repo_type: str,
    repo_id: str,
    *,
    cache_dir: Optional[str] = None,
    active_grace: float = DEFAULT_STALL_TIMEOUT,
    owned_incomplete_blobs: Optional[set] = None,
) -> None:
    """Delete the repo's active ``*.incomplete`` blobs and the broken snapshot symlinks the detector
    counts as active (else the next attempt inherits stale state and re-trips).
    ``iter_active_repo_cache_dirs`` is case-collision safe, so this destructive purge only touches an
    unambiguous repo cache dir.

    *owned_incomplete_blobs* (basenames the stalled child held open, captured before the kill) SCOPES the
    purge so a same-repo sibling writing a DIFFERENT blob is spared even if aged past *active_grace*;
    None -> coarser mtime guard only.

    Both retry directions need exactly this, for different reasons -- see the two wrappers below.
    """
    try:
        for entry in iter_active_repo_cache_dirs(repo_type, repo_id, cache_dir = cache_dir):
            blobs_dir = entry / "blobs"
            if blobs_dir.is_dir():
                for blob in blobs_dir.iterdir():
                    if blob.is_file() and blob.name.endswith(INCOMPLETE_SUFFIX):
                        # Scope to our own partials when known: never delete a sibling's blob.
                        if owned_incomplete_blobs is not None and blob.name not in owned_incomplete_blobs:
                            continue
                        try:
                            # The mtime grace only GUESSES whether a partial belongs to a live sibling,
                            # and when ownership is known the guess is wrong: a 180s grace spares the
                            # 30s-old partial of the child we just killed, so has_active_incomplete_blobs()
                            # forces force_download and the snapshot re-fetches every complete shard.
                            owned = (
                                owned_incomplete_blobs is not None
                                and blob.name in owned_incomplete_blobs
                            )
                            if not owned and time.time() - blob.stat().st_mtime < active_grace:
                                continue
                            blob.unlink()
                        except OSError:
                            continue  # a locked / denied blob must not abort the rest
            # Clear broken snapshot symlinks (also read as active incomplete state). Sweep EVERY snapshot,
            # else a dangling link under an older revision keeps the repo incomplete and re-trips.
            snapshots_dir = entry / "snapshots"
            try:
                snapshot_dirs = [s for s in snapshots_dir.iterdir() if s.is_dir()]
            except OSError:
                snapshot_dirs = []
            for snapshot in snapshot_dirs:
                try:
                    for link in snapshot.rglob("*"):
                        if link.is_symlink() and not link.exists():
                            # Scope to our own partials when known; a link to a sibling's blob is theirs.
                            if owned_incomplete_blobs is not None and (
                                _link_incomplete_partner_name(link) not in owned_incomplete_blobs
                            ):
                                continue
                            # Spare a sibling's active link (target still has a fresh .incomplete).
                            if _broken_link_has_active_partner(link, active_grace = active_grace):
                                continue
                            try:
                                link.unlink()
                            except OSError:
                                continue
                except OSError:
                    continue
    except Exception as e:
        logger.debug("partial purge failed for %s: %s", repo_id, e)


def _default_prepare_for_http(
    repo_type: str,
    repo_id: str,
    *,
    cache_dir: Optional[str] = None,
    active_grace: float = DEFAULT_STALL_TIMEOUT,
    owned_incomplete_blobs: Optional[set] = None,
) -> None:
    """Make the partial safe for an HTTP resume: an HTTP resume over a sparse Xet / hf_transfer
    partial silently corrupts the blob, so the partial has to go before the transport changes.
    Unsloth injects its marker-aware version instead."""
    _clear_partials(
        repo_type, repo_id, cache_dir = cache_dir, active_grace = active_grace,
        owned_incomplete_blobs = owned_incomplete_blobs,
    )


def _purge_owned_partials_for_xet_retry(
    repo_type: str,
    repo_id: str,
    *,
    cache_dir: Optional[str] = None,
    owned_incomplete_blobs: Optional[set] = None,
) -> None:
    """Clear the killed child's partial before ANOTHER Xet attempt. Same purge, different reason:
    hf_xet rebuilds a file from offset zero rather than resuming it (1.4.x overwrites in place,
    1.6.x truncates), so a leftover would hand the watchdog a frozen byte count while the new child
    re-fetches from the start and trip a false stall within one stall_timeout.

    Marker semantics are deliberately NOT used: Unsloth's injected ``prepare_for_http_fn`` writes an
    ``http`` marker, a lie about who owns the next partial. The grace stays the patient HTTP one --
    it asks whether a partial belongs to a LIVE sibling, not whether we stalled -- and our own blobs
    are exempt from it via the ownership set.
    """
    _clear_partials(
        repo_type, repo_id, cache_dir = cache_dir,
        active_grace = DEFAULT_HTTP_STALL_TIMEOUT,
        owned_incomplete_blobs = owned_incomplete_blobs,
    )


def _active_incomplete_blob_sizes(
    repo_type: Optional[str], repo_id: str, cache_dir: Optional[str] = None
) -> dict[str, int]:
    """Map ``{blob_filename: bytes_present}`` (sparse-aware) for the repo's ``*.incomplete`` partials, so
    the single-file watchdog follows only its own child's partials and a sibling download of a different
    file cannot mask this file's stall."""
    sizes: dict[str, int] = {}
    try:
        for entry in iter_active_repo_cache_dirs(repo_type, repo_id, cache_dir = cache_dir):
            blobs_dir = entry / "blobs"
            if not blobs_dir.is_dir():
                continue
            for blob in blobs_dir.iterdir():
                try:
                    if blob.is_file() and blob.name.endswith(INCOMPLETE_SUFFIX):
                        sizes[blob.name] = blob_bytes_present(blob)
                except OSError:
                    pass
    except Exception:
        pass
    return sizes


def _incomplete_partial_names(
    repo_type: Optional[str], repo_id: str, cache_dir: Optional[str] = None
) -> Optional[set]:
    """Names of the repo's ``*.incomplete`` partials, or ``None`` if the cache could not be read.

    ``None`` is not the same answer as "none of them" and must never release the guard above. Getting
    that distinction right takes an explicit probe of the cache root: ``hf_cache_root`` and
    ``_case_safe_repo_cache_dirs`` both swallow ``OSError`` and report an unreadable or briefly
    absent root as "no directories", which reads as "everything vanished". A root that disappears
    after the guard engaged is a remount or a permission flap, not proof.

    Only ABSENCE is reported, never a judgement about a partial that is still there. Whether a
    surviving partial is a valid prefix that an HTTP resume can safely continue is not recoverable
    from the filesystem: allocation metadata cannot express it. XFS turns speculative preallocation
    into unwritten extents that are allocated, counted in ``st_blocks``, and read back as zeros, so a
    partial with hundreds of megabytes of holes reports itself fully allocated; ext4 ``bigalloc``
    clusters, XFS extent-size hints and ZFS records hide any gap smaller than one allocation unit;
    a gap under one block is invisible to ``st_blocks`` and to ``SEEK_HOLE`` alike; and a FUSE or
    network server supplies ``st_blocks`` itself, so one that synthesises it from the size reports
    every sparse file as whole. Answering that question wrongly installs a zero-filled blob under its
    sha256 name with no error, because the HTTP path verifies size and not content.
    """
    names: set = set()
    try:
        root = hf_cache_root(cache_dir = cache_dir)
        if root is None:
            return None
        # Selected off ONE root listing rather than via iter_active_repo_cache_dirs, which swallows
        # OSError and reported a permission flap or a remount as "no repo dirs" and then "no
        # partials" -- the empty set that releases the guard. Here every error surfaces. The rule
        # mirrors _case_safe_repo_cache_dirs: exact case, else a lone folded match, else neither.
        target = repo_cache_dir_name(repo_type, repo_id)
        folded_target = target.lower()
        entries = [e for e in root.iterdir() if e.name.lower() == folded_target]
        exact = [e for e in entries if e.name == target]
        if exact:
            repo_dirs = exact
        elif len(entries) == 1 and (root / target).exists():
            repo_dirs = entries
        else:
            repo_dirs = []
        for entry in repo_dirs:
            blobs_dir = entry / "blobs"
            if not blobs_dir.is_dir():
                continue
            for blob in blobs_dir.iterdir():
                if blob.name.endswith(INCOMPLETE_SUFFIX):
                    names.add(blob.name)
    except Exception:
        return None
    return names


def _child_rss(pid: int) -> Optional[int]:
    """Resident bytes of child *pid*, or ``None`` when undeterminable.

    The sensor for "receiving data but not written yet": xet-core reconstructs strictly SEQUENTIALLY,
    so nothing reaches the ``.incomplete`` until the head-of-line xorb block (up to 64 MiB)
    completes and every fetched byte sits in the reconstruction buffer, i.e. in RSS. Measured at the
    proxy, 431 MB arrived at a sustained 19.9 Mbit/s while the partial stayed flat at 0.5 MB for 171
    consecutive seconds, with RSS climbing at the wire rate throughout.

    Deliberately NOT ``/proc/<pid>/io`` ``rchar``: that counts VFS reads and reqwest reads sockets
    with ``recv(2)``, which does not increment it (measured: 67 MB over a socket moves rchar by 99
    bytes), so a healthy Xet download shows a frozen rchar.

    The signal self-bounds: once the buffer pool saturates, backpressure throttles the network to the
    write rate, so RSS goes flat exactly when the disk starts growing.
    """
    try:
        import psutil  # type: ignore
    except ImportError:
        psutil = None  # type: ignore
    if psutil is not None:
        try:
            return int(psutil.Process(pid).memory_info().rss)
        except Exception:
            return None
    try:
        with open(f"/proc/{pid}/status", "r") as fh:
            for line in fh:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) * 1024
    except (OSError, ValueError, IndexError):
        pass
    return None


def _child_open_incomplete_blobs(pid: int) -> Optional[set]:
    """Basenames of the ``*.incomplete`` blobs child *pid* has open -- exactly the partial THIS child is
    writing (incl. a resumed partial reusing a prior blob-hash name), not a sibling's (different pid).
    ``None`` when undeterminable (no ``psutil`` / ``/proc``, or process gone) -> caller uses a coarser
    measure; empty set -> child not yet writing (connect / metadata phase)."""
    # psutil is cross-platform (Linux / macOS / Windows).
    try:
        import psutil  # type: ignore
    except ImportError:
        psutil = None  # type: ignore
    if psutil is not None:
        try:
            files = psutil.Process(pid).open_files()
        except Exception:
            return None
        return {os.path.basename(f.path) for f in files if f.path.endswith(INCOMPLETE_SUFFIX)}
    # Linux fallback: read open fds from /proc.
    fd_dir = f"/proc/{pid}/fd"
    try:
        entries = os.listdir(fd_dir)
    except OSError:
        return None  # no /proc (non-Linux) or process gone
    open_blobs: set = set()
    for fd in entries:
        try:
            target = os.readlink(os.path.join(fd_dir, fd))
        except OSError:
            continue
        if target.endswith(INCOMPLETE_SUFFIX):
            open_blobs.add(os.path.basename(target))
    return open_blobs


def get_hf_download_state(
    repo_ids: Optional[list[str]] = None,
    *,
    repo_type: Optional[str] = "model",
    cache_dir: Optional[str] = None,
) -> Optional[tuple[int, bool]]:
    """Return ``(total_on_disk_bytes, has_incomplete)`` for the HF cache being written (sparse-aware, so
    a partial Xet / ``hf_transfer`` blob is not read as full progress). Scans *cache_dir* or the active
    ``HF_HUB_CACHE``. Missing / empty cache -> ``(0, False)``; ``None`` only on a probe exception
    (unmeasurable -> callers skip stall logic this tick)."""
    try:
        if hf_cache_root(cache_dir = cache_dir) is None:
            return (0, False)

        total = 0
        has_incomplete = False
        for repo_id in repo_ids or []:
            # Skip local paths: HF IDs never start with / . ~, contain "\", or a drive-letter ":".
            if (
                not repo_id
                or repo_id.startswith(("/", ".", "~"))
                or "\\" in repo_id
                or ":" in repo_id
            ):
                continue
            for entry in iter_active_repo_cache_dirs(repo_type, repo_id, cache_dir = cache_dir):
                blobs_dir = entry / "blobs"
                if not blobs_dir.is_dir():
                    continue
                for blob in blobs_dir.iterdir():
                    try:
                        if blob.is_file():
                            total += blob_bytes_present(blob)
                    except OSError:
                        pass
            if has_active_incomplete_blobs(repo_type, repo_id, cache_dir = cache_dir):
                has_incomplete = True
        return (total, has_incomplete)
    except Exception as e:
        logger.debug("Failed to determine HF download state: %s", e)
        return None


def start_watchdog(
    *,
    repo_ids: list[str],
    on_stall: Callable[[str], None],
    repo_type: Optional[str] = "model",
    cache_dir: Optional[str] = None,
    interval: Optional[float] = None,
    stall_timeout: Optional[float] = None,
    connect_timeout: Optional[float] = None,
    heartbeat_interval: float = DEFAULT_HEARTBEAT_INTERVAL,
    xet_disabled: bool = False,
    on_heartbeat: Optional[Callable[[str], None]] = None,
    watch_new_partials_only: bool = False,
    baseline_incomplete_blobs: Optional[set] = None,
    child_pid: Optional[int] = None,
    watch_connect: Optional[bool] = None,
) -> threading.Event:
    """Start a daemon thread firing ``on_stall(message)`` once when a download stops making progress.
    Returns a stop event the caller sets when the download phase ends.

    Two clocks, because a frozen byte count means different things before and after bytes flow. Once
    a ``*.incomplete`` exists, *stall_timeout* (30s on Xet) of an unchanged on-disk size is a hang.
    While NO partial exists the child is still resolving DNS / TLS / metadata, so *connect_timeout*
    (90s) applies instead; this phase used to just reset the timer, so a child hung before it ever
    opened a partial was never detected. Both clocks are reset by real progress and neither runs
    after the download completes. Defaults are transport-aware (HTTP keeps the patient 180s) and
    overridable via ``UNSLOTH_XET_STALL_TIMEOUT`` / ``UNSLOTH_XET_CONNECT_TIMEOUT``.

    The connect clock only runs when there is a download process to kill, which *child_pid* signals
    and *watch_connect* forces either way. Callers wrapping the whole of ``from_pretrained`` cannot
    distinguish "no bytes because the child is wedged" from "no bytes because the repo is cached and
    we are quantising to 4-bit", so for them a frozen byte count is normal; they keep the stall
    clock, which only runs against a demonstrably open partial.

    *watch_new_partials_only* (single-file) measures only the child's own partial, so a sibling pull
    cannot keep a hung child alive. That partial is identified by the blobs *child_pid* has open
    (precise across a resume), else the partials not in *baseline_incomplete_blobs* (captured
    pre-spawn). Snapshots keep the repo-wide measurement."""
    stop = threading.Event()
    transport = "https" if xet_disabled else "xet"
    fired = False
    if stall_timeout is None:
        stall_timeout = _env_seconds(
            "UNSLOTH_XET_STALL_TIMEOUT",
            DEFAULT_HTTP_STALL_TIMEOUT if xet_disabled else DEFAULT_STALL_TIMEOUT,
        )
    if connect_timeout is None:
        connect_timeout = _env_seconds("UNSLOTH_XET_CONNECT_TIMEOUT", DEFAULT_CONNECT_TIMEOUT)
    if interval is None:
        # Never sample slower than the tighter of the two deadlines, or the timeout is meaningless.
        interval = min(DEFAULT_POLL_INTERVAL, max(1.0, min(stall_timeout, connect_timeout) / 4.0))
    baseline = set(baseline_incomplete_blobs or ())
    connect_clock = (child_pid is not None) if watch_connect is None else bool(watch_connect)
    single_repo_id = repo_ids[0] if repo_ids else ""

    def _partial_bytes(ids) -> int:
        """Bytes sitting in ACTIVE ``*.incomplete`` partials, nothing else."""
        total = 0
        for one in ids or []:
            total += sum(_active_incomplete_blob_sizes(repo_type, one, cache_dir).values())
        return total

    def _measure() -> Optional[tuple[int, bool, int]]:
        """``(bytes_watched, has_incomplete, bytes_in_active_partials)``.

        The third element exists because in the repo-wide modes *bytes_watched* also counts blobs
        already COMPLETE before this download began (a cached config, a shard from an earlier run),
        so a nonzero total says nothing about whether the CURRENT transfer got its first byte.
        """
        if watch_new_partials_only:
            sizes = _active_incomplete_blob_sizes(repo_type, single_repo_id, cache_dir)
            open_names = _child_open_incomplete_blobs(child_pid) if child_pid else None
            if open_names is not None:
                # Only partials this child holds open (handles a resume reusing a baseline name, excludes
                # siblings). hf_xet holds the .incomplete fd continuously, so an EMPTY set means the child
                # owns no partial YET (connect / metadata phase), not a sibling's.
                owned = {name: n for name, n in sizes.items() if name in open_names}
                owned_bytes = sum(owned.values())
                return (owned_bytes, len(owned) > 0, owned_bytes)
            if child_pid:
                # pid given but open files uninspectable (no psutil AND no /proc). Post-baseline name
                # filtering would forever EXCLUDE a resumed partial reusing a baseline name, so a frozen
                # Xet resume would never trip. Fall back to the repo-wide measure, accepting that a
                # same-repo sibling's progress may mask this child's stall.
                state = get_hf_download_state(
                    [single_repo_id], repo_type = repo_type, cache_dir = cache_dir
                )
                return None if state is None else (state[0], state[1], sum(sizes.values()))
            # No child pid at all: follow only newly-created (post-baseline) partials.
            owned = {name: n for name, n in sizes.items() if name not in baseline}
            owned_bytes = sum(owned.values())
            return (owned_bytes, len(owned) > 0, owned_bytes)
        state = get_hf_download_state(repo_ids, repo_type = repo_type, cache_dir = cache_dir)
        return None if state is None else (state[0], state[1], _partial_bytes(repo_ids))

    def _beat() -> None:
        nonlocal fired
        state = _measure()
        last_size = state[0] if state is not None else 0
        last_change = time.monotonic()
        last_heartbeat = 0.0
        # False until at least one BYTE has been observed. Phasing on the partial's existence was
        # wrong both ways: hub/hf_xet can create the .incomplete before CAS setup finishes, handing a
        # healthy-but-slow connect the 30s data deadline instead of the 90s connect one, and a
        # partial going away after bytes flowed means the transfer finished.
        seen_bytes = bool(state[2]) if state is not None else False
        # Sticky, unlike seen_bytes: it only selects the "did not resume" wording for the gap between
        # files, and must not reset when a partial set momentarily empties.
        seen_bytes_ever = seen_bytes
        peer_wait_start: Optional[float] = None
        # peer_wait_start's role for the branches that suppress on a peer AFTER bytes have been seen;
        # a separate variable because those run while seen_bytes is true, exactly when peer_wait_start
        # is cleared. Without a ceiling here a stale peer partial could hold the clock off forever.
        peer_hold_start: Optional[float] = None
        last_rss = (_child_rss(child_pid) if child_pid else None) or 0
        peer_size: Optional[int] = None

        def _peer_progressing() -> bool:
            """Is some OTHER writer downloading into this repo right now?

            huggingface_hub serialises two callers of the same uncached file on an unbounded per-file
            lock and the waiter owns no .incomplete, so in watch_new_partials_only mode it looks like
            a child stuck before the first byte. Repo-wide growth separates "queued behind a live
            download" from "hung"; without it, a first download lasting longer than connect_timeout
            makes every concurrent second caller fail hard.
            """
            nonlocal peer_size
            if not watch_new_partials_only:
                return False  # the snapshot measure is already repo-wide
            peer = get_hf_download_state(repo_ids, repo_type = repo_type, cache_dir = cache_dir)
            current = peer[0] if peer is not None else None
            if current is None or current != peer_size:
                peer_size = current
                return True
            # Flat disk is NOT proof the peer is dead: a healthy Xet transfer writes strictly
            # sequentially, so its .incomplete can sit unchanged for minutes while data piles up in
            # the reconstruction buffer (measured: 171s at 20 Mbit/s), and requiring continuous
            # growth killed a waiter at connect_timeout while the holder downloaded fine. A fresh
            # peer-owned partial is the liveness signal.
            #
            # The bound is the peer SUPPRESSION ceiling, not a stall timeout: 180s sits only 9s above
            # that measured 171s window, so any link slower than 20 Mbit/s expired the peer's
            # liveness mid-transfer. The caller enforces the ceiling independently, so a stale
            # leftover stays bounded by that rather than by an mtime that races the link speed.
            fresh = PEER_SUPPRESSION_CEILING
            now_wall = time.time()
            for one in repo_ids or []:
                for entry in iter_active_repo_cache_dirs(repo_type, one, cache_dir = cache_dir):
                    blobs_dir = entry / "blobs"
                    if not blobs_dir.is_dir():
                        continue
                    try:
                        for blob in blobs_dir.iterdir():
                            try:
                                if (
                                    blob.name.endswith(INCOMPLETE_SUFFIX)
                                    and blob.is_file()
                                    and now_wall - blob.stat().st_mtime < fresh
                                ):
                                    return True
                            except OSError:
                                continue
                    except OSError:
                        continue
            return False

        def _waiting_on_a_peers_partial() -> bool:
            """Repo-wide (snapshot) mode: does another PROCESS own the transfer we are watching?

            A child parked on the hub's per-blob cache lock holds no ``.incomplete``, yet the
            repo-wide phase signal already latched ``seen_bytes`` from the PEER's partial, so it
            lands in the data branch where its own disk and RSS signals are flat by definition.
            Without this it is killed at stall_timeout and records a false Xet failure; a multi-rank
            launch then hits the demotion threshold on the first run and pins a working machine to
            HTTP for 24h.

            Bounded by the caller's PEER_SUPPRESSION_CEILING, not the partial's mtime: an mtime
            window must exceed the peer's head-of-line pause, which scales with the link, so any
            value short enough to bound a leftover also expires on a healthy slow peer.
            """
            if watch_new_partials_only or not child_pid:
                return False
            owned = _child_open_incomplete_blobs(child_pid)
            if owned is None or owned:
                # Uninspectable -> keep the disk-only verdict. Non-empty -> the partial is ours.
                return False
            fresh = PEER_SUPPRESSION_CEILING
            now_wall = time.time()
            for one in repo_ids or []:
                for entry in iter_active_repo_cache_dirs(repo_type, one, cache_dir = cache_dir):
                    blobs_dir = entry / "blobs"
                    if not blobs_dir.is_dir():
                        continue
                    try:
                        for blob in blobs_dir.iterdir():
                            try:
                                if (
                                    blob.name.endswith(INCOMPLETE_SUFFIX)
                                    and blob.is_file()
                                    and now_wall - blob.stat().st_mtime < fresh
                                ):
                                    return True
                            except OSError:
                                continue
                    except OSError:
                        continue
            return False

        def _child_exited(pid: Optional[int]) -> bool:
            """Has the supervised downloader already gone? An exited process is not hung, and its exit
            code is what the ladder acts on, so neither connect trip should fire for it."""
            if not pid or not os.path.isdir("/proc"):
                return False
            return not os.path.isdir(f"/proc/{pid}")

        def _peer_hold_ok(now: float) -> bool:
            """May a peer keep holding the clock off? Bounded by PEER_SUPPRESSION_CEILING."""
            nonlocal peer_hold_start
            if not _waiting_on_a_peers_partial():
                return False
            if peer_hold_start is None:
                peer_hold_start = now
                return True
            return now - peer_hold_start < PEER_SUPPRESSION_CEILING

        def _trip(message: str) -> None:
            nonlocal fired
            if not fired:
                fired = True
                on_stall(message)

        while not stop.wait(interval):
            state = _measure()
            now = time.monotonic()

            if state is None:
                # Unmeasurable this tick (transient FS error): treat as progress so the gap cannot
                # trip a false stall once readable again.
                last_change = now
                _safe_status(on_heartbeat, f"Downloading ({transport} transport)...")
                continue

            current_size, has_incomplete, partial_bytes = state
            rss = _child_rss(child_pid) if child_pid else None
            if current_size != last_size:
                last_size = current_size
                last_change = now
                # The head-of-line block landed and the reconstruction buffer just drained, so re-base
                # the RSS sensor on the CURRENT reading: xet's buffer is a process-wide budget reused
                # across files, so the next episode refills BELOW this peak, and a lifetime high-water
                # mark would hide that fill and trip the data clock on a child receiving at wire rate.
                if rss is not None:
                    last_rss = rss
                peer_hold_start = None      # our own transfer moved: we are not holding on a peer
            # Phase on the partials open RIGHT NOW, not a run-once latch: partial bytes rather than
            # the repo-wide total (which includes blobs complete before this download began), and
            # re-evaluated every tick, because a latch stayed true after file N finished and charged
            # file N+1's empty .incomplete the 30s data deadline during CAS setup. last_size /
            # last_change stay repo-wide; only the deadline SELECTION was wrong.
            seen_bytes = bool(partial_bytes)
            if seen_bytes:
                seen_bytes_ever = True
                peer_wait_start = None      # a byte landed: we are not a lock waiter

            elapsed = now - last_change
            if has_incomplete and seen_bytes:
                # Bytes flowed into a still-open partial, so a frozen count is a hang UNLESS the child
                # is filling its reconstruction buffer, which does not touch disk until the
                # head-of-line block lands. See _child_rss.
                if rss is not None and rss < last_rss:
                    # Buffer handed back to the allocator: the baseline is the TROUGH since the last
                    # reset, never a peak, or growth below an old peak reads as no progress.
                    last_rss = rss
                if rss is not None and rss > last_rss + _RSS_PROGRESS_EPSILON:
                    last_rss = rss
                    last_change = now
                elif elapsed >= _deadline(rss, last_rss, stall_timeout):
                    if _peer_hold_ok(now):
                        # Someone else owns this transfer; we are a lock waiter, not a stall.
                        last_change = now
                        continue
                    _trip(
                        f"Download appears stalled ({transport} transport) "
                        f"-- no progress for {int(elapsed)}s"
                    )
                    return
            elif not has_incomplete and seen_bytes_ever:
                # Bytes flowed earlier and no partial is open now: either the transfer FINISHED
                # (symlinking) or the child is BETWEEN FILES and hung before opening the next one,
                # which is normal mid-download since a snapshot does metadata and the cache lock
                # first. Resetting unconditionally made that hang invisible to BOTH clocks forever
                # once any byte had been seen. The patient connect clock governs the gap; repo-wide
                # progress resets it above and a live peer is covered by the waiter gate.
                #
                # Only where there is a download child to kill: for a caller wrapping the whole of
                # from_pretrained this state is also what a FINISHED download looks like while the
                # weights are quantised, and the repo-wide total does not move across the final
                # .incomplete -> blob rename, so the clock would be counting model init.
                if (
                    connect_clock
                    and not _child_exited(child_pid)
                    and elapsed >= connect_timeout
                    and not _peer_hold_ok(now)
                ):
                    _trip(
                        f"Download did not resume ({transport} transport) "
                        f"-- no data for {int(elapsed)}s"
                    )
                    return
            else:
                # Not one byte in the partials open right now, empty .incomplete or not: the child is
                # stuck before its first byte, OR queued on the hub's per-file cache lock while
                # another writer fetches the same blob. Without this branch such a child is invisible
                # forever; without the peer check, a legitimate lock wait is killed at connect_timeout.
                #
                # The peer check is deliberately weaker than the question asked: the hub lock is per
                # blob but the parent cannot observe WHICH blob its child waits for (filelock closes
                # the lock fd between poll attempts), so any fresh partial in the repo counts. The
                # ceiling bounds how long that approximation may hold the clock off.
                if _peer_progressing() and (
                    peer_wait_start is None
                    or now - peer_wait_start < PEER_SUPPRESSION_CEILING
                ):
                    if peer_wait_start is None:
                        peer_wait_start = now
                    last_change = now
                elif (
                    connect_clock
                    and not _child_exited(child_pid)
                    and elapsed >= connect_timeout
                ):
                    _trip(
                        f"Download did not start ({transport} transport) "
                        f"-- no data after {int(elapsed)}s"
                    )
                    return

            if now - last_heartbeat >= heartbeat_interval:
                last_heartbeat = now
                _safe_status(on_heartbeat, f"Downloading ({transport} transport)...")

    threading.Thread(target = _beat, daemon = True, name = "hf-xet-watchdog").start()
    return stop


def _deadline(rss: Optional[int], trough: int, stall_timeout: float) -> float:
    """How long a flat disk may last before it counts as a hang.

    The short deadline assumes a flat disk means nothing is arriving, which holds only if RSS agrees:
    growth since the trough means the child IS receiving, and on a slow link the reconstruction
    buffer legitimately fills for minutes between writes, so that case gets the patient HTTP
    threshold. Flat or unreadable RSS keeps the short one.
    """
    if rss is not None and rss > trough + _RSS_SLOW_LINK_EPSILON:
        return max(stall_timeout, DEFAULT_HTTP_STALL_TIMEOUT)
    return stall_timeout


def _scrub_in_child(text: str, token: Optional[str]) -> str:
    """Redact secrets from a child error string, preferring Unsloth's patterns if present."""
    try:
        from hub.utils.download_registry import scrub_secrets  # type: ignore

        return scrub_secrets(text, hf_token = token)
    except Exception:
        return _default_scrub_secrets(text, hf_token = token)


# Deterministic Hub failures that recur identically over either transport, so retrying HTTP is
# pointless: surface them. Matched by class NAME so the parent need not import HF's error classes.
_DETERMINISTIC_ERROR_NAMES = frozenset({
    "RepositoryNotFoundError",
    "RevisionNotFoundError",
    "EntryNotFoundError",
    "GatedRepoError",
    "DisabledRepoError",
    "LocalEntryNotFoundError",
    "LocalTokenNotFoundError",  # a missing required token fails identically either way
    "BadRequestError",
    "HFValidationError",        # a malformed repo id / revision never reaches the network
    # An OSError (via builtin ConnectionError) with no errno, so nothing below catches it and the rung
    # default would spend an HTTP child plus the destructive purge on a repo the user switched offline.
    "OfflineModeIsEnabled",
})
# TYPE reconstructed across the spawn but NOT retry-deterministic: ``HfHubHTTPError`` bases both
# deterministic 4xx and transient 5xx / 429, so its retry stays status-code driven while the parent
# still re-raises the real type (not RuntimeError) so ``except HfHubHTTPError`` keeps working.
_TYPE_PRESERVE_ONLY_NAMES = frozenset({
    "HfHubHTTPError",
})
# Substrings marking a transient transport failure (hf_xet / CAS error, timeout, reset, 5xx / 429)
# that an HTTP retry may recover.
_TRANSIENT_ERROR_HINTS = (
    "xet", "casclient", "cas_", "timeout", "timed out", "connection", "reset by peer",
    "temporarily", "try again", "incompleteread", "protocolerror", "remotedisconnected",
    "broken pipe", "ssl", "eof occurred", "502", "503", "504", "500 server", "429",
    "too many requests", "service unavailable", "bad gateway", "gateway time",
    "connection aborted",
)


def _resolve_exception_class(type_name: str) -> "Optional[type]":
    """Map a deterministic Hub / OS error class NAME back to its class so the parent re-raises the
    original type, not RuntimeError. Best-effort (unknown -> None); local imports keep it import-light
    and independent of the huggingface_hub layout."""
    if type_name == "OSError":
        return OSError
    # Preserve builtin OSError subclasses (PermissionError, FileNotFoundError, ...): deterministic FS
    # failures the child cannot retry away, so a caller's `except OSError` / `except PermissionError`
    # must still fire rather than see RuntimeError.
    builtin_cls = getattr(builtins, type_name, None)
    if isinstance(builtin_cls, type) and issubclass(builtin_cls, OSError):
        return builtin_cls
    if type_name not in _DETERMINISTIC_ERROR_NAMES and type_name not in _TYPE_PRESERVE_ONLY_NAMES:
        return None
    for module_name in ("huggingface_hub.errors", "huggingface_hub.utils"):
        try:
            module = importlib.import_module(module_name)
        except Exception:
            continue
        cls = getattr(module, type_name, None)
        if isinstance(cls, type) and issubclass(cls, BaseException):
            return cls
    return None


def _instantiate_preserving_type(exc_cls: type, message: str) -> "Optional[BaseException]":
    """Build an *exc_cls* instance carrying *message*, robust to a finicky constructor: Hub errors
    subclass ``HfHubHTTPError`` whose ``response`` arg can be required, so ``exc_cls(message)`` may raise
    ``TypeError``. Try normal constructors, then BYPASS ``__init__`` via ``__new__`` so type + message
    survive. None only if ``__new__`` fails."""
    for build in (
        lambda: exc_cls(message),
        lambda: exc_cls(message, response = None),
    ):
        try:
            return build()
        except Exception:
            continue
    try:
        exc = exc_cls.__new__(exc_cls)
        BaseException.__init__(exc, message)
        return exc
    except Exception:
        return None


def _parse_errno(message: str) -> "Optional[int]":
    """Pull the errno out of a stringified OSError (CPython formats it ``[Errno 28] ...``), so a
    disk-full / quota error keeps its code across the spawn boundary for ``exc.errno`` branching."""
    match = re.search(r"\[Errno (\d+)\]", message)
    if match is None:
        return None
    try:
        return int(match.group(1))
    except ValueError:
        return None


def _is_builtin_oserror(exc: BaseException) -> bool:
    """True iff *exc* is a BUILTIN ``OSError`` (or subclass) with a real errno. Excludes HF/requests HTTP
    errors (``OSError`` via ``requests -> IOError`` but no OS errno), so a bracketed ``[Errno N]`` in
    their message is not mistaken for one."""
    if not isinstance(exc, OSError):
        return False
    builtin = getattr(builtins, type(exc).__name__, None)
    return isinstance(builtin, type) and issubclass(builtin, OSError) and isinstance(exc, builtin)


def _raise_child_error(message: str) -> None:
    """Re-raise a deterministic child error preserving its original TYPE for a known Hub / OS error, so
    callers' ``except RepositoryNotFoundError`` / ``GatedRepoError`` / ``OSError`` still match across the
    spawn. Child reports ``"<ClassName>: <message>"``; an unrecognized / uninstantiable class ->
    ``RuntimeError``."""
    type_name = message.split(":", 1)[0].strip() if ":" in message else ""
    exc_cls = _resolve_exception_class(type_name)
    if exc_cls is None:
        raise RuntimeError(message)
    exc = _instantiate_preserving_type(exc_cls, message)
    if exc is None:
        raise RuntimeError(message)
    if _is_builtin_oserror(exc) and getattr(exc, "errno", None) is None:
        # Preserve errno (ENOSPC / EDQUOT ...) across the spawn for `except OSError` cleanup, for EVERY
        # builtin OSError subclass. Restricted to BUILTIN types (an HF HTTP error is also an OSError via
        # requests -> IOError, but its "[Errno N]" is not a real errno). Set as an attribute, not via the
        # two-arg constructor: a single-arg __init__ subclass (LocalEntryNotFoundError) rejects it, and
        # this avoids a doubled "[Errno N]" prefix.
        errno_val = _parse_errno(message)
        if errno_val is not None:
            try:
                exc.errno = errno_val
            except Exception:
                pass
    raise exc


def _is_retryable_download_error(exc: BaseException, *, on_xet: bool) -> bool:
    """True when a captured exception looks like a transient transport failure (``hf_xet`` / CAS error,
    reset, timeout, 5xx / 429) the OTHER transport may recover, vs a deterministic Hub error (auth,
    not-found, gated, disk-full).

    An UNRECOGNIZED error is decided by the rung it happened on. hf_xet reports a CAS fault as a bare
    ``RuntimeError`` carrying a Rust error chain -- "Task error: File reconstruction error: CAS Client
    Error: Format error: I/O error: error decoding response body" -- which matches none of the hints
    below and is worded by xet-core rather than by this package, so the list cannot be kept complete
    from here. On Xet an unknown error is therefore treated as transport-attributable: that costs one
    HTTP attempt to disprove, against surrendering the supervised path to an unguarded in-process
    load, which is the worse trade by far. HTTP is the last rung, where an unknown error is surfaced
    rather than looped.
    """
    name = type(exc).__name__
    # Control flow, not transport: the child reports via `except BaseException`, so these reach the
    # classifier and the rung default would call them retryable, spending an HTTP child plus the
    # destructive purge. Programming errors stay unlisted -- the "one HTTP attempt to disprove it"
    # trade still holds for those, but nothing makes an interpreter shutdown a CDN problem.
    if isinstance(exc, (KeyboardInterrupt, SystemExit, GeneratorExit)):
        return False
    # LocalEntryNotFoundError wraps BOTH a genuine offline / uncached miss (deterministic) AND a
    # TRANSIENT HEAD connection error / timeout for an uncached file. Retry the transient sub-case; a
    # true offline miss (no transient hint) falls through to the deterministic set below.
    if name == "LocalEntryNotFoundError" and any(
        hint in f"{name}: {exc}".lower() for hint in _TRANSIENT_ERROR_HINTS
    ):
        return True
    if name in _DETERMINISTIC_ERROR_NAMES:
        return False
    # Disk full / quota: another transport cannot help. errnos are read defensively because an
    # AttributeError here would fire inside the child's `except BaseException` while it is REPORTING
    # a failure, turning a clean deterministic error into a "crashed" verdict that spends the budget.
    if isinstance(exc, OSError) and getattr(exc, "errno", None) in _DISK_FULL_ERRNOS:
        return False
    # HTTP status (HfHubHTTPError carries a requests / httpx response): 5xx / 429 / 408 transient,
    # other 4xx (401 / 403 / 404 / 416) deterministic.
    status = getattr(getattr(exc, "response", None), "status_code", None)
    if not isinstance(status, int):
        status = getattr(exc, "status_code", None)
    if isinstance(status, int):
        return status >= 500 or status in (408, 429)
    # A builtin OSError is decided by its CLASS, before the text scan: str(OSError) embeds the
    # FILENAME and the Xet cache lives at ~/.cache/huggingface/xet/, so a local PermissionError or
    # read-only-filesystem error under it matches the "xet" hint and would read as a transient
    # transport fault. Network subclasses stay retryable by type, which is robust to their wording.
    if _is_builtin_oserror(exc):
        # One exception: the Hub raises a bare EnvironmentError for a short download and says itself
        # it is usually a network issue, which is exactly what the HTTP retry budget is for. Matched
        # on the Hub's own wording, which cannot collide with a filename the way the "xet" hint does.
        if _HUB_CONSISTENCY_ERROR_RE.search(str(exc)):
            return True
        return isinstance(exc, (ConnectionError, TimeoutError, BrokenPipeError, BlockingIOError))
    text = f"{name}: {exc}".lower()
    if any(hint in text for hint in _TRANSIENT_ERROR_HINTS):
        return True
    return on_xet


def _child_download(*, kind: str, params: dict, token: Optional[str], repo_type: str) -> str:
    """Run the actual HF download for one attempt inside the spawn child."""
    if kind == "snapshot":
        from huggingface_hub import snapshot_download

        return snapshot_download(
            repo_id = params["repo_id"],
            repo_type = repo_type,
            token = token,
            revision = params.get("revision"),
            cache_dir = params.get("cache_dir"),
            allow_patterns = params.get("allow_patterns"),
            ignore_patterns = params.get("ignore_patterns"),
            force_download = params.get("force_download", False),
        )

    from huggingface_hub import hf_hub_download

    return hf_hub_download(
        repo_id = params["repo_id"],
        filename = params["filename"],
        subfolder = params.get("subfolder"),
        repo_type = repo_type,
        token = token,
        revision = params.get("revision"),
        cache_dir = params.get("cache_dir"),
        force_download = params.get("force_download", False),
    )


def _download_child_entry(
    *,
    kind: str,
    params: dict,
    token: Optional[str],
    repo_type: str,
    disable_xet: bool,
    result_queue: Any,
) -> None:
    """Spawn-child entrypoint (top-level + picklable): set the Xet env BEFORE importing huggingface_hub,
    form its own process group so the parent can kill the whole transfer, never log token / signed
    URLs."""
    # Die with the parent on Linux under Unsloth (best-effort; module absent standalone).
    try:
        from utils.process_lifetime import bind_current_process_to_parent_lifetime  # type: ignore

        bind_current_process_to_parent_lifetime()
    except Exception:
        pass

    if hasattr(os, "setsid"):
        try:
            os.setsid()
        except OSError:
            pass

    if disable_xet:
        os.environ["HF_HUB_DISABLE_XET"] = "1"
        # Keep the HTTP writer sequential and resumable (hf_transfer's sparse partials cannot).
        os.environ["HF_HUB_ENABLE_HF_TRANSFER"] = "0"
    else:
        # Defensive: the parent already seeded these around the spawn, but a child launched by any
        # other path must not inherit hf_xet's unbounded multi-GB buffer defaults.
        try:
            from unsloth_zoo.hf_xet_tuning import resize_for_cache_dir

            # A supervised child, so the shortened Xet timeouts belong here: a failure surfaces to
            # the ladder instead of being retried for ~6 minutes. resize, not apply: our own
            # import-time sizing is already in this environment and setdefault would keep it.
            resize_for_cache_dir(os.environ, params.get("cache_dir"))
        except Exception as e:
            logger.debug("Could not apply Xet tuning in child: %s", e)
    os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")

    repo_id = params["repo_id"]

    # Test-only fault injection (never set in production): stall the Xet attempt to exercise the
    # watchdog + HTTP fallback against a real repo.
    if not disable_xet and os.environ.get("UNSLOTH_HF_XET_FORCE_STALL") == "1":
        _stall_fh = None
        try:
            from huggingface_hub.constants import HF_HUB_CACHE

            # Write the fake partial under the repo_type-correct dir the watchdog scans.
            cache_root = params.get("cache_dir") or HF_HUB_CACHE
            repo_dir_name = f"{repo_type or 'model'}s--" + repo_id.replace("/", "--")
            blobs = os.path.join(cache_root, repo_dir_name, "blobs")
            os.makedirs(blobs, exist_ok = True)
            # Hold the partial OPEN for the whole stall (the single-file watchdog counts only partials
            # this PID holds open); bound to a local so it stays open across the sleep.
            _stall_fh = open(os.path.join(blobs, "xet-force-stall.incomplete"), "wb")
            _stall_fh.write(b"\0" * 4096)
            _stall_fh.flush()
        except OSError:
            pass
        while True:
            time.sleep(3600)

    try:
        path = _child_download(kind = kind, params = params, token = token, repo_type = repo_type)
        result_queue.put({"ok": True, "path": path})
    except BaseException as e:  # noqa: BLE001 - report every failure to the parent
        # Classify here, where status / errno / type are still intact. The rung decides an
        # unrecognized error, and only this child knows which rung it ran on.
        result_queue.put({
            "ok": False,
            "error": _scrub_in_child(f"{type(e).__name__}: {e}", token),
            "retryable": _is_retryable_download_error(e, on_xet = not disable_xet),
        })


def _terminate_process_group(proc: "mp.process.BaseProcess", grace_period: float) -> None:
    """Kill *proc* and its whole process group (Xet may spawn helpers). The child ``os.setsid()``s so its
    pgid == pid; the group is signalled via ``os.killpg`` only once ``os.getpgid(pid) == pid`` confirms
    it. SIGTERM, then SIGKILL after *grace_period*."""
    pid = proc.pid

    def _signal_group(sig: int) -> None:
        # Signal the GROUP only once the child is its own leader (pgid == pid after setsid). Before setsid
        # it is still in OUR group and its pid could collide with a recycled group, so ``getpgid != pid``
        # guards ``killpg`` from the WRONG group (a reaped child raises here). Otherwise (also Windows: no
        # killpg / getpgid) signal the single process.
        if pid is not None and hasattr(os, "killpg") and hasattr(os, "getpgid"):
            try:
                if os.getpgid(pid) == pid:
                    os.killpg(pid, sig)
                    return
            except (ProcessLookupError, PermissionError, OSError):
                pass
        try:
            proc.terminate() if sig != getattr(signal, "SIGKILL", -9) else proc.kill()
        except Exception:
            pass

    _signal_group(getattr(signal, "SIGTERM", signal.SIGINT))
    proc.join(timeout = grace_period)
    # SIGKILL only while alive, so the pid (== pgid) is a live target: once join() reaps a leader, a busy
    # host could recycle its pid into an unrelated group and killpg would hit the WRONG one. hf_xet 1.5.x
    # spawns no helpers, so a reaped leader leaves nothing to clean up.
    if proc.is_alive():
        # -9 sentinel takes the force-kill branch on Windows (signal.SIGKILL undefined; moot there since
        # proc.kill() == proc.terminate()), keeping the call site consistent.
        _signal_group(getattr(signal, "SIGKILL", -9))
        proc.join(timeout = 5.0)


def _run_download_attempt(
    repo_id: str,
    *,
    kind: str,
    params: dict,
    token: Optional[str],
    repo_type: str,
    disable_xet: bool,
    cancel_event: Optional[threading.Event],
    stall_timeout: Optional[float],
    interval: Optional[float],
    grace_period: float,
    on_status: Optional[Callable[[str], None]],
) -> tuple[str, Optional[str]]:
    """Run one download in a spawn child under the no-progress watchdog. Returns ``("ok", path)``,
    ``("stall", verdict)`` (the watchdog's message, which tells a DATA-phase hang from a
    pre-first-byte one -- see ``is_data_phase_stall``), ``("cancelled", None)``, ``("crashed",
    message)`` (crash, no captured exception), ``("retryable_error", message)`` (transient, worth an
    HTTP retry), or ``("error", message)`` (deterministic Hub error). Tests monkeypatch this seam to
    avoid spawning."""
    # Single-file: snapshot the on-disk partials BEFORE spawning so the watchdog follows only the blob(s)
    # this child writes, not a sibling's. Snapshots stay repo-wide.
    baseline_partials: Optional[set] = None
    if kind == "file":
        baseline_partials = set(
            _active_incomplete_blob_sizes(repo_type, repo_id, params.get("cache_dir"))
        )
    result_queue: Any = _CTX.Queue()
    proc = _CTX.Process(
        target = _download_child_entry,
        kwargs = dict(
            kind = kind,
            params = params,
            token = token,
            repo_type = repo_type,
            disable_xet = disable_xet,
            result_queue = result_queue,
        ),
        daemon = True,
    )
    # Set the transport env in THIS process around the spawn so the child inherits it from creation: HF
    # caches HF_HUB_DISABLE_XET at import time and the child re-imports huggingface_hub before its body,
    # so a child-side assignment lands too late. The child still sets it defensively.
    child_env = {
        "HF_HUB_DISABLE_PROGRESS_BARS": "1",
        # Skip unsloth_zoo's heavy torch / transformers / device init in the child.
        "UNSLOTH_ZOO_DISABLE_GPU_INIT": "1",
    }
    if disable_xet:
        child_env["HF_HUB_DISABLE_XET"] = "1"
        child_env["HF_HUB_ENABLE_HF_TRANSFER"] = "0"
    with _SPAWN_ENV_LOCK:
        if not disable_xet:
            # hf_xet reads its config natively at import, so the buffer caps must be in the
            # environment BEFORE the child starts; setting them inside the child is too late.
            try:
                from .hf_xet_tuning import resize_for_cache_dir

                # Decide against a COPY of the real environment so the child is tuned exactly the
                # way this process was at import: setdefault semantics keep every explicit user
                # setting, and a user-set HF_XET_HIGH_PERFORMANCE stands our sizing down here too
                # instead of being forced back to 0 for the one path that does the downloading. The
                # call returns only what it wrote, which is precisely what the child needs on top of
                # what it inherits. UNSLOTH_XET_FORCE_CAPS=1 still caps the machine regardless. It
                # resizes rather than applies because our import-time numbers are already in that
                # copy and setdefault would keep them: huggingface_hub honours cache_dir over
                # HF_HUB_CACHE, so the disk clamp has to be redone against the child's destination.
                # Under the lock, so the copy cannot catch a concurrent spawn's temporary overlay
                # below and read another child's numbers as this user's own settings.
                child_env.update(resize_for_cache_dir(dict(os.environ), params.get("cache_dir")))
            except Exception as e:
                logger.debug("Could not compute Xet tuning env: %s", e)
        # Cache Hub's transport constants in the PARENT from the REAL env NOW, before the child-only
        # HF_HUB_DISABLE_XET=1 is briefly set below: else a concurrent thread's FIRST `import
        # huggingface_hub` in the spawn window caches the disabled value and routes later in-process
        # downloads over HTTP. No-op once imported.
        try:
            import huggingface_hub.constants  # noqa: F401
        except Exception:
            pass
        saved_env = {k: os.environ.get(k) for k in child_env}
        # 'spawn' reconstructs __main__ from __main__.__file__: a pseudo-path ('<stdin>', a notebook)
        # fails to start, and a real UNGUARDED caller script re-imports as __mp_main__, re-running
        # top-level from_pretrained -> "start a process before bootstrapping" -> the child exits without
        # a result. Point __main__ at THIS side-effect-free module for the spawn.
        main_module = sys.modules.get("__main__")
        saved_main_file = _UNSET
        saved_main_spec = _UNSET
        if main_module is not None:
            saved_main_file = getattr(main_module, "__file__", _UNSET)
            main_module.__file__ = __file__
            # `python -m pkg`: spawn prefers __spec__.name and re-imports BY NAME. Clearing __spec__
            # forces the __file__ path branch.
            saved_main_spec = getattr(main_module, "__spec__", _UNSET)
            main_module.__spec__ = None
        try:
            os.environ.update(child_env)
            proc.start()
        except BaseException:
            # proc.start() can raise (OSError under fd / thread exhaustion). The lifecycle try/finally
            # that closes the queue's pipe fds runs only after a successful start, so close it here to
            # avoid an fd leak.
            try:
                result_queue.cancel_join_thread()
                result_queue.close()
            except Exception:
                pass
            raise
        finally:
            for k, v in saved_env.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v
            if main_module is not None:
                if saved_main_file is _UNSET:
                    # __file__ was absent before; remove the one we added.
                    try:
                        delattr(main_module, "__file__")
                    except AttributeError:
                        pass
                else:
                    main_module.__file__ = saved_main_file
                if saved_main_spec is _UNSET:
                    try:
                        delattr(main_module, "__spec__")
                    except AttributeError:
                        pass
                else:
                    main_module.__spec__ = saved_main_spec

    # Bind the child to the parent lifetime when running under Unsloth (best-effort).
    try:
        from utils.process_lifetime import adopt_pid  # type: ignore

        adopt_pid(proc.pid)
    except Exception:
        pass

    stalled = threading.Event()
    # The verdict, not just the fact of one: the ladder retries a data-phase hang over Xet but sends
    # a pre-first-byte one straight to HTTP. Written before the event, so a reader always sees it.
    stall_verdict: list = []
    # If start_watchdog raises ("can't start new thread"), the already-started child must STILL be
    # reaped, so it runs inside the try whose finally reaps it; stop_watchdog stays None until it works.
    stop_watchdog = None
    result: Optional[dict] = None

    def _note_stall(message: str) -> None:
        stall_verdict.append(message)
        stalled.set()

    try:
        stop_watchdog = start_watchdog(
            repo_ids = [repo_id],
            on_stall = _note_stall,
            repo_type = repo_type,
            cache_dir = params.get("cache_dir"),
            interval = interval,
            stall_timeout = stall_timeout,
            xet_disabled = disable_xet,
            on_heartbeat = on_status,
            watch_new_partials_only = (kind == "file"),
            baseline_incomplete_blobs = baseline_partials,
            child_pid = proc.pid,
        )
        while proc.is_alive():
            if cancel_event is not None and cancel_event.is_set():
                _terminate_process_group(proc, grace_period)
                return ("cancelled", None)
            if stalled.is_set():
                # Prefer a result the child enqueued in the watchdog's fire window, so a just-succeeded
                # download is not killed. Its feeder may not have flushed a microseconds-earlier put, so
                # use a short timeout, not get_nowait().
                try:
                    result = result_queue.get(timeout = 1.0)
                    break
                except queue.Empty:
                    pass
                # Capture the partials THIS child owns BEFORE killing it, so HTTP prep scopes its purge to
                # them. Prefer the per-pid open-fd set; else post-baseline partials; None -> coarser mtime
                # guard.
                owned = _child_open_incomplete_blobs(proc.pid) if proc.pid else None
                if not owned and baseline_partials is not None:
                    # None (no psutil / proc) OR an empty set (the child stalled in the connect / metadata
                    # phase before opening any partial): try the post-baseline diff before giving up on scope.
                    current = set(
                        _active_incomplete_blob_sizes(repo_type, repo_id, params.get("cache_dir"))
                    )
                    owned = current - baseline_partials
                # An empty ownership set would scope the HTTP-prep purge to NOTHING, leaving a pre-existing
                # stale *.incomplete blob / dangling link for the retry to inherit and re-trip on. Fall back
                # to None (unscoped) so the mtime + active-partner guards still clear genuinely-stale state
                # while sparing a live sibling.
                params["_owned_incomplete_blobs"] = owned or None
                _terminate_process_group(proc, grace_period)
                return ("stall", stall_verdict[0] if stall_verdict else "")
            try:
                result = result_queue.get(timeout = _POLL_INTERVAL)
                break
            except queue.Empty:
                continue
        else:
            # Process exited; drain any enqueued result. Short timeout, not get_nowait(): the child can
            # exit just before its feeder flushes the pipe, which would spuriously look resultless.
            try:
                result = result_queue.get(timeout = 1.0)
            except queue.Empty:
                result = None
    finally:
        if stop_watchdog is not None:
            stop_watchdog.set()
        proc.join(timeout = grace_period)
        # No loop exit may leak the child; _terminate_process_group is idempotent so a redundant call
        # is a no-op.
        if proc.is_alive():
            _terminate_process_group(proc, grace_period)
        # Release the queue's pipe fds now rather than at GC. The result is extracted and a killed child
        # has nothing to flush, so cancel the feeder before close.
        try:
            result_queue.cancel_join_thread()
            result_queue.close()
        except Exception:
            pass

    if result is None:
        # Child exited resultless: a process-level crash (native hf_xet abort / segfault), not a captured
        # exception, so the other transport may still succeed -- report "crashed".
        return (
            "crashed",
            f"download process for '{repo_id}' exited "
            f"(code={proc.exitcode}) without a result",
        )
    if result.get("ok"):
        return ("ok", result["path"])
    message = result.get("error") or "unknown download error"
    if result.get("retryable"):
        return ("retryable_error", message)
    return ("error", message)


def _intact_subset(
    snapshot_dir: Path, *, repo_type: str, allow_patterns: Any, ignore_patterns: Any,
) -> bool:
    """No interrupted-download evidence for the SELECTED files: no dangling requested symlink and every
    EXACT-named requested file present. A dangling EXCLUDED weight does not reject the subset."""
    return (
        not snapshot_has_requested_broken_symlinks(
            snapshot_dir, allow_patterns = allow_patterns, ignore_patterns = ignore_patterns,
            repo_type = repo_type,
        )
        and requested_named_files_present(
            snapshot_dir, allow_patterns = allow_patterns, ignore_patterns = ignore_patterns
        )
    )


def _is_default_load_weight_file(name: str) -> bool:
    """A weight a DEFAULT ``from_pretrained`` reads: safetensors or bin only. Excludes gguf / pt / onnx /
    msgpack / ... -- a stale cache holding only e.g. ``model.Q4_K_M.gguf`` must not satisfy the load, else
    it fetches the missing ``model.safetensors`` over un-killable Xet. Optimizer state is already excluded
    by ``_is_loadable_weight_file``."""
    return _is_loadable_weight_file(name) and name.endswith((".safetensors", ".bin"))


# CANONICAL root model weight a DEFAULT (no-variant) load reads: model.safetensors / pytorch_model.bin,
# single or numbered shard (dash infix, not a dotted variant token). A PEFT adapter, a variant
# (model.fp16.safetensors), a gguf, and a non-canonical root (consolidated.safetensors, tf_model.h5) are
# NOT matched -- a default from_pretrained probes only these names, so a cache holding only something
# else would fetch the missing canonical weight over un-killable Xet.
_CANONICAL_ROOT_MODEL_WEIGHT_RE = re.compile(
    r"^(?:model|pytorch_model)(?:-\d{5}-of-\d{5})?\.(?:safetensors|bin)$"
)

# CANONICAL (non-variant) diffusers component weight a PLAIN pipeline load reads in a component subfolder:
# a base with no intermediate dotted token, single or numbered shard, safetensors or bin. A VARIANT
# weight (diffusion_pytorch_model.fp16.safetensors) is EXCLUDED, so a variant='fp16' stale cache does not
# read as a warm PLAIN pipeline (which would fetch the non-variant name over un-killable Xet).
_CANONICAL_COMPONENT_WEIGHT_RE = re.compile(
    r"^(?:diffusion_pytorch_model|model|pytorch_model)(?:-\d{5}-of-\d{5})?\.(?:safetensors|bin)$"
)

# SINGLE-FILE canonical root TF / Flax weight a from_tf / from_flax load reads instead of a PyTorch
# format. A SHARDED TF/Flax weight is judged through its index instead -- a lone shard here must NOT read
# as present, else an incomplete sharded set is loaded over Xet.
_CANONICAL_ROOT_TF_FLAX_WEIGHT_RE = re.compile(r"^(?:tf_model\.h5|flax_model\.msgpack)$")

# The shard-index sidecars a sharded TF / Flax weight is enumerated through.
_TF_FLAX_WEIGHT_INDEX_NAMES = ("tf_model.h5.index.json", "flax_model.msgpack.index.json")


def _pytorch_root_weight_formats_ignored(ignore_patterns: Any) -> bool:
    """True when the ignore filter drops BOTH canonical PyTorch root weights (``model.safetensors`` AND
    ``pytorch_model.bin``) -- the ``from_tf`` / ``from_flax`` signature. Lets the readable-weight check
    count the TF/Flax weight the load actually reads rather than false-reject a complete h5/msgpack
    download. Never true for a normal load (which keeps a PyTorch format)."""
    return not _filter_paths(
        ["model.safetensors", "pytorch_model.bin"], None, ignore_patterns
    )

# A training-checkpoint subdir (checkpoint-500/): its weights are never read as diffusers pipeline
# COMPONENTS, so they must not mask missing unet/vae/text-encoder weights.
_CHECKPOINT_DIR_RE = re.compile(r"^checkpoint[-_]\d+$")


def _diffusers_active_component_dirs(specs: dict) -> set:
    """Declared components a pipeline actually loads: spec is a ``[library, class]`` pair with both
    non-null. A ``[null, null]`` (a disabled / optional component such as safety_checker) is excluded --
    the load skips it, so it is not required to be present."""
    active: set = set()
    for name, spec in specs.items():
        if (
            isinstance(spec, (list, tuple)) and len(spec) >= 2
            and spec[0] is not None and spec[1] is not None
        ):
            active.add(name)
    return active


def _is_weightless_component(names: list) -> bool:
    """Whether a component dir (given its top-level file names) is a WEIGHTLESS component --
    scheduler / tokenizer / feature_extractor, which ship a ``*_config.json`` / tokenizer sidecar and no
    model weight. Lets such a component satisfy the warm without a weight, while a dir carrying neither a
    ``config.json`` nor a readable weight nor a recognised sidecar reads as an incomplete model component."""
    return any(
        n.endswith("_config.json")
        or n.startswith("tokenizer")
        or n in ("preprocessor_config.json", "special_tokens_map.json", "merges.txt", "vocab.json")
        for n in names
    )


# Diffusers component classes that ship NO model weight (a config / tokenizer / preprocessor sidecar
# only). Matched as a SUBSTRING so *Scheduler / *Tokenizer / *TokenizerFast / *FeatureExtractor /
# *ImageProcessor / *Processor all register; no weight-bearing pipeline component class (a *Model /
# *Transformer2DModel / *AutoencoderKL / *ControlNetModel / *UNet*) contains one of these tokens.
_WEIGHTLESS_COMPONENT_CLASS_RE = re.compile(
    r"Scheduler|Tokenizer|FeatureExtractor|ImageProcessor|Processor"
)


def _component_requires_weight(spec: Any, names: list) -> bool:
    """Whether a component holding NEITHER a ``config.json`` NOR a readable weight is an INCOMPLETE model
    component (True -> reject) rather than a genuinely WEIGHTLESS one (False). Prefers the DECLARED class
    from ``model_index.json`` (a ``[library, class]`` pair): a scheduler / tokenizer / feature_extractor
    class needs no weight, everything else does -- so a model component holding only a stray sidecar
    (a lone ``tokenizer_config.json`` under ``unet/``) cannot masquerade as weightless. Falls back to the
    sidecar-name heuristic only when the class is unavailable (a malformed / non-string spec)."""
    cls = (
        spec[1]
        if isinstance(spec, (list, tuple)) and len(spec) >= 2 and isinstance(spec[1], str)
        else None
    )
    if cls is not None:
        return not bool(_WEIGHTLESS_COMPONENT_CLASS_RE.search(cls))
    return not _is_weightless_component(names)


def _diffusers_component_weights_complete(
    snapshot_dir: Path, *, variant: Optional[str], ignore_patterns: Any = None,
) -> bool:
    """True when a diffusers pipeline warm holds every weight a plain / variant load reads. Beyond "some
    declared component weight is present" it requires each DECLARED ACTIVE component to be materialised (a
    non-empty subfolder) AND a model-style component to hold a readable weight of the read format -- a
    component is model-style unless it is WEIGHTLESS-shaped (a scheduler / tokenizer / feature_extractor
    sidecar, no config.json + no weight). So a stale partial missing a whole component (unet present, vae
    absent), holding a component's config without its weight, or holding only a stray / nested-checkpoint
    file in a component dir is retried over un-killable Xet, not loaded. Excludes
    ROOT-level weights and training-checkpoint subtrees; applies the ignore filter (format the load reads).
    Fails OPEN on a malformed / empty ``model_index.json`` to the lenient any-component-weight check,
    preserving hang protection without false-rejecting. A variant load accepts a component's canonical
    weight as diffusers' per-component fallback."""
    specs = _diffusers_declared_component_specs(snapshot_dir)
    declared = set(specs) if specs else None
    active = _diffusers_active_component_dirs(specs) if specs else None
    # A VARIANT component weight is a CANONICAL component base carrying the variant token, single or
    # numbered shard: diffusion_pytorch_model.fp16.safetensors / ...fp16-00001-of-00002.safetensors.
    # Filtering to canonical bases (like the plain branch below) stops a variant-named SIDECAR
    # (unet/adapter_model.fp16.safetensors) from counting as a warm component weight the pipeline, which
    # reads unet/diffusion_pytorch_model.fp16.*, would otherwise fetch over un-killable Xet.
    variant_weight_re = (
        re.compile(
            rf"^(?:diffusion_pytorch_model|model|pytorch_model)\.{re.escape(variant)}"
            rf"(?:-\d{{5}}-of-\d{{5}})?\.(?:safetensors|bin)$"
        )
        if variant else None
    )
    per_comp_canon: dict = {}
    per_comp_variant: dict = {}
    try:
        for entry in snapshot_dir.rglob("*"):
            name = entry.name
            is_index = _is_canonical_component_shard_index(name)
            if not is_index and not _is_default_load_weight_file(name):
                continue
            try:
                if not entry.is_file():
                    continue
                rel = entry.relative_to(snapshot_dir).as_posix()
            except (OSError, ValueError):
                continue
            parts = rel.split("/")
            if len(parts) != 2:
                continue  # only a weight AT the component root counts (not a root file nor a nested
                # descendant such as unet/old/diffusion_pytorch_model.safetensors, which diffusers does
                # not read and which must not mask a missing top-level unet/diffusion_pytorch_model.*)
            comp = parts[0]
            if declared is not None and comp not in declared:
                continue  # an UNDECLARED subtree the load does not read
            if _CHECKPOINT_DIR_RE.match(comp):
                continue  # a training-checkpoint subtree, not a component
            if is_index:
                # A component shard INDEX of a kept format proves a readable component weight even for
                # non-standard shard names the weight regexes miss (mirrors _root_model_has_weight); the
                # probe is the component-relative weight (its OWN base), so the ignore filter matches.
                tok = _index_variant_token(name)
                probe = _component_index_weight_probe(name, comp)
                if probe is None:
                    continue
                if tok is None:
                    # A canonical component index: under a variant load it is the per-component FALLBACK the
                    # variant completeness pass skips, so accept it only when its shards are complete; a
                    # plain load validates it via the canonical completeness pass, so record it always.
                    if variant is not None and not _weight_shard_index_complete(entry):
                        continue
                    per_comp_canon.setdefault(comp, []).append(probe)
                elif tok == variant:
                    per_comp_variant.setdefault(comp, []).append(probe)
                continue
            if variant_weight_re is not None and variant_weight_re.match(name):
                per_comp_variant.setdefault(comp, []).append(rel)
            elif _CANONICAL_COMPONENT_WEIGHT_RE.match(name):
                per_comp_canon.setdefault(comp, []).append(rel)
    except OSError:
        return False

    def _has_canon(comp: str) -> bool:
        return bool(_filter_paths(per_comp_canon.get(comp, []), None, ignore_patterns))

    def _has_variant(comp: str) -> bool:
        return bool(_filter_paths(per_comp_variant.get(comp, []), None, ignore_patterns))

    def _has_read_weight(comp: str) -> bool:
        # variant load falls back to a component's canonical weight when it ships no variant file
        return _has_variant(comp) or _has_canon(comp) if variant else _has_canon(comp)

    if active is not None:
        for comp in active:
            comp_dir = snapshot_dir / comp
            try:
                names = [e.name for e in comp_dir.iterdir()] if comp_dir.is_dir() else []
            except OSError:
                names = []
            if not names:
                return False  # a declared active component was never materialised
            if "config.json" in names:  # a model-style component MUST hold a readable weight
                if not _has_read_weight(comp):
                    return False
            elif not _has_read_weight(comp) and _component_requires_weight(specs.get(comp), names):
                # No config.json and no readable weight: an incomplete model-style component whose weight
                # the load would fetch over un-killable Xet. A genuinely weightless component (scheduler /
                # tokenizer / feature_extractor) is exempt -- decided by its DECLARED class when known, so
                # a model component holding only a stray sidecar cannot pass as weightless.
                return False
    # Floor: at least one component holds a weight of the READ format -- rejects a variant-only-for-plain,
    # config-only, checkpoint-only, or undeclared-leftover-only stale snapshot.
    if variant:
        return any(_has_variant(c) for c in (declared or per_comp_variant))
    return any(_has_canon(c) for c in (declared or per_comp_canon))


def _has_diffusers_component_weight(snapshot_dir: Path, *, ignore_patterns: Any = None) -> bool:
    """Whether a PLAIN (non-variant) diffusers pipeline warm is complete for the weights a load reads
    (see ``_diffusers_component_weights_complete``)."""
    return _diffusers_component_weights_complete(
        snapshot_dir, variant = None, ignore_patterns = ignore_patterns
    )


def _root_model_has_weight(snapshot_dir: Path, *, ignore_patterns: Any = None) -> bool:
    """Whether an UNPATTERNED model warm holds a weight a default load reads: a CANONICAL ROOT weight
    (single or numbered shard), or -- for a diffusers pipeline (root ``model_index.json``) -- a
    component-subfolder weight. Counting ANY subtree weight would accept a stale checkpoint-only snapshot
    then fetch the root weights over un-killable Xet; diffusers is the one layout with weights in
    subfolders. Only canonical names count (a VARIANT root, PEFT adapter, gguf, or NON-canonical
    consolidated.* is retried over HTTP -- its canonical weight is still missing). The ignore filter is
    applied so a partial holding only the format the load will NOT read does not count."""
    try:
        is_diffusers = (snapshot_dir / "model_index.json").is_file()
    except OSError:
        is_diffusers = False
    if is_diffusers:
        return _has_diffusers_component_weight(snapshot_dir, ignore_patterns = ignore_patterns)
    rels: list = []
    tf_flax_rels: list = []
    index_probes: set = set()
    try:
        for entry in snapshot_dir.iterdir():
            name = entry.name
            try:
                if not entry.is_file():
                    continue
            except OSError:
                continue
            if _CANONICAL_ROOT_MODEL_WEIGHT_RE.match(name):
                rels.append(name)  # canonical model / pytorch_model (single or shard)
            elif _is_canonical_weight_shard_index(name):
                # a sharded model enumerated via its canonical root index (shard files may carry a
                # non-standard name the regex above misses); record the weight it enumerates.
                index_probes.add(_index_weight_probe(name))
            elif _CANONICAL_ROOT_TF_FLAX_WEIGHT_RE.match(name):
                tf_flax_rels.append(name)  # TF/Flax root weight (from_tf / from_flax)
    except OSError:
        return False
    if _filter_paths(rels, None, ignore_patterns):
        return True
    # A canonical ROOT shard INDEX of a kept format proves a readable weight even for non-standard shard
    # names (e.g. model.safetensors-00001-of-00002.safetensors): transformers enumerates the weight
    # through the index, so its presence is the readable-weight signal; completeness stays Invariant B's.
    if any(_read_format_kept(probe, ignore_patterns) for probe in index_probes):
        return True
    # from_tf / from_flax (both PyTorch formats ignored): count a SINGLE-FILE TF/Flax weight or a COMPLETE
    # sharded set (index + every listed shard present), so a complete h5/msgpack download is not
    # false-rejected, while an INCOMPLETE set is retried over HTTP. Gated so a normal load is unchanged
    # and a stray leftover never counts.
    if _pytorch_root_weight_formats_ignored(ignore_patterns):
        if tf_flax_rels and _filter_paths(tf_flax_rels, None, ignore_patterns):
            return True
        for index_name in _TF_FLAX_WEIGHT_INDEX_NAMES:
            index_path = snapshot_dir / index_name
            try:
                if index_path.is_file() and _weight_shard_index_complete(index_path):
                    return True
            except OSError:
                continue
    return False


def _root_has_variant_weight(
    snapshot_dir: Path, variant: str, *, ignore_patterns: Any = None
) -> bool:
    """True if a CANONICAL ROOT model weight carrying the requested *variant* token (kept by the ignore
    filter) is present. transformers reads ``model.<variant>.safetensors`` and
    ``model.<variant>-00001-of-00002.safetensors`` (``.<variant>-`` shard infix), matched by
    ``_ROOT_MODEL_VARIANT_WEIGHT_RE`` plus the variant infix. A non-canonical base, PEFT adapter, or
    non-``model`` variant is excluded -> a cache holding only those is retried over HTTP. The ignore
    filter is applied so an ignored-format partial does not count.

    Mirrors ``_root_model_has_weight``: a ROOT variant shard INDEX
    (``model.safetensors.index.<variant>.json`` / ``pytorch_model.bin.index.<variant>.json``) of a kept
    format also proves a readable weight, so a variant sharded with NON-standard shard names the weight
    regex misses is not false-rejected. Shard completeness stays ``_has_incomplete_variant_root_shards``'s
    job, so an index whose shards are missing is still correctly rejected."""
    infix_dot = f".{variant}."
    infix_dash = f".{variant}-"
    rels: list = []
    index_probes: set = set()
    try:
        for entry in snapshot_dir.iterdir():
            name = entry.name
            if infix_dot not in name and infix_dash not in name:
                continue  # not the requested variant token
            try:
                if not entry.is_file():
                    continue
            except OSError:
                continue
            if _ROOT_MODEL_VARIANT_WEIGHT_RE.match(name):
                rels.append(name)  # canonical model / pytorch_model variant weight (single or shard)
            elif _ROOT_MODEL_SHARD_INDEX_RE.match(name):
                # a sharded variant enumerated via its root index (shard files may carry a non-standard
                # name the regex above misses); record the variant weight it enumerates.
                index_probes.add(_index_weight_probe(name, variant))
    except OSError:
        return False
    if _filter_paths(rels, None, ignore_patterns):
        return True
    # A ROOT variant shard INDEX of a kept format proves a readable weight even for non-standard shard
    # names (mirrors _root_model_has_weight). Probe + format-kept are shared with
    # _has_incomplete_variant_root_shards so presence (Invariant A) and completeness (Invariant B) agree.
    return any(_read_format_kept(probe, ignore_patterns) for probe in index_probes)


def _has_diffusers_component_variant_weight(
    snapshot_dir: Path, variant: str, *, ignore_patterns: Any = None
) -> bool:
    """Variant analog of ``_has_diffusers_component_weight``: whether a diffusers *variant* pipeline warm
    is complete (a pipeline's variant weights are component-scoped, not root ``model.<variant>.*``, so a
    root-only check would false-reject a complete variant download). See
    ``_diffusers_component_weights_complete``."""
    return _diffusers_component_weights_complete(
        snapshot_dir, variant = variant, ignore_patterns = ignore_patterns
    )


def _root_model_has_variant_weight(
    snapshot_dir: Path, variant: str, *, ignore_patterns: Any = None
) -> bool:
    """Variant analog of ``_root_model_has_weight``: an UNPATTERNED variant warm holds a ROOT variant
    weight, or -- for a diffusers pipeline -- a component-subfolder variant weight (its weights live in
    subfolders, not root ``model.<variant>.*``, so the root-only check would false-reject them)."""
    try:
        is_diffusers = (snapshot_dir / "model_index.json").is_file()
    except OSError:
        is_diffusers = False
    if is_diffusers:
        return _has_diffusers_component_variant_weight(
            snapshot_dir, variant, ignore_patterns = ignore_patterns
        )
    return _root_has_variant_weight(snapshot_dir, variant, ignore_patterns = ignore_patterns)


# Interchangeable exact weight names collapse to one equivalence group: the either-format pair
# ``["pytorch_model.bin", "model.safetensors"]`` (and the variant pair) is satisfied by ANY one, since HF
# allow patterns are ALTERNATIVES over the repo. Distinct logical weights (base AND adapter, a different
# variant) stay separate groups (each required).
_EITHER_FORMAT_WEIGHT_RE = re.compile(
    r"^(model|pytorch_model|adapter_model)(?:\.([^.]+))?\.(?:safetensors|bin)$"
)


def _exact_weight_logical(base: str) -> Any:
    """Equivalence key for an EXACT-named weight so either-format alternatives share a group:
    ``model.safetensors`` / ``pytorch_model.bin`` -> ``("root_model", None)``; same variant in both
    formats -> ``("root_model", "<variant>")``; ``adapter_model.*`` -> ``("adapter_model", ...)``. A
    non-weight / sharded name maps to itself (still required individually)."""
    m = _EITHER_FORMAT_WEIGHT_RE.match(base)
    if m is None:
        return base
    stem, variant = m.group(1), m.group(2)
    logical = "adapter_model" if stem == "adapter_model" else "root_model"
    return (logical, variant)


def _requested_exact_files_present_grouped(
    snapshot_dir: Path, *, allow_patterns: Any, ignore_patterns: Any,
) -> bool:
    """True unless an EXACT-named requested file is missing. Interchangeable weights need any one; distinct
    logical files (base AND adapter, a tokenizer file) each. A glob / unpatterned request is trivially
    satisfied here."""
    allow = _as_pattern_list(allow_patterns)
    ignore = _as_pattern_list(ignore_patterns)
    if not allow or any(not isinstance(p, str) or _has_glob(p) for p in allow):
        return True
    requested = _filter_paths(allow, None, ignore)
    if not requested:
        return True  # ignore filter dropped every named file -> nothing to require
    try:
        present = {
            entry.relative_to(snapshot_dir).as_posix()
            for entry in snapshot_dir.rglob("*")
            if entry.is_file()
        }
    except OSError:
        return True  # cannot enumerate -> do not reject on an unreadable dir
    groups: "dict[tuple[str, Any], list[str]]" = {}
    for rel in requested:
        parent, base = rel.rsplit("/", 1) if "/" in rel else ("", rel)
        logical = _exact_weight_logical(base)
        groups.setdefault((parent, logical), []).append(rel)
    return all(
        any(candidate in present for candidate in candidates) for candidates in groups.values()
    )


def _has_selected_weight(
    snapshot_dir: Path, *, allow_patterns: Any, ignore_patterns: Any,
) -> bool:
    """True if a loadable weight the request SELECTS (allow / ignore filtered) is present, so a stale
    out-of-scope weight does not satisfy a patterned request."""
    weights: list = []
    try:
        for entry in snapshot_dir.rglob("*"):
            if not _is_loadable_weight_file(entry.name):
                continue
            try:
                if entry.is_file():
                    weights.append(entry.relative_to(snapshot_dir).as_posix())
            except (OSError, ValueError):
                continue
    except OSError:
        return False
    return bool(_filter_paths(weights, allow_patterns, ignore_patterns))


def _has_selected_variant_weight(
    snapshot_dir: Path, *, allow_patterns: Any, ignore_patterns: Any, variant: str,
) -> bool:
    """True if a SELECTED loadable weight carrying the *variant* token is present. Combines the request's
    allow / ignore scope with the variant infix check, so a patterned variant load whose partial kept
    only the canonical weight is retried over HTTP (else it fetches the variant over un-killable Xet)."""
    infix_dot = f".{variant}."
    infix_dash = f".{variant}-"
    weights: list = []
    try:
        for entry in snapshot_dir.rglob("*"):
            name = entry.name
            if not _is_loadable_weight_file(name):
                continue
            if infix_dot not in name and infix_dash not in name:
                continue
            try:
                if entry.is_file():
                    weights.append(entry.relative_to(snapshot_dir).as_posix())
            except (OSError, ValueError):
                continue
    except OSError:
        return False
    return bool(_filter_paths(weights, allow_patterns, ignore_patterns))


def _patterns_are_exact_names(patterns: Any) -> bool:
    """True only for a non-empty allow list of EXACT filenames (no ``None`` / glob / trailing-slash dir).
    Only such a request is locally provable complete; ``None`` / a glob needs the Hub manifest."""
    patterns = _as_pattern_list(patterns)
    if patterns is None:
        return False
    if not patterns:
        return True  # selects nothing -> nothing to fetch
    return all(isinstance(p, str) and not _has_glob(p) for p in patterns)


def _request_selects_canonical_root_shards(allow_patterns: Any, ignore_patterns: Any) -> bool:
    """Whether the allow / ignore filter keeps a canonical ROOT shard name. When False, an incomplete
    canonical root shard set is OUT of scope (a leftover a patterned adapter / gguf / subfolder load never
    reads), so the shard-completeness gate must NOT reject on it, else a complete patterned download is
    failed into a DownloadStallError."""
    probes = ["model-00001-of-00002.safetensors", "pytorch_model-00001-of-00002.bin"]
    return bool(_filter_paths(probes, allow_patterns, ignore_patterns))


def _request_selects_root_variant_weight(
    allow_patterns: Any, ignore_patterns: Any, variant: str,
) -> bool:
    """Whether the allow / ignore filter keeps a ROOT variant weight name. When False, a stale incomplete
    root variant shard set is OUT of scope (e.g. a subfolder request whose variant weights live under
    ``unet/``), so the ROOT variant-shard gate must not reject on it, else a complete in-scope variant
    download is failed."""
    probes = [
        f"model.{variant}.safetensors", f"model.{variant}-00001-of-00002.safetensors",
        f"pytorch_model.{variant}.bin", f"pytorch_model.{variant}-00001-of-00002.bin",
    ]
    return bool(_filter_paths(probes, allow_patterns, ignore_patterns))


def _cache_can_skip_download(
    snapshot_dir: Path, *, repo_type: str, allow_patterns: Any, ignore_patterns: Any,
    variant: Optional[str] = None,
) -> bool:
    """PRE-download: whether a cached snapshot is complete enough to skip the protective child. STRICT --
    a false True lets the load fetch a missing weight over un-killable Xet (the hang).

    Weight-bearing model request: only the conservative canonical gate (``snapshot_dir_is_complete``)
    skips; anything uncertain (diffusers, variants, patterns, sharded-without-index) spawns the child. A
    weightless / non-model request has no weight to hang on but is locally provable complete only when it
    names EXACT files (an intact exact-named subset short-circuits; unpatterned / glob defers)."""
    if repo_type in (None, "model") and request_can_include_weights(allow_patterns, ignore_patterns):
        # A variant load reads variant-named weights the canonical gate does not check, so a
        # canonical-only cache would fetch the variant over un-killable Xet. Defer to the child.
        if variant:
            return False
        # A sentence-transformers multi-module model reads a weight-bearing subfolder module (e.g.
        # 2_Dense) that the canonical ROOT gate does not check; a partial cache holding the root weight
        # but missing that subfolder weight would fetch it over un-killable Xet, so defer to the child.
        if _sentence_transformers_subfolder_incomplete(
            snapshot_dir, prefer_safetensors = True, ignore_patterns = ignore_patterns, strict = True
        ):
            return False
        # A default load probes model.safetensors before pytorch_model.bin, so a bin-only cache for a
        # repo that also publishes safetensors (unprovable locally) would fetch the safetensors over Xet.
        # prefer_safetensors defers it; a use_safetensors=False request still fast-paths its bin cache.
        return snapshot_dir_is_complete(
            snapshot_dir, allow_patterns = allow_patterns, ignore_patterns = ignore_patterns,
            prefer_safetensors = True,
        )
    # Weightless / non-model: skip only for an intact exact-named subset; None / glob defers to the child.
    if not _patterns_are_exact_names(allow_patterns):
        return False
    return _intact_subset(
        snapshot_dir, repo_type = repo_type, allow_patterns = allow_patterns,
        ignore_patterns = ignore_patterns,
    )


def _has_readable_weight(
    snapshot_dir: Path, *, allow_patterns: Any, ignore_patterns: Any, variant: Optional[str],
) -> bool:
    """Invariant A (presence): a weight the in-process load will READ is present, ignore filter ALWAYS
    applied and scope matched to the request:

    - variant + UNPATTERNED -> a ROOT variant weight;
    - variant + PATTERNED   -> a SELECTED variant weight;
    - plain  + UNPATTERNED  -> a ROOT (or diffusers-component) weight, NOT a stray subfolder checkpoint;
    - plain  + PATTERNED    -> a SELECTED weight.

    A partial that kept only the ignored format does not count -> retried over HTTP."""
    if variant:
        if allow_patterns is None:
            return _root_model_has_variant_weight(
                snapshot_dir, variant, ignore_patterns = ignore_patterns
            )
        return _has_selected_variant_weight(
            snapshot_dir, allow_patterns = allow_patterns,
            ignore_patterns = ignore_patterns, variant = variant,
        )
    if allow_patterns is None:
        return _root_model_has_weight(snapshot_dir, ignore_patterns = ignore_patterns)
    return _has_selected_weight(
        snapshot_dir, allow_patterns = allow_patterns, ignore_patterns = ignore_patterns
    )


def _readable_shard_set_incomplete(
    snapshot_dir: Path, *, allow_patterns: Any, ignore_patterns: Any, variant: Optional[str],
) -> bool:
    """Invariant B (shard completeness): an IN-SCOPE shard set the load reads is incomplete (index present
    with a shard missing, or a lone numbered shard without its index) and must be retried. ALWAYS scoped
    to what the request selects, so a co-resident stale shard set the load never reads does not
    false-reject a complete download:

    - variant: ROOT variant-shard check (NON-diffusers) for UNPATTERNED, or a PATTERNED request selecting
      a ROOT variant weight; a subfolder-scoped variant request does not root-check.
    - plain: canonical-root-shard check (NON-diffusers) for UNPATTERNED, or a GLOBBED request selecting
      canonical root shards; an exact-named subset / out-of-scope request does not.
    - non-root: a PATTERNED request also checks any SELECTED shard index the root checks miss (a sharded
      adapter, a component subfolder) via ``_selected_shard_index_incomplete``.
    - diffusers: a pipeline reads COMPONENT subfolders, NOT root model shards, so root checks are SKIPPED;
      its component shard sets go through ``_diffusers_component_shards_incomplete`` (unpatterned) /
      ``_selected_shard_index_incomplete`` (patterned).

    The ignore filter is threaded through so completeness is judged for the FORMAT the load reads."""
    try:
        is_diffusers = (snapshot_dir / "model_index.json").is_file()
    except OSError:
        is_diffusers = False
    if _patterns_are_exact_names(allow_patterns):
        # An exact-named subset defers to the exact-file presence check: the load reads exactly the named
        # shard(s), so a lone exact shard is not judged against its unrequested index (else false-reject).
        return False
    if variant:
        if not is_diffusers and (
            allow_patterns is None
            or _request_selects_root_variant_weight(allow_patterns, ignore_patterns, variant)
        ):
            # Only a non-diffusers root variant load runs the root-shard check (a diffusers pipeline's
            # variant weights are component-scoped, handled below).
            if _has_incomplete_variant_root_shards(
                snapshot_dir, variant, ignore_patterns = ignore_patterns
            ):
                return True
        if allow_patterns is not None:
            if _selected_shard_index_incomplete(
                snapshot_dir, allow_patterns = allow_patterns,
                ignore_patterns = ignore_patterns, variant = variant,
            ):
                return True
        elif is_diffusers and _diffusers_component_shards_incomplete(
            snapshot_dir, variant = variant, ignore_patterns = ignore_patterns
        ):
            # UNPATTERNED variant diffusers warm: a component variant shard index is incomplete (the root
            # variant check above only covers root model.<variant> shards).
            return True
        return False
    if allow_patterns is None:
        if not is_diffusers and _has_incomplete_canonical_root_shards(
            snapshot_dir, ignore_patterns = ignore_patterns
        ):
            # non-diffusers root model load (a diffusers stale root index is handled by the component
            # check below).
            return True
        if is_diffusers and _diffusers_component_shards_incomplete(
            snapshot_dir, variant = None, ignore_patterns = ignore_patterns
        ):
            # UNPATTERNED plain diffusers warm: a component shard index missing a shard is not covered by
            # the canonical ROOT-shard check.
            return True
        return False
    if not is_diffusers and _request_selects_canonical_root_shards(
        allow_patterns, ignore_patterns
    ) and _has_incomplete_canonical_root_shards(snapshot_dir, ignore_patterns = ignore_patterns):
        # non-diffusers only: a diffusers pipeline never reads root model shards (its component sets are
        # checked below), so a stale root index must not reject it.
        return True
    return _selected_shard_index_incomplete(
        snapshot_dir, allow_patterns = allow_patterns,
        ignore_patterns = ignore_patterns, variant = None,
    )


def _selected_readable_weight_complete(
    snapshot_dir: Path, *, allow_patterns: Any, ignore_patterns: Any, variant: Optional[str],
) -> bool:
    """Weight-bearing MODEL acceptance check: the weight the load will READ is present (Invariant A) AND
    its in-scope shard set is complete (Invariant B). Both apply the ignore filter and match scope
    uniformly, so a co-resident out-of-scope / ignored-format partial neither masks an incomplete weight
    (a silent Xet hang) nor false-rejects a complete download (a spurious ``DownloadStallError``)."""
    if not _has_readable_weight(
        snapshot_dir, allow_patterns = allow_patterns,
        ignore_patterns = ignore_patterns, variant = variant,
    ):
        return False
    if _readable_shard_set_incomplete(
        snapshot_dir, allow_patterns = allow_patterns,
        ignore_patterns = ignore_patterns, variant = variant,
    ):
        return False
    return True


def _download_result_usable(
    snapshot_dir: Path, *, repo_type: str, allow_patterns: Any, ignore_patterns: Any,
    variant: Optional[str] = None,
) -> bool:
    """POST-download: whether the child's result is usable or should be retried over HTTP.
    snapshot_download already did the authoritative manifest compare, so accept unless there is POSITIVE
    breakage evidence; LENIENT otherwise so a good download is never looped into a ``DownloadStallError``.
    A transient connection error during the child's metadata call makes ``snapshot_download`` silently
    return a stale / partial cache, so the checks apply the request's filters to the weight the load
    reads. Breakage:

    - A dangling REQUESTED symlink (a missing / still-``.incomplete`` blob).
    - A missing EXACT-named requested file (grouped by weight equivalence; globs stay lenient).
    - A weight-bearing MODEL request whose READABLE weight is absent or incomplete (delegated to
      ``_selected_readable_weight_complete``)."""
    if snapshot_has_requested_broken_symlinks(
        snapshot_dir, allow_patterns = allow_patterns, ignore_patterns = ignore_patterns,
        repo_type = repo_type,
    ):
        return False
    if not _requested_exact_files_present_grouped(
        snapshot_dir, allow_patterns = allow_patterns, ignore_patterns = ignore_patterns
    ):
        return False
    if repo_type in (None, "model") and request_can_include_weights(allow_patterns, ignore_patterns):
        if not _selected_readable_weight_complete(
            snapshot_dir, allow_patterns = allow_patterns,
            ignore_patterns = ignore_patterns, variant = variant,
        ):
            return False
        # A known weight-bearing sentence-transformers subfolder module (e.g. 2_Dense) missing from a
        # stale partial the child handed back is fetched in-process over un-killable Xet; reject so it
        # retries over HTTP. Lenient (strict=False): only a KNOWN weighted module rejects, so an unknown
        # weightless module cannot false-reject a finished download.
        if _sentence_transformers_subfolder_incomplete(
            snapshot_dir, prefer_safetensors = False, ignore_patterns = ignore_patterns, strict = False
        ):
            return False
    return True


def _snapshot_payload_incomplete(
    payload: Any, *, repo_type: str, allow_patterns: Any, ignore_patterns: Any,
    variant: Optional[str] = None,
) -> bool:
    """True when a snapshot download returned a real directory not usable for the request (see
    ``_download_result_usable``). Guarded to an existing dir, so a mocked / non-path payload (tests) is
    trusted; production always returns a real snapshot dir."""
    try:
        path = Path(payload)
    except (TypeError, ValueError, OSError):
        return False  # non-path payload (test sentinel) or invalid path -> trust it
    try:
        if not path.is_dir():
            return False
    except OSError:
        return False
    return not _download_result_usable(
        path, repo_type = repo_type, allow_patterns = allow_patterns,
        ignore_patterns = ignore_patterns, variant = variant,
    )


def _wait_before_http_retry(cancel_event: Optional[threading.Event]) -> None:
    """Back off between HTTP children so a CDN shedding load is not hit again in the same instant.

    Interruptible: a cancel arriving during the wait raises immediately rather than spending another
    child on a download the caller has already abandoned.
    """
    delay = _http_retry_backoff()
    if cancel_event is None:
        time.sleep(delay)
        return
    if cancel_event.wait(delay):
        raise RuntimeError("Cancelled")


def _download_with_xet_fallback(
    *,
    repo_id: str,
    label: str,
    kind: str,
    params: dict,
    token: Optional[str],
    repo_type: str,
    cancel_event: Optional[threading.Event],
    stall_timeout: Optional[float],
    interval: Optional[float],
    grace_period: float,
    on_status: Optional[Callable[[str], None]],
    prepare_for_http_fn: Optional[Callable[[str, str], None]],
    variant: Optional[str] = None,
) -> str:
    """Shared transport ladder: Xet primary, HTTP last. Returns the local path.

    Xet gets ``xet_attempts()`` children (2 by default) before the transport changes, spent only on
    a DATA-phase stall; every other Xet failure flips straight to HTTP. HTTP is the last rung and is
    never retried back to Xet, but it gets ``http_attempts()`` children of its own (2 by default) on a
    transient failure or a crash, because the Xet bridge CDN serves Xet-backed blobs over plain HTTP
    too and a degraded CDN therefore fails BOTH rungs. A stall on HTTP still raises on the first
    verdict. Bounded: each iteration returns, raises, spends one Xet attempt, spends one HTTP attempt,
    or flips to HTTP.
    """
    if cancel_event is not None and cancel_event.is_set():
        raise RuntimeError("Cancelled")

    cache_dir = params.get("cache_dir")
    # Read xet_force_disabled() under the lock a CONCURRENT download briefly sets HF_HUB_DISABLE_XET
    # under (around its spawn), so this download cannot observe the other's child-only value and wrongly
    # force itself onto HTTP from the start.
    with _SPAWN_ENV_LOCK:
        disable_xet = xet_force_disabled()
    # WHY Xet is off matters on the way out: a user-level disable is an env var the caller's
    # in-process fallback inherits, while the health demotion below is internal to this module and
    # leaves that fallback with Xet still ENABLED. See the terminal unknown-error wrap.
    xet_disabled_by_user = disable_xet

    # Skip a doomed Xet attempt on a machine already known to be bad at it (too little RAM,
    # unreachable CAS, recent failures): the ladder still recovers, but the user would pay the full
    # stalled attempt on every download.
    if not disable_xet:
        health = _xet_health_or_none()
        if health is not None and not health.use_xet:
            logger.info("Starting '%s' on HTTP instead of Xet: %s", label, health.reason)
            _safe_status(on_status, f"{label}: using HTTP ({health.reason})")
            disable_xet = True
    started_on_xet = not disable_xet
    # Xet children this download may spend before HTTP, and how many it has spent.
    xet_budget = xet_attempts() if started_on_xet else 0
    xet_used = 0
    # HTTP children this download may spend, and how many it has spent.
    http_budget = http_attempts()
    http_used = 0
    # The caller's own force_download, handed back once the partial that forced a clean re-download
    # is provably gone.
    caller_force_download = params.get("force_download", False)
    forced_clean_redownload = False
    # The Xet -> HTTP purge runs at the TRANSITION only: repeating it per HTTP child would spare the
    # partial that child just wrote (younger than active_grace), forcing force_download so every
    # retry restarts from zero instead of resuming.
    http_prepared = False
    # Health is reported ONCE per logical download, not once per child: the tracker demotes a machine
    # for 24h after two CONSECUTIVE failures, so charging both attempts would let one bad download
    # pin it, against the "one is noise, two is a pattern" rule the tracker is built on.
    pending_xet_failure: Optional[str] = None
    # Whether that held reason still needs proof: a STALL stands on its own and is charged whichever
    # door the ladder leaves by, but a fault or a crash does not, since a degraded CDN fails both
    # rungs and only HTTP finishing what Xet could not shows the Xet path alone was broken.
    pending_needs_http_success = False

    def _flush_pending_failure() -> None:
        """Report a deferred Xet failure on the way out of the ladder (exactly once)."""
        nonlocal pending_xet_failure
        if pending_xet_failure is not None:
            _record_xet_outcome(False, pending_xet_failure)
            pending_xet_failure = None

    def _hold_unproven_xet_failure(reason: str) -> None:
        """Hold a fault / crash pending an HTTP rescue, WITHOUT displacing a stall already held.

        There is one reason slot, and a stall outranks a fault: a stall was proven by the watchdog on
        this machine, whereas a fault is only evidence once HTTP shows the network was fine. Letting
        a fault overwrite a stall also flips ``pending_needs_http_success`` to True, so a later
        both-rungs-failed exit would drop the stall as well and the machine would never be charged
        for it. Reachable exactly as the degraded CDN this ladder targets: Xet child 1 stalls, child
        2 raises the CAS fault, HTTP then fails too.
        """
        nonlocal pending_xet_failure, pending_needs_http_success
        if pending_xet_failure is None:
            pending_xet_failure = _xet_failure_reason(reason)
            pending_needs_http_success = True

    while True:
        if disable_xet:
            http_used += 1
        else:
            xet_used += 1

        if disable_xet and not http_prepared:
            http_prepared = True
            # Purge a non-HTTP partial first (an HTTP resume over a sparse Xet/hf_transfer partial
            # silently corrupts the blob), scoped to the stalled child's own partials so a same-repo
            # sibling is spared. An injected (Unsloth) hook keeps the plain (repo_type, repo_id) signature.
            owned_incomplete = params.pop("_owned_incomplete_blobs", None)
            try:
                if prepare_for_http_fn is None:
                    # This grace asks whether a partial belongs to a LIVE sibling, not whether OUR
                    # child stalled, so it stays patient even though the Xet stall trip is 30s: a
                    # 30s grace would delete a slow-but-healthy peer's partial mid-write.
                    _default_prepare_for_http(
                        repo_type, repo_id, cache_dir = cache_dir,
                        active_grace = max(stall_timeout or 0.0, DEFAULT_HTTP_STALL_TIMEOUT),
                        owned_incomplete_blobs = owned_incomplete,
                    )
                else:
                    prepare_for_http_fn(repo_type, repo_id)
            except Exception as e:
                logger.debug("prepare_for_http failed for %s: %s", repo_id, e)
            # An unsafe partial that could not be cleared (locked / permission) would corrupt the blob on
            # an HTTP resume: force a clean re-download instead.
            if has_active_incomplete_blobs(repo_type, repo_id, cache_dir = cache_dir):
                logger.warning(
                    "Unsafe partial for '%s' could not be cleared; forcing a clean "
                    "HTTP re-download instead of an unsafe resume.", label
                )
                params = {**params, "force_download": True}
                forced_clean_redownload = True
        elif disable_xet:
            # Re-read before EVERY later HTTP child, in both directions: a concurrent Xet downloader
            # can create a partial under the same blob name after a release (typically while this
            # child waits on the blob lock), and resuming it unforced finalizes a corrupt blob.
            #
            # Release only on NO *.incomplete at all. "One HTTP child has run" is not proof: hub
            # unlinks the .incomplete only after the HEAD/metadata call, so a child that died on a
            # 5xx there -- the degraded CDN this ladder exists for -- leaves the Xet partial intact.
            #
            # ABSENCE is the only evidence accepted. Judging a surviving partial to be a safe prefix
            # was tried three ways and each released the guard on a real filesystem: the NAME cannot
            # tell a sparse Xet partial from the resumable one hub rewrites at the same path, the
            # INODE is unstable on overlayfs / FUSE and reused after an unlink, and ALLOCATION
            # metadata reports XFS unwritten extents as fully allocated. The cost is that a partial
            # the forced child itself wrote also holds the latch, so the remaining retries
            # re-download rather than resume. That is bandwidth; the alternative was the blob.
            present = _incomplete_partial_names(repo_type, repo_id, cache_dir)
            if forced_clean_redownload:
                if present is not None and not present:
                    forced_clean_redownload = False
                    params = {**params, "force_download": caller_force_download}
                else:
                    logger.debug(
                        "Keeping force_download for '%s': %s",
                        label,
                        "cache not inspectable" if present is None
                        else f"{len(present)} partial(s) still present",
                    )
            elif present:
                # Positive evidence only: an uninspectable cache leaves the guard as it was rather
                # than forcing a clean re-download for no proof.
                logger.warning(
                    "Partial for '%s' appeared after the guard was released; forcing a clean "
                    "HTTP re-download instead of an unsafe resume.", label
                )
                forced_clean_redownload = True
                params = {**params, "force_download": True}

        kind_result, payload = _run_download_attempt(
            repo_id,
            kind = kind,
            params = params,
            token = token,
            repo_type = repo_type,
            disable_xet = disable_xet,
            cancel_event = cancel_event,
            stall_timeout = stall_timeout,
            interval = interval,
            grace_period = grace_period,
            on_status = on_status,
        )

        # An incomplete snapshot rides on "ok" but is a FAILURE, so classify it before the cancel
        # check: it used to run the destructive purge and spend another child after a cancel.
        incomplete_snapshot = kind_result == "ok" and kind == "snapshot" and (
            _snapshot_payload_incomplete(
                payload,
                repo_type = repo_type,
                allow_patterns = params.get("allow_patterns"),
                ignore_patterns = params.get("ignore_patterns"),
                variant = variant,
            )
        )

        # Cancellation wins over every FAILURE verdict, uniformly. Per-branch precedence let a cancel
        # landing on a stall, a deterministic error or an incomplete snapshot report the download's
        # own error, and on a Xet verdict run the destructive purge and spend another child. A
        # genuine success is exempt: the bytes are on disk, so returning them beats discarding them.
        if (
            (kind_result != "ok" or incomplete_snapshot)
            and cancel_event is not None
            and cancel_event.is_set()
        ):
            # The user's decision says nothing about this machine's Xet health.
            pending_xet_failure = None
            raise RuntimeError("Cancelled")

        if kind_result == "ok":
            if incomplete_snapshot:
                # HF can hand back an existing incomplete snapshot dir (offline / timed-out) instead of
                # fetching: never load it in-process. Retry over HTTP, then fail loudly. (Patterned /
                # non-model requests judge their own subset, so a valid weightless snapshot is not
                # rejected.)
                if not disable_xet:
                    logger.warning(
                        "Download for '%s' returned an incomplete snapshot -- "
                        "retrying with HF_HUB_DISABLE_XET=1", label
                    )
                    _safe_status(on_status, f"{label}: incomplete snapshot, retrying over HTTP")
                    # Held pending an HTTP rescue, like the fault and crash branches: a short
                    # snapshot is a transport symptom too, so a CDN bad enough to shorten BOTH rungs
                    # is not evidence against this machine's Xet (two such demote it for 24h).
                    _hold_unproven_xet_failure("Xet returned an incomplete snapshot")
                    disable_xet = True
                    continue
                # Both rungs came back short: an UNPROVEN reason is not evidence against this
                # machine's Xet, but a watchdog-proven stall survives and is still charged.
                if pending_needs_http_success:
                    pending_xet_failure = None
                _flush_pending_failure()
                raise DownloadStallError(
                    f"Download for '{label}' returned an incomplete snapshot even with "
                    f"HF_HUB_DISABLE_XET=1 -- missing files, check your network connection"
                )
            if started_on_xet and not disable_xet:
                # Completed on the transport it started on: this machine can do Xet, so a stall an
                # earlier attempt recovered from is dropped rather than reported.
                pending_xet_failure = None
                _record_xet_outcome(True)
            elif started_on_xet:
                # HTTP finished what Xet could not, so the held failure is now evidence. Charge it.
                _flush_pending_failure()
            return payload  # type: ignore[return-value]
        if kind_result == "cancelled":
            # The user's decision says nothing about this machine's Xet health.
            pending_xet_failure = None
            raise RuntimeError("Cancelled")
        if kind_result == "error":
            # Deterministic failure (auth / not-found / gated / disk-full): the other transport fails
            # identically, and _raise_child_error preserves the original type across the spawn. An
            # earlier STALL is still evidence and is reported before the raise; a held transport
            # fault is not, since the download then succeeded on neither rung.
            if pending_needs_http_success:
                pending_xet_failure = None
            _flush_pending_failure()
            # An UNRECOGNIZED error here leaves as a bare RuntimeError (_raise_child_error cannot
            # rebuild an unknown class), which is not a DownloadStallError -- so the caller logs
            # "continuing with the normal load" and hands a twice-failed transport to the unguarded
            # in-process path: issue #1122 one rung further along. Keep it inside the guard.
            # Scoped by WHY Xet is off, not by whether this ladder used it. pending_needs_http_success
            # left a hole (a PROVEN stall is held with it False); started_on_xet left another (the
            # health tracker can demote a machine to HTTP before the ladder begins, and that demotion
            # is internal, so the caller's in-process fallback still has Xet ENABLED). Only an
            # explicit user disable is left alone: that one is an env var the fallback inherits.
            if disable_xet and not xet_disabled_by_user:
                type_name = payload.split(":", 1)[0].strip() if ":" in (payload or "") else ""
                if _resolve_exception_class(type_name) is None:
                    raise DownloadTransportError(payload)
            _raise_child_error(payload)
        if kind_result == "retryable_error":
            # Transient transport failure (hf_xet CAS fault, 5xx, reset): change transport, then spend
            # the HTTP budget, then surface it as a stall-class error rather than a bare RuntimeError.
            if not disable_xet:
                logger.warning(
                    "Download for '%s' hit a transient Xet transport error -- retrying "
                    "with HF_HUB_DISABLE_XET=1: %s", label, payload
                )
                _safe_status(on_status, f"{label}: transient Xet error, retrying over HTTP")
                # HELD, not recorded: a transient fault only counts against THIS MACHINE's Xet if
                # HTTP then succeeds. A degraded CDN fails both rungs, and charging it here demoted a
                # perfectly good machine to HTTP for 24h after two such downloads.
                _hold_unproven_xet_failure("transient Xet transport error")
                disable_xet = True
                continue
            if http_used < http_budget:
                logger.warning(
                    "Download for '%s' hit a transient error on HTTP -- retrying "
                    "(attempt %d of %d): %s", label, http_used + 1, http_budget, payload
                )
                _safe_status(
                    on_status,
                    f"{label}: transient HTTP error, retrying "
                    f"(attempt {http_used + 1} of {http_budget})",
                )
                # HTTP met the SAME fault, so the incident was shared, not Xet-specific. Dropped here
                # rather than at the terminal exit, or a later HTTP success would flush it and charge
                # Xet for a CDN that had simply recovered. A proven stall still survives.
                if pending_needs_http_success:
                    pending_xet_failure = None
                    pending_needs_http_success = False
                _wait_before_http_retry(cancel_event)
                continue
            # Both rungs met the same transport fault: that is not evidence against this machine's
            # Xet, so an UNPROVEN reason is dropped. A held stall was proven on its own and survives.
            if pending_needs_http_success:
                pending_xet_failure = None
            _flush_pending_failure()
            raise DownloadTransportError(payload)
        if kind_result == "crashed":
            # Process-level crash with no captured exception: HTTP may still succeed, so retry once.
            if not disable_xet:
                logger.warning(
                    "Download process for '%s' crashed without a result -- "
                    "retrying with HF_HUB_DISABLE_XET=1", label
                )
                _safe_status(on_status, f"{label}: download crashed, retrying over HTTP")
                # Held for the same reason as a transient error: only an HTTP rescue proves it was Xet.
                _hold_unproven_xet_failure("Xet download process crashed")
                disable_xet = True
                continue
            if http_used < http_budget:
                logger.warning(
                    "Download process for '%s' crashed on HTTP -- retrying (attempt %d of %d)",
                    label, http_used + 1, http_budget,
                )
                _safe_status(
                    on_status,
                    f"{label}: download crashed, retrying "
                    f"(attempt {http_used + 1} of {http_budget})",
                )
                # HTTP died the same way, so the incident hit both rungs and is not evidence against
                # this machine's Xet. Same rule (and same reason for dropping it here rather than at
                # the terminal exit) as the transient HTTP branch above. A PROVEN stall survives.
                if pending_needs_http_success:
                    pending_xet_failure = None
                    pending_needs_http_success = False
                _wait_before_http_retry(cancel_event)
                continue
            if pending_needs_http_success:
                pending_xet_failure = None
            _flush_pending_failure()
            raise DownloadTransportError(payload)
        # kind_result == "stall"
        if not disable_xet:
            # Another Xet child first, while the budget lasts and the hang looks recoverable. Only a
            # DATA-phase verdict qualifies: retrying a pre-first-byte trip would buy a second full
            # connect_timeout (600s under Studio) before HTTP ever starts. A cancel landing in the
            # stall window must not spawn one more child.
            if (
                xet_used < xet_budget
                and is_data_phase_stall(payload or "")
                and not (cancel_event is not None and cancel_event.is_set())
            ):
                logger.warning(
                    "Download stalled for '%s' -- retrying on Xet (attempt %d of %d)",
                    label, xet_used + 1, xet_budget,
                )
                _safe_status(
                    on_status,
                    f"{label}: Xet stalled, retrying Xet "
                    f"(attempt {xet_used + 1} of {xet_budget})",
                )
                # Held, not recorded: if the next attempt succeeds this stall was noise.
                pending_xet_failure = _xet_failure_reason("Xet download stalled")
                pending_needs_http_success = False
                _purge_owned_partials_for_xet_retry(
                    repo_type, repo_id, cache_dir = cache_dir,
                    owned_incomplete_blobs = params.pop("_owned_incomplete_blobs", None),
                )
                continue
            logger.warning(
                "Download stalled for '%s' -- retrying with HF_HUB_DISABLE_XET=1", label
            )
            # _safe_status: a raising status hook must not abort the retry before disable_xet is set.
            _safe_status(on_status, f"{label}: Xet stalled, retrying over HTTP")
            # Xet phase over: report the earlier deferred stall if there was one, else this one.
            pending_xet_failure = pending_xet_failure or _xet_failure_reason("Xet download stalled")
            _flush_pending_failure()
            disable_xet = True
            continue
        # An HTTP stall says nothing about Xet, but a Xet stall held from an earlier attempt does,
        # and this is the last door out of the ladder.
        if pending_needs_http_success:
            pending_xet_failure = None
        _flush_pending_failure()
        raise DownloadStallError(
            f"Download stalled for '{label}' even with HF_HUB_DISABLE_XET=1 "
            f"-- check your network connection"
        )


def hf_hub_download_with_xet_fallback(
    repo_id: str,
    filename: str,
    token: Optional[str] = None,
    *,
    cancel_event: Optional[threading.Event] = None,
    repo_type: Optional[str] = "model",
    revision: Optional[str] = None,
    cache_dir: Optional[str] = None,
    subfolder: Optional[str] = None,
    force_download: bool = False,
    local_files_only: bool = False,
    stall_timeout: Optional[float] = None,
    interval: Optional[float] = None,
    grace_period: float = DEFAULT_GRACE_PERIOD,
    on_status: Optional[Callable[[str], None]] = None,
    prepare_for_http_fn: Optional[Callable[[str, str], None]] = None,
) -> str:
    """Download a single file with Xet primary and HTTP as the fallback; return the local path.

    Raises ``RuntimeError("Cancelled")`` if *cancel_event* is set, re-raises a deterministic child error
    unchanged, raises ``DownloadStallError`` if BOTH transports stall, and ``DownloadTransportError``
    (a ``DownloadStallError``) once a transient transport fault has exhausted both. Neither is ever
    raised while an untried rung remains. ``local_files_only=True`` resolves from cache in-process with
    no child (HF offline semantics).
    """
    repo_type = repo_type or "model"  # HF treats None as the default model repo.
    # Expand ~ as huggingface_hub does, so the probe and the child resolve to the same location.
    if isinstance(cache_dir, (str, os.PathLike)):
        cache_dir = os.path.expanduser(os.fspath(cache_dir))
    # Honor cancellation before any probe (the short-circuits below bypass the fallback's cancel check).
    if cancel_event is not None and cancel_event.is_set():
        raise RuntimeError("Cancelled")
    # Offline: resolve from cache. HF raises LocalEntryNotFoundError if uncached; let it propagate.
    if local_files_only:
        from huggingface_hub import hf_hub_download

        return hf_hub_download(
            repo_id = repo_id,
            filename = filename,
            subfolder = subfolder,
            token = token,
            repo_type = repo_type,
            revision = revision,
            cache_dir = cache_dir,
            local_files_only = True,
        )
    # Finalized blob already cached: return it with no child (skipped under force_download). A subfolder
    # file is cached under "<subfolder>/<filename>".
    if not force_download:
        try:
            from huggingface_hub import try_to_load_from_cache

            probe_filename = f"{subfolder}/{filename}" if subfolder else filename
            cached = try_to_load_from_cache(
                repo_id, probe_filename, repo_type = repo_type, revision = revision, cache_dir = cache_dir
            )
            if isinstance(cached, str) and os.path.exists(cached):
                return cached
        except Exception as e:
            logger.debug("Cached probe failed for %s/%s: %s", repo_id, filename, e)

    return _download_with_xet_fallback(
        repo_id = repo_id,
        label = f"{repo_id}/{filename}",
        kind = "file",
        params = {
            "repo_id": repo_id,
            "filename": filename,
            "subfolder": subfolder,
            "revision": revision,
            "cache_dir": cache_dir,
            "force_download": force_download,
        },
        token = token,
        repo_type = repo_type,
        cancel_event = cancel_event,
        stall_timeout = stall_timeout,
        interval = interval,
        grace_period = grace_period,
        on_status = on_status,
        prepare_for_http_fn = prepare_for_http_fn,
    )


def snapshot_download_with_xet_fallback(
    repo_id: str,
    *,
    revision: Optional[str] = None,
    token: Optional[str] = None,
    repo_type: Optional[str] = "model",
    cache_dir: Optional[str] = None,
    allow_patterns: Optional[Any] = None,
    ignore_patterns: Optional[Any] = None,
    force_download: bool = False,
    local_files_only: bool = False,
    variant: Optional[str] = None,
    cancel_event: Optional[threading.Event] = None,
    stall_timeout: Optional[float] = None,
    interval: Optional[float] = None,
    grace_period: float = DEFAULT_GRACE_PERIOD,
    on_status: Optional[Callable[[str], None]] = None,
    prepare_for_http_fn: Optional[Callable[[str, str], None]] = None,
) -> str:
    """Download a whole repo snapshot with Xet primary and HTTP as the fallback; return the local
    snapshot dir.

    Raises as ``hf_hub_download_with_xet_fallback`` does; in particular a transient transport fault
    that exhausts both rungs raises ``DownloadTransportError`` rather than a bare ``RuntimeError``, so
    the caller cannot mistake it for "could not pre-download, carry on" and hand a degraded transport
    to the unguarded in-process load this function exists to protect.

    Used by Unsloth's ``from_pretrained`` to warm the cache in a killable child BEFORE the in-process
    load (which then hits a warm cache and cannot hang on a native Xet thread). A fully cached repo
    short-circuits in-process with no child. ``local_files_only=True`` resolves from cache in-process
    (HF offline semantics). ``variant`` forces the child even on a warm canonical cache, since the
    canonical gate cannot prove the variant-named weights present.
    """
    repo_type = repo_type or "model"  # HF treats None as the default model repo.
    # Expand ~ as huggingface_hub does, so the probe and the child resolve to the same location.
    if isinstance(cache_dir, (str, os.PathLike)):
        cache_dir = os.path.expanduser(os.fspath(cache_dir))
    # Honor cancellation before any probe (the short-circuits below bypass the fallback's cancel check).
    if cancel_event is not None and cancel_event.is_set():
        raise RuntimeError("Cancelled")
    # Offline: resolve from cache. HF raises if uncached; let it propagate.
    if local_files_only:
        from huggingface_hub import snapshot_download

        return snapshot_download(
            repo_id = repo_id,
            repo_type = repo_type,
            revision = revision,
            cache_dir = cache_dir,
            allow_patterns = allow_patterns,
            ignore_patterns = ignore_patterns,
            local_files_only = True,
        )
    # Fast path: everything on disk -> resolve in-process (no Xet, no hang). Skipped under force_download.
    if not force_download:
        try:
            from huggingface_hub import snapshot_download

            cached_dir = snapshot_download(
                repo_id = repo_id,
                repo_type = repo_type,
                revision = revision,
                cache_dir = cache_dir,
                allow_patterns = allow_patterns,
                ignore_patterns = ignore_patterns,
                local_files_only = True,
            )
            # local_files_only returns a snapshot dir whenever refs/<rev> + snapshots/<sha> exist, even
            # one left by a prior interrupted / patterned download. Validate the EXACT returned revision
            # dir (scoped to this snapshot, not the whole repo, so an unrelated revision mid-download does
            # not force a needless re-fetch).
            if _cache_can_skip_download(
                Path(cached_dir),
                repo_type = repo_type,
                allow_patterns = allow_patterns,
                ignore_patterns = ignore_patterns,
                variant = variant,
            ):
                return cached_dir
            logger.debug("Cached snapshot for %s is incomplete; downloading.", repo_id)
        except Exception as e:
            logger.debug("Snapshot not fully cached for %s (%s); downloading.", repo_id, e)

    return _download_with_xet_fallback(
        repo_id = repo_id,
        label = repo_id,
        kind = "snapshot",
        params = {
            "repo_id": repo_id,
            "revision": revision,
            "cache_dir": cache_dir,
            "allow_patterns": allow_patterns,
            "ignore_patterns": ignore_patterns,
            "force_download": force_download,
        },
        token = token,
        repo_type = repo_type,
        cancel_event = cancel_event,
        stall_timeout = stall_timeout,
        interval = interval,
        grace_period = grace_period,
        on_status = on_status,
        prepare_for_http_fn = prepare_for_http_fn,
        variant = variant,
    )
