# Unsloth Zoo - Utilities for Unsloth
# Copyright 2023-present Daniel Han-Chen, Michael Han-Chen & the Unsloth team. All rights reserved.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

__all__ = [
    "get_peft_regex",
    "merge_and_overwrite_lora",
    "merge_and_dequantize_lora",
    "SKIP_QUANTIZATION_MODULES",
    "get_lora_layer_modules",
    "requires_grad_for_gradient_checkpointing",
]

import inspect
import torch
import os
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Type, TypeVar, Union
from collections import OrderedDict
import re
from .log import logger
from .empty_model import _get_module_attribute

# Skip some modules sensitive to quantization
SKIP_QUANTIZATION_MODULES = [
    "lm_head",
    "multi_modal_projector",    # Llama 3.2 Vision, Pixtral, Llava
    "merger",                   # Qwen2 VL
    "modality_projection",      # Idefics, SmolVLM
    "router",                   # MoE Router
    "mlp.gate",                 # MoE Router
    "block_sparse_moe.gate",    # MoE Router
    'mamba',
    "audio_tower",              # Gemma3N audio encoder conformer
    "vision_tower",             # Gemma3 vision encoder (SigLIP)
    "vision_embedder",          # multimodal embedders kept in full precision
    "embed_vision",
    "embed_audio",
    "score",                    # *ForSequenceClassification head
    "classifier",               # *ForTokenClassification, *ForImageClassification, BERT-family head
    "qa_outputs",               # *ForQuestionAnswering head
]

def get_peft_regex(
    model,
    finetune_vision_layers     : bool = True,
    finetune_language_layers   : bool = True,
    finetune_attention_modules : bool = True,
    finetune_mlp_modules       : bool = True,
    target_modules             : List[str] = None,
    vision_tags                : List[str] = ["vision", "image", "visual", "patch",],
    language_tags              : List[str] = ["language", "text",],
    attention_tags             : List[str] = ["self_attn", "attention", "attn", "mixer",],
    mlp_tags                   : List[str] = ["mlp", "feed_forward", "ffn", "dense", "mixer",],
    finetune_audio_layers      : bool = False,
) -> str:
    """
    Create a regex pattern to apply LoRA to only select layers of a model.
    """
    # All Unsloth Zoo code licensed under LGPLv3
    if not finetune_vision_layers and not finetune_language_layers and not finetune_audio_layers:
        raise RuntimeError(
            "Unsloth: No layers to finetune - please select to finetune the vision, language and/or audio layers!"
        )
    if not finetune_attention_modules and not finetune_mlp_modules:
        raise RuntimeError(
            "Unsloth: No modules to finetune - please select to finetune the attention and/or the mlp modules!"
        )
    pass

    from collections import Counter
    modules = model.named_modules()
    linear_modules = [name for name, module in modules if isinstance(module, torch.nn.Linear)]

    # Gemma4 ClippableLinear wraps nn.Linear as .linear child -- detect and add those
    try:
        from transformers.models.gemma4.modeling_gemma4 import Gemma4ClippableLinear
        for name, module in model.named_modules():
            if isinstance(module, Gemma4ClippableLinear):
                linear_modules.append(name + ".linear")
    except ImportError:
        pass

    all_linear_modules = Counter(x.rsplit(".")[-1] for x in linear_modules)

    # Isolate lm_head / projection matrices (count == 1)
    if target_modules is None:
        only_linear_modules = []
        projection_modules  = {}
        for j, (proj, count) in enumerate(all_linear_modules.items()):
            if count != 1:
                only_linear_modules.append(proj)
            else:
                projection_modules[proj] = j
        pass
    else:
        assert(type(target_modules) is list)
        only_linear_modules = list(target_modules)
    pass

    regex_model_parts = []
    if finetune_vision_layers:     regex_model_parts += vision_tags
    if finetune_language_layers:   regex_model_parts += language_tags
    regex_components  = []
    if finetune_attention_modules: regex_components  += attention_tags
    if finetune_mlp_modules:       regex_components  += mlp_tags

    regex_model_parts = "|".join(regex_model_parts)
    regex_components  = "|".join(regex_components)

    match_linear_modules = r"(?:" + "|".join(re.escape(x) for x in only_linear_modules) + r")"
    # No trailing ".*?" after the linear-module group: PEFT uses re.fullmatch, so ".*?" would let
    # "...attn.proj_drop" (a Dropout) match ("proj" + ".*?" eating "_drop") -> "Target module
    # Dropout is not supported". LoRA targets are leaf Linears whose names ARE the group entries,
    # so ending at the group keeps every real target and drops same-prefix non-linear modules.
    if regex_model_parts == "":
        # No vision/language model-part selected (e.g. audio-only finetuning):
        # the standard matcher would degenerate into matching every attention/mlp
        # leaf in the model, so make the base inert and rely solely on the
        # dedicated audio branches added below.
        regex_matcher = r"(?!x)x"  # never matches
    else:
        regex_matcher = \
            r".*?(?:"  + regex_model_parts + \
            r").*?(?:" + regex_components + \
            r").*?"    + match_linear_modules

        # Also account for model.layers.0.self_attn/mlp type modules like Qwen
        if finetune_language_layers:
            regex_matcher = r"(?:" + regex_matcher + \
            r")|(?:\bmodel\.layers\.[\d]{1,}\.(?:" + regex_components + \
            r")\.(?:" + match_linear_modules + r"))"
        pass
    pass

    # Gemma 4 / Gemma 3N keep the visual/audio path in flat embedder Linears
    # (embed_vision.embedding_projection, embed_audio.embedding_projection,
    # vision_embedder.patch_dense, vision_tower.patch_embedder.input_proj) and a
    # conformer audio_tower whose ffw_layer_* / lconv1d.linear_* / attention.post
    # leaves carry no attn/mlp component token, so the standard matcher above can
    # never select them. Add dedicated name-anchored branches, gated on the
    # vision/audio flags, scoped to the attention/mlp flags, and -- when an explicit
    # target_modules list is given -- intersected with it. Each branch is appended
    # only if it re.fullmatch-es a Linear in THIS model (matching PEFT's own matcher).
    # Some of these leaf names are NOT Gemma-exclusive: empty_model.py also lists
    # embed_vision.embedding_projection / vision_tower.patch_embedder.input_proj as
    # Mistral3 components, so a name-only match could change a non-Gemma target set.
    # Gate the whole block on the Gemma 4 / Gemma 3N model families (via model_type /
    # architectures) so every other architecture's regex stays byte-identical.
    # Leading ".*?"; no trailing ".*?" (a real Linear leaf terminates the match);
    # "(?:\.linear)?" also covers Gemma4ClippableLinear ".linear" children.
    def _scoped(leaves):
        # Honour an explicit target_modules list when one was provided.
        if target_modules is not None:
            return [x for x in leaves if x in only_linear_modules]
        return leaves

    _config        = getattr(model, "config", None)
    _model_type    = str(getattr(_config, "model_type", "") or "").lower()
    _architectures = " ".join(getattr(_config, "architectures", None) or []).lower()
    _is_gemma_mm   = (
        "gemma4"  in _model_type or "gemma4"  in _architectures or
        "gemma3n" in _model_type or "gemma3n" in _architectures
    )

    def _linear_aware_branches(cores):
        # For each "core" (a regex that, after a leading ".*?", should fullmatch a
        # real Linear's dotted module name), emit a branch matching ONLY the actual
        # nn.Linear -- the bare module and/or the ".linear" child of a
        # Gemma4ClippableLinear wrapper, whichever genuinely exists in this model.
        # On Gemma 4 a projection appears in named_modules() as BOTH the wrapper
        # ("...q_proj", not an nn.Linear) and its inner Linear ("...q_proj.linear").
        # A blanket optional "(?:\.linear)?" would fullmatch the wrapper too, so PEFT
        # would try to adapt the unsupported wrapper / double-process the inner
        # Linear. Deciding per-core against linear_modules (which holds the real
        # Linear names, including the appended ".linear" children) keeps Gemma 3N's
        # bare leaves and Gemma 4's ".linear" children both correct.
        out = []
        for core in cores:
            if any(re.fullmatch(r".*?" + core + r"\.linear", name, flags = re.DOTALL) for name in linear_modules):
                out.append(r"(?:.*?" + core + r"\.linear)")
            if any(re.fullmatch(r".*?" + core, name, flags = re.DOTALL) for name in linear_modules):
                out.append(r"(?:.*?" + core + r")")
        return out

    candidate_branches = []
    if finetune_audio_layers and _is_gemma_mm:
        # conv / *norm leaves are not nn.Linear so they are never candidates. The
        # conformer attention leaves are gated by finetune_attention_modules; the
        # feed-forward / lightweight-conv / subsample / output projections (and the
        # audio projector) are gated by finetune_mlp_modules. A "." is required
        # before each leaf (the "(?:.*\.)?" segment) so e.g. target_modules=["k_proj"]
        # does not also match "...relative_k_proj".
        audio_leaves = []
        if finetune_attention_modules:
            audio_leaves += ["q_proj", "k_proj", "v_proj", "relative_k_proj", "pos_proj", "post"]
        if finetune_mlp_modules:
            audio_leaves += ["ffw_layer_1", "ffw_layer_2", "linear_start", "linear_end",
                             "input_proj_linear", "output_proj"]
        audio_leaves = _scoped(audio_leaves)
        audio_cores = [r"\baudio_tower\.(?:.*\.)?" + re.escape(x) for x in audio_leaves]
        # The audio projector is a feed-forward projection -> gate under the mlp flag.
        if finetune_mlp_modules and _scoped(["embedding_projection"]):
            audio_cores.append(r"\bembed_audio\.embedding_projection")
        candidate_branches += _linear_aware_branches(audio_cores)
    if finetune_vision_layers and finetune_mlp_modules and _is_gemma_mm:
        # The Gemma vision embedders are flat projection / dense Linears -> like the
        # audio projector, gate them under the mlp flag (attention-only stays clean).
        vision_cores = []
        if _scoped(["embedding_projection"]): vision_cores.append(r"\bembed_vision\.embedding_projection")
        if _scoped(["patch_dense"]):          vision_cores.append(r"\bvision_embedder\.patch_dense")
        if _scoped(["input_proj"]):           vision_cores.append(r"\bvision_tower\.patch_embedder\.input_proj")
        candidate_branches += _linear_aware_branches(vision_cores)
    # _linear_aware_branches already only emits branches that fullmatch a real Linear;
    # re-filter for safety / to mirror PEFT's own re.fullmatch matcher exactly.
    extra_branches = [
        branch for branch in candidate_branches
        if any(re.fullmatch(branch, name, flags = re.DOTALL) for name in linear_modules)
    ]
    if extra_branches:
        regex_matcher = r"(?:" + regex_matcher + r")|" + "|".join(extra_branches)
    pass

    # Fallback only when a vision/language model-part was requested but neither the
    # base matcher nor the branches above matched anything (e.g. a VLM whose vision
    # modules are not tagged with vision keywords): drop the model-part requirement.
    # Never broaden for audio-only (regex_model_parts == ""), which would otherwise
    # pull in the whole language stack.
    if regex_model_parts != "":
        check = any(re.search(regex_matcher, name, flags = re.DOTALL) for name in linear_modules)
        if not check:
            regex_matcher = \
                r".*?(?:" + regex_components + \
                r").*?"   + match_linear_modules
    pass

    # Final check to confirm if matches exist
    check = any(re.search(regex_matcher, name, flags = re.DOTALL) for name in linear_modules)
    if not check and target_modules is not None:
        raise RuntimeError(
            f"Unsloth: No layers to finetune? You most likely specified target_modules = {target_modules} incorrectly!"
        )
    elif not check:
        raise RuntimeError(
            f"Unsloth: No layers to finetune for {model.config._name_or_path}. Please file a bug report!"
        )
    pass
    return regex_matcher
pass


def get_lora_layer_modules():
    # All Unsloth Zoo code licensed under LGPLv3
    import peft.tuners.lora
    path = os.path.split(peft.tuners.lora.__file__)[0]
    files = os.listdir(path)

    Linear_LoRA_Layers = []
    for file in files:
        if file == "__init__.py" or not file.endswith(".py"): continue
        item = f"peft.tuners.lora.{file[:-len('.py')]}"
        # Skip submodules whose optional backend (bnb/eetq/awq/...) is missing
        # instead of crashing LoRA-layer discovery.
        try:
            exec(f"import {item}", locals(), globals())
        except (ImportError, OSError, ValueError, AttributeError, TypeError) as exception:
            logger.debug(
                f"Unsloth: Skipping LoRA layers from `{item}` "
                f"(optional backend unavailable): {exception}"
            )
            continue
        modules = dir(eval(item))
        modules = [x for x in modules if x.startswith("Linear") or x.endswith("Linear")]
        if len(modules) == 0: continue
        exec(f"from {item} import ({', '.join(modules)})", locals(), globals())
        Linear_LoRA_Layers += [(eval(x), item, x,) for x in modules]
    pass
    return tuple(Linear_LoRA_Layers)
pass


def requires_grad_for_gradient_checkpointing(model):
    # All Unsloth Zoo code licensed under LGPLv3
    # Enables requires_grad to make gradient checkpointing work on
    # non language models that don't just use .embed_tokens
    def register_other_hooks(name1, name2, module, _hooks):
        old_hooks = eval(f"module.{_hooks}")
        other_hooks = []
        for value in old_hooks.values():
            qualname = getattr(value, "__qualname__", "")
            name     = getattr(value, "__name__", "")
            if name1 in qualname or name2 in qualname: pass
            elif name2 in name or name2 in name: pass
            else: other_hooks.append(value)
        pass
        # Keep none input requires grad hooks
        exec(f"module.{_hooks} = OrderedDict()")
        if _hooks == "_forward_pre_hooks":
            if hasattr(module, "_forward_pre_hooks_with_kwargs"):
                module._forward_pre_hooks_with_kwargs.clear()
        for hook in other_hooks:
            exec(f"module.register{_hooks[:-1]}(hook)")
        pass
    pass

    # Remove all previous forward hooks for gradient checkpointing
    for name, module in model.named_modules():
        if len(module._forward_hooks) != 0:
            register_other_hooks(
                "enable_input_require_grads",
                "make_inputs_require_grad",
                module,
                "_forward_hooks",
            )
        pass
    pass

    # Add post forward hook
    def requires_grad_post_hook(module, input, output):
        type_output = type(output)
        if type_output is torch.Tensor:
            target = output
        else:
            try: # For HF dataclass, try loss or logits
                if hasattr(output, "loss") and output.loss is not None:
                    target = output.loss
                elif hasattr(output, "logits") and output.logits is not None: # RL like GRPO has no loss (no labels)
                    target = output.logits
                elif hasattr(output, "last_hidden_state") and output.last_hidden_state is not None:
                    # Encoder / decoder-style embedding backbones (e.g. Qwen3-Embedding) return a
                    # BaseModelOutputWithPast with only last_hidden_state (no loss/logits) when called
                    # for sentence embeddings. Make it require grad so gradient checkpointing works.
                    # See https://github.com/unslothai/unsloth/issues/5360
                    target = output.last_hidden_state
                else:
                    # Raise while tracing too: is_compiling() is constant folded, so a skip
                    # here is permanent and the region trains with no adapter gradients.
                    raise ValueError("Neither loss, logits, nor last_hidden_state are available for grad post hook.")
            except Exception as e:
                raise RuntimeError(f"Unsloth: Failed to make output require gradients: {e}")
        # Dynamo rejects requires_grad_() only when it would flip the flag, so skipping the
        # no-op keeps fullgraph = True working. Skipping a real flip would break the frozen
        # input embedding this also lands on, losing every checkpointing gradient.
        if torch.compiler.is_compiling() and target.requires_grad: return
        target.requires_grad_(True)
    pass

    def requires_grad_pre_hook(module, args, kwargs):
        # Dynamo cannot trace requires_grad_(), and Gemma 3N compiles a LoRA target
        # (embed_audio.embedding_projection) with fullgraph = True, so it is a hard error.
        # Safe to skip: anything traced here is already downstream of trainable LoRA weights.
        if torch.compiler.is_compiling(): return
        # Try positional args first (normal text models)
        if args:
            first = args[0]
            if type(first) is torch.Tensor:
                if torch.is_floating_point(first):
                    first.requires_grad_(True)
                return
            pass
        pass
        # Kwargs-only path (VLMs like Idefics3, SmolVLM2, Llava, Qwen2VL, etc.):
        # inputs_embeds is universal; hidden_states covers vision encoders;
        # pixel_values covers image inputs.
        for key in ("inputs_embeds", "hidden_states", "pixel_values"):
            tensor = kwargs.get(key)
            if tensor is not None and type(tensor) is torch.Tensor:
                if torch.is_floating_point(tensor):
                    tensor.requires_grad_(True)
                return
            pass
        pass
        # Fallback: scan kwargs for any float tensor
        for key, val in kwargs.items():
            if type(val) is torch.Tensor and torch.is_floating_point(val):
                val.requires_grad_(True)
                return
            pass
        pass
    pass

    def collect_hook_targets():
        hook_targets = OrderedDict()
        fallback_targets = OrderedDict()

        for name, param in model.named_parameters():
            if not param.requires_grad: continue

            name = re.sub(r"\.([\d]{1,})\.", r"[\1].", name)
            name_components = name.split(".")

            if len(name_components) == 0:
                raise RuntimeError("Unsloth: Model has 0 layers?")

            final_where = None
            fallback_name = None
            fallback_module = None

            # Try getting previous parent module
            for j in range(len(name_components)-1, 0, -1):
                name_curr = name_components[j]
                name_pre  = "model." + ".".join(name_components[:j])
                # Disable [\d] since it fails in gradient checkpointing
                if re.search(r"\[[\d]{1,}\]", name_pre): continue
                module = _get_module_attribute(model, ".".join(name_components[:j]))
                fallback_name   = name_pre
                fallback_module = module
                if hasattr(module, "forward"):
                    try: forward = inspect.getsource(module.forward)
                    except: continue

                    # Normal self.language_model(...)
                    if f"self.{name_curr}(" in forward:
                        final_where = j + 1
                        break

                    # Fix self.blocks[0] like in Qwen
                    module_list = re.sub(r"\[[\d]{1,}\]", "", name_curr)
                    if f"in self.{module_list}:" in forward:
                        final_where = j
                        break
                    elif re.search(r"for [^\s]{3,} in self\." + module_list, forward) is not None:
                        # Might have failed finding self.layers: like self.layers[...]:
                        final_where = j
                        break
                    pass
                pass
            pass

            if final_where is None:
                if fallback_module is not None:
                    fallback_targets[fallback_name] = fallback_module
                continue
            pass

            module_name = "model." + ".".join(name_components[:final_where])
            module = _get_module_attribute(model, ".".join(name_components[:final_where]))
            hook_targets[module_name] = module
        pass
        return hook_targets, fallback_targets
    pass

    hook_targets, fallback_targets = collect_hook_targets()
    if len(hook_targets) == 0 and len(fallback_targets) == 0: return

    hook_target_ids = {id(module) for module in hook_targets.values()}
    for fallback_name, fallback_target in fallback_targets.items():
        if id(fallback_target) in hook_target_ids: continue
        logger.info(
            f"Unsloth: Falling back to output gradient hook for `{fallback_name}` "
            f"during gradient checkpointing."
        )
        register_other_hooks(
            "requires_grad_post_hook",
            "requires_grad_post_hook",
            fallback_target,
            "_forward_hooks",
        )
        fallback_target.register_forward_hook(requires_grad_post_hook)
    pass
    if len(hook_targets) == 0: return

    for module_name, module in hook_targets.items():
        logger.info(f"Unsloth: Making `{module_name}` require gradients")

        still_need_patching = True
        # Check if input_embeddings exists
        if hasattr(module, "get_input_embeddings"):
            # Use forward hook after Embedding() is called
            try:
                module = module.get_input_embeddings()
                register_other_hooks(
                    "requires_grad_post_hook",
                    "requires_grad_post_hook",
                    module,
                    "_forward_hooks",
                )
                module.register_forward_hook(requires_grad_post_hook)
                logger.info(f"Unsloth: Registered output gradient hook on `{module_name}` input embeddings.")
                still_need_patching = False
            except Exception as exception:
                logger.warning(
                    f"Unsloth: Failed to register input-embedding hook for `{module_name}`: {exception}. "
                    "Falling back to pre-forward hook."
                )
                still_need_patching = True
        pass

        if still_need_patching:
            # Use forward pre hook before module is called
            register_other_hooks(
                "requires_grad_pre_hook",
                "requires_grad_pre_hook",
                module,
                "_forward_pre_hooks",
            )
            module.register_forward_pre_hook(requires_grad_pre_hook, with_kwargs=True)
            logger.info(f"Unsloth: Registered pre-forward gradient hook on `{module_name}`.")
        pass
    pass
pass

# Unsloth Zoo - Utilities for Unsloth
# Copyright 2023-present Daniel Han-Chen, Michael Han-Chen & the Unsloth team. All rights reserved.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
